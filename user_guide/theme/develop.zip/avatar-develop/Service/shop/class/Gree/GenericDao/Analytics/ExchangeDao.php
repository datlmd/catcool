<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/ExchangeDao.php
 *
 *  @author   Yuji Yamane <Yuji.Yamane@gree.net>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_ExchangeDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var テーブル名 */
    var $_table_name = 'exchange';

    /** @var 主キー。複合キーはarrayハッシュで指定する。*/
    var $_primary_key = 'id';

    /** @var 更新日カラム名 */
    var $_updated_at_column = 'mtime';

    /** @var 登録日カラム名 */
    var $_created_at_column = 'ctime';

    /** @var マスターデータベースの接続文字列 */
    var $_master_dsn = 'gree://master/avatar_analytics';

    /** @var 登録日カラム名 */
    var $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var オートインクリメント*/
    var $_auto_increment = true;

    /** @var フィールド名 */
    var $_field_names = array(
        'id',
        'date',
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'action1',
        'service',
        'action2',
        'exchange_transaction_id',
        'charge',
        'having_point',
        'ctime',
    );

    /**
     * @var クエリ定義。
     */
    var $_queries = array(
        // {{{ 更新系
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    datetime DATETIME NOT NULL,
                    user_id BIGINT(20) UNSIGNED NOT NULL,
                    user_sex TINYINT(4) NOT NULL,
                    user_age TINYINT(4) NOT NULL,
                    phone_carrier TINYINT(4) NOT NULL,
                    action1 VARCHAR(255) NOT NULL,
                    service VARCHAR(16) NOT NULL,
                    action2 VARCHAR(255) NOT NULL,
                    exchange_transaction_id INT UNSIGNED NOT NULL,
                    charge INT UNSIGNED NOT NULL,
                    having_point INT UNSIGNED NOT NULL,
                    mtime TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    ctime DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    KEY datetime (datetime),
                    KEY user_id (user_id),
                    KEY user_sex (user_sex),
                    KEY user_age (user_age),
                    KEY phone_carrier (phone_carrier),
                    KEY action1 (action1),
                    KEY service (service),
                    KEY action2 (action2),
                    KEY exchange_transaction_id (exchange_transaction_id),
                    KEY charge (charge),
                    KEY having_point (having_point)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        // }}}
        // {{{ 参照系
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
    );
    /** #@- */
}
