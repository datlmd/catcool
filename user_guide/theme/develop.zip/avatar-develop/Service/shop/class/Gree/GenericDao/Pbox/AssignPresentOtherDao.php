<?php
/**
 * @package     GREE Avatar
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

class Gree_GenericDao_Pbox_AssignPresentOtherDao extends Gree_GenericDao {
    /** @var table name */
    var $_table_name = 'pbox_assign_present_other';

    /** @var primary key */
    var $_primary_key = 'assign_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_present_box';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_present_box';

    /** @var field names */
    // ※ item_id について
    // avapri_ticket_id 専用 column なので、avapri_ticket_id としてもいいのですが、
    // 今後 gacha ticket やその他 life item もこのツールで一本化する可能性もあると思い、item_id にしました
    var $_field_names = array(
        'assign_id',
        'item_id',
        'item_type',
        'start_date',
        'msg_id',
        'reason',
        'time_setting',
        'status',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY assign_id DESC',
        ),
        'find_all_by_time_setting_and_status'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__  WHERE status = :status AND time_setting <= :time_setting',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE assign_id = :assign_id',
        ),
        // }}}
        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (item_id, item_type, start_date, msg_id, reason, time_setting, status, ctime) VALUES (:item_id, :item_type, :start_date, :msg_id, :reason, :time_setting, :status, NOW())',
            'return_last_insert_id' => true
        ),
        'update_status'          => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE assign_id = :assign_id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `assign_id`     INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `item_id`       INT(10) UNSIGNED NOT NULL,
                    `item_type`     INT(10) UNSIGNED NOT NULL,
                    `start_date`    DATETIME NOT NULL,
                    `msg_id`        INT(10) UNSIGNED NOT NULL,
                    `reason`        VARCHAR(255) NOT NULL,
                    `time_setting`  DATETIME NOT NULL,
                    `status`        TINYINT(4) UNSIGNED NOT NULL,
                    `ctime`         DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime`         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    INDEX (`status`),
                    PRIMARY KEY (`assign_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
