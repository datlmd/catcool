<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
/**
 * Gree_GenericDao_Avapri_User_SealDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_User_SealDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'user_seal';
	/** @var primary key */
    var $_primary_key = array( 'seal_id', 'user_id', 'create_user_id');
    /** @var auto increment */
    var $_auto_increment = false;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'seal_id',
        'user_id',
        'create_user_id',
        'num',
        'book_id',
        'priority',
        'is_open',
        'get_type',
        'state',
        'ctime',
        'mtime'
    );

    var $_queries = array( // ʣ�祭�� 
        // select----------------------
        'find_by_seal_id_and_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE seal_id = :seal_id AND user_id = :user_id AND create_user_id =:create_user_id',
        ),
        'find_by_seal_id_and_user_id_and_book_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE seal_id = :seal_id AND user_id = :user_id AND create_user_id =:create_user_id AND book_id = :book_id',
        ),
        'find_by_user_id_and_open' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND is_open = :is_open AND num > 0',
        ),
        'find_by_user_id_and_open_and_book_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND is_open = :is_open AND num > 0 AND book_id = :book_id',
        ),
        'find_by_my_seal_list' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id = :user_id AND num > 0 ORDER BY ctime DESC',
        ),
        'find_by_user_id_and_create_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id = :create_user_id AND get_type = :get_type AND ctime >= :check_date ',
        ),
            
        'find_by_my_avapri_list' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id AND num > 0 AND book_id = :book_id ORDER BY ctime DESC, seal_id ASC',
        ),
        'find_by_my_avapri_list_and_open' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id AND num > 0 AND is_open = :is_open ORDER BY ctime DESC',
        ),
        'find_by_my_avapri_list_and_open_and_book_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id AND num > 0 AND book_id = :book_id AND is_open = :is_open ORDER BY ctime DESC',
        ),
        'count_my_avapri_list' => array(
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id AND num > 0 AND book_id = :book_id ORDER BY ctime DESC',
        ),
        'count_my_avapri_list_and_open' => array(
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id AND num > 0 AND is_open = :is_open ORDER BY ctime DESC',
        ),
        'count_my_avapri_list_and_open_and_book_id' => array(
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id AND num > 0 AND book_id = :book_id AND is_open = :is_open ORDER BY ctime DESC',
        ),
        'sum_my_avapri_num_book_id' => array(
            'sql' => 'SELECT sum(num) FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id AND book_id = :book_id ORDER BY ctime DESC',
        ),
        'count_my_seal_list' => array(
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id = :user_id AND num > 0 ORDER BY ctime DESC',
        ),
        // for support tool
        'find_by_all_my_avapri_list' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id ORDER BY ctime DESC',
        ),
        'count_by_all_my_avapri_list' => array(
                'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE user_id = :user_id AND create_user_id <> :user_id',
        ),
        // count all(for debug)
        'find_all' => array(
            'sql' => 'SELECT count(*) as cnt FROM __TABLE_NAME__',
        ),
        // update----------------------
        //'update_num_plus' => array(
        //    'sql' => 'INSERT INTO __TABLE_NAME__ (seal_id, user_id, create_user_id, num, ctime) VALUES (:seal_id, :user_id, :create_user_id, 1, NOW()) ON DUPLICATE KEY UPDATE num = num + 1',
        //),
        'update_num_minus' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET num = num - 1 WHERE seal_id = :seal_id AND user_id = :user_id AND create_user_id =:create_user_id AND book_id = :book_id',
        ),
        //'update_state' => array(
        //    'sql' => 'UPDATE __TABLE_NAME__ SET state = :state WHERE seal_id = :seal_id AND user_id = :user_id AND create_user_id =:create_user_id',
        //),
        'update_open_state' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET is_open = :is_open WHERE seal_id = :seal_id AND user_id = :user_id AND create_user_id =:create_user_id',
        ),
        // update num for support tool
        'update_num' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET num = :num WHERE seal_id = :seal_id AND user_id = :user_id AND create_user_id = :create_user_id AND book_id = :book_id',
        ),
        // insert----------------------
        'insert_user_seal' => array(
            'sql' =>  'INSERT INTO __TABLE_NAME__ (seal_id, user_id, create_user_id, num, book_id, priority, is_open, get_type, state, ctime)
                          VALUES (:seal_id, :user_id, :create_user_id, :num, :book_id, :priority, :is_open, :get_type, :state, :create_datetime) ON DUPLICATE KEY UPDATE num = num + :num'
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `seal_id` int(11) unsigned NOT NULL,
                  `user_id` int(11) unsigned NOT NULL,
                  `create_user_id` int(11) unsigned NOT NULL,
                  `num` tinyint(4) unsigned NOT NULL default '0',
                  `book_id` int(11) unsigned NOT NULL default '1',
                  `priority` tinyint(4) unsigned NOT NULL default '0',
                  `is_open` tinyint(4) unsigned NOT NULL default '0',
                  `get_type` tinyint(4) unsigned NOT NULL default '0',
                  `state` tinyint(4) unsigned NOT NULL default '0',
                  `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                  `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  PRIMARY KEY  (`user_id`,`seal_id`,`create_user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'add_primary_key' => array(
            'sql' => 'ALTER TABLE __TABLE_NAME__ DROP primary key, ADD constraint primary key(`user_id`,`seal_id`,`create_user_id`, `book_id`);',
        ),
    );
    
    function _init()
    {
        parent::_init();
        
        require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
    
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
?>
