<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Official_Entry_Create
 */
class Gree_Service_AvatarFeed_Processor_Official_Entry_Create
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;

    /**
     * @return array|void
     *
     * return array has is_success and etnry_id
     *
     * flow is
     *     - check parameter and destination_user_id => _getCreateParams()
     *     - create Entry
     *     - (add Destination)
     *       if $is_create_success && $is_require_additional_destination
     */
    protected function invoke()
    {
        $is_create_success = false;
        $entry_id          = null;

        $create_params = $this->_getCreateParams();

        if ($create_params == false) {
            return array(
                $is_create_success,
                $entry_id
            );
        }
        try {
            $this->mod_appfeed = self::getModule('AppFeed');
            list($is_create_success, $entry_id) = $this->mod_appfeed->createEntry($create_params);
        } catch (Exception $e) {
            $msg     = 'failed official create feed entry.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_OFFICIAL_ENTRY_CREATE;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array(
                $is_create_success,
                $entry_id
            );
        }

        return array(
            $is_create_success,
            $entry_id
        );
    }

    /**
     * @param $category
     * @return array
     *
     * return array has create params
     *
     * $create_params = array(
     *     'content'      => array(
     *          'sender_id'  => $this->_certified_user->my['user_id'],
     *          'entry_type' => 'mood',
     *          'text'       => $text,
     *          'attr'       => array(
     *              'entry_category' => $category,
     *          ),
     *     ),
     *     'destinations' => $destinations,
     * );
     *
     * flow is
     *     - check input value
     *     - check destination
     *     - create input params
     *     - add params of category-specific
     *
     * category-specific(type) is
     *     - change(activity): avatar key
     *     - avapri(activity): avatar key
     */
    public function _getCreateParams()
    {
        $text = '';
        if (isset($this->input_values['text'])) {
            $text = $this->input_values['text'];
        }
        if (isset($this->input_values['entry_category'])) {
            $entry_category = $this->input_values['entry_category'];
        } else {
            $entry_category = 'change_mood';
        }

        $destination_user_id = $this->input_values['destination_user_id'];

        $create_params = array(
            'content'      => array(
                'sender_id'  => $this->_certified_user->my['user_id'],
                'entry_type' => 'mood',
                'text'       => $text,
                'attr'       => array(
                    'entry_category' => $entry_category,
                ),
            ),
            'destinations' => array(
                array(
                    'type'  => 'feed_key',
                    'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' .$destination_user_id
                ),
            ),
        );

        if (isset($this->input_values['avatar_key'])) {
            $create_params['content']['attr']['avatar_key'] = $this->input_values['avatar_key'];
        } else {
            $create_params = false;
        }

        return $create_params;
    }
}
