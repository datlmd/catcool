<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Follow_Import_RandomTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Follow_Import_RandomTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;
    var $module_follow;
    var $enable_user_list;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $registry               = getService('shop')->getRegistry();
        $enable_user_lists      = $registry->getArray('avatar_feed_enable_user_list');
        $this->enable_user_list = $enable_user_lists['dev'];

        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();
        $this->module      = Gree_Service_AvatarFeed_Module::singleton('AppFeed');

        try {
            $this->module->setUserIDtoCtfy(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        try {
            $this->module->setUserIDtoCtfy(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        // initialize follow status
        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_follow->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        try {
            $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1);
            list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
                UNIT_TEST_USER_ID_1,
                100,
                0
            );

            foreach ($following_user_ids as $following_user_id) {
                $this->module_follow->removeFollowingUser($following_user_id['content']['sender_id'], UNIT_TEST_USER_ID_1);
                $this->module_follow->removeFollowedUser(UNIT_TEST_USER_ID_1, $following_user_id['content']['sender_id']);
            }
        } catch (Exception $e) {
        }

        sleep(2);

        list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($following_user_ids));
    }

    /**
     * test1:
     *   case  : not exist stream data
     *   expect: success_import is empty, miss_hit is 0
     *
     * test2:
     *   case  : stream data has same user entry
     *   expect: success_import is empty, miss_hit is 50
     */
    public function test_import_failed()
    {
        // test1
        $add_result_random = $this->avatar_feed->process('follow_import_random', array(), UNIT_TEST_USER_ID_1);
        $this->assertEmpty($add_result_random['success_import']);
        $this->assertEquals(0, $add_result_random['miss_hit']);

        // test2
        $create_count = 0;
        while ($create_count < 300) {
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);

            $this->_createEntry(UNIT_TEST_USER_ID_2, GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);

            $create_count++;
        }

        sleep(4);

        $add_result_random = $this->avatar_feed->process('follow_import_random', array(), UNIT_TEST_USER_ID_1);
        $this->assertEmpty($add_result_random['success_import']);
        $this->assertEquals(50, $add_result_random['miss_hit']);
    }

    public function test_import_success()
    {
        $create_count = 0;
        while ($create_count < 300) {
            $index = mt_rand(0, count($this->enable_user_list) - 1);
            $this->module->setUserIDtoCtfy($this->enable_user_list[$index]);

            $this->_createEntry($this->enable_user_list[$index], GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);

            $create_count++;
        }

        sleep(4);

        list($has_more, $stream_data) = $this->module->getEntriesByFeedKey(
            GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID,
            GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
            300,
            null,
            'batch'
        );
        $this->assertEquals(300, count($stream_data));

        $add_result_rundam = $this->avatar_feed->process('follow_import_random', array(), UNIT_TEST_USER_ID_1);

        sleep(10);

        list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );
        $this->assertEquals(GREE_SERVICE_AVATARFEED_RANDOM_CHECK_USER_NUMBER, count($following_user_ids));
        $following_user_list = array();
        foreach ($following_user_ids as $user) {
            $following_user_list[] = $user['content']['sender_id'];
        }
        $this->assertEquals(GREE_SERVICE_AVATARFEED_RANDOM_CHECK_USER_NUMBER, count(array_unique($following_user_list)));

        list($has_more, $stream_data) = $this->module->getEntriesByFeedKey(
            UNIT_TEST_USER_ID_1,
            GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
            300,
            null,
            'batch'
        );

        $this->assertEquals(GREE_SERVICE_AVATARFEED_RANDOM_CHECK_USER_NUMBER, count($stream_data));

        foreach ($stream_data as $entry) {
            $this->assertTrue(in_array($entry['content']['sender_id'], $following_user_list));
        }
    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_follow_import_random',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}