<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Lounge_Limit_Count
 */
class Gree_Service_AvatarFeed_Processor_Lounge_Limit_Count
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array
     *
     * return
     *   remaining_count
     *   reset_date
     */
    protected function invoke()
    {
        $mod_lounge = self::getModule('Lounge');

        $user_id = $this->input_values['user_id'];

        $ret = array(
            'remaining_count' => $mod_lounge->getRemainingPostCount($user_id),
            'reset_date'      => $mod_lounge->getPostLimitResetDate(),
        );

        return $ret;
    }
}
