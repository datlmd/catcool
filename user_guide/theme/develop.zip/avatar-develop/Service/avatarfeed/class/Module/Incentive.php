<?php

class Gree_Service_AvatarFeed_Module_Incentive
    extends Gree_Service_AvatarFeed_Module_Base
{

    function getPointInfo($user_id, $now_datetime)
    {
        $srv_shop = getService('shop');
        $point_manager = $srv_shop->getPointManager();

        $point_info = array(
            'current'   => 0,
            'by_like'   => 0,
            'by_liked'  => 0,
            'by_lounge' => 0,
            'by_second' => 0,
            'total'     => 0,
        );

        $point_info['current'] = $point_manager->getPointValue($user_id);


        $target_rows = array();
        $limit = GREE_SERVICE_SHOP_POINT_HISTORY_LIST_LIMIT;
        $offset = 0;
        $history_term = 2;

        $is_need_next = true;
        while ($is_need_next) {
            $user_history = $point_manager->getHistory($user_id, $offset, $limit, $history_term);

            if (empty($user_history)) {
                break;
            }

            foreach ($user_history as $row) {
                if ($this->_getDate($now_datetime) == $this->_getDate($row['ctime'])) {
                    $target_rows[] = $row;
                }

                if (strtotime($this->_getDate($now_datetime)) > strtotime($this->_getDate($row['ctime']))) {
                    $is_need_next = false;
                    break;
                }
            }

            $offset = $offset + $limit;
        }
        if (empty($target_rows)) {
            return $point_info;
        }

        foreach ($target_rows as $row) {
            switch ($row['type']) {
                case GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD:
                    $point_info['by_like'] = $row['point'];
                    break;
                case GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED:
                    $point_info['by_liked'] = $row['point'];
                    break;
                //case GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LOUNGE_POST:
                //    $point_info['by_lounge'] = $row['point'];
                //    break;
                //case GREE_SERVICE_SHOP_POINT_RECENT_TYPE_SECOND_AVATAR_CAMPAIGN:
                //    $point_info['by_second'] = $row['point'];
                //    break;
                default:
            }
        }

        $point_info['total'] = $point_info['by_like'] + $point_info['by_liked'] + $point_info['by_lounge'] + $point_info['by_second'];
        return $point_info;
    }

    public function _getDate($datetime)
    {
        $date = new DateTime($datetime);

        return $date->format('Y-m-d');
    }

    public function getPointInfoBorder($user_id, $point_type)
    {
        $srv_shop = getService('shop');
        $point_manager = $srv_shop->getPointManager();
        $recent_mood = $point_manager->getRecentValue(
            $user_id,
            $point_type
        );

        if ($recent_mood == 0) {
            $already_get = false;
        } else {
            $already_get = true;
        }

        return $already_get;
    }
}
