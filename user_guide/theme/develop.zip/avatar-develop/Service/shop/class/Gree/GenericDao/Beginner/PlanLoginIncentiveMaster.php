<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Beginner/PlanLoginIncentiveMaster.php
 * Gree_GenericDao_Beginner_PlanLoginIncentiveMasterDao
 *
 * @package     GREE Avatar
 * @author      ikuko.tamura <z.ikuko.tamura@gree.net>
 */
class Gree_GenericDao_Beginner_PlanLoginIncentiveMasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'plan_login_incentive_master';

    /** @var primary key */
    var $_primary_key = 'login_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'login_id',
        'plan_id',
        'day_num',
        'incentive',
        'expired_day',
        'ctime',
        'mtime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all'         => [
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ],
        'find_by_id'       => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_id = :login_id',
        ],
        'find_by_plan_id_and_day_num' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE plan_id = :plan_id and day_num = :day_num',
        ],
        'find_by_plan_id'       => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE plan_id = :plan_id order by day_num',
        ],
        'find_by_plan_id_and_greater_day_num'       => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE plan_id = :plan_id AND day_num > :day_num ',
        ],
        'find_by_plan_id_and_day_num'       => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE plan_id = :plan_id AND day_num = :day_num ',
        ],
        // }}}

        // {{{ update queries
        'entry'            => [
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (plan_id, day_num, incentive, expired_day, ctime) VALUES (:plan_id, :day_num, :incentive, :expired_day, NOW())',
        ],
        'update'           => [
            'sql' => 'UPDATE __TABLE_NAME__ SET plan_id = :plan_id, day_num = :day_num, incentive = :incentive, expired_day = :expired_day WHERE login_id = :login_id',
        ],
        'update_by_plan_id'           => [
            'sql' => 'UPDATE __TABLE_NAME__ SET day_num = :day_num, incentive = :incentive, expired_day = :expired_day WHERE plan_id = :plan_id',
        ],
        'delete'           => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE login_id = :login_id',
        ],
        'delete_by_plan_id_and_day_num' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE plan_id =:plan_id AND day_num = :day_num',
        ],
        'create_table'     => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `login_id` INT unsigned NOT NULL auto_increment,
                  `plan_id` INT unsigned NOT NULL,
                  `day_num` INT unsigned NOT NULL,
                  `incentive` VARCHAR(255) NOT NULL,
                  `expired_day` INT unsigned NOT NULL,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`login_id`),
                  KEY `plan_day_num` (`plan_id`, `day_num`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ],
        // }}}
    ];
}
