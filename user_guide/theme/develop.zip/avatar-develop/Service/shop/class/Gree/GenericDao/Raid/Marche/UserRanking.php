<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserRanking.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Raid_Marche_UserRankingDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'raid_marche_user_ranking';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_raid';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_raid';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'group_id',
        'rank',
        'point',
        'date',
        'received_reward',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ select
        'find_for_ranking' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE date = :date and group_id=:group_id ORDER BY rank',
        ),
        'find_date_to_recent_ranking' => array(
            'sql' => 'SELECT date FROM __TABLE_NAME__ WHERE group_id=:group_id ORDER BY date DESC',
        ),
        'count_ranking' => array(
            'sql' => 'SELECT COUNT(id) as count FROM __TABLE_NAME__ WHERE date = :date and group_id=:group_id',
        ),
        'find_by_user_id_for_reward' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id and date=:date and group_id=:group_id',
        ),
        'update_by_received_reward' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET received_reward=:received_reward WHERE id=:id AND user_id=:user_id',
        ),
        'find_by_user_id_and_date' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and group_id = :group_id and date = :date',
        ),
        // }}}
        // {{{ support tool
        'find_all_date' => array(
            'sql' => 'SELECT date FROM __TABLE_NAME__ WHERE group_id=:group_id GROUP BY date',
        ),
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id and group_id=:group_id',
        ),
        // }}}
        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                int(11) unsigned NOT NULL auto_increment,
                    `user_id`           int(11) unsigned NOT NULL default '0',
                    `group_id`          int(11) unsigned NOT NULL default '0',
                    `rank`              int(11) unsigned NOT NULL default '0',
                    `point`             int(11) unsigned NOT NULL default '0',
                    `date`              int(11) unsigned NOT NULL default '0',
                    `received_reward`   tinyint(1) unsigned NOT NULL default '0',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    KEY `date` (`date`, `rank`, `group_id`),
                    UNIQUE KEY `user_id` (`user_id`, `date`, `group_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT  CHARSET=ujis
            ",
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'truncate_table' => array(      // for batch
            'sql' => "TRUNCATE TABLE __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Raid_Marche_UserRankingSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserRanking.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Raid_Marche_UserRankingSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ TABLE_DIVIDE_NUM
    /* �ơ��֥�ʬ��� */
    const TABLE_DIVIDE_NUM = 2;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d";   // event_id
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['event_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, $hint['event_id']);

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
