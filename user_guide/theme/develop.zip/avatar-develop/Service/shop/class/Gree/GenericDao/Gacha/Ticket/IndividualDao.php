<?php
/**
 * Gree_GenericDao_Gacha_Ticket_IndividualDao
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Gacha_Ticket_IndividualDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name    = 'gacha_ticket_individual';

    /** @var primary key */
    var $_primary_key   = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var master dsn */
    var $_master_dsn    = 'gree://master/avatar_gacha_ticket';

    /** @var slave dsn */
    var $_slave_dsn     = 'gree://slave/avatar_gacha_ticket';

    /** @var field names */
    var $_field_names   = array(
        'id',
        'user_id',
        'gacha_id',
        'status',
        'life_user_item_id',
        'token',
        'mtime',
        'ctime',
    );

    /**
     * query definitions
     */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user_gacha_status' => array(
            'sql'   => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND gacha_id = :gacha_id AND status = :status',
        ),
        'find_by_user_gacha_token'  => array(
            'sql'   => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND gacha_id = :gacha_id AND token = :token',
        ),
        'find_by_user_status'       => array(
            'sql'   => 'SELECT *, COUNT(*) as count FROM __TABLE_NAME__ WHERE user_id = :user_id AND status = :status GROUP BY gacha_id',
        ),
        'find_by_user_id'           => array(
            'sql'   => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}

        // {{{ update queries
        'update_status_and_item' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :status AND life_user_item_id = :life_user_item_id WHERE id = :id',
        ),
        'create_table' => array(
            'sql'   => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id                  INT(11)         UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id             INT(11)         UNSIGNED NOT NULL,
                    gacha_id            INT(11)         UNSIGNED NOT NULL,
                    status              TINYINT(2)      NOT NULL DEFAULT "0",
                    life_user_item_id   INT(11)         UNSIGNED,
                    token               VARCHAR(255)    NOT NULL,
                    mtime               TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    ctime               DATETIME        NOT NULL DEFAULT "0000-00-00 00\:00\:00",
                    PRIMARY KEY (id),
                    UNIQUE token (user_id, gacha_id, token)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(
            'sql'   => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    /**
     * initialize farm selector
     *
     * @access  private
     */
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Gacha_Ticket_IndividualFarmSelector();
    }
    // }}}
}

/**
 * Gree_GenericDao_Gacha_Ticket_IndividualFarmSelector
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Gacha_Ticket_IndividualFarmSelector extends Gree_GenericDao_FarmSelector
{
    /** @var int number of table */
    var $_table_nums            = 100;

    /** @var string table number format */
    var $_table_suffix_format   = "_%02d";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        if (empty($hint['user_id'])) {
            $error_msg = "hint is empty. dao = " . get_class($dao) . "];";
            return PEAR::raiseError($error_msg);
        }
        $user_id = $hint['user_id'];
        if ($user_id <= 0) {
            $error_msg = "wrong user id. dao = " . get_class($dao) . "];";
            return PEAR::raiseError($error_msg);
        }

        // get table name
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            $error_msg = "original table name is empty. dao = " . get_class($dao) . "];";
            return PEAR::raiseError($error_msg);
        }

        // add farm to table name
        $farm_no    = (int) (((int) $user_id) % $this->_table_nums);
        $farm       = sprintf($this->_table_suffix_format, $farm_no);
        if (empty($farm)) {
            $error_msg = "farm is blank. user_id = " . $user_id;
            return PEAR::raiseError($error_msg);
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
