<?php
/**
 *
 */
class Gree_Service_Shop_Exception_SystemException
    extends Gree_Service_Shop_Exception
{
}
