<?php
require_once PATH_SRC_CLASS . 'Gree/GenericDao/UserIdFarmSelector.php';

class Gree_GenericDao_Material_User_ItemDao extends Gree_GenericDao
{
    var $_table_name = 'material_user';

    var $_primary_key = array('user_id', 'item_id');

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_studio';

    var $_slave_dsn = 'gree://slave/avatar_studio';

    var $_auto_increment = false;

    var $_field_names = array(
        'user_id',
        'item_id',
        'type',
        'value',
        'mtime',
        'ctime'
    );

    var $_queries = array(

        //Refer queries
        'find_by_user_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY item_id desc",
        ),

        'find_by_user_id_and_item_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and item_id in (:item_ids)",
        ),

        'find_by_user_id_and_type' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and type = :type ORDER BY item_id desc",
        ),

        //Update queries
        'update_item_value' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET value = :value WHERE user_id = :user_id and item_id = :item_id",
        ),

        //Insert queries
        'insert' => array(
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    user_id,
                    item_id,
                    type,
                    value,
                    ctime
                )
                VALUES (
                    :user_id,
                    :item_id,
                    :type,
                    :value,
                    NOW()
                )
            ",
        ),

        //Create queries
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `user_id`    int(11) unsigned NOT NULL,
                    `item_id`    int(11) unsigned NOT NULL,
                    `type`       int(2) unsigned NOT NULL,
                    `value`      int(2) unsigned NOT NULL,
                    `mtime`      timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`      datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`user_id`, `item_id`),
                    KEY `user_item_type` (`user_id`, `type`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
    );

    public function _initFarmSelector()
    {
        $table_nums = GREE_CLI_TABLE_SHARD_NUMBER_USERID;

        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = GREE_CLI_TABLE_SHARD_NUMBER_USERID_DEVELOP;
        }

        $this->_farm_selector = new Gree_GenericDao_UserIdFarmSelector($table_nums);
    }
}
