<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/RankPointSummaryDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-19
 */

/**
 * RankPointSummary form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_RankPointSummaryDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'rank_point_summary';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'status',
        'min_point',
        'max_point',
        'num',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all_and_sort_desc'    => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id'                => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'find_summary_by_point'     => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE min_point <= :search_point AND max_point >= :search_point',
        ),
        'sum_num_by_larger_summary' => array(
            'sql' => 'SELECT SUM(num) as sum_num FROM __TABLE_NAME__ WHERE id > :id',
        ),
        // }}}

        // {{{ update queries
        'decrement_num_by_id'       => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET num = num - 1 WHERE id = :id AND num > 0',
        ),
        'increment_num_by_id'       => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET num = num + 1 WHERE id = :id',
        ),
        'entry'                     => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (status, min_point, max_point, num, ctime) VALUES (:status, :min_point, :max_point, :num, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                    => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status, min_point = :min_point, max_point = :max_point, num = :num WHERE id = :id',
        ),
        'delete'                    => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'              => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `status` TINYINT(3) UNSIGNED NOT NULL,
                    `min_point` INT(11) UNSIGNED NOT NULL,
                    `max_point` INT(11) UNSIGNED NOT NULL,
                    `num` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                    `mtime`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`         DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Osacolo_RankPointSummaryFarmSelector();
    }
}

class Gree_GenericDao_Osacolo_RankPointSummaryFarmSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%02d"; //[osacolo_id]

    function getTableName($dao, $type, $hint)
    {
        if (empty($hint) || !isset($hint['osacolo_id'])) {
            return PEAR::raiseError("hint is empty osacolo_id. dao=" . get_class($dao) . "];");
        }

        $table_suffix = sprintf($this->_table_suffix_format, $hint['osacolo_id']);
        $table_name   = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
}