<?php
/**
 *
 */
class Gree_Service_Shop_Exception_KeyException
    extends Gree_Service_Shop_Exception
{
}
