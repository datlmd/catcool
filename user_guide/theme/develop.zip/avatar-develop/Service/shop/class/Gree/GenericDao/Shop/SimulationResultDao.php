<?php
/**
 *  SimulationResultDao.php
 *
 *  @author     Kanro Kikuchi
 *  @package    GREE
 *  @version    $Id: 
 */
class Gree_GenericDao_Shop_Simulation_ResultDao extends Gree_GenericDao {
    var $_table_name = 'gacha_simulation_result';
    var $_master_dsn = 'gree://master/avatar_gacha';
    var $_slave_dsn = 'gree://slave/avatar_gacha';
    var $_primary_key = ['setting_id', 'item_id', 'type', 'limit'];
    var $_auto_increment = false;
    var $_created_at_column = null;
    var $_updated_at_column = null;
    var $_field_names = [
        'setting_id',
        'item_id',
        'limit',
        'type',
    ];

    var $_queries = [
        'find_by_setting_id_type' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE setting_id=:setting_id AND type=:type'
        ],
        'find_by_setting_id_type_order_by_limit' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE setting_id=:setting_id AND type=:type ORDER BY `limit`'
        ],
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `setting_id`    INT UNSIGNED NOT NULL,
                    `item_id`       INT UNSIGNED NOT NULL,
                    `limit`         INT UNSIGNED NOT NULL DEFAULT '0',
                    `type`          TINYINT unsigned NOT NULL DEFAULT '1',
                    PRIMARY KEY (`setting_id`,`item_id`,`type`,`limit`),
                    KEY `setting_id` (`setting_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            "
        ],
        'insert' => [
            'sql' => "
                INSERT INTO __TABLE_NAME__ (
                    `setting_id`, `item_id`, `limit`, `type`
                ) values (
                    :setting_id, :item_id, :limit, :type
                )
            "
        ],
    ];
}
?>
