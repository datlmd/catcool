<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Lounge_Limit_Increment
 */
class Gree_Service_AvatarFeed_Processor_Lounge_Limit_Increment
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array
     *
     * return
     *   remaining_count
     *   reset_date
     */
    protected function invoke()
    {
        $mod_lounge = self::getModule('Lounge');

        $user_id = $this->input_values['user_id'];

        if ($mod_lounge->getRemainingPostCount($user_id) <= 0) {
            return array(
                'success'         => false,
                'remaining_count' => 0,
                'reset_date'      => $mod_lounge->getPostLimitResetDate(),
            );
        }

        $ret = array(
            'success'         => true,
            'remaining_count' => $mod_lounge->incrementPostCount($user_id),
            'reset_date'      => $mod_lounge->getPostLimitResetDate(),
        );

        return $ret;
    }
}
