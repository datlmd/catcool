<?php

class Gree_GenericDao_PushNotification_TokenDao extends Gree_GenericDao
{
    var $_table_name        = 'push_notification_token';

    var $_primary_key       = 'id';

    var $_auto_increment    = true;

    var $_created_at_column = 'ctime';

    var $_updated_at_column = 'mtime';

    var $_master_dsn        = 'gree://master/avatar_oauth';

    var $_slave_dsn         = 'gree://slave/avatar_oauth';

    var $_field_names       = array(
        'id',
        'user_id',
        'udid',
        'endpoint_token',
        'os_type',
        'ctime',
        'mtime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id             INT(11)      UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id        INT(11)      UNSIGNED NOT NULL,
                    udid           VARCHAR(255) NOT NULL,
                    endpoint_token VARCHAR(255) NOT NULL,
                    os_type        INT(3)       UNSIGNED NOT NULL,
                    ctime          DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    mtime          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    KEY    user_id_index         (user_id),
                    UNIQUE udid_unique           (udid),
                    UNIQUE endpoint_token_unique (endpoint_token)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),

        'insert' => array(
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    user_id,
                    udid,
                    endpoint_token,
                    os_type,
                    ctime
                )
                VALUES (
                    :user_id,
                    :udid,
                    :endpoint_token,
                    :os_type,
                    NOW()
                )
            ",
            'return_last_insert_id' => true,
        ),

        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),

        'find_by_user_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id in (:user_ids)',
        ),

        'find_by_udid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE udid = :udid',
        ),

        'find_by_endpoint_token' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE endpoint_token = :endpoint_token',
        ),

        // for batch
        'find_user_ids' => array(
            'sql' => 'SELECT distinct user_id FROM __TABLE_NAME__ WHERE user_id > :min_user_id order by user_id limit :limit',
        ),

        'update_mtime_by_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET mtime = NOW() WHERE id = :id',
        ),

        'update_endpoint_by_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET mtime = NOW(), endpoint_token = :endpoint_token WHERE id = :id',
        ),

        'delete_by_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
    );
}
