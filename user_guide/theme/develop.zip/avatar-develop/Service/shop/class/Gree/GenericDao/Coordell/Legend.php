<?php
/**
 * Gree_GenericDao_Coordell_LegendDao
 * 
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */

class Gree_GenericDao_Coordell_LegendDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'legend';
    /** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = false;
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_coordell';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_coordell';

    /** @var field names */
    var $_field_names = array(
        'feed_id',
        'item_ids',
        'title',
        'event_id',
        'date',
        'ctime'
    );

    var $_queries = array(
    // --select
        'select_by_event_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id = :event_id ORDER BY date DESC',
        ),
        'select_by_feed_id_and_event_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE feed_id = :feed_id and event_id = :event_id',
        ),
        'count_by_event_id' => array(
            'sql' => 'SELECT count(*) as count FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ),
    // --insert & update
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (feed_id, item_ids, title, event_id, date, ctime) VALUES (:feed_id, :item_ids, :title, :event_id, :date, :ctime)',
        ),
    // --create table 
    // ctime is unixtime
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `feed_id`   INT(10) UNSIGNED NOT NULL,
                `item_ids`  VARCHAR(255) NOT NULL,
                `title`     VARCHAR(255) NOT NULL,
                `event_id`  INT(10) UNSIGNED NOT NULL,
                `date`      INT(10) UNSIGNED NOT NULL,
                `ctime`     DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                PRIMARY KEY  (`feed_id`, `event_id`),
                KEY         (`event_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
    );
}
