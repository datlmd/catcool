<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/DailyFarmSelector.php';

/**
 * Gree_GenericDao_Greeting_DailyDao
 */
class Gree_GenericDao_Greeting_DailyDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'avatar_greeting_daily';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',          // UserID
        'skin',             // ItemID
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_userid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_userid_targetid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND target_id = :target_id',
        ),
        'find_history' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY ctime',
        ),
        'find_history_target' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE target_id = :target_id ORDER BY ctime DESC',
        ),
        'find_history_target_count' => array(
            'sql' => 'SELECT count(*) AS cnt FROM __TABLE_NAME__ WHERE target_id = :target_id',
        ),
        // }}}

        // {{{ update queries
        'entry' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, target_id, item, ctime) VALUES (:user_id, :target_id, :item, NOW())',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `target_id`           INT(10)     UNSIGNED NOT NULL,
                  `item`                VARCHAR(255),
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  UNIQUE (`user_id`, `target_id`),
                  KEY `target_id_idx` (`target_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_DailyFarmSelector();
    }
}
