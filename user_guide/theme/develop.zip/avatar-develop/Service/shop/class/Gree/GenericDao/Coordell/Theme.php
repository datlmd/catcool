<?php
/**
 * Gree_GenericDao_Coordell_ThemeDao
 * 
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */

class Gree_GenericDao_Coordell_ThemeDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'theme';
    /** @var primary key */
    var $_primary_key = 'theme_id';
    /** @var auto increment */
    var $_auto_increment = true;
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_coordell';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_coordell';

    /** @var field names */
    var $_field_names = array(
        'theme_id',
        'user_id',
        'item_ids',
        'state',
        'ctime',
    );

    var $_queries = array(
    // --select
        'find_theme_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE theme_id = :theme_id',
        ),
        'find_recent_theme' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = 1 ORDER BY theme_id DESC',
        ),
        'find_user_last_insert' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY theme_id DESC',
        ),
        'find_theme_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY theme_id DESC',
        ),
        'count_theme_by_user_id' => array(
            'sql' => 'SELECT count(theme_id) as cnt FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'count_total_theme' => array(
            'sql' => 'SELECT count(theme_id) as cnt FROM __TABLE_NAME__ WHERE state = 1',
        ),
        'get_theme_id_by_user_id' => array(
            'sql' => 'SELECT theme_id FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
    // --insert & update
        'insert_theme' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, item_ids, ctime) VALUES (:user_id, :item_ids, :ctime)',
            'return_last_insert_id' => true,
        ),
    // --create table
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `theme_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT(10) UNSIGNED NOT NULL,
                `item_ids` VARCHAR(255) NOT NULL,
                `state`  TINYINT(3) UNSIGNED DEFAULT 1,
                `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                PRIMARY KEY (`theme_id`),
                KEY `user_id` (`user_id`),
                KEY `state` (`state`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Coordell_ThemeFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Coordell_ThemeFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    // var string �ơ��֥�ե������ֹ�ե����ޥå�
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        if (empty($hint)) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾�˥ե�������ɲ�
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['event_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
