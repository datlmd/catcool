<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Beginner/PlanMaster.php
 *
 * Gree_GenericDao_Beginner_PlanMasterDao
 *
 * @package     GREE Avatar
 * @author      ikuko.tamura <z.ikuko.tamura@gree.net>
 */
class Gree_GenericDao_Beginner_PlanMasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'plan_master';

    /** @var primary key */
    var $_primary_key = 'plan_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'plan_id',
        'pack_id',
        'grade',
        'price',
        'incentive',
        'ctime',
        'mtime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all'         => [
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ],
        'find_by_id'       => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE plan_id = :plan_id',
        ],
        'find_by_pack' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE pack_id = :pack_id',
        ],
        'find_by_pack_and_grade' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE pack_id = :pack_id AND grade = :grade',
        ],
        // }}}

        // {{{ update queries
        'entry'            => [
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (pack_id, grade, price, incentive, ctime) VALUES (:pack_id, :grade, :price, :incentive, NOW())',
        ],
        'update'           => [
            'sql' => 'UPDATE __TABLE_NAME__ SET pack_id = :pack_id, grade = :grade, price = :price, incentive = :incentive WHERE plan_id = :plan_id',
        ],
        'delete'           => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE plan_id = :plan_id',
        ],
        'create_table'     => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `plan_id` INT unsigned NOT NULL auto_increment,
                  `pack_id` INT unsigned NOT NULL,
                  `grade` INT unsigned NOT NULL,
                  `price` INT unsigned NOT NULL,
                  `incentive` VARCHAR(255) NOT NULL,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`plan_id`),
                  KEY `pack_grade` (`pack_id`, `grade`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ],
        // }}}
    ];
}
