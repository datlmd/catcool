<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/LoginCampaign/Incentive.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_LoginCampaign_IncentiveDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'login_campaign_incentive';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'login_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var auto_increment */
    var $_auto_increment = 'false';

    /** @var �ե������̾ */
    var $_field_names = array(
        'login_id',
        'incentive_id',
        'incentive_type',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'find_incentive_list' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_incentive_info_by_login_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_id = :login_id',
        ),
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `login_id` TINYINT(4) unsigned NOT NULL,
                `incentive_id` int(11) unsigned NOT NULL,
                `incentive_type` TINYINT(4) unsigned NOT NULL DEFAULT '0',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                 PRIMARY KEY (`login_id`)
             ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__
                        (login_id, incentive_id, incentive_type, ctime) 
                      VALUES
                        (:login_id, :incentive_id, :incentive_type, NOW())'
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ 
                      SET
                        incentive_id = :incentive_id,
                        incentive_type = :incentive_type
                      WHERE
                        login_id = :login_id'
        ),
        // {{{ �����
        'delete_by_login_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE login_id = :login_id',
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_LoginCampaign_IncentiveFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Contest/EntryFarmSelector.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: IncentiveDao.php 142658 2011-12-21 05:21:25Z shingo-harada $
 */
class Gree_GenericDao_LoginCampaign_IncentiveFarmSelector extends Gree_GenericDao_FarmSelector
{

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['login_campaign_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $login_campaign_id = $hint['login_campaign_id'];
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }

        $farm = sprintf($this->_table_suffix_format, $login_campaign_id);
        if (empty($farm)) {
            return PEAR::raiseError("farm is blank");
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
