<?php

class Gree_Service_AvatarFeed_Module_Base
    extends Gree_Service_AvatarFeed_Module
{
    // for appendUserInfo()
    public function _alignFormatOfEntry($find_results, $column_name)
    {
        $aligned_format_list = array();

        foreach($find_results as $result){
            $aligned_format_list[] = array(
                'content' => array(
                    'sender_id' => $result[$column_name]
                )
            );
        }

        return $aligned_format_list;
    }
}
