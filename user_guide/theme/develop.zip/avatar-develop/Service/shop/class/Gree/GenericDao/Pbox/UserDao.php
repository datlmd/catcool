<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Pbox/User.php
 *
 *  @author   Masayoshi Yoshino <masayoshi.yoshino@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_Pbox_UserDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'pbox_user';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_present_box';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_present_box';

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'present_hash',
        'value',
        'value_order',
        'type',
        'choice',
        'count',
        'state',
        'message_id',
        'route_id',
        'start_date',
        'expire_date',
        'ctime',
        'mtime',
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_user_id_and_state_and_value_order' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = :state AND value_order = :value_order',
        ),
        'find_by_user_id_and_present_hashs' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND present_hash in (:present_hash) ORDER BY mtime DESC, present_hash',
        ),
        'find_by_user_id_and_present_hashs_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND present_hash in (:present_hash) AND state = :state',
        ),
        'find_by_user_id_and_present_hashs_and_value' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND present_hash = :present_hash AND value = :value AND state = 0',
        ),
        'find_by_user_id_and_received_state_and_value_order' => array(
            'sql' => 'SELECT present_hash FROM __TABLE_NAME__ WHERE user_id = :user_id AND state <> 0 AND value_order = :value_order ORDER BY mtime DESC, id DESC',
        ),
        'find_by_user_id_and_state_and_value_order_and_time' => array(
            'sql' => 'SELECT present_hash FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = :state AND value_order = :value_order AND start_date <= :now_date AND expire_date > :now_date ORDER BY ctime DESC, id DESC',
        ),
        'find_by_user_single_all_available_presents' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = 0 AND choice = 0 AND start_date <= :now_date AND expire_date > :now_date ORDER BY type',
        ),
        'find_not_received_present_hash_by_user_id' => array(
            'sql' => 'SELECT present_hash FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = 0 AND value_order = 1 AND start_date <= :now_date AND expire_date > :now_date',
        ),
        'find_not_received_present_info_by_user_id' => array(
            'sql' => 'SELECT present_hash, start_date, expire_date FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = 0 AND value_order = 1 AND start_date <= :now_date AND expire_date > :now_date',
        ),
        'count_by_user_id_and_value' => array(
            'sql' => 'SELECT count(*) as count FROM __TABLE_NAME__ WHERE user_id = :user_id AND value = :value',
        ),
        'count_not_received_by_user_id' => array(
            'sql' => 'SELECT count(*) as count FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = 0 AND value_order = 1 AND start_date <= :now_date AND expire_date > :now_date',
        ),
        'count_received_by_user_id' => array(
            'sql' => 'SELECT count(*) as count FROM __TABLE_NAME__ WHERE user_id = :user_id AND state <> 0 AND value_order = 1',
        ),
        'find_all_by_value_and_ctime' => array(
            'sql' => 'SELECT user_id, value, ctime FROM __TABLE_NAME__ WHERE value = :value AND ctime <= :ctime',
        ),
        // }}}
        // {{{ ������
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (
                        user_id, 
                        present_hash,
                        value,
                        value_order,
                        type,
                        choice,
                        count,
                        message_id,
                        route_id,
                        start_date,
                        expire_date,
                        ctime
                    ) VALUES (
                        :user_id, 
                        :present_hash,
                        :value,
                        :value_order,
                        :type,
                        :choice,
                        :count,
                        :message_id,
                        :route_id,
                        :start_date,
                        :expire_date,
                        :ctime
                    )'
        ),
        'update_state_by_user_id_and_present_hash' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state WHERE user_id = :user_id AND present_hash = :present_hash',
        ),
        'update_state_by_user_id_and_present_hashs' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = value WHERE user_id = :user_id AND present_hash in (:present_hash)',
        ),
        'update_state_by_user_id_and_choice_and_time_all' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = value WHERE user_id = :user_id AND choice = :choice AND start_date <= :now_date AND expire_date > :now_date',
        ),
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`            INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`       INT(10) UNSIGNED NOT NULL,
                    `present_hash`  VARCHAR(255) NOT NULL,  
                    `value`         INT(10) UNSIGNED NOT NULL,
                    `value_order`   TINYINT(2) UNSIGNED NOT NULL,
                    `type`          TINYINT(4) UNSIGNED NOT NULL,
                    `choice`        TINYINT(2) UNSIGNED NOT NULL,
                    `count`         INT(10) UNSIGNED DEFAULT 1 NOT NULL,
                    `state`         INT(10) UNSIGNED DEFAULT 0 NOT NULL,
                    `message_id`    INT(10) UNSIGNED NOT NULL,
                    `route_id`      INT(10) UNSIGNED DEFAULT NULL,
                    `start_date`    INT(10) UNSIGNED NOT NULL,
                    `expire_date`   INT(10) UNSIGNED NOT NULL,
                    `ctime`         DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime`         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    KEY (`expire_date`),
                    KEY (`user_id`, `choice`),
                    KEY (`user_id`, `state`),
                    UNIQUE (`user_id`, `present_hash`, `value`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        // }}}
        //{{{ ���ݡ��ȥġ����
        'find_by_user_id_and_received_and_value_order' => array(
            'sql' => 'SELECT present_hash FROM __TABLE_NAME__ WHERE user_id = :user_id AND value_order = :value_order ORDER BY mtime DESC',
        ),
        'count_all_by_user_id' => array(
            'sql' => 'SELECT count(*) as count FROM __TABLE_NAME__ WHERE user_id = :user_id AND value_order = 1',
        ),
        'delete_by_user_id_and_hash' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id AND present_hash = :present_hash',
        ),
        'find_by_user_id_and_value' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND value = :value AND type = 1 ORDER BY id DESC',
        ),
        //debug only
        'delete_by_user_id_and_hash_like' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id AND present_hash like :present_hash',
        ),
        //batch only
        'delete_by_expire_date' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE expire_date <= :expire_date',
        ),
        'delete_by_user_id_and_hash_and_state' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id AND present_hash = :present_hash AND state = :state',
        ),
        //}}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Pbox_UserFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Pbox_UserFarmSelector extends Gree_GenericDao_FarmSelector
{

    /** @var string table suffix format */
    var $_table_suffix_format = "_%02d";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        /** var �ơ��֥�ʬ��� */
        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = 2;
        } else {
            $table_nums = 100;
        }

        // check $hint[user_id]
        if (empty($hint['user_id']) || is_numeric($hint['user_id']) == false || $hint['user_id'] <= 0) {
            $error_msg  = sprintf('hint is empty. dao = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
        $user_id = $hint['user_id'];
        $postfix = (int)($user_id % $table_nums);

        // create table name
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
    // }}}
}
