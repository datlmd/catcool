<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Like_List_ShowTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Like_List_ShowTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();
        $this->module      = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        $this->initialize_like_status();
    }

    public function test_get_list_no_specified_offset_and_limit()
    {
        list($is_created_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        $like_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1, // for TD
            'entry_id' => $entry_id,
            'user_id'  => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, // for td
            'liked_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 // for td
        );

        list($is_added_like, $added_entry_id) = $this->module->addLike($like_params);

        $this->assertTrue($is_added_like);

        list($has_more, $like_list) = $this->avatar_feed->process('like_list_show', $like_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more);
        $this->assertEquals(1, count($like_list));
        $like_data = array_shift($like_list);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $like_data['content']['sender_id']);
        $this->assertTrue(isset($like_data['content']['user_info']));
        $this->assertTrue(isset($like_data['content']['user_info']['nick_name']));
        $this->assertTrue(isset($like_data['content']['user_info']['thumbnail_url']));
    }

    public function test_get_list_specified_offset_and_limit()
    {
        list($is_created_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        $like_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1, // for TD
            'entry_id' => $entry_id,
            'user_id'  => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, // for td
            'liked_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 // for td
        );

        $add_users = array(
            0 => UNIT_TEST_USER_ID_1,
            1 => UNIT_TEST_USER_ID_2,
            2 => UNIT_TEST_USER_ID_3,
            3 => UNIT_TEST_USER_ID_4,
            4 => UNIT_TEST_USER_ID_5,
        );
        foreach ($add_users as $add_user) {
            $this->module->setUserIDtoCtfy($add_user);
            list($is_added_like, $added_entry_id) = $this->module->addLike($like_params);

            $this->assertTrue($is_added_like);
        }

        $get_params = array(
            'entry_id' => $entry_id,
            'limit'    => 2,
            'start_id' => UNIT_TEST_USER_ID_3,
            'user_id'  => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, // for td
            'liked_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 // for td
        );

        list($has_more, $like_list) = $this->avatar_feed->process('like_list_show', $get_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more);
        $this->assertEquals(2, count($like_list));

        $like_data_1 = array_shift($like_list);
        $this->assertEquals(UNIT_TEST_USER_ID_2, $like_data_1['content']['sender_id']);
        $this->assertTrue(isset($like_data_1['content']['user_info']));
        $this->assertTrue(isset($like_data_1['content']['user_info']['nick_name']));
        $this->assertTrue(isset($like_data_1['content']['user_info']['thumbnail_url']));

        $like_data_2 = array_shift($like_list);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $like_data_2['content']['sender_id']);
        $this->assertTrue(isset($like_data_2['content']['user_info']));
        $this->assertTrue(isset($like_data_2['content']['user_info']['nick_name']));
        $this->assertTrue(isset($like_data_2['content']['user_info']['thumbnail_url']));
    }

    public function test_not_exist_like()
    {
        list($is_created_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        $get_params = array(
            'entry_id' => $entry_id
        );
        list($has_more, $like_list) = $this->avatar_feed->process('like_list_show', $get_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more);
        $this->assertEmpty($like_list);
    }
}