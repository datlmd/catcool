<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Gacha/Prize/UserPointDao.php
 *
 * @package     GREE Avatar
 * @since       2018-06-04
 */
require_once(GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserLightFarmSelector.php');

/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_Gacha_Prize_UserPointDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'gacha_prize_user_point';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var field names */
    var $_field_names = [
        'id',
        'gacha_prize_master_id',
        'user_id',
        'total_point',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_user_id'                  => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        'find_by_user_id_and_gacha_prize_master_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and gacha_prize_master_id = :gacha_prize_master_id',
        ],
        // }}}

        // {{{ update queries
        'entry'  => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (gacha_prize_master_id, user_id, total_point, ctime) VALUES (:gacha_prize_master_id, :user_id, :total_point, NOW())',
            'return_last_insert_id' => true
        ],
        'update' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET gacha_prize_master_id = :gacha_prize_master_id, user_id = :user_id, total_point = :total_point WHERE id = :id and total_point = :old_total_point',
        ],
        // }}}

        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `gacha_prize_master_id` INT UNSIGNED NOT NULL,
                  `user_id` INT UNSIGNED NOT NULL,
                  `total_point` INT UNSIGNED NOT NULL DEFAULT '0',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `gacha_prize_master_id`(`gacha_prize_master_id`, `user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ],
        // }}}
    ];

    public function _init()
    {
        parent::_init();
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
}