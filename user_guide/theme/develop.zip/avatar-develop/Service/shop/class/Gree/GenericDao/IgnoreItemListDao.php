<?php

class Gree_GenericDao_IgnoreItemListDao extends Gree_GenericDao
{
    public $_table_name = 'ignore_item_list';

    public $_primary_key = 'id';

    public $_created_at_column = 'ctime';

    public $_updated_at_column = 'mtime';

    public $_master_dsn = 'gree://master/avatar_user';

    public $_slave_dsn  = 'gree://slave/avatar_user';

    public $_auto_increment = true;

    public $_field_names = [
        'id',
        'item_id',
        'ignore_type',
        'mtime',
        'ctime',
    ];

    public $_queries = [

        //Refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY item_id DESC'
        ],
        'find_item_id_by_item_ids' => [
            'sql' => 'SELECT item_id FROM __TABLE_NAME__ WHERE item_id in (:item_ids) AND ignore_type = :ignore_type'
        ],

        //Insert query
        'insert' => [
            'sql' => "
            INSERT IGNORE INTO __TABLE_NAME__ (
                    id,
                    item_id,
                    ignore_type,
                    mtime,
                    ctime,
                )
                VALUES(
                    DEFAULT,
                    :item_id,
                    :ignore_type,
                    NOW(),
                    NOW()
                )
            ",
        ],

        //Create table query
        'create_table' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `item_id` int(10) NOT NULL,
                `ignore_type` tinyint(4) UNSIGNED NOT NULL,
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE (`item_id`),
                KEY `item_idx` (`item_id`),
                KEY `ignore_type` (`ignore_type`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],

        // Delete query
        'delete_by_item_ids' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE item_id in (:item_ids) AND ignore_type = :ignore_type'
        ],
    ];

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
