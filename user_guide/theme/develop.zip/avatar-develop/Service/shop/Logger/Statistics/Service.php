<?php
/**
 * Service.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */

require_once dirname(dirname(__FILE__)) . '/Statistics.php';
require_once PATH_SRC_CLASS . '/Gree/Statistics/Logger/Service.php';

/**
 * logger class of shop service
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @access  public
 * @package GREE
 */
class Gree_Service_Shop_Logger_Statistics_Service
    extends Gree_Service_Shop_Logger_Statistics
{
    /* -------- [ public methods ] -------- */

    // {{{ __construct
    /**
     * constructor
     */
    public function __construct()
    {
        // do nothing
    }
    // }}}

    // ------------------------------------------------------------------
    // Point Log
    // ------------------------------------------------------------------

    // {{{ changePoint
    /**
     * change avatar point log
     *
     * @access  public
     * @param   int     $user_id    the user id
     * @param   int     $diff       the diff
     * @param   int     $total      the total point
     */
    public function changePoint($user_id, $diff, $total)
    {
        // calc increment / decrement
        $increment  = (0 < $diff) ? $diff       : 0;
        $decrement  = ($diff < 0) ? abs($diff)  : 0;

        // log
        $data_multi = array(
            'increment' => $increment,
            'decrement' => $decrement,
            'total'     => $total,
        );
        $this->_log('shop/point/change', $data_multi, $user_id);
    }
    // }}}

    // {{{ updatePoint
    /**
     * update avatar point log
     *
     * @access  public
     * @param   int     $user_id    the user id
     * @param   int     $total      the total point
     */
    public function updatePoint($user_id, $total)
    {
        $data_multi = array(
            'total' => $total,
        );
        $this->_log('shop/point/update', $data_multi, $user_id);
    }
    // }}}

    // ------------------------------------------------------------------
    // Market Log
    // ------------------------------------------------------------------

    // {{{ marketAction
    /**
     * market action log
     *
     * @access  public
     * @param   string  $log_name   the log name
     * @param   int     $market_id  the market id
     * @param   int     $item_id    the item id
     * @param   int     $point      the point
     */
    public function marketAction($log_name, $market_id, $item_id, $point)
    {
        $log_name   = 'shop/market/' . $log_name;
        $data_multi = array(
            'market_id' => $market_id,
            'item_id'   => $item_id,
        );
        $this->_log($log_name, $data_multi);
    }
    // }}}

    // ------------------------------------------------------------------
    // Avapri Log
    // ------------------------------------------------------------------
    
    // {{{ avapriAction
    /**
     * avapri action log
     *
     * @access  public
     * @param   string  $log_name   the log name
     * @param   int     $item_id    the item id
     * @param   int     $point      the point
     */
     public function avapriAction($log_name, $item_id, $point)
     {
         $log_name   = 'shop/avapri/' . $log_name;
         $data_multi = array(
            'item_id'   => $item_id,
            'point'     => $point,
         );
         $this->_log($log_name, $data_multi);
    }
    // }}}

    public function avatarFeedLog($log_name, $log_data){
        $user_id = null;
        if (array_key_exists('user_id', $log_data)){
            $user_id = $log_data['user_id'];
        }

        $this->_log($log_name, $log_data, $user_id);
    }

    // ------------------------------------------------------------------
    // User Item Delete Log
    // ------------------------------------------------------------------
    
    // {{{ UserItemDeleteAction
    /**
     * user item delete log
     *
     * @access  public
     * @param   string  $log_name   the log name
     * @param   int     $item_id    the item id
     * @param   int     $point      the point
     */
     public function UserItemDelete($user_id, $item_id)
     {
        $data_multi = array(
            'item_id'     => $item_id,
        );
        $this->_log('shop/user/delete', $data_multi, $user_id);
    }
    // }}}

    /* -------- [ protected methods ] -------- */

    // {{{ _log
    /**
     * write log
     *
     * @access  protected
     * @param   string  $log_name   the log directory name
     * @param   array   $data_multi the data
     * @param   int     $user_id    the user id
     */
    protected function _log($log_name, $data_multi, $user_id = null)
    {
        // get logger
        $logger = Gree_Statistics_Logger_Service::getInstance();
        $logger->log_name = $log_name;
        if (!is_null($user_id)) {
            $logger->setUserId($user_id);
        }

        // get data
        $data_multi = $this->_appendNetLog($data_multi);
        $data       = array();
        foreach ($data_multi as $key => $val) {
            $data[] = $key;
            $data[] = $val;
        }

        // write log
        call_user_func_array(array($logger, 'write'), $data);
        $logger = null;
    }
    // }}}
}
