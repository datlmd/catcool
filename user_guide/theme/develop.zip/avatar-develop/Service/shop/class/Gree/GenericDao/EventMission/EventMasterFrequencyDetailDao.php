<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/EventMission/EventMasterFrequencyDetailDao.php
 * @package     GREE Avatar
 * @since       2018-10-16
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * EventMasterFrequencyDetail form constructor
 * @access      public
 */
class Gree_GenericDao_EventMission_EventMasterFrequencyDetailDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'mission_event_master_frequency_detail';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'master_id',
        'mission_info_master_id',
        'day_num',
        'is_special_mission',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_id'        => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'find_by_master_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_id = :master_id ORDER BY day_num',
        ],
        // }}}

        // {{{ update queries
        'entry'             => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (master_id, mission_info_master_id, day_num, is_special_mission, ctime) VALUES (:master_id, :mission_info_master_id, :day_num, :is_special_mission, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'            => [
            'sql' => 'UPDATE __TABLE_NAME__ SET master_id = :master_id, mission_info_master_id = :mission_info_master_id, day_num = :day_num WHERE id = :id',
        ],
        'delete_normal_by_master_id'=> [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE is_special_mission = 0 AND master_id = :master_id',
        ],
        'delete_by_id'=> [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'delete_by_master_id' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE master_id = :master_id',
        ],
        // }}}

        'create_table' => [
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `master_id` INT UNSIGNED NOT NULL,
                `mission_info_master_id` INT UNSIGNED NOT NULL,
                `day_num` INT UNSIGNED NOT NULL,
                `is_special_mission` INT UNSIGNED NOT NULL DEFAULT '0',
                `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `name` (`master_id`,`mission_info_master_id`,`day_num`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
        //{{{ DEV ONLY
        'delete_data' => [
            'sql' => 'TRUNCATE TABLE __TABLE_NAME__;'
        ],
        'update_filed_date' => [
            'sql' => 'ALTER TABLE __TABLE_NAME__ DROP COLUMN `date`, ADD COLUMN `day_num` INT UNSIGNED NOT NULL AFTER `mission_info_master_id`,  DROP INDEX `name`, ADD UNIQUE `name_key`(master_id, mission_info_master_id, day_num);'
        ],
        'add_filed_is_special_mission' => [
            'sql' => 'ALTER TABLE __TABLE_NAME__ ADD COLUMN `is_special_mission` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `day_num`;'
        ],
        // }}}
    ];
}
