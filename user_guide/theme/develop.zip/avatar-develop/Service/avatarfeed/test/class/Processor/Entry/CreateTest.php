<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Entry_Create
 *
 * this test is create entry process
 */
final class Gree_Service_Avatarfeed_Test_Processor_Entry_Crate
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    var $module_follow;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');

        try {
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        try {
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        // initialize follow status
        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_follow->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        try {
            $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1);
            $this->module_follow->removeFollowedUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
            $this->module_follow->removeFollowedUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_1);
            $this->module_follow->removeFollowedUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_1);

        } catch (Exception $e) {
        }

        sleep(2);

    }

    /**
     * test1:
     * Success Create Entry
     * is_success == true
     * entry_id   == string
     *
     * test2
     * Failed Crate Entry
     * is success == false
     * entry_id   == null
     */
    public function test_create_entry_on_followed_user_is_0()
    {
        // test1
        $create_params = array(
            'entry_category' => 'mood',
            'text'           => 'test_create_entry_on_followed_user_is_0'
        );
        list($is_create_entry, $entry_id) = $this->avatar_feed->process('entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_create_entry);

        sleep(2);

        list($is_exist, $entry) = $this->module->getEntry($entry_id);
        $entry_data = array_shift($entry);
        $this->assertTrue($is_exist);
        $this->assertEquals($entry_id, $entry_data['entry_id']);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $entry_data['content']['sender_id']);
        $this->assertEquals($create_params['entry_category'], $entry_data['content']['entry_type']);
        $this->assertEquals($create_params['text'], $entry_data['content']['text']);
        $this->assertEquals('mood', $entry_data['content']['attr']['entry_category']);

        $expect_destinations = array(
            array(
                'type'  => 'feed_key',
                'value' => '2164:default:' . UNIT_TEST_USER_ID_1
            )
        );
        $this->assertEquals($expect_destinations, $entry_data['destinations']);

        // test2
        $create_params = array(
            'entry_category' => 'change',
            'text'           => 'test_create_entry_on_followed_user_is_0'
        );
        list($is_create_entry, $entry_id_2) = $this->avatar_feed->process('entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($is_create_entry);
        $this->assertTrue(is_null($entry_id_2));


    }

    /**
     * GREE_SERVICE_AVATARFEED_FIRST_DESTINATION_LIMIT == 5 // dev
     *
     * test1:
     * followed count <= GREE_SERVICE_AVATARFEED_FIRST_DESTINATION_LIMIT
     * Success Create Entry
     * is_success   == true
     * entry_id     == string
     *
     * test2:
     * followed count > GREE_SERVICE_AVATARFEED_FIRST_DESTINATION_LIMIT
     * Success Create Entry
     * is_success   == true
     * entry_id     == string
     *
     * Since appfeed async has stopped, it is not confirmed add destination
     *
     */
    public function test_create_entry_on_followed_user_is_first_limit()
    {
        // test1
        $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1, 0, 5);
        $this->module_follow->addFollowedUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);

        sleep(2);

        $create_params = array(
            'entry_category' => 'mood',
            'text'           => 'test_create_entry_on_followed_user_is_first_limit'
        );
        list($is_create_entry, $entry_id) = $this->avatar_feed->process('entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_create_entry);

        sleep(2);

        list($is_exist, $entry) = $this->module->getEntry($entry_id);
        $entry_data = array_shift($entry);
        $this->assertTrue($is_exist);
        $this->assertEquals($entry_id, $entry_data['entry_id']);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $entry_data['content']['sender_id']);
        $this->assertEquals($create_params['entry_category'], $entry_data['content']['entry_type']);
        $this->assertEquals($create_params['text'], $entry_data['content']['text']);
        $this->assertEquals('mood', $entry_data['content']['attr']['entry_category']);

        $expect_destinations = array(
            array(
                'type'  => 'feed_key',
                'value' => '2164:default:' . UNIT_TEST_USER_ID_2
            ),
            array(
                'type'  => 'feed_key',
                'value' => '2164:default:' . UNIT_TEST_USER_ID_1
            )
        );
        $this->assertEquals($expect_destinations, $entry_data['destinations']);

        // test2
        $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1, 0, 6);

        sleep(2);

        list($is_create_entry_2, $entry_id_2) = $this->avatar_feed->process('entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_create_entry_2);

        sleep(2);

        list($is_exist_2, $entry_2) = $this->module->getEntry($entry_id_2);
        $entry_data_2 = array_shift($entry_2);
        $this->assertTrue($is_exist_2);
        $this->assertEquals($entry_id_2, $entry_data_2['entry_id']);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $entry_data_2['content']['sender_id']);
        $this->assertEquals($create_params['entry_category'], $entry_data_2['content']['entry_type']);
        $this->assertEquals($create_params['text'], $entry_data_2['content']['text']);
        $this->assertEquals('mood', $entry_data_2['content']['attr']['entry_category']);

        $expect_destinations = array(
            array(
                'type'  => 'feed_key',
                'value' => '2164:default:' . UNIT_TEST_USER_ID_1
            )
        );
        $this->assertEquals($expect_destinations, $entry_data_2['destinations']);

        sleep(5);

        //$this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
        // appfeed async is stopped always.
        list($has_more, $dest_stream_data) = $this->module->getEntriesByFeedKey(UNIT_TEST_USER_ID_2, GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY, 10, null, 'batch');
        $dest_entry = array_shift($dest_stream_data);

        $this->assertEquals($entry_id_2, $dest_entry['entry_id']);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $dest_entry['content']['sender_id']);
        $this->assertEquals($create_params['entry_category'], $dest_entry['content']['entry_type']);
        $this->assertEquals($create_params['text'], $dest_entry['content']['text']);
        $this->assertEquals('mood', $dest_entry['content']['attr']['entry_category']);
    }

    /**
     * GREE_SERVICE_AVATARFEED_SECOND_DESTINATION_LIMIT == 10 // dev
     *
     * test1:
     * followed count <= GREE_SERVICE_AVATARFEED_SECOND_DESTINATION_LIMIT
     * Success Create Entry
     * is_success   == true
     * entry_id     == string
     *
     * test2:
     * followed count > GREE_SERVICE_AVATARFEED_SECOND_DESTINATION_LIMIT
     * Success Create Entry
     * is_success   == true
     * entry_id     == string
     *
     * Since appfeed async has stopped, it is not confirmed add destination
     *
     */
    public function test_create_entry_on_followed_user_is_second_limit()
    {
        $async_obj        = Gree_Async::getInstance();
        $async_queue_list = $async_obj->getQueueByNamespace('shop', 100);
        foreach ($async_queue_list as $queue) {
            $async_obj->remove($queue['id'], 'shop');
        }

        // test1
        $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1, 0, 10);
        $this->module_follow->addFollowedUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);

        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        sleep(2);

        $create_params = array(
            'entry_category' => 'mood',
            'text'           => 'test_create_entry_on_followed_user_is_second_limit'
        );
        list($is_create_entry, $entry_id) = $this->avatar_feed->process('entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_create_entry);

        $async_queue = $async_obj->getQueueByNamespace('shop', 10);

        $this->assertTrue(empty($async_queue));

        // test2
        $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1, 0, 11);

        sleep(2);

        list($is_create_entry_2, $entry_id_2) = $this->avatar_feed->process('entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_create_entry_2);

        sleep(2);

        $async_queue_2 = $async_obj->getQueueByNamespace('shop', 10);

        $this->assertEquals(1, count($async_queue_2));

        $async_data = array_shift($async_queue_2);
        $this->assertEquals('addDestination', $async_data['operation']);
        $expect_async_params = array(
            'entry_id'  => $entry_id_2,
            'sender_id' => UNIT_TEST_USER_ID_1,
        );
        $get_async_params    = gzuncompress($async_data['parameter']);
        $this->assertEquals($expect_async_params, unserialize($get_async_params));
    }

    public function test_no_destination()
    {
        $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);

        sleep(2);

        $create_params = array(
            'entry_category' => 'mood',
            'text'           => 'test_create_entry_on_followed_user_is_0'
        );
        list($is_create_entry, $entry_id) = $this->avatar_feed->process('entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_create_entry);

        sleep(2);

        list($is_exist, $entry) = $this->module->getEntry($entry_id);
        $entry_data = array_shift($entry);
        $this->assertTrue($is_exist);
        $this->assertEquals($entry_id, $entry_data['entry_id']);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $entry_data['content']['sender_id']);
        $this->assertEquals($create_params['entry_category'], $entry_data['content']['entry_type']);
        $this->assertEquals($create_params['text'], $entry_data['content']['text']);
        $this->assertEquals('mood', $entry_data['content']['attr']['entry_category']);

        $expect_destinations = array();
        $this->assertEquals($expect_destinations, $entry_data['destinations']);
    }

    /*
        public function test_create_entry_specific_category()
        {

        }

        public function test_create_entry_destination()
        {

        }
    */

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_entry_show',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}