<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Like_RemoveTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Like_RemoveTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();
        $this->module      = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
    }

    public function test_remove_like()
    {
        list($is_created_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        $like_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1, // for TD
            'entry_id' => $entry_id,
            'liked_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 // for td
        );

        list($is_added_like, $entry_id) = $this->module->addLike($like_params);

        $this->assertTrue($is_added_like);

        $like_result_true = $this->avatar_feed->process('like_remove', $like_params);

        $this->assertTrue($like_result_true);

        $like_result_false = $this->avatar_feed->process('like_remove', $like_params);

        $this->assertFalse($like_result_false);
    }

    /**
     * test1:
     *    case    : entry_id is null
     *    expected: like_result == false
     * test2:
     *    case    : entry_id is not exist
     *    expected: like_result == false
     */
    public function test_not_specified()
    {

        // test1
        $like_params_1 = array(
            'user_id'  => UNIT_TEST_USER_ID_1, // for TD
            'entry_id' => null
        );

        $like_result_1 = $this->avatar_feed->process('like_remove', $like_params_1);

        $this->assertFalse($like_result_1);

        // test2
        $like_params_2 = array(
            'user_id'  => UNIT_TEST_USER_ID_1, // for TD
            'entry_id' => 'hogehoge'
        );

        $like_result_2 = $this->avatar_feed->process('like_remove', $like_params_2);

        $this->assertFalse($like_result_2);
    }
}