<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
/**
 * Gree_GenericDao_AvapriUserSettingDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_User_SettingDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'user_setting';
	/** @var primary key */
    var $_primary_key = array( 'user_id', 'type');
    /** @var auto increment */
    var $_auto_increment = false;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'user_id',
        'type',
        'val',
        'ctime',
        'mtime'
    );

    var $_queries = array( // ʣ�祭��
        // select----------------------
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_user_id_and_name' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND type = :type',
        ),
        // update----------------------
        'update_user_setting' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, type, val, ctime) VALUES (:user_id, :type, :val, NOW()) ON DUPLICATE KEY UPDATE val = :val',
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
              `user_id` int(11) unsigned NOT NULL,
              `type` int(11) unsigned  NOT NULL,
              `val` tinyint(4) unsigned NOT NULL default '0',
              `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
              `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
              PRIMARY KEY  (`user_id`,`type`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'delete_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
    );
    
    function _init()
    {
        parent::_init();
        
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
?>
