<?php

require_once('/home/gree/src/Gree_Bootstrap.php');
require_once('/home/gree/xgree/avatar/Service/avatarfeed/bootstrap.php');
require_once('Console/Getopt.php');
require_once("/home/gree/xgree/avatar/Service/avatarfeed/service.php");

Gree_Service_AvatarFeed_Cli_Base::main();

class Gree_Service_AvatarFeed_Cli_Base
{
    var $avatar_feed;
    var $module;
    var $module_follow;
    var $module_block;
    var $module_score;
    var $arg_list;
    var $input_opt_list;
    var $short_opt = '';
    var $opt_names = array();

    public function main()
    {
    }

    function _initialize()
    {
        $this->avatar_feed   = Gree_Service_AvatarFeed::getInstance();
        $this->module        = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_block  = Gree_Service_AvatarFeed_Module::singleton('Block');
        $this->module_score  = Gree_Service_AvatarFeed_Module::singleton('Score');
        $input_arg_list      = $_SERVER['argv'];
        array_shift($input_arg_list);
        $this->arg_list = $input_arg_list;
    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_incentive_add',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }

    function _get_enable_user()
    {
        $registry          = getService('shop')->getRegistry();
        $enable_user_lists = $registry->getArray('avatar_feed_enable_user_list');

        return $enable_user_lists['dev'];
    }

    function _print_line()
    {
        $line = str_pad('', 80, '-');
        printf("$line\n");
    }

    function _print_header($header)
    {
        $this->_print_line();
        printf("this cli is : $header\n");
        $this->_print_line();
    }

    function _print_footer()
    {
        $this->_print_line();


    }

    function _print_kv($k, $v, $w)
    {
        $v              = var_export($v, 1);
        $pattern []     = "/(\r|\n)/";
        $pattern []     = "/(\(\s+)/";
        $replacement [] = "";
        $replacement [] = "(";
        $v              = preg_replace($pattern, $replacement, $v);
        printf("- %-{$w}s : %s\n", $k, $v);
    }

    function _get_width($k)
    {
        $w = intval(strlen($k) * 1.1);
    }

    function _get_parse_arg_list()
    {
        list($opt_list, $additional) = Console_Getopt::getopt2($this->arg_list, $this->short_opt, $this->opt_names);
        return $opt_list;
    }

    public function _set_option_value()
    {
        $set_options = array();
        foreach ($this->input_opt_list as $option) {
            if (is_array($option) == false || !isset($option[0])) {
                printf("invalid option \n");

                throw new Exception();
            }

            list($option_name, $option_value) = $this->_find_input_option($option);
            $set_options[$option_name] = $option_value;
        }

        printf("input params \n");
        foreach ($set_options as $index => $value) {
            $this->_print_kv($index, $value, 5);
        }

        return $set_options;
    }

    function parse_arg_list($arg_list)
    {
        list($opt_list, $additional) = Console_Getopt::getopt2($arg_list, "u:f:k:ch", array("property", "show", 'count', 'delete', 'delete-friend', 'truncate', 'drop', 'help'));
        $user_id = $feed_id = $key = $mode = null;
        if (is_null($opt_list)) {
            $opt_list = array();
        }
        foreach ($opt_list as $opt) {
            if (is_array($opt) && isset($opt[0])) {
                switch ($opt[0]) {
                    case 'u':
                        $user_id = $opt[1];
                        break;
                    case 'f':
                        $feed_id = $opt[1];
                        break;
                    case 'k':
                        $key = $opt[1];
                        break;
                    case '--property':
                        if (is_null($mode) === false) {
                            exclusive_message();
                            usage();
                        }
                        $mode = 'property';
                        break;
                    case '--show':
                        if (is_null($mode) === false) {
                            exclusive_message();
                            usage();
                        }
                        $mode = 'show';
                        break;
                    case '--count':
                        if (is_null($mode) === false) {
                            exclusive_message();
                            usage();
                        }
                        $mode = 'count';
                        break;
                    case '--delete':
                        if (is_null($mode) === false) {
                            exclusive_message();
                            usage();
                        }
                        $mode = 'delete';
                        break;
                    case '--delete-friend':
                        if (is_null($mode) === false) {
                            exclusive_message();
                            usage();
                        }
                        $mode = 'delete-friend';
                        break;
                    case '--truncate':
                        if (is_null($mode) === false) {
                            usage();
                        }
                        $mode = 'truncate';
                        break;
                    case '--drop':
                        if (is_null($mode) === false) {
                            exclusive_message();
                            usage();
                        }
                        $mode = 'drop';
                        break;
                    case 'h':
                    case '--help':
                        usage();
                        break;
                    default:
                        printf("unknown option [%s]\n\n", $opt[0]);
                        usage();
                        break;
                }
            }
        }
        if (is_null($user_id) === true || is_null($feed_id) === true || is_null($mode) === true) {
            usage();
        }
        if (($mode == 'delete' || $mode == 'delete-friend') && is_null($key) === true) {
            usage();
        }

        return array($user_id, $feed_id, $mode, $key);
    }

    function exclusive_message()
    {
        printf("--property, --show, --count, --delete, --delete-friend, --truncate, --drop are exclusive\n\n");
    }

    function usage()
    {
        $usage = <<<EOD
feed_manager.php [options]
options:
  -u                user id
  -f                feed id
  -k                key of data
  --property        show property of feed
  --show            show all data of feed
  --count           show count of feed data
  --delete          delete data by key (require -k option)
  --delete-friend   delete data by key from friend-feed (require -k option)
  --truncate        delete all data
  --drop            drop feed
and something else:
  -h, --help            show this message
EOD;
        printf($usage);
        exit();
    }
}