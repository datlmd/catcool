<?php

require_once '/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php';

/**
 * Gree_GenericDao_Shop_Gacha_Coupon_HistoryDao
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Gacha_Coupon_HistoryDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'gacha_coupon_history';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_gacha_coupon';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_gacha_coupon';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'gacha_id',     // �оݥ�����ID
        'price',        // �����ݥ����ѻ��Υ��������
        'action_name',  // �����սꥢ�������̾
        'status',       // ���ơ�������0:���� 1:���ѡ�
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, gacha_id, price, action_name, status, ctime)
                VALUES
                    (:user_id, :gacha_id, :price, :action_name, :status, NOW())
            ',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id`                  INT(10)         UNSIGNED NOT NULL AUTO_INCREMENT,
                  `user_id`             INT(10)         UNSIGNED NOT NULL,
                  `gacha_id`            INT(10)         UNSIGNED NOT NULL,
                  `price`               INT(10)         UNSIGNED NOT NULL,
                  `action_name`         VARCHAR(255)    NOT NULL,
                  `status`              TINYINT(3)      UNSIGNED NOT NULL,
                  `ctime`               DATETIME        NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`),
                  KEY `user_id` (`user_id`),
                  KEY `gacha_id` (`gacha_id`, `price`),
                  KEY `status` (`status`),
                  KEY `action_name` (`action_name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
