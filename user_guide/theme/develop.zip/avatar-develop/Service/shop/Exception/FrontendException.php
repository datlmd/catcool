<?php
/**
 *
 */
class Gree_Service_Shop_Exception_FrontendException
    extends Gree_Service_Shop_Exception
{
}
