<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';
/**
 * Class Gree_GenericDao_Contest_ItemVoteDao
 * @author z.shintaro.okada
 * @package  GREE
 */
class Gree_GenericDao_Contest_ItemVoteDao extends Gree_GenericDao
{
    /** @var テーブル名 */
    var $_table_name = 'contest_item_vote';

    /** @var 主キー。複合キーはarrayハッシュで指定する。*/
    var $_primary_key = 'id';

    /** @var オートインクリメント*/
    var $_auto_increment = true;

    /** @var 更新日カラム名 */
    var $_created_at_column = 'ctime';

    /** @var 登録日カラム名 */
    var $_updated_at_column = 'mtime';

    /** @var マスターデータベースの接続文字列 */
    var $_master_dsn = 'gree://master/avatar_contest';

    /** @var スレーブデータベースの接続文字列 */
    var $_slave_dsn = 'gree://slave/avatar_contest';

    /** @var フィールド名 */
    var $_field_names = array(
        'id',
        'user_id',
        'item_id',
        'point',
        'ctime',
        'mtime',
    );

    /** @var クエリ */
    var $_queries = array(
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                      `id`      INT(11)     UNSIGNED  NOT NULL AUTO_INCREMENT,
                      `user_id` INT(11)     UNSIGNED  NOT NULL,
                      `item_id` INT(11)     UNSIGNED  NOT NULL,
                      `point`   BIGINT(20)  UNSIGNED  NOT NULL DEFAULT '0',
                      `ctime`   DATETIME              NOT NULL DEFAULT '00-00-00 00\:00\:00',
                      `mtime`   TIMESTAMP             NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                      PRIMARY KEY (`id`),
                      KEY `item_id` (`item_id`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        /** @var 参照系 */
        'find_by_contest_id_and_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = :item_id',
        ),
        /** @var 更新系 */
        'insert' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, item_id, point, ctime) value (:user_id, :item_id, :point, now())',
        ),
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Contest_ItemVoteFarmSelector();
    }
}

class Gree_GenericDao_Contest_ItemVoteFarmSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%d_%02d";
    var $_table_num           = 100;

    function getTableName($dao, $type, $hint)
    {
        if (empty($hint) || !isset($hint['contest_id']) || !isset($hint['user_id'])) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }
        $contest_id = $hint['contest_id'];
        $user_id    = $hint['user_id'];
        $farm_no    = (int)(((int)$user_id) % $this->_table_num);
        $table_suffix   = sprintf($this->_table_suffix_format, $contest_id, $farm_no);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
}
