<?php
$start_time = microtime(true);
require "/home/gree/src/Gree_Bootstrap.php";
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once PATH_SRC_CLASS.'/Gree/CLI.php';
require_once "/home/gree/xgree/avatar/Service/avatarfeed/service.php";
echo '-------------------------------------------' . PHP_EOL;
echo ' bundle check enable user... ' . PHP_EOL;
echo '-------------------------------------------' . PHP_EOL;

$shop_service      = getService('shop');
$registry          = $shop_service->getRegistry();
$enable_user_lists = $registry->getArray('avatar_feed_enable_user_list');
if (Config::get('state') == 'dev'){
    $enable_user_list = $enable_user_lists['dev'];
} else {
    $enable_user_list = $enable_user_lists['production'];
}

$avatar_feed   = Gree_Service_AvatarFeed::getInstance();
foreach($enable_user_list as $user){
    $follow_params = array(
        'user_id'  => $this->user_id,
    );
    $add_result = $avatar_feed->process('following_add', $follow_params);
}

echo "[DONE]\t" . sprintf('%.3f', (microtime(TRUE) - $start_time)) . PHP_EOL;