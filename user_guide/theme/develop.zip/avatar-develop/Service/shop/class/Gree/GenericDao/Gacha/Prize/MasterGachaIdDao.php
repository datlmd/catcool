<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Gacha/Prize/MasterGachaIdDao.php
 *
 * @package     GREE Avatar
 * @since       2018-06-04
 */


/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_Gacha_Prize_MasterGachaIdDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'gacha_prize_master_gacha_id';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var field names */
    var $_field_names = [
        'id',
        'gacha_prize_master_id',
        'gacha_id',
        'prize_point',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_gacha_prize_master_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_prize_master_id = :gacha_prize_master_id',
        ],
        'find_by_gacha_id'              => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id ORDER BY gacha_prize_master_id DESC',
        ],
        'find_by_gacha_id_and_gacha_prize_master_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id and gacha_prize_master_id = :gacha_prize_master_id',
        ],
        // }}}

        // {{{ update queries
        'entry'                         => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (gacha_prize_master_id, gacha_id, prize_point, ctime) VALUES (:gacha_prize_master_id, :gacha_id, :prize_point, NOW())',
            'return_last_insert_id' => true
        ],
        'update'                        => [
            'sql' => 'UPDATE __TABLE_NAME__ SET gacha_prize_master_id = :gacha_prize_master_id, gacha_id = :gacha_id, prize_point = :prize_point WHERE id = :id',
        ],
        'delete_by_gacha_prize_master_id' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE gacha_prize_master_id = :gacha_prize_master_id',
        ],
        // }}}

        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `gacha_prize_master_id` INT UNSIGNED NOT NULL,
                  `gacha_id` INT UNSIGNED NOT NULL,
                  `prize_point` INT UNSIGNED NOT NULL,
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  INDEX (`gacha_id`),
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `gacha_prize_master_id`(`gacha_prize_master_id`, `gacha_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ],
        // }}}
    ];
}