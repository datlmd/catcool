<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Class Gree_GenericDao_Mission_UserDao
 *
 * @author     Thien Nguyen <z.thanhthien.nguyen@gree.co.jp>
 * @package    GREE
 */
class Gree_GenericDao_Mission_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'mission_user';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_tutorial';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_tutorial';

    /** @var field names */
    var $_field_names = array(
        'id',                   // ID
        'user_id',              // UserID
        'mission_detail_id',    // MissionID
        'is_got_incentive',     // 0: not get item, 1: got
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        'find_by_userid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_userid_and_mission_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND mission_detail_id = :mission_detail_id',
        ),
        'entry' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (mission_detail_id, user_id, ctime) VALUES (:mission_detail_id, :user_id, NOW())',
        ),
        'got_incentive' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET is_got_incentive = 1 WHERE mission_detail_id = :mission_detail_id AND user_id = :user_id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id`                  INT(10)     UNSIGNED NOT NULL AUTO_INCREMENT,
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `mission_detail_id`   TINYINT(3)  UNSIGNED NOT NULL,
                  `is_got_incentive`    TINYINT(1)  UNSIGNED NOT NULL DEFAULT 0,
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`),
                  KEY `user_and_mission` (`user_id`, `mission_detail_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
