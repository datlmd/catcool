<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Beginner/PlanLoginUser.php
 * Gree_GenericDao_Beginner_PlanLoginUserDao
 *
 * @author      ikuko.tamura <z.ikuko.tamura@gree.net>
 * @package     GREE
 */
class Gree_GenericDao_Beginner_PlanLoginUserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'plan_login_user';
    /** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
    /** @var updated at column */
    var $_updated_at_column = 'mtime';
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'user_id',
        'plan_id',
        'access_days',
        'last_login_day',
        'expired',
        'ctime',
        'mtime'
    ];

    var $_queries = [ // ʣ�祭��
        // select----------------------
        'find_by_user_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        'find_by_user_id_and_plan_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and plan_id = :plan_id',
        ],
        // insert----------------------
        'insert' => [
            'sql' =>  'INSERT INTO __TABLE_NAME__ (user_id, plan_id, access_days, last_login_day, expired, ctime) VALUES (:user_id, :plan_id, :access_days, :last_login_day, :expired, NOW())'
        ],
        'update' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET access_days=:access_days, last_login_day=:last_login_day WHERE id = :id AND last_login_day = :old_last_login_day',
        ],
        'delete_by_user_id' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        'delete_by_user_id_and_plan_id' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id and plan_id = :plan_id',
        ],
        // create table ----------------
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT unsigned NOT NULL AUTO_INCREMENT,
                  `user_id` INT unsigned NOT NULL,
                  `plan_id` INT unsigned NOT NULL,
                  `access_days` INT unsigned NOT NULL,
                  `last_login_day` INT unsigned NOT NULL,
                  `expired` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `ctime` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`),
                  UNIQUE (`user_id`, `plan_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
    ];

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
