<?php
/**
 * Gree_GenericDao_AvapriContestVoteStandbyDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Contest_VoteStandbyDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'contest_vote';
	/** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://standby/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'target_user_id',
        'target_seal_id',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        // select----------------------
        'get_ranking' => array(// for create ranking
             'sql' => 'SELECT COUNT(*) as win,target_user_id  FROM __TABLE_NAME__ GROUP BY target_user_id ORDER BY win desc',
        ),
        'get_vote_to_by_user_id' => array(// for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'get_vote_from_by_target_user_id_and_target_seal_id' => array(// for support tool
             'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE target_user_id = :target_user_id AND target_seal_id = :target_seal_id',
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`        INT(11)     UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`   INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                    `target_user_id` INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                    `target_seal_id` INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                    `mtime`     TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                    `ctime`     DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY `ids` (`user_id`, `target_user_id`, `target_seal_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE  IF EXISTS __TABLE_NAME__',
        ),
    );

    // {{{ _initFarmSelector
    function _initFarmSelector() {
        $this->_farm_selector = new Gree_GenericDao_Avapri_Contest_VoteFarmSelector();
    }
    // }}}
}
/**
 *  /home/gree/service/shop/class/GenericDao/Avapri/Contest/VotestandbyFarmSelector.php
 *
 *  @author   Norie Matsuda <norie.matsuda@gree.net>
 *  @package  GREE
 */
class Gree_GenericDao_Avapri_Contest_VoteStandbyFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ getTableName
    /**
    *  get table name
    *
    *  @param      $dao        Dao class
    *  @param      $type       type
    *  @param      $hint       select table hint
    *  @return     string      table
    */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['contest_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $contest_id = $hint['contest_id'];

        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is emptry. dao=" . get_class($dao) . "];");
        }
        $farm = $contest_id;
        $table_name = $original_table_name .'_'. $farm;
        return $table_name;
    }
    // }}}
}