<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Second/Contest/Entry.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_Second_Contest_EntryDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'second_contest_entry';

    var $_primary_key ='id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_second_contest';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_second_contest';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
                              'id',
                              'user_id',
                              'title',
                              'image_key',
                              'mtime',
                              'ctime'
                             );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE id=:id",
        ),
        'find_by_user_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id",
        ),
        'find_max_id' => array(
            'sql' => "SELECT max(id) FROM __TABLE_NAME__",
        ),
        'find_ids' => array(
            'sql' => "SELECT id FROM __TABLE_NAME__ ORDER BY id",
        ),
        // }}}

        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`      int(11) unsigned NOT NULL AUTO_INCREMENT,
                `user_id` int(11) unsigned NOT NULL,
                `title`   varchar(60) NOT NULL,
                `image_key` varchar(255) NOT NULL,
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY (`user_id`)
            ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'insert_or_update' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ 
                        (user_id, title, image_key, ctime) 
                      VALUES 
                        (:user_id, :title, :image_key, NOW())
                      ON DUPLICATE KEY UPDATE 
                        title     = :title,
                        image_key = :image_key
                      "
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Second_Contest_EntryFarmSelector();
    }
    // }}}

}

/**
 *  /home/gree/service/shop/class/GenericDao/Second/Contest/EntryFarmSelector.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 */
class Gree_GenericDao_Second_Contest_EntryFarmSelector extends Gree_GenericDao_FarmSelector
{

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['contest_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $contest_id = $hint['contest_id'];
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }

        $farm = sprintf($this->_table_suffix_format, $contest_id);

        if (empty($farm)) {
            return PEAR::raiseError("farm is blank. contest_id=" . $contest_id);
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}

}
