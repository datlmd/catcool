<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Ranking/Vote/FromUserSpecialTermDao.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: FromUserDao.php 142624 2011-12-20 16:28:49Z ibuki $
 */
class Gree_GenericDao_Ranking_Vote_FromUserSpecialTermDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */ 

    /** @var �ơ��֥�̾ */
    var $_table_name = 'vote_from_user_special_term';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_ranking_vote';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_ranking_vote';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'from_user_count',
        'mtime',
        'ctime',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`         INT(10) UNSIGNED NOT NULL,
                  `from_user_count` INT(10) UNSIGNED NOT NULL DEFAULT '0',
                  `mtime`           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `ctime`           DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`user_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        'create_or_increment' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ 
                          (user_id, from_user_count, ctime) 
                      VALUES
                          (:user_id, 1, NOW()) 
                      ON DUPLICATE KEY UPDATE 
                          from_user_count = from_user_count + 1
                      ',
        ),
        'update' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__
                          (user_id, from_user_count, ctime)
                      VALUES
                          (:user_id, 1, NOW())
                      ON DUPLICATE KEY UPDATE
                          from_user_count = :from_user_count
                      ',
        ),
        'insert' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET from_user_count = from_user_count + 1, from_user_csv = :from_user_csv WHERE user_id = :user_id AND from_user_count = :from_user_count'
        ),
        // }}}
        // {{{ ���ȷ�
        'get_from_user_count_by_user_id_and_user_sex' => array(
            'sql' => 'SELECT from_user_count FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        'delete_by_user_id' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE user_id=:user_id",
        ),
        // }}}
    );
    /** #@- */

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Ranking_Vote_FromUserSpecialTermFarmSelector();
    }
    // }}}
}

/**
 *  vote_from_user�ơ��֥��Farm Selector���
 *  
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @access   public
 *  @package  GREE
 */
class Gree_GenericDao_Ranking_Vote_FromUserSpecialTermFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 100;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%d";
    // }}}

    // {{{ getTableName($dao, $type, $hint)
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ����������
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        // contest_id, user_sex��ɬ��
        if (empty($hint['contest_id']) || empty($hint['user_sex'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾����
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['contest_id'], $hint['user_sex']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
