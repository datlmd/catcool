<?php

abstract class Gree_Service_AvatarFeed_Object
{
    protected $_certified_user = null;

    protected function __construct()
    {
        if (is_null($this->_certified_user)){
            $this->_certified_user = $this->getCtfyInfo();
        }
    }

    protected final static function getModule($name)
    {
        return Gree_Service_AvatarFeed_Module::singleton($name);
    }

    protected final function getCtfyInfo()
    {
        $srv_id = getService('id');
        // Change Geteway if use mobile
        if (defined('IS_MSHOP') !== false) {
            $srv_id->setGateway(GREE_SERVICE_ID_GATEWAY_MOBILE);
        } else {
            $srv_id->setGateway(GREE_SERVICE_ID_GATEWAY_PC);
        }
        return $srv_id->getCertify();
    }

    // for unit test
    public function setUserIDtoCtfy($user_id)
    {
        $this->_certified_user->my = array(
            'user_id' => $user_id,
        );
    }
}
