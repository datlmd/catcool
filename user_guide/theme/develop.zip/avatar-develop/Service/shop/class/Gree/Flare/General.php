<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare.php';

class Gree_Service_Shop_Flare_General extends Gree_Service_Shop_Flare
{
    var $_time = null;
    var $_namespace = null;

    public function __construct($time = null, $namespace = null)
    {
        $this->_time = $time;
        $this->_namespace = $namespace;
    }

    // Cache Life Time
    protected function getExpireTime()
    {
        return $this->_time;
    }

    protected function getNameSpace()
    {
        return $this->_namespace;
    }

    public function getCache($user_id, $key)
    {
        if (empty($user_id) || empty($key)) {
            throw new Gree_Service_Shop_Exception('system error(FLSUP)', $code = '1000');
        }
        try {
            list($ret, $var) = parent::get($key . $user_id);
        } catch (Exception $e) {
            if ($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = self::FLARE_EMERGENCY_ERROR);
            }
        }

        return $ret;
    }

    public function setCache($user_id, $key, $cache)
    {
        if (empty($user_id) || empty($key)) {
            throw new Gree_Service_Shop_Exception('system error(FLRLT)', $code = '2000');
        }
        try {
            $ret = parent::set($key . $user_id, $cache);
        } catch (Exception $e) {
            // no action for exception
        }

        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }

    public function setCacheWithoutUserId($key, $cache)
    {
        if (empty($key)) {
            throw new Gree_Service_Shop_Exception('system error(FLRLT)', $code = '2000');
        }

        $ret = parent::set($key, $cache);
        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }

    public function getCacheWithoutUserId($key)
    {
        if (empty($key)) {
            throw new Gree_Service_Shop_Exception('system error(FLSUP)', $code = '1000');
        }
        try {
            list($ret, $var) = parent::get($key);
        } catch (Exception $e) {
            if ($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = self::FLARE_EMERGENCY_ERROR);
            }
        }

        return $ret;
    }

    public function set($key, $val)
    {
        throw new Exception();
    }

    public function get($key)
    {
        throw new Exception();
    }

    public function cas($key, $val, $version)
    {
        throw new Exception();
    }
}
