<?php

class Gree_Service_AvatarFeed_Processor_Block_List_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $block_list = array();
        $has_more = false;
        $show_all       = false;

        $mod_block = self::getModule('Block');

        if (!empty($this->input_values['show_all'])) {
            $show_all = $this->input_values['show_all'];
        }

        $block_user_ids = null;
        try {
            list($has_more, $block_user_ids) = $mod_block->getBlockListOrderInTime(
                $this->input_values['user_id'],
                $this->input_values['limit'],
                $this->input_values['offset']
            );
        } catch (Exception $e) {
            $msg = 'failed get block status.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_BLOCK_LIST_SHOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        if (is_null($block_user_ids)) {
            return array(
                $has_more,
                $block_list
            );
        }

        $mod_user = self::getModule('User');
        $block_list = $mod_user->appendUserInfo($block_user_ids, $show_all);

        return array(
            $has_more,
            $block_list
        );
    }
}