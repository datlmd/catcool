<?php

class Gree_Service_AvatarFeed_Processor_Follow_Import_Recommend
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $mod_appfeed   = self::getModule('AppFeed');
        $mod_recommend = self::getModule('RecommendUser');

        $import_number = GREE_SERVICE_AVATARFEED_IMPORT_RECOMMEND_NUMBER;
        try {
            // check exist table
            $is_exist_table = $mod_recommend->isExistTable();
            if ($is_exist_table == false) {
                $msg  = 'not exist recommend table';
                $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_RECOMMEND;
                new Gree_Service_AvatarFeed_Logger($msg, $code, $this->input_values);

                return false;
            }

            // start import process
            $rand_array = range(1, GREE_SERVICE_AVATARFEED_TOTAL_RECOMMEND_NUMBER);
            shuffle($rand_array);

            for ($i = 0; $i < $import_number; $i++) {
                // get user_id
                $import_user = $mod_recommend->getUserIdFromId($rand_array[$i]);

                if (is_null($import_user)) {
                    continue;
                }

                // add following
                $add_params        = array(
                    'user_id'        => $import_user,
                    'certified_user' => $this->input_values['user_id'],
                    'is_async'       => true
                );

                $follow_add_result = Gree_Service_AvatarFeed_Processor::execute(
                    'following_add',
                    $add_params
                );

                if ($follow_add_result == false) {
                    continue;
                }

                // destination entry
                list($has_more, $stream_data) = $mod_appfeed->getEntriesByFeedKey(
                    $import_user,
                    'user',
                    1,
                    null,
                    'batch'
                );

                if (isset($stream_data[0]) == false) {
                    continue;
                }

                $destinations   = array();
                $destinations[] = array(
                    'type'  => 'feed_key',
                    'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' .
                        GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $this->input_values['user_id']
                );
                $add_params     = array(
                    'entry_id'     => $stream_data[0]['entry_id'],
                    'destinations' => $destinations
                );

                // ignore add destination result
                $mod_appfeed->addDestination($add_params);
            }
        } catch (Exception $e) {
            $msg  = 'failed Import recommend user.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_RECOMMEND;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $this->input_values);

            return false;
        }

        return true;
    }
}