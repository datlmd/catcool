<?php

class Gree_Service_AvatarFeed_Processor_Follow_List_Lounge_Mutual
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $num = $this->input_values['num'];

        $mod_appfeed   = self::getModule('AppFeed');
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;
        $mod_avatar = self::getModule('Avatar');
        $mod_follow = self::getModule('Follow');

        $user_ids = $this->_fetchMutualLoungePostedUsers($num);

        $user_list = array();
        foreach ($user_ids as $user_id) {
            $user_info = $mod_user->selectByID($user_id);
            if (empty($user_info) || empty($user_info['nick_name'])) {
                continue;
            }

            $second_image = Gree_Service_Shop_SecondUtil::getPreviewUrlIncludeSecond($user_id);
            if (!empty($second_image)) {
                $img_url = $second_image;
            } else {
                $img_url = $mod_avatar->getAvatarImgUrl($user_id, GREE_SERVICE_AVATARFEED_CHANGE_IMG_SIZE);
            }

            list($following_count, $followed_count) = $mod_follow->getFollowCount($user_id);

            $user_list[] = array(
                'user_id' => $user_id,
                'nickname' => $user_info['nick_name'],
                'following_count' => $following_count,
                'followed_count' => $followed_count,
                'preview_url' => $img_url,
            );
        }

        return $user_list;
    }

    private function _getMutualLoungeUserId()
    {
        $registry = getService('shop')->getRegistry();
        $avatar_feed_lounge_info = $registry->getArray('avatar_feed_lounge_info');
        $mutual_lounge_info = $avatar_feed_lounge_info['official_user_list']['mutual1'];
        $mutual_lounge_user_id = (Config::get('state') == GREE_STATE_DEVELOPMENT) ? $mutual_lounge_info['dev_user_id'] : $mutual_lounge_info['user_id'];

        return $mutual_lounge_user_id;
    }

    private function _fetchMutualLoungePostedUsers($num)
    {
        $mutual_lounge_user_id = $this->_getMutualLoungeUserId();

        $avatar_feed   = Gree_Service_AvatarFeed::getInstance();
        $stream_params = array(
            'user_id'  => $mutual_lounge_user_id,
            'category' => GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
            'limit'    => $num + 10,
            'start_id' => null,
        );
        list($has_more, $stream_data) = $avatar_feed->process('official_stream_show', $stream_params);

        $user_ids = array();
        foreach ($stream_data as $entry) {
            $user_ids[] = $entry['content']['sender_id'];
        }
        $user_ids = array_unique($user_ids);
        $user_ids = array_slice($user_ids, 0, $num);

        return $user_ids;
    }
}
