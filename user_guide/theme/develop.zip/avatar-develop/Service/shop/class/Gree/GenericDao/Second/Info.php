<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Second/InfoDao.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_Second_InfoDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'second_info';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_second';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_second';

    /** @var ��Ͽ�������̾ */
    var $_auto_increment = '';

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',        // �ᥤ���user_id
        'second_user_id', // ������ɥ��Х�����user_id��life��selected�ȥ��(4 or 5)
        'display',        // ɽ������ɽ��
        'user_sex',       // ����
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_second_info_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'get_all_info' => array( // for td
            'sql' => 'SELECT * FROM __TABLE_NAME__ order by user_id'
        ),
        // }}}
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` int(11) unsigned NOT NULL,
                `second_user_id` tinyint(2) unsigned NOT NULL,
                `display` tinyint(2) unsigned NOT NULL,
                `user_sex` tinyint(2) unsigned NOT NULL,
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY `user_id` (`user_id`, `second_user_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__
                         (`user_id`, `second_user_id`, `display`, `user_sex`, `ctime`)
                      VALUES
                         (:user_id, :second_user_id, :display, :user_sex, NOW())'
        ),
        'update_second_info' => array(
            'sql' => 'UPDATE __TABLE_NAME__
                SET
                   display  = :display,
                   user_sex = :user_sex
                WHERE
                   user_id = :user_id
                   AND
                   second_user_id = :second_user_id'
        ),
        'reset_second_display' => array(
            'sql' => 'UPDATE __TABLE_NAME__
                SET
                   display  = :display
                WHERE
                   user_id = :user_id'
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }

}
