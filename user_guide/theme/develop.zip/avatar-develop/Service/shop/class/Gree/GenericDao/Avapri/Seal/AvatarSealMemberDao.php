<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
/**
 * Gree_GenericDao_AvapriSealAvatarSealMemberDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Seal_AvatarSealMemberDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'avatar_seal_member';
	/** @var primary key */
    var $_primary_key = array('seal_id', 'member_user_id');
    /** @var auto increment */
    var $_auto_increment = false;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'seal_id',
        'user_id',
        'member_id',
        'priority',
        'state',
        'ctime',
        'mtime'
    );

    var $_queries = array(
        // select----------------------
        'find_by_seal_id_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE seal_id = :seal_id AND state = :state',
        ),
            
        //for support tool
        'find_by_seal_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE seal_id = :seal_id',
        ),

        // update----------------------
        'update_seal_member_state' => array( // update max 3 recode.
            'sql' =>  'UPDATE __TABLE_NAME__ SET state = :new_state WHERE seal_id = :seal_id AND state=:state',
        ),
        'update_seal_member' => array(
            'sql' =>  'UPDATE __TABLE_NAME__ SET member_id = :member_id, member_user_id=:new_member_user_id WHERE seal_id = :seal_id AND member_user_id =:member_user_id',
        ),
        'update_seal_member_state_by_key' => array(
            'sql' =>  'UPDATE __TABLE_NAME__ SET state = :new_state WHERE seal_id = :seal_id and member_user_id=:member_user_id and state=:state',
        ),

       // insert----------------------
        'insert_seal_member' => array(
            'sql' =>  'INSERT INTO __TABLE_NAME__ (seal_id, user_id, member_id, member_user_id, priority, state, ctime)
                           VALUES (:seal_id, :user_id, :member_id, :member_user_id, :priority, :state, NOW()) 
                           ON DUPLICATE KEY UPDATE seal_id =:seal_id, user_id =:user_id, member_id =:member_id, member_user_id =:member_user_id, priority =:priority, state=:state'
        ),
        
        // create table ----------------
        'create_table' => array(
            'sql' => "
                 CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                      `seal_id` int(11) unsigned NOT NULL,
                      `member_user_id` int(11) unsigned NOT NULL,
                      `user_id` int(11) unsigned NOT NULL,
                      `member_id` int(11) unsigned NOT NULL,
                      `priority` tinyint(4) unsigned NOT NULL default '0',
                      `state` tinyint(4) unsigned NOT NULL default '0',
                      `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                      `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                      PRIMARY KEY  (`seal_id`,`member_user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
       // for gs query------------------
        'gc_records' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE seal_id = :seal_id AND user_id=:user_id AND state=:state',
        ),
    );
    
    function _init()
    {
        parent::_init();
    
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
?>
