<?php
/**
 * Gree_GenericDao_Shop_UserFarmSelector
 *
 * @author  Takahsi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */

if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
    define('GREE_GENERIC_DAO_SHOP_USER_FARM_SELECTOR_COUNT',   2);
} else {
    define('GREE_GENERIC_DAO_SHOP_USER_FARM_SELECTOR_COUNT', 100);
}
 /**
  * user_id �Τߤ򥭡��ˤ����ե�����ʬ������Ѥ��Ƥ�������
  * ��ȯ�����С���ٷڸ��Τ��ᡢ���ַϤȳ�ȯ�Ϥ�ʬ������ۤʤ�ޤ�
  *
  * ������㻲�ȡ�
  * Gree_GenericDao_Shop_UserDao
  */
class Gree_GenericDao_Shop_UserFarmSelector
    extends Gree_GenericDao_FarmSelector
{
    /** @var string table suffix format */
    var $_table_suffix_format = "_%02d";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        // check $hint[user_id]
        if (empty($hint['user_id']) || is_numeric($hint['user_id']) == false || $hint['user_id'] <= 0) {
            $error_msg  = sprintf('hint is empty. dao = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
        $user_id = $hint['user_id'];
        $postfix = (int)($user_id % GREE_GENERIC_DAO_SHOP_USER_FARM_SELECTOR_COUNT);

        // create table name
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
    // }}}
}
