<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	CampaignItemDao.php
 *
 *	@author		Tomoaki Sawa <sawa@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: ItemDao.php 40396 2008-12-10 07:06:18Z  $
 */
class Gree_GenericDao_Shop_Campaign_ItemDao extends Gree_GenericDao {
	var $_table_name = 'shop_campaign_item';
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';
	var $_primary_key = 'id';
	var $_auto_increment = true;
	var $_queries = array(
			'find_by_campaign_id' => array(
					'sql' => 'SELECT * FROM shop_campaign_item WHERE campaign_id=:campaign_id'
			),
			'find_by_campaign_ids' => array(
					'sql' => 'SELECT * FROM shop_campaign_item WHERE campaign_id IN (:campaign_ids)'
			),
			'find_by_item_id' => array(
					'sql' => 'SELECT * FROM shop_campaign_item WHERE item_id=:item_id'
			),
			'find_by_campaign_id_and_sex' => array(
					'sql' => 'SELECT * FROM shop_campaign_item WHERE campaign_id=:campaign_id AND item_sex=:item_sex'
			),
			'find_by_campaign_id_and_sex_and_type' => array(
					'sql' => 'SELECT * FROM shop_campaign_item WHERE campaign_id=:campaign_id AND item_sex=:item_sex AND item_type=:item_type'
			),
			'delete_by_campaign_id_and_sex_and_type' => array(
					'sql' => 'DELETE FROM shop_campaign_item WHERE campaign_id=:campaign_id AND item_sex=:item_sex AND item_type=:item_type'
			),
			'find_all' => array(
					'sql' => 'SELECT * FROM shop_campaign_item'
			),
	);
}
?>
