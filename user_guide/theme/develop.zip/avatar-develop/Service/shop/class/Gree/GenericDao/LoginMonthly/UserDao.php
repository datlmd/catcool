<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/LoginMonthly/UserDao.php
 * @package     GREE Avatar
 * @since       2018-06-04
 */
require_once(GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserLightFarmSelector.php');

/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_LoginMonthly_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'loginmonthly_user';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'user_id',
        'master_id',
        'access_days',
        'continue_days',
        'last_login_day',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_user_id'               => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        'find_by_user_id_and_master_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and master_id = :master_id',
        ],
        // }}}

        // {{{ update queries
        'entry'                         => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (master_id, user_id, access_days, continue_days, last_login_day, ctime) VALUES (:master_id, :user_id, :access_days, :continue_days, :last_login_day, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'                        => [
            'sql' => 'UPDATE __TABLE_NAME__ SET access_days = :access_days, continue_days = :continue_days, last_login_day = :last_login_day WHERE id = :id and last_login_day = :old_last_login_day',
        ],
        //debug only
        'delete_by_user_id' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        // }}}

        // {{{ create table
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `user_id` INT UNSIGNED NOT NULL,
                  `master_id` INT UNSIGNED NOT NULL,
                  `access_days` INT UNSIGNED NOT NULL DEFAULT '0',
                  `continue_days` INT UNSIGNED NOT NULL DEFAULT '0',
                  `last_login_day` INT UNSIGNED NOT NULL,
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `user_id_and_master_id`(`master_id`, `user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
    ];

    public function _init()
    {
        parent::_init();
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
}
