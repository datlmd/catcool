<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Gree_GenericDao_Market_Ticket
 *
 * @author  Norie Matsuda <norie.matsuda@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_TicketDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name        = 'market_ticket_master';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'id',
        'status',
        'name',
        'num',
        'type',
        'open_datetime',
        'expire_datetime',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ get_all
        'get_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_by_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id in (:ids)',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (status, name, num, type, open_datetime, expire_datetime, ctime) VALUES (:status, :name, :num, :type, :open_datetime, :expire_datetime, NOW())',
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status, name=:name, num=:num, type=:type, open_datetime=:open_datetime ,expire_datetime=:expire_datetime  WHERE id = :id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(11) unsigned NOT NULL auto_increment,
                `status` tinyint(2) NOT NULL default 0,
                `name` varchar(255) NOT NULL default \'\',
                `num` int(10) unsigned NOT NULL default 0,
                `type` int(10) unsigned NOT NULL default 0,
                `open_datetime` datetime NOT NULL default \'0000-00-00 00\:00\:00\',
                `expire_datetime` datetime NOT NULL default \'0000-00-00 00\:00\:00\',
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL default \'0000-00-00 00\:00\:00\',
                PRIMARY KEY  (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );
}
