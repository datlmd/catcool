<?php

class Gree_Service_AvatarFeed_Processor_Like_List_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $like_list = array();
        $has_more = false;

        $mod_appfeed = self::getModule('AppFeed');

        $like_user_ids = null;
        try {
            list($has_more,$like_user_ids) = $mod_appfeed->getLikeList($this->input_values);
        } catch (Exception $e){
            $msg     = 'failed get like list.';
            $code    =  Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_LIKE_LIST;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        if (is_null($like_user_ids)){
            return array(
                $has_more,
                $like_list
            );
        }

        $mod_user  = self::getModule('User');
        $like_list = $mod_user->appendUserInfo($like_user_ids);

        return array(
            $has_more,
            $like_list
        );
    }
}