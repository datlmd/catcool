<?php
/**
 * Gree_GenericDao_Stream_SettingDao
 *
 * @author  katsumi.zeniya
 * @package GREE
 */
require_once PATH_SRC_CLASS . 'Gree/GenericDao/UserIdFarmSelector.php';

class Gree_GenericDao_Stream_SettingDao extends Gree_GenericDao
{
    /** table devide num */
    const TABLE_DIVIDE_NUM = 5;

    /** @var table name */
    var $_table_name        = 'stream_setting';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'id',               // primary id
        'user_id',          // user uniq id
        'type',             // type no
        'value',            // setting value
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),

        // common queries
        'find_by_user_id_and_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND type = :type',
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, type, value, ctime) VALUES (:user_id, :type, :value, NOW())',
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET value = :value WHERE user_id = :user_id AND type = :type',
        ),

        // table control
        'create_table' => array(    // for batch
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                INT(10)     UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`           INT(10)     UNSIGNED NOT NULL,
                    `type`              INT(10)     UNSIGNED NOT NULL,
                    `value`             INT(10)     UNSIGNED NOT NULL,
                    `ctime`             DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                    `mtime`             TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE `user_id` (`user_id`, `type`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_UserIdFarmSelector(self::TABLE_DIVIDE_NUM);
    }
    // }}}
}
