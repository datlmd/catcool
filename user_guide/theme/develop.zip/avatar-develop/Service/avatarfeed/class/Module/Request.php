<?php

require_once 'HTTP/Request.php';
require_once GREE_SERVICE_AVATAR_ROOT . '/Service/shop/util.php';

class Gree_Service_AvatarFeed_Module_Request
    extends Gree_Service_AvatarFeed_Module_Base
{
    var $type   = null;
    var $path   = null;
    var $method = null;
    var $body   = null;

    var $resp_body = null;

    var $url;

    public function prepare()
    {
        $this->url = GREE_SERVICE_AVATARFEED_ENDPOINT . $this->path;
        if(gettype($this->body)=='array'){
            $this->body = json_encode($this->body);
        }
    }

    function getAuthorizationHeader()
    {
        $mod_oauth         = self::getModule('OAuth');
        $mod_oauth->body   = $this->body;
        $mod_oauth->method = $this->method;
        $mod_oauth->type   = $this->type;
        $mod_oauth->url    = $this->url;

        try {
            $authorization_header = $mod_oauth->generateAuthorizationHeader();
        } catch(Exception $e){
            throw new Gree_Service_AvatarFeed_Exception(
                $e->getMessage(),
                Gree_Service_AvatarFeed_Exception::E_OAuth_UNKNOWN
            );
        }

        return $authorization_header;
    }

    public function invoke()
    {
        $this->prepare();
        $authorization_header = $this->getAuthorizationHeader();

        $http_request = new HTTP_Request();

        if (Gree_Service_Shop_Util::isDev() == false) {
            list($proxy_host, $proxy_port) = Gree_Service_Shop_Util::getProxyUrl();
            if (!empty($proxy_host) && !empty($proxy_port)) {
                $http_request->setProxy($proxy_host, $proxy_port);
            }
        }

        if($this->method=="POST"){
            $http_request->setMethod(HTTP_REQUEST_METHOD_POST);
            $http_request->setBody($this->body);
        }
        $http_request->setURL($this->url);
        $http_request->addHeader('Content-Type', "application/json");
        $http_request->addHeader('Authorization', $authorization_header);
        $http_request->sendRequest();

        $code = $http_request->getResponseCode();
        $body = $http_request->getResponseBody();
        $content_type = $http_request->getResponseHeader('Content-Type');

        $resp = json_decode($body, true);
        $this->resp_body = $body;

        return array($code, $resp);
    }
}
