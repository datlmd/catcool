<?php

/**
 * Class Gree_GenericDao_Gacha_Fever_UserStatusDao
 */
class Gree_GenericDao_Gacha_Fever_UserStatusDao extends Gree_GenericDao
{

    /** @var �ơ��֥�̾ */
    public $_table_name = 'gacha_fever_user_status';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣 */
    public $_primary_key = 'user_id';

    /** @var �����������̾ */
    public $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    public $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    public $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    public $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �����ȥ��󥯥���� */
    public $_auto_increment = false;

    /** @var �ե������̾ */
    public $_field_names = [
        'user_id',
        'grade',
        'platinum_point',
        'last_gacha_date',
        'last_gacha_id',
        'daily_count',
        'mtime',
        'ctime',
    ];

    /**
     * @var �����������
     */
    public $_queries = [
        // {{{ ������
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` INT NOT NULL,
                `grade` INT NOT NULL,
                `platinum_point` INT NOT NULL,
                `last_gacha_date` DATETIME NOT NULL,
                `last_gacha_id` INT NOT NULL,
                `daily_count` INT NOT NULL default 0,
                `mtime` DATETIME NOT NULL default CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL default CURRENT_TIMESTAMP,
                PRIMARY KEY  (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ],
        'drop_table'   => [
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ],
        'insert'       => [
            'sql' => "INSERT IGNORE INTO __TABLE_NAME__ (user_id, grade, platinum_point, last_gacha_date, last_gacha_id, daily_count) values (:user_id, :grade, :platinum_point, :last_gacha_date, :last_gacha_id, :daily_count)",
        ],
        'delete'       => [
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE `user_id`=:user_id LIMIT 1",
        ],

        'update_user_status' => [
            'sql' => "UPDATE __TABLE_NAME__ SET grade=:grade, platinum_point=:platinum_point, last_gacha_date=:last_gacha_date, last_gacha_id=:last_gacha_id, daily_count=:daily_count WHERE user_id=:user_id",
        ],

        'update_daily_count' => [
            'sql' => "UPDATE __TABLE_NAME__ SET daily_count=:daily_count WHERE user_id=:user_id",
        ],
        'find_by_user_id'    => [
            'sql' => 'SELECT * FROM `__TABLE_NAME__` WHERE `user_id` = :user_id',
        ],

    ];

    public function _initFarmSelector()
    {
        $table_nums = GREE_CLI_TABLE_SHARD_NUMBER_USERID;

        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = GREE_CLI_TABLE_SHARD_NUMBER_USERID_DEVELOP;
        }

        $this->_farm_selector = new Gree_GenericDao_UserIdFarmSelector($table_nums);
    }
}
