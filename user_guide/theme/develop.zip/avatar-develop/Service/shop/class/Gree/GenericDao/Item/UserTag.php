<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Gree_GenericDao_Shop_Item_UserTagDao
 *
 * @author  Keisuke Kagiya <keisuke.kagiya@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Item_UserTagDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'item_user_tag';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_item_tags';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_item_tags';

    /** @var field names */
    var $_field_names = array(
        'id',               // ID
        'user_id',          // UserID
        'name',             // tag_name
        'status',           // Status(0:false,1:true)
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND status = 1',
        ),
        'find_by_usertag' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id AND user_id = :user_id AND status = 1',
        ),
        // }}}

        // {{{ update queries
        'entry' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, name, status, ctime)
                VALUES
                    (:user_id, :name, :status, NOW())
            ',
        ),
        'update' => array(
            'sql' => '
                UPDATE __TABLE_NAME__ SET name = :name WHERE id = :id AND user_id = :user_id AND status = 1
            ',
        ),
        'status_off' => array(
            'sql' => '
                UPDATE __TABLE_NAME__ SET status = 0 WHERE id = :id AND user_id = :user_id AND status = 1
            ',
        ),
        'last_insert_id' => array(
            'sql' => 'SELECT LAST_INSERT_ID()',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id`                  INT(10)     UNSIGNED NOT NULL AUTO_INCREMENT,
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `name`                VARCHAR(255) NOT NULL,
                  `status`              TINYINT(3)  UNSIGNED NOT NULL,
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`),
                  KEY `user_idx` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
