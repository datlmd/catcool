# Unit Test
このtestディレクトリはService/avatarfeed/以下のユニットテストを配置する場所です。

## 実行

```
単体テストの実行
sh Service/avatarfeed/test/run.sh Service/avatarfeed/test/class/Processor/Notification/AddTest.php
```

## Unit Testの作成
* `Gree_Service_AvatarFeed_Test_Base`を継承してください

# スケジュール
## Phase1
- [done] 既存のProcessor Testからsleep()を削除する
 * とりあえず、既存のテスト時間の短縮をおこなう
 * 現在、slave遅延用のsleepをいれているのでテストに時間がかかりすぎており、全体実行ができない
- [] sleep()を削除するためにテストを修正する(appfeed async)
  - [] Entry/Create/ RecentCoordinate.php
  - [] Follow/Random.php
  - [] Notification/Add.php
  - [] Notification/Remove.php
- [] sleep()を削除するためにテストを修正する(GenricDao)
  - [] Follow/Import/Check.php
  - [] Follow/Import/Link.php
  - [] Incentive/ADD.php
  - [] Like/Status/Show.php
- [] 既存のTestがないProcessorについてTestを作成する
 - [] Support/Entry/Create.php

## Phase2
- [ ] Unit Testの最適化
 * Moduleのtestを作成し、ProcessorのテストでMockをにおきかえれるようにするなど