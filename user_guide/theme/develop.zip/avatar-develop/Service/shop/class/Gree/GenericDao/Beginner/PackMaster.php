<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Beginner/PackMaster.php
 *
 * Gree_GenericDao_Beginner_PackMasterDao
 *
 * @package     GREE Avatar
 * @author      ikuko.tamura <z.ikuko.tamura@gree.net>
 */
class Gree_GenericDao_Beginner_PackMasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'pack_master';

    /** @var primary key */
    var $_primary_key = 'pack_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'pack_id',
        'name',
        'start_day',
        'status',
        'pack_type',
        'ctime',
        'mtime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all'          => [
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ],
        'find_by_id'        => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE pack_id = :pack_id',
        ],
        'find_by_status'    => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :status',
        ],
        'find_by_grade_and_status' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ AS pack INNER JOIN plan_master AS plan ON pack.pack_id = plan.pack_id WHERE pack.status = :status AND plan.grade = :grade',
        ],
        // }}}

        // {{{ update queries
        'entry'            => [
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (name, start_day, status, pack_type, ctime) VALUES (:name, :start_day, :status, :pack_type, NOW())',
        ],
        'update'           => [
            'sql' => 'UPDATE __TABLE_NAME__ SET name = :name, start_day = :start_day, status = :status, pack_type = :pack_type WHERE pack_id = :pack_id',
        ],
        // }}}
        'delete'           => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE pack_id = :pack_id',
        ],
        'create_table'     => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `pack_id` INT unsigned NOT NULL auto_increment,
                  `name` VARCHAR(255) NOT NULL,
                  `start_day` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `status` TINYINT unsigned NOT NULL,
                  `pack_type` VARCHAR(20) NOT NULL,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`pack_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ],
    ];
}
