<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Notification_AddTest
 *
 * this test is notification add
 */
final class Gree_Service_Avatarfeed_Test_Processor_Notification_AddTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;
    var $user_id;
    var $entry_sender_id;

    public function setUp() {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        }catch (Exception $e){}

        sleep(2);

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        }catch (Exception $e){}

        sleep(2);

        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        }catch (Exception $e){}

        sleep(2);

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        }catch (Exception $e){}

        sleep(2);

        $this->user_id = 548670;
        $this->entry_sender_id = 548662;
        //548672
        //548673
    }

    public function test_notification_add_new()
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $this->entry_sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_notification_add_new',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $this->entry_sender_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        $notification_params = array(
            'user_id'               => $this->user_id,
            'entry_category'        => 'notification_like',
            'notification_entry_id' => $entry_id,
            'destination_user'      => $this->entry_sender_id,
        );
        $is_success_add_notification = $this->avatar_feed->process('notification_add', $notification_params, $this->user_id);

        $this->assertTrue($is_success_add_notification);
        // slave delay
        sleep(2);
        list($has_more, $entries_data) = $this->module->getEntriesByFeedKey($this->entry_sender_id, GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        $entry = array_shift($entries_data);
        $this->assertEquals($entry['content']['sender_id'], $this->user_id);
        $this->assertEquals($entry['content']['attr']['entry_category'], 'notification_like');
        $this->assertEquals($entry['content']['attr']['notification_entry_id'], $entry_id);
        $this->assertEquals($entry['content']['attr']['notification_user'], serialize(array()));
        $this->assertEquals($entry['content']['attr']['notification_count'], 0);
    }


    /**
     * test1; add notification of incentive
     * expect: add_result == true
     */
    public function test_notification_incentive_add_new()
    {
        $notification_params         = array(
            'user_id'               => UNIT_TEST_USER_ID_1,
            'entry_category'        => 'notification_incentive',
            'notification_entry_id' => date("Y-m-d"),
            'destination_user'      => UNIT_TEST_USER_ID_1,
            'sum_point_value'       => 100
        );
        $is_success_add_notification = $this->avatar_feed->process('notification_add', $notification_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_success_add_notification);
        // slave delay
        sleep(2);
        list($has_more, $entries_data) = $this->module->getEntriesByFeedKey($this->entry_sender_id, GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        $entry = array_shift($entries_data);
        $this->assertEquals($notification_params['user_id'], $entry['content']['sender_id']);
        $this->assertEquals($notification_params['entry_category'], $entry['content']['attr']['entry_category']);
        $this->assertEquals($notification_params['notification_entry_id'], $entry['content']['attr']['notification_entry_id']);
        $this->assertEquals($notification_params['sum_point_value'], $entry['content']['attr']['incentive']);
        $this->assertEquals(serialize(array()), $entry['content']['attr']['notification_user']);
        $this->assertEquals(0, $entry['content']['attr']['notification_count']);
    }


    public function test_notification_add_exist_same_entry()
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $this->entry_sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_notification_add_new',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $this->entry_sender_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        $first_notification_params = array(
            'user_id'               => $this->user_id,
            'entry_category'        => 'notification_comment',
            'notification_entry_id' => $entry_id,
            'destination_user'      => $this->entry_sender_id,
        );
        $is_success_add_notification_first = $this->avatar_feed->process('notification_add', $first_notification_params,  $this->user_id);
        // slave delay
        sleep(2);
        $second_notification_params = array(
            'user_id'               => 548672,
            'entry_category'        => 'notification_comment',
            'notification_entry_id' => $entry_id,
            'destination_user'      => $this->entry_sender_id,
        );
        $is_success_add_notification_second = $this->avatar_feed->process('notification_add', $second_notification_params, 548672);

        $this->assertTrue($is_success_add_notification_second);
        // slave delay
        sleep(2);
        list($has_more, $entries_data) = $this->module->getEntriesByFeedKey($this->entry_sender_id, GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        $entry = array_shift($entries_data);
        $this->assertEquals($entry['content']['sender_id'], 548672);
        $this->assertEquals($entry['content']['attr']['entry_category'], 'notification_comment');
        $this->assertEquals($entry['content']['attr']['notification_entry_id'], $entry_id);
        $expected_notification_user = array(
            (string)$this->user_id
        );
        $this->assertEquals($entry['content']['attr']['notification_user'], serialize($expected_notification_user));
        $this->assertEquals($entry['content']['attr']['notification_count'], 0);

        $third_notification_params = array(
            'user_id'               => 548673,
            'entry_category'        => 'notification_comment',
            'notification_entry_id' => $entry_id,
            'destination_user'      => $this->entry_sender_id,
        );
        $is_success_add_notification_third = $this->avatar_feed->process('notification_add', $third_notification_params, 548673);

        $this->assertTrue($is_success_add_notification_third);
        // slave delay
        sleep(2);
        list($has_more, $entries_data) = $this->module->getEntriesByFeedKey($this->entry_sender_id, GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        $entry = array_shift($entries_data);
        $this->assertEquals($entry['content']['sender_id'], 548673);
        $this->assertEquals($entry['content']['attr']['entry_category'], 'notification_comment');
        $this->assertEquals($entry['content']['attr']['notification_entry_id'], $entry_id);
        $expected_notification_user = array(
            "548672"
        );
        $this->assertEquals($entry['content']['attr']['notification_user'], serialize($expected_notification_user));
        $this->assertEquals($entry['content']['attr']['notification_count'], 1);
    }

    public function test_notification_incentive_add_exist_same_entry()
    {
        $first_notification_params = array(
            'user_id'               => UNIT_TEST_USER_ID_1,
            'entry_category'        => 'notification_incentive',
            'notification_entry_id' => date("Y-m-d"),
            'destination_user'      => UNIT_TEST_USER_ID_1,
            'sum_point_value'       => 100
        );
        $is_success_add_notification_first = $this->avatar_feed->process('notification_add', $first_notification_params,  UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_success_add_notification_first);

        // slave delay
        sleep(2);

        $second_notification_params = array(
            'user_id'               => UNIT_TEST_USER_ID_1,
            'entry_category'        => 'notification_incentive',
            'notification_entry_id' => date("Y-m-d"),
            'destination_user'      => UNIT_TEST_USER_ID_1,
            'sum_point_value'       => 200
        );
        $is_success_add_notification_second = $this->avatar_feed->process('notification_add', $second_notification_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_success_add_notification_second);
        // slave delay
        sleep(2);

        list($has_more, $entries_data) = $this->module->getEntriesByFeedKey(UNIT_TEST_USER_ID_1, GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);

        $this->assertEquals(1, count($entries_data));
        $entry = array_shift($entries_data);
        $this->assertEquals($second_notification_params['user_id'], $entry['content']['sender_id']);
        $this->assertEquals($second_notification_params['entry_category'], $entry['content']['attr']['entry_category']);
        $this->assertEquals($second_notification_params['notification_entry_id'], $entry['content']['attr']['notification_entry_id']);
        $this->assertEquals($second_notification_params['sum_point_value'], $entry['content']['attr']['incentive']);
        $expected_notification_user = array(
            (string)UNIT_TEST_USER_ID_1
        );
        $this->assertEquals(serialize($expected_notification_user), $entry['content']['attr']['notification_user']);
        $this->assertEquals(0, $entry['content']['attr']['notification_count']);
    }

    /**
     * test1: delete old notification when count(notification) > notification_limit
     * expect: add_result == true
     *
     * GREE_SERVICE_AVATARFEED_NOTIFICATION_LIMIT_COUNT == 10 // dev
     * entry_owner ==  UNIT_TEST_USER_ID_1
     * like_user   ==  UNIT_TEST_USER_ID_2
     *
     */
    public function test_notification_add_limit_over()
    {
        // test1
        $create_entry_ids = array();
        for ($i = 0; $i <= GREE_SERVICE_AVATARFEED_NOTIFICATION_LIMIT_COUNT + 1; $i++) {
            list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
            $this->assertTrue($is_success_create_entry);
            $create_entry_ids[$i] = $entry_id;
        }

        sleep(2);

        foreach ($create_entry_ids as $entry_id) {
            $notification_params = array(
                'user_id'               => UNIT_TEST_USER_ID_2,
                'entry_category'        => 'notification_like',
                'notification_entry_id' => $entry_id,
                'destination_user'      => UNIT_TEST_USER_ID_1,
            );
            $is_success_add_notification = $this->avatar_feed->process('notification_add', $notification_params, UNIT_TEST_USER_ID_2);
            $this->assertTrue($is_success_add_notification);
            sleep(2);
        }

        sleep(2);

        list($has_more, $entries_data) = $this->module->getEntriesByFeedKey(UNIT_TEST_USER_ID_1, GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        $this->assertFalse($has_more);
        $this->assertEquals(10, count($entries_data));
        $this->assertEquals($create_entry_ids[GREE_SERVICE_AVATARFEED_NOTIFICATION_LIMIT_COUNT + 1], $entries_data[0]['content']['attr']['notification_entry_id']);
        $this->assertEquals($create_entry_ids[2], $entries_data[9]['content']['attr']['notification_entry_id']);
    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_notification_add',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}