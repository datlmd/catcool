<?php

/**
 * Logger.php
 *
 * @package GREE
 */

require_once PATH_SRC_ROOT . 'class/Gree/LogFactory.php';

class Gree_Service_Shop_Logger
    extends Gree_Logger
{
    // -------------------- [ properties ] -------------------------------------------- //

    private static  $instance       = null;
    private         $_crit_logger   = null;
    private         $_action_name   = '';

    // {{{ getInstance
    public static function getInstance($frontend_action_name = '')
    {
        if (self::$instance === null) {
            self::$instance = new self($frontend_action_name);
        }
        return self::$instance;
    }
    // }}}

    // -------------------- [ public method ] -------------------------------------------- //

    // {{{ _createLog
    public function &_createLog()
    {
        $log = Log::factory(
            'file',
            Config::get('debug_path') . strftime('shop.' . Config::get('app_log_filename'), time()),
            "[action: $this->_action_name]",
            array('timeFormat' => '%Y-%m-%d %H:%M:%S', 'append' => true, 'mode' => 0666),
            Config::get('app_log_level')
        );
        return $log;
    }
    // }}}

    // {{{ crit
    public function crit($object, $error = null)
    {
        // get info
        $level      = PEAR_LOG_CRIT;
        $backtraces = debug_backtrace();
        $text       = '';
        $this->_log($object, $error, $level, $backtraces);
        if (array_key_exists(0, $backtraces)) {
            $backtrace = $backtraces[0];
            $text .= sprintf(
                $this->_debugtrace_format,
                $backtrace['function'],
                $backtrace['line'],
                $backtrace['file'],
                $backtrace['class']
            );
        }
        if (is_object($error)) {
            $text .= ' ' . $error->toString();
        } else {
            $text .= var_export($object, true);
        }

        // write log
        $this->_crit_logger->log($text, $level);
        if ($this->_flush === true) {
            $this->_crit_logger->flush();
        }
    }
    // }}}

    // {{{ __construct
    function __construct($action_name = "")
    {
        $this->_action_name = $action_name;
        parent::__construct();
        $this->_crit_logger = Log::factory(
            'file',
            PATH_LOG_ROOT . 'shop/critical/' . strftime("%Y%m%d.log", time()),
            "[action: $this->_action_name]",
            array('timeFormat' => '%Y-%m-%d %H:%M:%S', 'append' => true, 'mode' => 0666),
            PEAR_LOG_CRIT
        );
    }
    // }}}

}

