<?php

class Gree_GenericDao_Survey_MasterDao extends Gree_GenericDao
{
    var $_table_name = 'customer_survey_master';

    var $_primary_key = 'id';

    var $_master_dsn = 'gree://master/avatar_user';

    var $_slave_dsn  = 'gree://slave/avatar_user';

    var $_auto_increment = false;

    var $_field_names = [
        'id',
        'hash',
        'type',
        'title',
        'status',
        'incentive_type',
        'incentive_ids',
        'incentive_count',
        'private_uids',
        'start_dt',
        'end_dt',
        'mtime',
        'ctime',
    ];

    var $_queries = [

        //Refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC'
        ],
        'find_by_status_dt' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :status and start_dt <= :now and :now <= end_dt ORDER BY end_dt'
        ],
        'find_by_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id'
        ],
        'find_by_hash' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE hash = :hash'
        ],

        //update status
        'update_status' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE id = :id'
        ],

        //update all attr
        'update_all' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET
            type = :type,
            title = :title,
            status = :status,
            link_type = :link_type,
            incentive_type  = :incentive_type,
            incentive_ids   = :incentive_ids,
            incentive_count = :incentive_count,
            private_uids  = :private_uids,
            start_dt = :start_dt,
            end_dt = :end_dt
            WHERE id = :id',
        ],

        //Insert query
        'insert' => [
            'sql' => "
            INSERT IGNORE INTO __TABLE_NAME__ (
                    hash,
                    type,
                    title,
                    link_type,
                    incentive_type,
                    incentive_ids,
                    incentive_count,
                    start_dt,
                    end_dt,
                    private_uids,
                    ctime
                )
                VALUES(
                    :hash,
                    :type,
                    :title,
                    :link_type,
                    :incentive_type,
                    :incentive_ids,
                    :incentive_count,
                    :start_dt,
                    :end_dt,
                    :private_uids,
                    NOW()
                )
            ",
        ],

       //Create table query 
        'create' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `hash` varchar(255) NOT NULL,
                `type` tinyint(4) UNSIGNED NOT NULL,
                `title` varchar(255) NOT NULL,
                `status` tinyint(4) UNSIGNED NOT NULL DEFAULT 0,
                `incentive_type` tinyint(4) UNSIGNED NOT NULL,
                `incentive_ids` varchar(255) NOT NULL,
                `incentive_count` int(10) UNSIGNED NOT NULL,
                `private_uids` text NOT NULL,
                `link_type` tinyint(4) UNSIGNED DEFAULT NULL,
                `start_dt` timestamp NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_dt` timestamp NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                KEY `hash_idx` (`hash`),
                KEY `status_idx` (`status`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
        'add_column_link_type' => [
            'sql' => 'ALTER TABLE __TABLE_NAME__ ADD COLUMN `link_type` tinyint(4) UNSIGNED NOT NULL AFTER `private_uids`'
        ],
        'update_default_link_type' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET `link_type` = 1'
        ],
    ];

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
