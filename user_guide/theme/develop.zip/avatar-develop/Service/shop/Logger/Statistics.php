<?php
/**
 * Statistics.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */

/**
 * logger class of shop service
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @access  public
 * @package GREE
 */
class Gree_Service_Shop_Logger_Statistics
{
    /* -------- [ public methods ] -------- */

    // {{{ __construct
    /**
     * constructor
     */
    public function __construct()
    {
        // do nothing
    }
    // }}}

    /* -------- [ public methods ] -------- */

    // {{{ _getLogActionName
    /**
     * get action name for log
     *
     * @access  protected
     * @param   string      $action the action name
     * @return  string              the action name
     */
    protected function _getLogActionName($action)
    {
        if (defined('IS_AVATAR_PC')) {
            $action .= '_pc';
        } else if (defined('IS_AVATAR_TOUCH')) {
            $action .= '_touch';
        } else if (defined('HOST_SHOP_DYNAMIC') && HOST_SHOP_DYNAMIC == HOST_TSHOP) {
            $action .= '_touch';
        } else if (Gree_Ggp_Domain::isTLDNet()) {
            $action .= '_touch';
        }

        return $action;
    }
    // }}}

    // {{{ _appendNetLog($item)
    /**
     * append is_tld_net and is_app to array
     *
     * @access  protected
     * @param   array   $item   the item to append net log
     */
    protected function _appendNetLog($item)
    {
        $is_tld_net = 0;
        $is_app     = 0;
        if (Gree_Ggp_Domain::isTLDNet()) {
            $is_tld_net = 1;
            $cc = getService('cc');
            if (Gree_Service_Cc_Foundation_UserAgent_App::isApp()) {
                $is_app = 1;
            }
            mb_convert_variables('eucJP-win', mb_internal_encoding(), $item);
        }
        $item['is_tld_net'] = $is_tld_net;
        $item['is_app']     = $is_app;

        return $item;
    }
    // }}}
}
