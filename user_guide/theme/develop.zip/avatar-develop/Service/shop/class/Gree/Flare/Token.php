<?php
/**
 * service/shop/class/Flare/Token.php
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare.php';

class Gree_Service_Shop_Flare_Token extends Gree_Service_Shop_Flare
{
    var $_expire_time = 600; //sec

    public function __construct($expire_time = null) {
        if (!empty($expire_time)) {
            $this->_expire_time = $expire_time;
        }
    }

    // token life time
    protected function getExpireTime() {
        return $this->_expire_time; //sec
    }

    // cache name space
    protected function getNameSpace() {
        return 'token';
    }

    // dead token
    const INVALID_TOKEN = 'dead_token';

    // {{{ isValid
    /**
     * check token is valid
     *
     * @access  public
     * @return  booken
     */
    public function isValid($user_id, $token, $size = null) {
        if (empty($token)) {
            throw new Gree_Service_Shop_Exception('system error(FLTK)', $code = 1000);
        }
        $ret = parent::get(self::getNameSpace() . '_' . $user_id);
        if (!$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            if ($err_code == MEMCACHED_DATA_DOES_NOT_EXIST || $err_code == MEMCACHED_NOTFOUND) {
                throw new Gree_Service_Shop_Exception('system error(FLTK)', $code = 1001);
            }
            return false;
        }

        list($val, $ver) = $ret;

        if (!is_null($size)) {
            $val = substr($val, 0, $size);
        }

        if ($val !== $token) {
            return false;
        }

        return parent::cas(self::getNameSpace() . '_' . $user_id, self::INVALID_TOKEN, $ver);
    }
    // }}}
    // {{{ initialize
    /**
     * set token to flare
     *
     * @access  public
     * @return  string token
     */
    public function initialize($user_id, $key, $uniq = null) {
        if (empty($user_id) || empty($key)) {
            throw new Gree_Service_Shop_Exception('system error(FLTK)', $code = 2000);
        }

        if (is_null($uniq)) {
            $token = 'f_' . md5($key.$user_id.mt_rand());
        } else {
            $token = 'f_' . md5($key.$uniq);
        }
        
        try {                                                                         
            $ret = parent::set(self::getNameSpace() . '_' . $user_id, $token);        
            return $token;                                                            
        }                                                                             
        catch (Exception $e) {                                      
            return false;                                                             
        } 
    }
    // }}}

    /**
     * check token is valid(return string)
     *
     * @access  public
     * @return  booken
     */
    public function isValidForString($user_id, $token, $size = null) {
        if (empty($token)) {
            throw new Gree_Service_Shop_Exception('system error(FLTK)', $code = 1000);
        }
        $ret = parent::get(self::getNameSpace() . '_' . $user_id);
        if (!$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            if ($err_code == MEMCACHED_DATA_DOES_NOT_EXIST || $err_code == MEMCACHED_NOTFOUND) {
                throw new Gree_Service_Shop_Exception('system error(FLTK)', $code = 1001);
            }
            return 'false';
        }

        list($val, $ver) = $ret;

        if (!is_null($size)) {
            $val = substr($val, 0, $size);
        }

        if ($val !== $token) {
            return $val == self::INVALID_TOKEN ? self::INVALID_TOKEN : 'false';
        }

        $cas_ret = parent::cas(self::getNameSpace() . '_' . $user_id, self::INVALID_TOKEN, $ver);
        return $cas_ret ? 'true' : 'false';
    }

    // public =>  private
    public function set($key, $val) { throw new Exception(); }
    public function get($key) { throw new Exception(); }
    public function cas($key, $val, $version) { throw new Exception(); }
}
