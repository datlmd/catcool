<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Loginbonus/Master.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Loginbonus_MasterDao extends Gree_GenericDao_Apc {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'loginbonus_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'login_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'login_id',
        'name',
        'status',
        'price',
        'sheet_num',
        'item_num',
        'start_date',
        'end_date',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(                 // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY login_id DESC',
        ),
        'find_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_id=:login_id',
        ),
        'find_by_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status=:status',
        ),
        // }}}

        // {{{ ��������������
        'insert' => array(              // for support tool
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (name, price, sheet_num, item_num, start_date, end_date, ctime)
                VALUES
                    (:name, :price, :sheet_num, :item_num, :start_date, :end_date, NOW())',
        ),
        'update_by_id' => array(  // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET name=:name, status=:status, price=:price, sheet_num=:sheet_num, item_num=:item_num, start_date=:start_date, end_date=:end_date WHERE login_id=:login_id',
        ),
        // }}}

        // {{{ �ơ��֥����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `login_id`          int(11) unsigned NOT NULL auto_increment,
                    `name`              varchar(255) NOT NULL DEFAULT '',
                    `status`            tinyint(2) unsigned NOT NULL default '0',
                    `price`             int(11) unsigned NOT NULL default '0',
                    `sheet_num`         int(11) unsigned NOT NULL default '0',
                    `item_num`          int(11) unsigned NOT NULL default '0',
                    `start_date`        datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `end_date`          datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`login_id`),
                    KEY `status` (`status`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
