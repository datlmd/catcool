<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/ProfilePurchaseDao.php
 *
 *  @author   Jun Tomioka <jun.tomioka@gree.net>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_ProfilePurchaseDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var �ơ��֥�̾ */
    var $_table_name = 'profile_purchase';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_analytics';

    /** @var ��Ͽ�������̾ */
    var $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'datetime',
        'service',
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'action1',
        'shop',
        'action2',
        'profile_id',
        'price',
        'ctime',
    );

    /** @var namespace */
    var $_namespace = null;

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id`                  INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                  `datetime`            DATETIME NOT NULL,
                  `service`             VARCHAR(16) NOT NULL,
                  `user_id`             BIGINT(20) UNSIGNED NOT NULL,
                  `user_sex`            TINYINT(4),
                  `user_age`            TINYINT(4),
                  `phone_carrier`       TINYINT(4),
                  `action1`             VARCHAR(16),
                  `shop`                VARCHAR(16),
                  `action2`             VARCHAR(16),
                  `price`               INT(10) UNSIGNED,
                  `profile_id`          INT(10) UNSIGNED,
                  `ctime`               DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY  (`id`),
                  KEY `datetime` (`datetime`),
                  KEY `service` (`service`),
                  KEY `user_id` (`user_id`),
                  KEY `user_sex` (`user_sex`),
                  KEY `user_age` (`user_age`),
                  KEY `phone_carrier` (`phone_carrier`),
                  KEY `action1` (`action1`),
                  KEY `shop` (`shop`),
                  KEY `action2` (`action2`),
                  KEY `price` (`price`),
                  KEY `profile_id` (`profile_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        // }}}
        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ),
        'count_by_user_id' => array(
            'sql' => 'SELECT COUNT(item_id) AS cnt, SUM(price) AS sum FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
    );
    /** #@- */
}
