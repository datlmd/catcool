<?php

class Gree_Service_AvatarFeed_Processor_Support_Score_List_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_score;
    var $mod_user;
    var $top_score_list_key;

    protected function invoke()
    {
        $this->mod_score = self::getModule('Score');
        $this->mod_user  = self::getModule('User');
        $this->top_score_list_key = $this->mod_score->_getTopScoreListKey($this->input_values['category'], $this->input_values['date']);

        try {
            list($top_score_list, $token) = $this->mod_score->get($this->input_values['cycle'], $this->top_score_list_key);
            // not exist top score list
            if (is_array($top_score_list) == false) {
                return array();
            }

            unset($top_score_list['min']);
            arsort($top_score_list);

            $appended_score_list = $this->mod_user->appendScoreUserInfoAndSupportInfo($top_score_list);
        } catch (Exception $e) {
            $msg = 'failed get list.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_SCORE_LIST_SHOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array();
        }

        /**
         * $stream_data = array(
         *   [0] => array(  // rank score
         *     'user_id' => xxxxxxx,
         *     'nick_name' => xxxxxx,
         *     'img_url'   => xxxxxxx,
         *     'is_following' => boolean
         *   )
         * )
         */
        return $appended_score_list;
    }
}
