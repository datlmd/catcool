<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Official_Stream_Show
 */
class Gree_Service_AvatarFeed_Processor_Official_Stream_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return
     *   has_more
     *   stream_data
     */
    protected function invoke()
    {
        $mod_follow = self::getModule('Follow');

        $avatar_feed = Gree_Service_AvatarFeed::getInstance();
        $create_params = array(
            'user_id'  => $this->input_values['user_id'],
            'category' => $this->input_values['category'],
            'limit'    => $this->input_values['limit'],
            'start_id' => $this->input_values['start_id'],
        );

        list($has_more, $stream_data) = $avatar_feed->process('stream_show', $create_params);

        if (empty($stream_data)) {
            return array(
                $has_more,
                $stream_data
            );
        }

        try {
            foreach ($stream_data as $key => $data) {
                $is_following = $mod_follow->getFollowingUser($data['content']['sender_id']);
                if ($is_following) {
                    $stream_data[$key]['is_following'] = true;
                }
            }
        } catch (Exception $e) {
            $msg     = 'failed get follow status.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_OFFICIAL_STREAM_SHOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $has_more,
            $stream_data
        );
    }
}
