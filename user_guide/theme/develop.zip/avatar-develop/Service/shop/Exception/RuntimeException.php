<?php
/**
 *
 */
class Gree_Service_Shop_Exception_RuntimeException
    extends Gree_Service_Shop_Exception
{
}
