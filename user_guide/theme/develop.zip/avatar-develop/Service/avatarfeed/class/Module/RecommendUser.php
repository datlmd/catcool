<?php

class Gree_Service_AvatarFeed_Module_RecommendUser
    extends Gree_Service_AvatarFeed_Module_Base
{
    public function getUserIdfromId($id)
    {
        $accessor = Cascade::getAccessor('avatar_feed#recommend_user');
        $values   = array(
            'id' => $id
        );
        $result   = $accessor->findFirst('find_by_id', $values);

        if (is_null($result)) {
            return null;
        }

        return $result['user_id'];
    }

    public function isExistTable($date = null)
    {
        $accessor = Cascade::getAccessor('avatar_feed#recommend_user');

        $params = array();
        if (is_null($date) == false) {
            $params['date'] = $date;
        }

        $find_result = $accessor->find('check_table', $params);
        if (empty($find_result)) {
            return false;
        } else {
            return true;
        }
    }
}