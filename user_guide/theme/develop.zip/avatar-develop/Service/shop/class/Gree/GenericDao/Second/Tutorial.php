<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Second/TutorialDao.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_Second_TutorialDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'second_tutorial';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_second';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_second';

    /** @var ��Ͽ�������̾ */
    var $_auto_increment = '';

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',        // �ᥤ���user_id
        'state',          // ���ơ�����
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_state_by_user_id' => array(
            'sql' => 'SELECT state FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),  
        // }}}
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` int(11) unsigned NOT NULL,
                `state` tinyint(2) unsigned NOT NULL DEFAULT '0',
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY `user_id` (`user_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__
                         (`user_id`, `state`, `ctime`)
                      VALUES
                         (:user_id, :state, NOW())'
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__
                SET
                   state = :state
                WHERE
                   user_id = :user_id'
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }

}
