<?php
/**
 * service/shop/class/Flare/Event.php
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare.php';

class Gree_Service_Shop_Flare_Event extends Gree_Service_Shop_Flare
{
    var $_time = null;
    var $_key  = null;
    
    public function __construct($time, $key = null) {
        if (empty($time) || !is_numeric($time)) {
            throw new Gree_Service_Shop_Exception("empty cache expire time(FLENT)");
        }
        $this->_time = $time;
        $this->_key  = $key;
    }

    // Cache Life Time
    protected function getExpireTime() {
        return $this->_time;
    }
    protected function getNameSpace() {
        return 'event';
    }
    // {{{ error function code
    // general
    const FLARE_ERROR_CODE_GENERAL_GET = 0000;
    const FLARE_ERROR_CODE_GENERAL_SET = 0100;
    // }}}

    // *******************************************
    // for general
    // *******************************************
    // {{{
    public function getUserEvent($user_id) {
        if (empty($user_id)) {
            throw new Gree_Service_Shop_Exception('system error(FLENT)', $code = self::FLARE_ERROR_CODE_GENERAL_GET);
        }
        try {
            list($ret, $var) = parent::get($this->_key . $user_id);
        } catch (Exception $e) {
            if($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                throw new Gree_Service_Shop_Exception("System Error(FLENT)", $code = parent::FLARE_EMERGENCY_ERROR);
            }
        }

        return $ret;
    }
    // }}}
    // {{{
    public function setUserEvent($user_id, $state) {
        if (empty($user_id)) {
            throw new Gree_Service_Shop_Exception('system error(FLENT)', $code = self::FLARE_ERROR_CODE_GENERAL_SET);
        }
        try {
            $ret = parent::set($this->_key . $user_id, $state);
        } catch (Exception $e) {
            // no action for exception
        }

        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }
    // }}}
    // *******************************************
    // for raid
    // *******************************************
    // {{{
    public function getRaidEvent() {
        try {
            list($ret, $var) = parent::get($this->_key);
        } catch (Exception $e) {
            if($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                throw new Gree_Service_Shop_Exception("System Error(FLENT)", $code = parent::FLARE_EMERGENCY_ERROR);
            }
        }

        return $ret;
    }
    // }}}
    // {{{
    public function setRaidEvent($data) {
        try {
            $ret = parent::set($this->_key, $data);
        } catch (Exception $e) {
            // no action for exception
        }

        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }
    // }}}
    public function getBeginnerSaleTargetEvent() {
        try {
            list($ret, $var) = parent::get($this->_key);
        } catch (Exception $e) {
            if($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                throw new Gree_Service_Shop_Exception("System Error(FLENT)", $code = parent::FLARE_EMERGENCY_ERROR);
            }
        }

        return $ret;
    }
    // }}}
    // {{{
    public function setBeginnerSaleTargetEvent($state) {
        try {
            $ret = parent::set($this->_key, $state);
        } catch (Exception $e) {
            // no action for exception
        }

        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }
    // public =>  private
    public function set($key, $val) { throw new Exception(); }
    public function get($key) { throw new Exception(); }
    public function cas($key, $val, $version) { throw new Exception(); }
}
