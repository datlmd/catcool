<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Comment_Delete
 */
class Gree_Service_AvatarFeed_Processor_Comment_Delete
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;
    /**
     * @return array|void
     *
     * return is_delete, comment_id
     *
     * if failed delete comment then
     *   is_delete  == false
     *   comment_id == null
     */
    protected function invoke()
    {
        $is_delete_success = false;
        $comment_id        = null;

        $this->mod_appfeed = self::getModule('AppFeed');

        $is_enable_delete  = $this->_isEnableDelete();
        try {
            if ($is_enable_delete) {
                list($is_delete_success, $comment_id) = $this->mod_appfeed->deleteComment($this->input_values);
            }
        } catch (Exception $e) {
            $msg     = 'failed delete comment.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_COMMENT_DELETE;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $is_delete_success,
            $comment_id
        );
    }

    /**
     * @return bool
     */
    public function _isEnableDelete()
    {
      try {
          list($is_exist_comment, $comment) = $this->mod_appfeed->getComment($this->input_values);

          if ($is_exist_comment == false) {
              return false;
          }

          if ($is_exist_comment
              && $this->_certified_user->my['user_id'] == $comment[0]['content']['sender_id']
          ) {
              return true;
          }
          list($is_exist_entry, $entry) = $this->mod_appfeed->getEntry($comment[0]['parent_entry_id']);

          if ($is_exist_entry
              && $this->_certified_user->my['user_id'] == $entry[0]['content']['sender_id']
          ) {
              return true;
          } else {
              return false;
          }
      } catch (Exception $e) {
          $msg     = 'failed get comment.';
          $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_COMMENT_DELETE;
          $context = $this->input_values;

          new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

          return false;
      }
    }
}
