<?php

    class Gree_GenericDao_Analytics_GachaReport_PayGachaReleaseTermDao extends Gree_GenericDao
    {
        var $_table_name = 'pay_gacha_release_term';
        var $_primary_key = 'id';
        var $_updated_at_column = 'mtime';
        var $_created_at_column = 'ctime';
        var $_master_dsn = 'gree://master/avatar_analytics';
        var $_slave_dsn = 'gree://slave/avatar_analytics';
        var $_auto_increment = true;
        var $_field_names = [
            'id',
            'gacha_id',
            'type_id',
            'sex',
            'pay',
            'pay_uu',
            'login_uu',
            'gacha_page_uu',
            'mtime',
            'ctime',
        ];
        var $_queries = [
            'create'                 => [
                'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `gacha_id` INT NOT NULL,
                    `type_id` INT NOT NULL,
                    `sex` TINYINT UNSIGNED NOT NULL,
                    `pay` INT UNSIGNED NOT NULL DEFAULT 0,
                    `pay_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `login_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `gacha_page_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    UNIQUE (gacha_id, sex),
                    INDEX type_id (type_id)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
            ],
            'insert_or_update_pay'         => [
                'sql' => "INSERT INTO __TABLE_NAME__ (`gacha_id`, `type_id`, `sex`, `pay`, `pay_uu`, `ctime`)
                      VALUES (:gacha_id, :type_id, :sex, :pay, :pay_uu, NOW())
                      ON DUPLICATE KEY UPDATE `pay` = VALUES(pay), `pay_uu` = VALUES(pay_uu)",
            ],
            'insert_or_update_login_uu'    => [
                'sql' => "INSERT INTO __TABLE_NAME__ (`gacha_id`, `type_id`, `sex`, `login_uu`, `gacha_page_uu`, `ctime`)
                      VALUES (:gacha_id, :type_id, :sex, :login_uu, :gacha_page_uu, NOW())
                      ON DUPLICATE KEY UPDATE `login_uu` = VALUES(login_uu), `gacha_page_uu` = VALUES(gacha_page_uu)",
            ],
            'find_by_gacha_id'             => [
                'sql' => "SELECT * FROM __TABLE_NAME__ WHERE `gacha_id` <> -1 AND `gacha_id` = :gacha_id ORDER BY `gacha_id` DESC, `sex`",
            ],
            'find_by_gacha_id_and_sex'              => [
                'sql' => "SELECT * FROM __TABLE_NAME__ WHERE `gacha_id` <> -1 AND `gacha_id` = :gacha_id AND `sex` = :sex ORDER BY `gacha_id` DESC, `sex`",
            ],
            'find_by_gacha_ids'              => [
                'sql' => "SELECT * FROM __TABLE_NAME__ WHERE `gacha_id` <> -1 AND `gacha_id` in (:gacha_ids) ORDER BY `gacha_id` DESC, `sex`",
            ],
            'find_by_gacha_ids_and_sex'              => [
                'sql' => "SELECT * FROM __TABLE_NAME__ WHERE `gacha_id` <> -1 AND `gacha_id` in (:gacha_ids) AND `sex` = :sex ORDER BY `gacha_id` DESC, `sex`",
            ],
        ];
    }
