<?php
/**
 *  Cascade Configuration
 */
return $cascade_config = array(
    'system' => array(
        // {{{ log
        'log' => array(
            'level' => 7,
            'dir'   => array(
                // �ǥե���Ƚ�����
                'default' => '/var/log/cascade',
                // ���顼��˽�������ѹ�������
                'emerg'   => NULL,
                'alert'   => NULL,
                'crit'    => NULL,
                'err'     => NULL,
                'warning' => NULL,
                'notice'  => NULL,
                'info'    => NULL,
                'debug'   => NULL,
            ),
        ),
        // }}}
        // {{{ log#sql
        'log#sql : log' => array(
            'dir' => array(
                'default' => '/home/gree/log/mysql',
                'err'     => '/home/gree/log/error/mysql',
                'debug'   => '/home/gree/log/error/debug/mysql',
            ),
        ),
        // }}}
        // {{{ log#kvs
        'log#kvs : log' => array(
            'dir' => array(
                'default' => '/home/gree/log/kvs',
                'err'     => '/home/gree/log/error/kvs',
                'debug'   => '/home/gree/log/error/debug/kvs',
            ),
        ),
        // }}}
        // {{{ dsn-config-gree
        'dsn-config-gree' => array(
            // gree(mysql)
            'mysql.var'     => 'db_config_list',
            //'mysql.path'    => PATH_ROOT.'/etc/mysql.ini.php',
            'mysql.path'    => '/home/gree/xgree/avatar/Service/avatarfeed/test/conf/mysql.ini.php',
            // gree(memcache)
            'memcache.var'  => 'memcache_config_list',
            'memcache.path' => PATH_ROOT.'/etc/memcache.ini.php',
            // gree(flare)
            'flare.var'     => 'flare_config_list',
            'flare.path'    => PATH_ROOT.'/etc/flare.ini.php',
            // gree(squall)
            'squall.var'    => 'squall_config_list',
            'squall.path'   => PATH_ROOT.'/etc/squall.ini.php',
        ),
        // }}}
    ),
    'schema' => array(
        /**
         *  ���饹̾��prefix, suffix������򵭽Ҥ���
         *  - �ǡ����ؤΥ���������������뤿�������Ǥ��롣
         *  - ���������ϼ��Τ褦�˼�������롣
         *     $ac = Cascade::getAccessor(${��������̾});
         *
         *     ${��������̾} = ${̾������}${���ѥ졼��}${���̻ҤȤʤ�}
         *     ${���ѥ졼��} = ɸ��Ǥ� # �Ȥʤ�
         *
         *  - ${̾������} = ���ꥻ�������Ȥ��ƴ���Ū������򵭽Ҥ��롣
         *
         *  (��:)
         *  'xxx : default' => array(
         *    'dataformat.prefix'  => 'Gree_Service_XXX_Cascade_DataFormat',
         *    'gateway.prefix'     => 'Gree_Service_XXX_Cascade_Gateway',
         *    ),
         *
         *  �����ꤷ�����
         *
         *    Cascade::getAccessor('xxx#user_item')
         *    => Gree_Service_XXX_Cascade_DataFormat_User_Item
         *    => Gree_Service_XXX_Cascade_Gateway_User_Item
         *
         *  �Ȥ�������̾����褬�����
         *    ( _ �ϥǥ��쥯�ȥꡦ���ѥ졼����ǧ�������)
         */
        // {{{ default
        'default' => array(
            'dataformat' => array(
                'prefix' => 'Cascade_DataFormat',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Cascade_Gateway',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ async
        'async' => array(
            'dataformat' => array(
                'prefix' => 'Async_Cascade_',
                'suffix' => 'DataFormat',
            ),
            'gateway'    => array(
                'prefix' => 'Async_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ knight
        'knight : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Knight_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Knight_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ gundam
        'gundam : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Gundam_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Gundam_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ pirate
        'pirate : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Pirate_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Pirate_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ dig
        'dig : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Dig_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Dig_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ pet
        'pet : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Pet_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Pet_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // {{{ onpuxie
        'onpuxie : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Onpuxie_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Onpuxie_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),

        // }}}
        // {{{ monster
        'monster : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Monster_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Monster_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ lgc-blog
        'lgc_blog : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Blog_Legacy_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Blog_Legacy_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ lgc_blog-map
        'lgc_blog_map : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Blog_Legacy_Cascade_DataFormat_Mapping_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Blog_Legacy_Cascade_Gateway_Mapping_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ sns
        'sns : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Sns_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Sns_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ like
        'like : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Like_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Like_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ community
        'community : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Community_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Community_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ spread
        'spread : default' => array(
              'dataformat' => array(
                  'prefix' => 'Gree_Service_Spread_Cascade_DataFormat_',
                  'suffix' => NULL,
              ),
              'gateway'    => array(
                  'prefix' => 'Gree_Service_Spread_Cascade_Gateway_',
                  'suffix' => NULL,
              ),
        ),
        // }}}
        'avatar_feed : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_AvatarFeed_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_AvatarFeed_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // {{{ snsapi
        'snsapi : default' => array(
              'dataformat' => array(
                  'prefix' => 'Gree_Service_Snsapi_Cascade_DataFormat_',
                  'suffix' => NULL,
              ),
              'gateway'    => array(
                  'prefix' => 'Gree_Service_Snsapi_Cascade_Gateway_',
                  'suffix' => NULL,
              ),
        ),
        // }}}

        // {{{ animal
        'animal : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Animal_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Animal_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ user
        'user : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_User_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_User_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ userplus
        'userplus : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Userplus_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Userplus_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ id
        'id : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Id_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Id_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ oauth2
        'oauth2 : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Oauth2_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Oauth2_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ ggpproxy
        'ggpproxy : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Ggpproxy_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Ggpproxy_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ ggp
        'platformapp : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Platformapp_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Platformapp_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        'user : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_User_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_User_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ ggpviolation
        'violation : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Violation_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Violation_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{
        'restoration : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Restoration_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Restoration_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ patrol
        'patrol : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Patrol_Cascade_DataFormat_',
                 'suffix' => NULL,
             ),
             'gateway'    => array(
                 'prefix' => 'Gree_Service_Patrol_Cascade_Gateway_',
                 'suffix' => NULL,
             ),
        ),
        // }}}
        // {{{ defense
        'defense : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Defense_Cascade_DataFormat_',
                 'suffix' => NULL,
             ),
             'gateway'    => array(
                 'prefix' => 'Gree_Service_Defense_Cascade_Gateway_',
                 'suffix' => NULL,
             ),
        ),
        // }}}
        // {{{ classifier
        'classifier : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Classifier_Cascade_DataFormat_',
                 'suffix' => NULL,
             ),
             'gateway'    => array(
                 'prefix' => 'Gree_Service_Classifier_Cascade_Gateway_',
                 'suffix' => NULL,
             ),
        ),
        // }}}
        // {{{ support
        'support : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Support_Cascade_DataFormat_',
                 'suffix' => NULL,
             ),
             'gateway'    => array(
                 'prefix' => 'Gree_Service_Support_Cascade_Gateway_',
                 'suffix' => NULL,
             ),
        ),
        // }}}
        // {{{ ranking
        'ranking : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Ranking_Cascade_',
                'suffix' => 'DataFormat',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Ranking_Cascade_',
                'suffix' => 'Gateway',
            ),
       ),
       // }}}
       // {{{ platform
       'platform : default' => array(
           'dataformat' => array(
               'prefix' => 'Gree_Service_Platform_Cascade_DataFormat_',
               'suffix' => NULL,
           ),
           'gateway'    => array(
               'prefix' => 'Gree_Service_Platform_Cascade_Gateway_',
               'suffix' => NULL,
           ),
       ),
       // }}}
        // {{{ pfpayment
        'pfpayment : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Pfpayment_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Pfpayment_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ sgp
        'sgp : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Sgp_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Sgp_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ ggp_developer
        'developer : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Developer_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Developer_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ ggp_developer
        'pfdeveloper : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Pfdeveloper_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Pfdeveloper_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ ggp game portal
        'announce : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Announce_Cascade_DataFormat_',
                 'suffix' => NULL
             ),
             'gateway' => array(
                 'prefix' => 'Gree_Service_Announce_Cascade_Gateway_',
                 'suffix' => NULL
             )
        ),
        'docs : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Docs_Cascade_DataFormat_',
                 'suffix' => NULL
             ),
             'gateway' => array(
                 'prefix' => 'Gree_Service_Docs_Cascade_Gateway_',
                 'suffix' => NULL
             )
        ),
        'gameportal : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Gameportal_Cascade_DataFormat_',
                 'suffix' => NULL
             ),
             'gateway' => array(
                 'prefix' => 'Gree_Service_Gameportal_Cascade_Gateway_',
                 'suffix' => NULL
             )
        ),
        'apps : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Apps_Cascade_DataFormat_',
                 'suffix' => NULL
             ),
             'gateway' => array(
                 'prefix' => 'Gree_Service_Apps_Cascade_Gateway_',
                 'suffix' => NULL
             )
        ),
        'media : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Media_Cascade_DataFormat_',
                 'suffix' => NULL
             ),
             'gateway' => array(
                 'prefix' => 'Gree_Service_Media_Cascade_Gateway_',
                 'suffix' => NULL
             )
        ),
        'mediadata : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Mediadata_Cascade_DataFormat_',
                'suffix' => NULL
            ),
            'gateway' => array(
                'prefix' => 'Gree_Service_Mediadata_Cascade_Gateway_',
                'suffix' => NULL
            )
        ),
        // }}}
        // {{{ payment
        'payment : default' => array(
             'dataformat' => array(
                 'prefix' => 'Gree_Service_Payment_Cascade_DataFormat_',
                 'suffix' => NULL
             ),
             'gateway' => array(
                 'prefix' => 'Gree_Service_Payment_Cascade_Gateway_',
                 'suffix' => NULL
             )
        ),
        // }}}
        // {{{ land
        'land : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Land_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Land_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ marketapp
        'marketapp : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Marketapp_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Marketapp_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ image
        'image : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Image_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Image_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ control center
        'cc_geo_ip' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Cc_Cascade_DataFormat_Geo_Ip_',
                'suffix' => NULL,
                ),
            'gateway' => array(
                'prefix' => 'Gree_Service_Cc_Cascade_Gateway_Geo_Ip_',
                'suffix' => NULL,
                ),
            ),
        'cc_entity : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Cc_Cascade_DataFormat_Entity_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Cc_Cascade_Gateway_Entity_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ item tracer
        'item-tracer' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_ItemTracker_Cascade_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_ItemTracker_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ GREE Platform Delivery Tools
        'deliver' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Deliver_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Deliver_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        'deliverytools' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Deliverytools_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Deliverytools_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        'addressuploader' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Addressuploader_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Addressuploader_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        //{{ social graph
        'graph : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Graph_Cascade_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Graph_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ solr
        'solr : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Solr_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Solr_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ GREE rd
        'rd' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Rd_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Rd_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ news
        'news' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_News_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_News_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ newsinternal
        'newsinternal' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Newsinternal_Cascade_DataFormat_',
                'suffix' => NULL,
            ),  
            'gateway'    => array(
                'prefix' => 'Gree_Service_Newsinternal_Cascade_Gateway_',
                'suffix' => NULL,
            ),  
        ),  
        // }}}
        // {{{ weather
        'weather' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Weather_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Weather_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ npf
        'npf' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Npf_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway' => array(
                'prefix' => 'Gree_Service_Npf_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ shortener
        'shortener' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Shortener_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway' => array(
                'prefix' => 'Gree_Service_Shortener_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ dic
        'dic' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Dic_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Dic_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ messenger
        'messenger' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Messenger_Cascade_DataFormat_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Messenger_Cascade_Gateway_',
            ),
        ),
        // }}}
        // {{{ appfeed
        'appfeed' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Appfeed_Cascade_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Appfeed_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ lily
        'lily' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Lily_Cascade_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Lily_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        'lilyapp' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Lilyapp_Cascade_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Lilyapp_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ tracker
        'tracker' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Tracker_Cascade_DataFormat_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Tracker_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ stadmaster 
        'stadmaster' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Stadmaster_Cascade_DataFormat_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Stadmaster_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ forum
        'forum' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Forum_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Forum_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ rt 
        'rt' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Rt_Cascade_DataFormat_',
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Rt_Cascade_',
                'suffix' => 'Gateway',
            ),
        ),
        // }}}
        // {{{ fortuneggp
        'fortuneggp' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Fortuneggp_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Fortuneggp_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ chat
        'chat : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_Chat_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_Chat_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
        // {{{ worldcup
        'worldcup : default' => array(
            'dataformat' => array(
                'prefix' => 'Gree_Service_WorldCup_Cascade_DataFormat_',
                'suffix' => NULL,
            ),
            'gateway'    => array(
                'prefix' => 'Gree_Service_WorldCup_Cascade_Gateway_',
                'suffix' => NULL,
            ),
        ),
        // }}}
    ),
);
