<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/MasterItem.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Raid_Marche_MasterItemDao extends Gree_GenericDao_Apc {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'master_raid_marche_item';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'item_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    //var $_master_dsn = 'gree://master/avatar_print';
    var $_master_dsn = 'gree://master/avatar_raid';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    //var $_slave_dsn = 'gree://slave/avatar_print';
    var $_slave_dsn = 'gree://slave/avatar_raid';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array('id', 'event_id', 'item_id', 'level', 'price', 'point', 'mtime', 'ctime');

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id' => array( 
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id=:id',
        ),
        'find_by_event_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id=:event_id',
        ),
        'find_by_event_id_and_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id=:event_id AND item_id=:item_id',
        ),
        // }}}

        // {{{ ��������������
        'insert' => array(                  // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (event_id, item_id, level, price, point, ctime) VALUES(:event_id, :item_id, :level, :price, :point, NOW())',
        ),
        'update_by_id' => array(  // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET event_id=:event_id, item_id=:item_id, level=:level, price=:price, point=:point WHERE id=:id',
        ),
        'delete_by_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id=:id',
        ),
        // }}}

        // {{{ �ơ��֥����
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`        int(11) unsigned NOT NULL auto_increment,
                `event_id`  int(11) unsigned NOT NULL DEFAULT 0,
                `item_id`   int(11) unsigned NOT NULL DEFAULT 0,
                `level`     int(11) unsigned NOT NULL DEFAULT 0,
                `price`     int(11) unsigned NOT NULL DEFAULT 0,
                `point`     int(11) unsigned NOT NULL DEFAULT 0,
                `mtime`     timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime`     datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                UNIQUE KEY `item_id` (`event_id`,`item_id`)
            ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis",
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );
}
