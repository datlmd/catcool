<?php
/**
 * Gree_GenericDao_Market_ItemFarmSelector
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_MarketFarmSelector
    extends Gree_GenericDao_FarmSelector
{
    /** @var string table suffix format */
    var $_table_suffix_format   = "_%d";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        // check $hint[market_id]
        if (!array_key_exists('market_id', $hint) || is_null($hint['market_id'])) {
            $error_msg  = sprintf('hint is empty. dao = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        } else if (!is_numeric($hint['market_id']) || $hint['market_id'] <= 0) {
            $error_msg  = sprintf('wrong hint = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
        $market_id = (int) $hint['market_id'];

        // create table name
        $farm       = sprintf($this->_table_suffix_format, $market_id);
        $table_name = sprintf('%s%s', $dao->_getTableName(), $farm);

        return $table_name;
    }
    // }}}
}
