<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Following_Add
 */
class Gree_Service_AvatarFeed_Processor_Following_Add
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return bool|void
     *
     * flow is
     *   check is async
     *   add following
     *   increment following count
     *   check is blocked
     *   add followed
     *   increment followed count
     */
    protected function invoke()
    {
        $add_result = true;

        $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOWING_ADD;
        $context = $this->input_values;

        $certified_user = $this->_certified_user->my['user_id'];
        if (array_key_exists('is_async', $this->input_values) && $this->input_values['is_async'] && array_key_exists('certified_user', $this->input_values)) {
            $certified_user = $this->input_values['certified_user'];
        }

        $mod_follow = self::getModule('Follow');
        $mod_block  = self::getModule('Block');

        try {
            $add_following_result = $mod_follow->addFollowingUser(
                $this->input_values['user_id'],
                $certified_user
            );

            if ($add_following_result == false) {
                $msg = 'failed add following user.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }

            $increment_following_result = $mod_follow->incrementFollowCount(
                'following',
                $certified_user
            );

            if ($increment_following_result == false) {
                $msg = 'failed increment following count.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }

            // if user is block user then not followed
            $is_block = $mod_block->getBlockUser(
                $certified_user,
                $this->input_values['user_id']
            );

            if ($is_block) {
                return $add_result;
            }

            $add_followed_result = $mod_follow->addFollowedUser(
                $certified_user,
                $this->input_values['user_id']
            );

            if ($add_followed_result == false) {
                $msg = 'failed add followed user.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }

            $increment_followed_result = $mod_follow->incrementFollowCount(
                'followed',
                $this->input_values['user_id']
            );

            if ($increment_followed_result == false) {
                $msg = 'failed increment followed count.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }


            // フォロー通知
            $shop_service = getService('shop');
            $silencer = $shop_service->getFlareFollowNotificationSilencer();
            if ($silencer->isSilentTime($certified_user, $this->input_values['user_id']) == false) {
                $notification_params = array(
                    'user_id'               => $certified_user,
                    'entry_category'        => 'notification_follow',
                    'notification_entry_id' => $this->input_values['user_id'],
                    'destination_user'      => $this->input_values['user_id'],
                );
                $avatar_feed = Gree_Service_AvatarFeed::getInstance();
                $avatar_feed->process('notification_add', $notification_params);
            }

            $silencer->setSilencer($certified_user, $this->input_values['user_id']);

        } catch (Exception $e) {
            $msg = 'failed add following user.';
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            $add_result = false;
        }

        return $add_result;
    }
}
