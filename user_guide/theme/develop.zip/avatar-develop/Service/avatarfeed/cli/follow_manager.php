<?php

require_once("/home/gree/xgree/avatar/Service/avatarfeed/cli/Base.php");

/**
 * Class Gree_Service_AvatarFeed_Cli_FollowManager
 *
 * useage is https://git.gree-dev.net/gist/yuki-hada/29338
 */
class Gree_Service_AvatarFeed_Cli_FollowManager
    extends Gree_Service_AvatarFeed_Cli_Base
{
    public $log_dir = '/home/gree/log/statistics/shop/avatar_feed/cli';

    public function main()
    {
        $this->_initialize();

        $this->_print_header('follow_manager');

        $this->short_opt = "m:u:t:f:";
        $this->opt_names = array(
            'update_following_count=',
            'update_followed_count=',
            'start_date=',
            'end_date=',
            'dry_run='
        );
        $this->input_opt_list = $this->_get_parse_arg_list();

        try {
            $set_options = $this->_set_option_value();
            $this->_invoke($set_options);
        } catch (Exception $e) {
            printf("finish with error. \n");
        }

        $this->_print_footer();
    }

    public function _find_input_option($option)
    {
        $option_name = null;
        $option_value = null;

        switch ($option[0]) {
            case 'm':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'mode';
                $option_value = $option[1];
                break;
            case 'u':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'user_id';
                $option_value = $option[1];
                break;
            case 't':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'target_id';
                $option_value = $option[1];
                break;
            case 'f':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'file_path';
                $option_value = $option[1];
                break;
            case '--update_following_count':
                $option_name = 'update_following_count';
                $option_value = $option[1];
                break;
            case '--update_followed_count':
                $option_name = 'update_followed_count';
                $option_value = $option[1];
                break;
            case '--start_date':
                $option_name = 'start_date';
                $option_value = $option[1];
                break;
            case '--end_date':
                $option_name = 'end_date';
                $option_value = $option[1];
                break;
            case '--dry_run':
                $option_name = 'dry_run';
                $option_value = $option[1];
                break;
            default:
                printf("please input mode \n");
                throw new Exception();
        }

        return array(
            $option_name,
            $option_value,
        );
    }

    public function _invoke($option)
    {
        switch ($option['mode']) {
            case 'show_follow_count':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }

                $this->_show_follow_count($option);
                break;
            case 'show_relation':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['target_id'])) {
                    printf("need target_id.\n");

                    throw new Exception();
                }

                $this->_show_relation($option);
                break;
            case 'update_follow_count':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }

                $this->_update_follow_count($option);
                break;
            case 'add_following':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['target_id'])) {
                    printf("need target_id.\n");
                    throw new Exception();
                }

                $this->_add_following($option);
                break;
            case 'add_following_by_user_list':
                if (!isset($option['user_id']) && !isset($option['target_id'])) {
                    printf("need param user_id or target_id.\n");
                    throw new Exception();
                }
                if (isset($option['user_id']) && isset($option['target_id'])) {
                    printf("duplicate param user_id or target_id.\n");
                    throw new Exception();
                }
                if (!isset($option['file_path'])) {
                    printf("need file_path.\n");
                    throw new Exception();
                }
                if (!file_exists($option['file_path'])) {
                    printf("not found file.\n");
                    throw new Exception();
                }
                $user_data = array();
                $file_path = $option['file_path'];
                $fh = @fopen($file_path, "r");
                if ($fh) {
                    while (!feof($fh)) {
                        $buffer = fgets($fh, 4096);
                        $data = preg_split("/[\s,]+/", $buffer);
                        if (empty($data[0])) {
                            continue;
                        }
                        $user_data[] = $data[0];
                    }
                    fclose($fh);
                }

                if (empty($user_data)) {
                    printf("not found user by file.\n");
                    throw new Exception();
                }

                $target_fixity = true;
                if (isset($option['user_id'])) {
                    $target_fixity = false;
                }

                $count_added = 0;
                foreach ($user_data as $user_id) {
                    if (!is_numeric($user_id) || $user_id < 0) {
                        continue;
                    }
                    if ($target_fixity) {
                        $option['user_id'] = $user_id;
                    } else {
                        $option['target_id'] = $user_id;
                    }
                    $this->_print_line();

                    $is_following = $this->module_follow->getFollowingUser($option['target_id'], $option['user_id']);
                    if ($is_following) {
                        printf('user already followed. user_id: %d, target_id: %d' . "\n", $option['user_id'], $option['target_id']);
                    } else {
                        $count_added++;
                        printf('user not followed yet. user_id: %d, target_id: %d' . "\n", $option['user_id'], $option['target_id']);
                        if (!isset($option['dry_run'])) {
                            $this->_add_following($option);
                        }
                    }
                    usleep(10000);
                }
                $this->_print_line();
                printf('count_added: %d'. "\n", $count_added);

                break;
            case 'remove_following':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['target_id'])) {
                    printf("need target_id.\n");
                    throw new Exception();
                }

                $this->_remove_following($option);
                break;
            case 'add_followed':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['target_id'])) {
                    printf("need target_id.\n");
                    throw new Exception();
                }

                $this->_add_followed($option);
                break;
            case 'add_followed_by_user_list':
                if (!isset($option['user_id']) && !isset($option['target_id'])) {
                    printf("need param user_id or target_id.\n");
                    throw new Exception();
                }
                if (isset($option['user_id']) && isset($option['target_id'])) {
                    printf("duplicate param user_id or target_id.\n");
                    throw new Exception();
                }

                if (!isset($option['file_path'])) {
                    printf("need file_path.\n");
                    throw new Exception();
                }
                if (!file_exists($option['file_path'])) {
                    printf("not found file.\n");
                    throw new Exception();
                }
                $user_data = array();
                $file_path = $option['file_path'];
                $fh = @fopen($file_path, "r");
                if ($fh) {
                    while (!feof($fh)) {
                        $buffer = fgets($fh, 4096);
                        $data = preg_split("/[\s,]+/", $buffer);
                        if (empty($data[0])) {
                            continue;
                        }
                        $user_data[] = $data[0];
                    }
                    fclose($fh);
                }
                if (empty($user_data)) {
                    printf("not found user by file.\n");
                    throw new Exception();
                }

                $target_fixity = true;
                if (isset($option['user_id'])) {
                    $target_fixity = false;
                }

                $count_added = 0;
                foreach ($user_data as $user_id) {
                    if (!is_numeric($user_id) ||  $user_id < 0) {
                        continue;
                    }
                    if ($target_fixity) {
                        $option['user_id'] = $user_id;
                    } else {
                        $option['target_id'] = $user_id;
                    }
                    $this->_print_line();

                    $is_followed = $this->module_follow->getFollowedUser($option['target_id'], $option['user_id']);
                    if ($is_followed) {
                        printf('user already followed. user_id: %d, target_id: %d' . "\n", $option['user_id'], $option['target_id']);
                    } else {
                        $count_added++;
                        printf('user not followed yet. user_id: %d, target_id: %d' . "\n", $option['user_id'], $option['target_id']);
                        if (!isset($option['dry_run'])) {
                            $this->_add_followed($option);
                        }
                    }
                    usleep(10000);
                }
                $this->_print_line();
                printf('count_added: %d'. "\n", $count_added);
                break;
            case 'remove_followed':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['target_id'])) {
                    printf("need target_id.\n");
                    throw new Exception();
                }

                $this->_remove_followed($option);
                break;
            case 'manual_update_follow_count':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['update_following_count'])) {
                    printf("need update_following_count.\n");
                    throw new Exception();
                }
                if (!isset($option['update_followed_count'])) {
                    printf("need update_followed_count.\n");
                    throw new Exception();
                }

                $this->_manual_update_follow_count($option);
                break;
            case 'initialize_follow_status':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }

                $this->_initialize_follow_status($option);
                break;
            //revert_to_link_and_check_has_been_imported
            case 'revert_following_count':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }

                $this->_revert_following_count($option);
                break;
            case 'get_followed_user_list_from_standby':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['start_date'])) {
                    printf("need start_date.\n");
                    throw new Exception();
                }
                if (!isset($option['end_date'])) {
                    printf("need end_date.\n");
                    throw new Exception();
                }

                $this->_get_followed_user_list_from_standby($option);
                break;
            case 'add_user_to_block_from_followed_list':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['start_date'])) {
                    printf("need start_date.\n");
                    throw new Exception();
                }

                $this->_add_user_to_block_from_followed_list($option);
                break;
            case 'remove_following_user_by_term':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['start_date'])) {
                    printf("need start_date.\n");
                    throw new Exception();
                }
                $this->_remove_following_user_by_term($option);
                break;
            default:
                printf("please input exist mode\n");
                throw new Exception();
        }
    }

    public function _show_follow_count($option)
    {
        printf("show follow count \n");
        printf("user_id: " . $option['user_id'] . "\n");

        list($following_count, $followed_count) = $this->module_follow->getFollowCount($option['user_id']);

        printf("following_count: " . $following_count . "\n");
        printf("followed_count: " . $followed_count . "\n");
    }

    public function _show_relation($option)
    {
        printf("show relation \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("target_id: " . $option['target_id'] . "\n");

        $is_following_target = ($this->module_follow->getFollowingUser($option['target_id'], $option['user_id'])) ? 'true' : 'false';
        $is_followed_target = ($this->module_follow->getFollowedUser($option['target_id'], $option['user_id'])) ? 'true' : 'false';

        printf("is following to target: " . $is_following_target . "\n");
        printf("is followed  from target: " . $is_followed_target . "\n");
    }

    public function _update_follow_count($option)
    {
        printf("update follow count \n");
        printf("user_id: " . $option['user_id'] . "\n");

        list($before_following_count, $before_followed_count) = $this->module_follow->getFollowCount($option['user_id']);


        printf("before following_count: " . $before_following_count . "\n");
        printf("before followed_count: " . $before_followed_count . "\n");

        $this->_print_line();

        $no_exist_user_list = array();
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;

        printf("check following user \n");
        $offset_user_id = 0;
        $has_more = true;
        while ($has_more) {
            printf("offset: " . $offset_user_id . "\n");
            printf("count no exist user: " . count($no_exist_user_list) . "\n");
            $following_user_list = $this->module_follow->getFollowingListByFollowingUser($offset_user_id, $option['user_id'], 100);

            // check exist user
            foreach ($following_user_list as $following_user) {
                $user_info = $mod_user->selectByID($following_user['following_user_id']);

                if ($user_info == false) {
                    $no_exist_user_list[] = $following_user['following_user_id'];
                }
            }

            if (count($following_user_list) < 100) {
                $has_more = false;
            }

            printf("count get user: " . count($following_user_list) . "\n");

            $offset_user = array_pop($following_user_list);
            $offset_user_id = $offset_user['following_user_id'];
        }

        $this->_print_line();

        printf("count no exist user: " . count($no_exist_user_list) . "\n");
        printf("no exist user list  \n");
        foreach ($no_exist_user_list as $no_exist_user) {
            printf($no_exist_user . "\n");
        }

        $is_delete_no_exist_user = false;
        if (count($no_exist_user_list) > 0) {
            printf("is delete no exist user from following(yes/no)?");
            $is_delete_no_exist_user = fgets(STDIN);
        }

        if (trim($is_delete_no_exist_user) == 'yes') {
            foreach ($no_exist_user_list as $no_exist_user) {
                $result = $this->module_follow->removeFollowingUser($no_exist_user, $option['user_id']);
                printf($no_exist_user . ": " . $result . "\n");
            }
        }

        // sleep for replication
        sleep(2);

        $this->_print_line();

        printf("count following user \n");
        $after_following_user_count = 0;
        $offset_user_id = 0;
        $has_more = true;
        while ($has_more) {
            printf("offset: " . $offset_user_id . "\n");
            $following_user_list = $this->module_follow->getFollowingListByFollowingUser($offset_user_id, $option['user_id'], 100);

            $after_following_user_count = $after_following_user_count + count($following_user_list);

            if (count($following_user_list) < 100) {
                $has_more = false;
            }

            printf("count get user: " . count($following_user_list) . "\n");

            $offset_user = array_pop($following_user_list);
            $offset_user_id = $offset_user['following_user_id'];
        }

        printf("count after following user: " . $after_following_user_count . "\n");

        if ($before_following_count != $after_following_user_count) {
            printf("is update following count (yes/no)?");
            $is_update_following_count = fgets(STDIN);

            $following_count = $before_following_count;
            if (trim($is_update_following_count) == 'yes') {
                $result = ($this->module_follow->updateFollowCount($option['user_id'], $after_following_user_count, $before_followed_count)) ? 'true' : 'false';
                printf("result: " . $result . "\n");

                $following_count = $after_following_user_count;

                list($updated_following_count, $updated_followed_count) = $this->module_follow->getFollowCount($option['user_id']);

                printf("before following_count: " . $before_following_count . "\n");
                printf("before followed_count: " . $before_followed_count . "\n");
                printf("updated following_count: " . $updated_following_count . "\n");
                printf("updated followed_count: " . $updated_followed_count . "\n");

            }
        } else {
            printf("following count is true \n");
            $following_count = $before_following_count;
        }

        $this->_print_line();

        printf("count followed user \n");
        $offset_user_id = 0;
        $has_more = true;
        $no_exist_user_list_followed = array();
        while ($has_more) {
            printf("offset: " . $offset_user_id . "\n");
            list($has_next, $followed_user_list) = $this->module_follow->getFollowedListByFollowedUser($offset_user_id, $option['user_id'], 100);

            // check exist user
            foreach ($followed_user_list as $followed_user) {
                $user_info = $mod_user->selectByID($followed_user);

                if ($user_info == false) {
                    $no_exist_user_list_followed[] = $followed_user;
                }
            }

            if (count($followed_user_list) < 100) {
                $has_more = false;
            }

            printf("count get user: " . count($followed_user_list) . "\n");

            $offset_user = array_pop($followed_user_list);
            $offset_user_id = $offset_user;
        }

        printf("count no exist user: " . count($no_exist_user_list_followed) . "\n");
        printf("no exist user list  \n");
        foreach ($no_exist_user_list_followed as $no_exist_user) {
            printf($no_exist_user . "\n");
        }

        $is_delete_no_exist_user = false;
        if (count($no_exist_user_list_followed) > 0) {
            printf("is delete no exist user from followed(yes/no)?");
            $is_delete_no_exist_user = fgets(STDIN);
        }

        if (trim($is_delete_no_exist_user) == 'yes') {
            foreach ($no_exist_user_list_followed as $no_exist_user) {
                $result = $this->module_follow->removeFollowedUser($no_exist_user, $option['user_id']);
                printf($no_exist_user . ": " . $result . "\n");
            }
        }

        $this->_print_line();

        // sleep for replication
        sleep(2);

        $after_followed_user_count = 0;
        $has_more = true;
        $offset_user_id = 0;
        while ($has_more) {
            printf("offset: " . $offset_user_id . "\n");
            list($has_next, $followed_user_list) = $this->module_follow->getFollowedListByFollowedUser($offset_user_id, $option['user_id'], 100);

            $after_followed_user_count = $after_followed_user_count + count($followed_user_list);

            if (count($followed_user_list) < 100) {
                $has_more = false;
            }

            printf("count get user: " . count($followed_user_list) . "\n");

            $offset_user = array_pop($followed_user_list);
            $offset_user_id = $offset_user;
        }

        printf("count after followed user: " . $after_followed_user_count . "\n");

        if ($before_followed_count != $after_followed_user_count) {
            printf("is update followed count (yes/no)? \n");
            $is_update_followed_count = fgets(STDIN);

            if (trim($is_update_followed_count) == 'yes') {
                $result = ($this->module_follow->updateFollowCount($option['user_id'], $following_count, $after_followed_user_count)) ? 'true' : 'false';
                printf("result: " . $result . "\n");
                list($updated_following_count, $updated_followed_count) = $this->module_follow->getFollowCount($option['user_id']);

                printf("before following_count: " . $before_following_count . "\n");
                printf("before followed_count: " . $before_followed_count . "\n");
                printf("updated following_count: " . $updated_following_count . "\n");
                printf("updated followed_count: " . $updated_followed_count . "\n");
            }
        } else {
            printf("followed count is true \n");
        }
    }

    public function _add_following($option)
    {
        printf("add following \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("target_id: " . $option['target_id'] . "\n");

        $result = ($this->module_follow->addFollowingUser($option['target_id'], $option['user_id'])) ? 'true' : 'false';

        printf('result: ' . $result . "\n");

        if ($result == 'true') {
            $is_incremented = ($this->module_follow->incrementFollowCount('following', $option['user_id'])) ? 'true' : 'false';

            printf('is_incremented: ' . $is_incremented . "\n");
        }
    }

    public function _remove_following($option)
    {
        printf("remove following \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("target_id: " . $option['target_id'] . "\n");

        $result = ($this->module_follow->removeFollowingUser($option['target_id'], $option['user_id'])) ? 'true' : 'false';

        printf('result: ' . $result . "\n");

        if ($result == 'true') {
            $is_decremented = ($this->module_follow->decrementFollowCount('following', $option['user_id'])) ? 'true' : 'false';

            printf('is_decremented: ' . $is_decremented . "\n");
        }
    }

    public function _add_followed($option)
    {
        printf("add followed \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("target_id: " . $option['target_id'] . "\n");

        $result = ($this->module_follow->addFollowedUser($option['target_id'], $option['user_id'])) ? 'true' : 'false';

        printf('result: ' . $result . "\n");

        if ($result == 'true') {
            $is_incremented = ($this->module_follow->incrementFollowCount('followed', $option['user_id'])) ? 'true' : 'false';

            printf('is_incremented: ' . $is_incremented . "\n");
        }
    }

    public function _remove_followed($option)
    {
        printf("remove followed \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("target_id: " . $option['target_id'] . "\n");

        $result = ($this->module_follow->removeFollowedUser($option['target_id'], $option['user_id'])) ? 'true' : 'false';

        printf('result: ' . $result . "\n");

        if ($result == 'true') {
            $is_decremented = ($this->module_follow->decrementFollowCount('followed', $option['user_id'])) ? 'true' : 'false';

            printf('is_decremented: ' . $is_decremented . "\n");
        }
    }

    public function _manual_update_follow_count($option)
    {
        printf("update follow count \n");
        printf("user_id: " . $option['user_id'] . "\n");

        list($before_following_count, $before_followed_count) = $this->module_follow->getFollowCount($option['user_id']);


        printf("before following_count: " . $before_following_count . "\n");
        printf("before followed_count: " . $before_followed_count . "\n");

        $this->_print_line();

        printf("is update follow count(yes/no)? \n");
        $is_update_following_count = fgets(STDIN);

        if (trim($is_update_following_count) == 'yes') {
            $result = ($this->module_follow->updateFollowCount($option['user_id'], $option['update_following_count'], $option['update_followed_count'])) ? 'true' : 'false';
            printf("result: " . $result . "\n");
        }
    }

    public function _initialize_follow_status($option)
    {
        printf("initialize follow status \n");
        printf("user_id: " . $option['user_id'] . "\n");

        printf("is initialize follow status(yes/no)? \n");
        $is_initialize_following_count = fgets(STDIN);

        if (trim($is_initialize_following_count) != 'yes') {
            return;
        }

        printf("initialize following \n");
        $offset_user_id = 0;
        $has_more = true;

        while ($has_more) {
            printf("offset: " . $offset_user_id . "\n");
            $following_user_list = $this->module_follow->getFollowingListByFollowingUser($offset_user_id, $option['user_id'], 100);

            foreach ($following_user_list as $following_user) {
                $result = ($this->module_follow->removeFollowingUser($following_user['following_user_id'], $option['user_id'])) ? 'true' : 'false';
                printf($following_user['following_user_id'] . ": " . $result . "\n");

                $result = ($this->module_follow->removeFollowedUser($option['user_id'], $following_user['following_user_id'])) ? 'true' : 'false';
                printf($following_user['following_user_id'] . ": " . $result . " --followed \n");

                $is_decremented = ($this->module_follow->decrementFollowCount('followed', $following_user['following_user_id'])) ? 'true' : 'false';
                printf($following_user['following_user_id'] . ": " . $is_decremented . " --decrement followed count \n");
            }

            if (count($following_user_list) < 100) {
                $has_more = false;
            }

            printf("count get user: " . count($following_user_list) . "\n");

            $offset_user = array_pop($following_user_list);
            $offset_user_id = $offset_user;
        }

        $this->_print_line();

        printf("initialize followed \n");
        $offset_user_id = 0;
        $has_more = true;

        while ($has_more) {
            printf("offset: " . $offset_user_id . "\n");
            list($has_next, $followed_user_list) = $this->module_follow->getFollowedListByFollowedUser($offset_user_id, $option['user_id'], 100);

            foreach ($followed_user_list as $followed_user) {
                $result = ($this->module_follow->removeFollowedUser($followed_user, $option['user_id'])) ? 'true' : 'false';
                printf($followed_user . ": " . $result . "\n");

                $result = ($this->module_follow->removeFollowingUser($option['user_id'], $followed_user)) ? 'true' : 'false';
                printf($followed_user . ": " . $result . " --following \n");

                $is_decremented = ($this->module_follow->decrementFollowCount('following', $followed_user)) ? 'true' : 'false';
                printf($followed_user . ": " . $is_decremented . " --decrement following count \n");
            }

            if (count($followed_user_list) < 100) {
                $has_more = false;
            }

            printf("count get user: " . count($followed_user_list) . "\n");

            $offset_user = array_pop($followed_user_list);
            $offset_user_id = $offset_user;
        }

        $this->_print_line();

        printf("initialize follow count \n");
        $result = ($this->module_follow->updateFollowCount($option['user_id'], 0, 0)) ? 'true' : 'false';
        printf("result: " . $result . "\n");
    }

    public function _revert_following_count($option)
    {
        printf("revert following count \n");
        printf("user_id: " . $option['user_id'] . "\n");

        printf("is revert following count(yes/no)? \n");
        $is_revert_following_count = fgets(STDIN);

        if (trim($is_revert_following_count) != 'yes') {
            return;
        }

        printf("initialize following \n");
        $offset_user_id = 0;
        $has_more = true;

        while ($has_more) {
            printf("offset: " . $offset_user_id . "\n");
            $following_user_list = $this->module_follow->getFollowingListByFollowingUser($offset_user_id, $option['user_id'], 100);

            foreach ($following_user_list as $following_user) {
                $result = ($this->module_follow->removeFollowingUser($following_user['following_user_id'], $option['user_id'])) ? 'true' : 'false';
                printf($following_user['following_user_id'] . ": " . $result . "\n");

                $result = ($this->module_follow->removeFollowedUser($option['user_id'], $following_user['following_user_id'])) ? 'true' : 'false';
                printf($following_user['following_user_id'] . ": " . $result . " --followed \n");

                $is_decremented = ($this->module_follow->decrementFollowCount('followed', $following_user['following_user_id'])) ? 'true' : 'false';
                printf($following_user['following_user_id'] . ": " . $is_decremented . " --decrement followed count \n");
            }

            if (count($following_user_list) < 100) {
                $has_more = false;
            }

            printf("count get user: " . count($following_user_list) . "\n");

            $offset_user = array_pop($following_user_list);
            $offset_user_id = $offset_user;

            sleep(1);
        }

        $this->_print_line();

        list($before_following_count, $before_followed_count) = $this->module_follow->getFollowCount($option['user_id']);

        printf("before following_count: " . $before_following_count . "\n");
        printf("before followed_count: " . $before_followed_count . "\n");

        printf("initialize following count \n");
        $result = ($this->module_follow->updateFollowCount($option['user_id'], 0, $before_followed_count)) ? 'true' : 'false';
        printf("result: " . $result . "\n");

        $this->_print_line();

        printf("add Async Task \n");

        $import_params = array(
            'user_id' => $option['user_id'],
        );
        Gree_Async::add('shop::avatarfeed', 'importcheckuser', null, $import_params);
        Gree_Async::add('shop::avatarfeed', 'importlinkuser', null, $import_params);
    }


    // specified followed date and user_id
    // write log on /home/gree/log/statistics/shop/avatar_feed/cli/followed_yyyymmdd_'user_id'.log
    public function _get_followed_user_list_from_standby($option)
    {
        printf("add user to block from followed \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("start_date: " . $option['start_date'] . "\n");
        printf("end_date: " . $option['end_date'] . "\n");

        if (file_exists($this->log_dir) == false) {
            mkdir($this->log_dir, 0777, true);
        }
        $log_file = $this->log_dir . "/followed_" . $option['start_date'] . '_' . $option['user_id'] . '.log';
        if (file_exists($log_file)) {
            $msg = "followed_list log file is already exist. log file name is " . $log_file;
            exit($msg);
        } else {
            $file_object = fopen($log_file, 'w');
        }

        $accessor = Cascade::getAccessor('avatar_feed#followed');
        $find_values = array(
            'user_id' => $option['user_id'],
            'start_date' => $option['start_date'],
            'end_date' => $option['end_date'],
        );

        $offset = 0;
        $limit = 100;
        $has_next = true;
        while ($has_next) {
            $followed_list = $accessor->findEx('standby', 'find_list_by_user_id_and_date', $find_values, $offset, $limit);

            if (is_array($followed_list) && empty($followed_list)) {
                break;
            } else {
                $offset = $offset + $limit;
            }

            foreach ($followed_list as $index) {
                fwrite($file_object, $index['followed_user_id'] . "\n");
            }

            printf("write done. offset = " . $offset . "\n");
            sleep(1);
        }

        fclose($file_object);
    }

    public function _add_user_to_block_from_followed_list($option)
    {
        printf("add user to block from followed list \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("start_date: " . $option['start_date'] . "\n");

        $log_file = $this->log_dir . "/followed_" . $option['start_date'] . '_' . $option['user_id'] . '.log';
        if (file_exists($log_file)) {
            $file_object = fopen($log_file, 'r');
        } else {
            $msg = "followed_list log file is not exist. log file name is " . $log_file;
            printf($msg);
            exit($msg);
        }

        $has_next = true;
        $count = 0;
        while ($has_next) {
            $count++;
            $block_user_id = fgets($file_object);
            if ($block_user_id == false) {
                break;
            }
            $add_result = $this->module_block->addBlockUser($block_user_id, $option['user_id']);
            if ($add_result == false) {
                printf("Failed to add block. followed_user_id = " . $block_user_id . "\n");
            } else {
                printf("count is " . $count . "\n");
            }
            // 0.1sec
            usleep(100000);
        }

        printf("finish \n");
        fclose($file_object);
    }

    public function _remove_following_user_by_term($option)
    {
        printf("add user id from following \n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("start_date: " . $option['start_date'] . "\n");
        $end_date = null;
        if (isset($option['end_date'])) {
            $end_date = $option['end_date'];
        }
        if (empty($end_date)) {
            $end_date = date('Y-m-d H:i:s', (strtotime($option['start_date']) + 3));
        }
        printf("end_date: " . $end_date . "\n");

        $exclude_id = array(47001825,);     // exclude official user

        $accessor = Cascade::getAccessor('avatar_feed#following');
        $find_values = array(
            'user_id' => $option['user_id'],
            'start_date' => $option['start_date'],
            'end_date' => $end_date,
        );

        $offset = 0;
        $limit = 10;

        $delete_user = array();
        while (true) {
            $find_values['offset_user_id'] = $find_values;
            $following_list = $accessor->findEx('standby', 'find_list_by_user_id_and_date', $find_values, $offset, $limit);

            if (!is_array($following_list) || empty($following_list)) {
                break;
            }

            $this->_print_line();
            printf("offset count  :" . $offset . "\n");
            printf("get user count:" . count($following_list) . "\n");

            foreach ($following_list as $following_user) {
                printf($following_user['ctime'] . '     ' . $following_user['following_user_id']);
                if (in_array($following_user['following_user_id'], $exclude_id)) {
                    printf(">>>> OFFICIAL USER ESCAPE\n");
                    continue;
                }
                printf("\n");
                $delete_user[] = $following_user['following_user_id'];
            }
            $offset = $offset + $limit;
            sleep(1);
        }

        // delete
        if (empty($delete_user) || !is_array($delete_user)) {
            printf("empty delete user.\n");
            throw new Exception();
        }

        $this->_print_line();
        printf("delete count:" . count($delete_user) . "\n");
        printf("is delete user from following(yes/no)?");
        $is_delete_user = fgets(STDIN);
        list($before_following_count, $before_followed_count) = $this->module_follow->getFollowCount($option['user_id']);
        if (trim($is_delete_user) != 'yes') {
            printf("not select 'yes'.\n");
        } else {
            printf("start...\n");
            printf("\n");
            $delete_count = 0;
            foreach ($delete_user as $following_user) {

                printf($following_user . " delete.");
                $result = ($this->module_follow->removeFollowingUser($following_user, $option['user_id'])) ? 'true' : 'false';
                printf(".. result=" . $result . "\n");

                $delete_count++;
                if (($delete_count%$limit) == 0) {
                    sleep(1);
                }
            }
            printf("........delete finish.\n");
            $this->_print_line();
        }
        $following_list = $accessor->find('count_list_by_user_id', array('user_id' => $option['user_id']));
        if (PEAR::isError($following_list)) {
            printf("error get following count.\n");
            printf("error code:" . json_encode($following_list) . "\n");
            throw new Exception();
        }
        $following_list = $following_list[0];
        if (!isset($following_list['following_count']) || !is_numeric($following_list['following_count']) || $following_list['following_count'] < 0) {
            printf("error get following count.\n");
            printf("error code:" . json_encode($following_list) . "\n");
            throw new Exception();
        }
        $after_following_count = $following_list['following_count'];
        printf("before following_count: " . $before_following_count . "\n");
        printf("after  following_count: " . $after_following_count . "\n");
        printf("repair following count: {$before_following_count} => {$after_following_count}\n");
        printf("is repair(yes/no)?");
        $is_repair_user = fgets(STDIN);
        if (trim($is_repair_user) != 'yes') {
            printf("not select 'yes'.\n");
            throw new Exception();
        }
        $result = ($this->module_follow->updateFollowCount($option['user_id'], $after_following_count, $before_followed_count)) ? 'true' : 'false';
        printf("repair result: " . $result . "\n");

        $this->_print_line();
        printf("finish.\n");
    }
}

$class = new Gree_Service_AvatarFeed_Cli_FollowManager();
$class->main();
