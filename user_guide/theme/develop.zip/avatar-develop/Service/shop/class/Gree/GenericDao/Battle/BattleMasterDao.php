<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Battle/BattleMasterDao.php
 *
 *  @author   Adib Gholaminezhad <adib.gholaminezhad@gree.net>
 *  @package  GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
class Gree_GenericDao_Battle_BattleMasterDao extends Gree_GenericDao_Apc {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'battle_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'battle_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_coorde_battle';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_coorde_battle';

    /** @var ��Ͽ�������̾ */
    var $_auto_increment = 'true';

    /** @var �ե������̾ */
    var $_field_names = array(
        'battle_id',
        'gacha_id_csv',
        'entry_items',
        'status',
        'name',
        'vote_limit',
        'open_datetime',
        'close_datetime',
        'entry_open_datetime',
        'entry_close_datetime',
        'vote_open_datetime',
        'vote_close_datetime',
        'ranking_open_datetime',
        'ranking_close_datetime',
        'lot_open_datetime',
        'lot_close_datetime',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY battle_id'
        ),
        'find_by_battle_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE battle_id = :battle_id'
        ),
        'find_latest_battle_id' => array(
            'sql' => 'SELECT battle_id FROM __TABLE_NAME__ ORDER BY battle_id DESC'
        ),
        'find_entry_items_by_battle_id' => array(
            'sql' => 'SELECT entry_items FROM __TABLE_NAME__ WHERE battle_id = :battle_id'
        ),
        // }}}
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `battle_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `status` TINYINT(2) NOT NULL DEFAULT '0',
                `name` VARCHAR(255) NOT NULL DEFAULT '',
                `vote_limit` TINYINT(2) NOT NULL,
                `open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `entry_open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `entry_close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `vote_open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `vote_close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `ranking_open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `ranking_close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `lot_open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `lot_close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`battle_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        'update_master' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status , name = :name, vote_limit = :vote_limit, open_datetime = :open_datetime, close_datetime = :close_datetime, entry_open_datetime = :entry_open_datetime, entry_close_datetime = :entry_close_datetime, vote_open_datetime = :vote_open_datetime, vote_close_datetime = :vote_close_datetime, ranking_open_datetime = :ranking_open_datetime, ranking_close_datetime = :ranking_close_datetime, lot_open_datetime = :lot_open_datetime, lot_close_datetime = :lot_close_datetime where battle_id = :battle_id'
        ),
        'add_column_gacha_id_csv' => array(
            'sql' => 'ALTER TABLE __TABLE_NAME__ ADD COLUMN gacha_id_csv text AFTER battle_id'
        ),
        'add_column_entry_items' => array(
            'sql' => 'ALTER TABLE __TABLE_NAME__ ADD COLUMN entry_items text AFTER gacha_id_csv'
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
