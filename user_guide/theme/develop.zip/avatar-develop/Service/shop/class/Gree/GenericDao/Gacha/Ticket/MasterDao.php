<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Ticket/Master.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: MasterDao.php 140372 2011-10-26 10:06:55Z ibuki $
 */

class Gree_GenericDao_Gacha_Ticket_MasterDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'gacha_ticket_master';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_gacha_ticket';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_gacha_ticket';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
	                          'id',
							  'type_id',
							  'status',
							  'name',
							  'price',
							  'lot_ratio',
							  'rare_ratio',
							  'open_datetime',
							  'close_datetime',
							  'expire_datetime',
							  'expire_term',
							  'mtime',
							  'ctime'
							 );
      
	/** @var ������ */
	var $_queries = array(
	    // {{{ ���ȷ�
        'all' => array(
		    'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC'
		),
        'find_by_ids' => array(
		    'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id IN (:ids) ORDER BY expire_datetime ASC'
		),
        'find_all_order_by_expire_datetime' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY expire_datetime desc'
        ),
		// }}}

		// {{{ ������
		'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(11) unsigned NOT NULL auto_increment,
                `type_id` int(11) unsigned NOT NULL default '0',
                `status` tinyint(2) NOT NULL default '0',
                `name` varchar(255) NOT NULL default '',
                `price` int(10) unsigned NOT NULL default '0',
				`lot_ratio` int(10) unsigned NOT NULL default '0',
                `rare_ratio` varchar(255) NOT NULL default '',
                `open_datetime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `close_datetime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `expire_datetime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `expire_term` int(11) unsigned NOT NULL,
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis"
		),
		// }}}
    ); 
}
