<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/GachaDao.php
 *
 *  @author   Koichi Osanai <koichi.osanai@gree.net>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_GachaDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var テーブル名 */
    public $_table_name = 'gacha';

    /** @var 主キー。複合キーはarrayハッシュで指定する。*/
    public $_primary_key = 'id';


    /** @var 更新日カラム名 */
    public $_updated_at_column = 'mtime';

    /** @var 登録日カラム名 */
    public $_created_at_column = 'ctime';

    /** @var マスターデータベースの接続文字列 */
    public $_master_dsn = 'gree://master/avatar_analytics';

    /** @var 登録日カラム名 */
    public $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var オートインクリメント*/
    public $_auto_increment = true;

    /** @var フィールド名 */
    public $_field_names = [
        'id',
        'datetime',
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'action1',
        'service',
        'action2',
        'item_id',
        'price',
        'having_point',
        'gacha_type',
        'gacha_id',
        'is_tld_net',
        'is_app',
        'multi',
        'mtime',
        'ctime',
    ];

    /**
     * @var クエリ定義。
     */
    public $_queries = [
        // {{{ 更新系
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    datetime DATETIME NOT NULL,
                    user_id BIGINT(20) UNSIGNED NOT NULL,
                    user_sex TINYINT(4) NOT NULL,
                    user_age TINYINT(4) NOT NULL,
                    phone_carrier TINYINT(4) NOT NULL,
                    action1 VARCHAR(255) NOT NULL,
                    service VARCHAR(16) NOT NULL,
                    action2 VARCHAR(255) NOT NULL,
                    item_id INT UNSIGNED,
                    price INT UNSIGNED NOT NULL,
                    having_point INT UNSIGNED NOT NULL,
                    gacha_type INT UNSIGNED,
                    gacha_id INT UNSIGNED,
                    is_tld_net  TINYINT(4),
                    is_app      TINYINT(4),
                    multi BOOL NOT NULL,
                    mtime TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    ctime DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    KEY datetime (datetime),
                    KEY user_id (user_id),
                    KEY user_sex (user_sex),
                    KEY user_age (user_age),
                    KEY phone_carrier (phone_carrier),
                    KEY action1 (action1),
                    KEY service (service),
                    KEY action2 (action2),
                    KEY item_id (item_id),
                    KEY price (price),
                    KEY having_point (having_point),
                    KEY gacha_type (gacha_type),
                    KEY is_tld_net (is_tld_net),
                    KEY is_app (is_app),
                    KEY gacha_id (gacha_id),
                    KEY multi (multi)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ],
        'drop_table' => [
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ],
        'update_multi_gacha_column' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET price = :price, gacha_id = :gacha_id, gacha_type = :gacha_type WHERE multi = 1 AND item_id in (:items)',
        ],
        // }}}
        // {{{ 参照系
        'find_by_user_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ],
        'show_tables' => [
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ],
        'get_summary' => [
            'sql' => '
                SELECT
                    user_id,
                    user_sex,
                    if((user_sex in (1) \&\& user_sex in (2)),
                        3, -- unisex
                        if(user_sex in (1),
                            1,
                            if(user_sex in (2), 2, -1)
                          )
                      ) as user_sex,
                    user_age,
                    phone_carrier,
                    sum(price) as gacha_spent_coin,
                    count(*) - sum(multi) as gacha_single_count,
                    sum(multi) as gacha_multi_count,
                    sum(multi = false \&\& price = 0) as free_gacha_count,
                    count(*) as gacha_count,
                    count(distinct gacha_id) as gacha_single_kind_count
                FROM __TABLE_NAME__
                WHERE price > 0 OR multi = 1
                GROUP BY user_id',
        ],

        // 以下、tool用
        'get_summary_by_gacha_id' => [
            'sql' => '
                SELECT
                    COUNT(*) AS cnt,
                    COUNT(DISTINCT user_id) AS uu,
                    SUM(price) AS sum
                FROM __TABLE_NAME__
                WHERE gacha_id = :gacha_id',
        ],
        'get_summary_by_gacha_id_and_service' => [
            'sql' => '
                SELECT SUM(price) AS sum
                FROM __TABLE_NAME__
                WHERE gacha_id = :gacha_id AND service = :service',
        ],
        'get_uniq_user_by_gacha_id' => [
            'sql' => '
                SELECT
                    user_id,
                    SUM(price) AS sum
                FROM __TABLE_NAME__
                WHERE gacha_id = :gacha_id
                GROUP BY user_id',
        ],
        // }}}
    ];
    /** #@- */
}
