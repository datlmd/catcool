<?php
/**
 * Add feed to db. Cron will be run every 5 minute
 *
 *
 */

require_once '/home/gree/xgree/avatar/Service/avatarfeed/cli/Base.php';
require_once '/home/gree/xgree/avatar/Service/shop/service.php';
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare/Support.php';

/**
 * Class Gree_Service_AvatarFeed_Cli_FeedAdd
 */
Class Gree_Service_AvatarFeed_Cli_FeedAdd extends Gree_Service_AvatarFeed_Cli_Base
{
    const DAY_15      = 1296000;

    /**
     * flow is
     *  - Get data from flare with key "coco_post"
     *  - If have a data
     *    1. Compare time in [now -> now + 5min] -> post and delete flare cache
     *
     * @throws Gree_Service_Shop_Exception
     */
    function main()
    {
        $this->_initialize();

        $this->_print_header('feed_add');

        //Step 1: Get flare data
        $flare_support = new Gree_Service_Shop_Flare_Support(self::DAY_15, 'result');
        try {
            $arr_cache_data = $flare_support->getCacheWithoutUserId("coco_post");

            if (PEAR::isError($arr_cache_data)) {
                echo 'ERROR: Flare is error' . PHP_EOL;
            }

            if (empty($arr_cache_data)) {
                echo 'Have no reserved to post' . PHP_EOL;
                $this->_print_footer();

                return;
            }

            //Step 2: Compare time setting
            echo 'START' . PHP_EOL;

            foreach ($arr_cache_data as $k => $cache_data) {
                if (time() >= $cache_data['time_setting']) {
                    echo 'Perform: support_entry_create' . PHP_EOL;
                    $rs = $this->avatar_feed->process('support_entry_create', $cache_data);
                    if (is_array($rs) && isset($rs[1])) {
                        $cache_data['entry_id'] = $rs[1];
                        $cache_data['coco_post_id'] = $k;
                    } else {
                        if (Config::get('state') == 'dev') {
                            echo 'Please, check GREE_SERVICE_AVATARFEED_ENDPOINT';
                            echo '/home/gree/xgree/avatar/Service/avatarfeed/bootstrap.php';
                            die();
                        }
                    }

                    echo 'Perform: remove coco_post in reserved' . PHP_EOL;
                    unset($arr_cache_data[$k]);
                    $flare_support->setCacheWithoutUserId("coco_post", $arr_cache_data);

                    echo 'Perform: add coco_post in history' . PHP_EOL;
                    $this->_saveHistoriesDataToFlare($flare_support, $cache_data);

                    // push notification
                    if (isset($cache_data['push_message']) && !empty($cache_data['push_message'])) {
                        echo 'Perform: push notification coco_post' . PHP_EOL;
                        $notification_manager = getService('shop')->getPushNotificationNotificationManager();
                        $notification_manager->pushNotificationCocoFeed($cache_data['push_message']);
                    }
                } else {
                    echo 'A reserved will run at ' . date('Y-m-d H:i:s', $cache_data['time_setting']) . PHP_EOL;
                }
            }

            echo 'DONE' . PHP_EOL;
        } catch (Exception $e) {
            echo $e->getMessage() . PHP_EOL;
        }

        $this->_print_footer();
    }

    /**
     * Save data histories post in flare
     *
     * Same function: frontend/support/act/Shop/Coco/Addfeed.php:207
     *
     * @param $flare_support
     * @param $create_params
     *
     * @throws Exception
     */
    private function _saveHistoriesDataToFlare($flare_support, $create_params)
    {
        try {
            $history = $flare_support->getCacheWithoutUserId("coco_post_histories");
            if (!$history) {
                $history = array();
            }

            array_unshift($history, $create_params);
            $history = array_slice($history, 0, 5);

            $retHistory = $flare_support->setCacheWithoutUserId("coco_post_histories", $history);
            if (!$retHistory) {
                throw new Exception('ERROR: Can not set cache. ' . __FILE__ . __LINE__);
            }

        } catch (Exception $e) {
            throw new Exception($e->getMessage() . __FILE__ . __LINE__);
        }
    }
}

/**
 * Call function
 */
$class = new Gree_Service_AvatarFeed_Cli_FeedAdd();
$class->main();
