<?php

/**
 * service/shop/Exception.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.co.jp>
 * @package GREE
 */
require_once dirname(__FILE__).'/Exception/ServiceException.php';
require_once dirname(__FILE__).'/Exception/DBException.php';
require_once dirname(__FILE__).'/Exception/KeyException.php';
require_once dirname(__FILE__).'/Exception/RuntimeException.php';
require_once dirname(__FILE__).'/Exception/SystemException.php';
require_once dirname(__FILE__).'/Exception/FrontendException.php';

/**
 * Gree_Service_Shop_Exception
 *
 * @package GREE
 * @access  public
 */
class Gree_Service_Shop_Exception extends Exception
{
    // ----------------- [ constants] ------------------------------------------ //
    const LOG_FLAG_NONE   = 1000;
    const LOG_FLAG_ERROR  = 1001;
    const LOG_FLAG_CRIT   = 1002;
    const DEFAULT_ERROR_TPL = "common_error";

    // ----------------- [ properties ] ------------------------------------------ //

    /** @var $_default_message */
    protected $_default_message = 'system error.';

    /** @var $_previous */
    protected $_previous;

    /** @var $_attr */
    protected $_attr;

    // ----------------- [ public methods] ------------------------------------------ //

    // {{{ __construct
    /**
     * constructor
     *
     * @access  public
     * @param   string  $message    the exception message
     * @param   int     $code       the exception code
     * @param   object  $previous   the previous exception
     * @param   int     $log_flag   the log flag 
     * @param   array   $attr       the attributes
     */
    public function __construct($message = '', $code = 0, Exception $previous = null, $log_flag = self::LOG_FLAG_NONE, array $attr = array())
    {
        // set default message
        if (empty($message)) {
            $message = $this->_default_message;
        }

        // encode
        $message = mb_convert_encoding($message, mb_internal_encoding(), mb_detect_encoding($message));
        if (empty($code)) {
            $message = sprintf('%s', $message);
        }else{
            $message = sprintf('%s [CODE=%s]', $message, $code);
        }

        parent::__construct($message, $code);

        // set properties
        if ($previous != null) {
            $this->_previous = $previous;
        }
        $this->_attr = $attr;

        // write log
        if (in_array($log_flag, array(self::LOG_FLAG_ERROR, self::LOG_FLAG_CRIT))) {
            $backtrace = $this->getTrace();
            if (array_key_exists(0, $backtrace)) {
                $class      = (array_key_exists('class', $backtrace[0])) ? $backtrace[0]['class'] : 'no class';
                $attr_strs  = array();
                foreach ($attr as $key => $value) {
                    $value      = (is_array($value)) ? 'array' : $value;
                    $attr_strs[]    = "$key=$value";
                }

                $prev_str       = (is_null($previous)) ? "-" : get_class($previous);
                $prev_msg_str   = (is_null($previous)) ? "-" : $previous->getMessage();

                $error_message  = sprintf(
                    '[%s] %s, code=%s, prev=%s(%s) attrs=(%s)',
                    $class,
                    $message,
                    $code,
                    $prev_str,
                    $prev_msg_str,
                    implode(',', $attr_strs)
                );

                // write log
                $logger = Gree_Service_Shop_Logger::getInstance();
                switch ($log_flag) {
                case (self::LOG_FLAG_ERROR):
                    $logger->err($error_message);
                    break;
                case (self::LOG_FLAG_CRIT):
                    $logger->crit($error_message);
                    break;
                default:
                    // ここは通らない
                    break;
                }
            }
        }

        // debug message
        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            error_log(get_class($this));
            error_log(print_r(compact('message', 'code', 'previous', 'log_flag', 'attr'), true));
            error_log(print_r(Debugger::getbacktrace(), true));
        }
    }
    // }}}
    // {{{ redirect
    /**
     * get exception to redirect
     *
     * @access  public
     * @static
     * @param   int     $url    the redirect url
     * @return  Gree_Service_Shop_Exception          the instance
     */
    public static function redirect($url = null)
    {
        // set default redirect url
        if (is_null($url)) {
            if (Gree_Ggp_Domain::isTLDNet() && defined('HTTP_ROOT_GAVATAR')) {
                $url = HTTP_ROOT_GAVATAR;
            } else if (defined('HTTP_ROOT_SHOP_DYNAMIC')) {
                if (HTTP_ROOT_SHOP_DYNAMIC == HTTP_ROOT_TSHOP) {
                    $url = HTTP_ROOT_TAVATAR;
                } else {
                    $url = HTTP_ROOT_MSHOP;
                }
            } else {
                $url = HTTP_ROOT;
            }
        }
        $attr = array(
            'redirect_url' => $url
        );
        return new self('', 0, null, self::LOG_FLAG_NONE, $attr);
    }
    // }}}

    // {{{ getPreviousException
    /**
     * get previous exception instance
     *
     * @access  public
     * @return  Gree_Service_Shop_Exception  the previous exception instance
     */
    public function getPreviousException()
    {
        return $this->_previous;
    }
    // }}}

    // {{{ getAttribute
    /**
     * get attribute
     *
     * @access  public
     * @param   string  $key    the attribute key
     * @return  mixed           the attribute
     */
    public function getAttribute($key = null)
    {
        if ($key === null) {
            return $this->_attr;
        }

        if (!array_key_exists($key, $this->_attr)) {
            return null;
        }

        return $this->_attr[$key];
    }
    // }}}
    // {{{ error
    /**
     * @access  public
     * @static
     * @param   string  $msg
     */
    public static function error($msg)
    {
        throw new self($msg, 0, null, self::LOG_FLAG_ERROR);
    }
    // }}}
    public function getTpl(){
        return self::DEFAULT_ERROR_TPL;
    }
}
