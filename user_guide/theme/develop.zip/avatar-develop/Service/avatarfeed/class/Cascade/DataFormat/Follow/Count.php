<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Follow_Count
    extends Cascade_DB_SQL_DataFormat
{
    // dsn setting
    protected $master_dsn        = 'gree://master/avatar_follow_count';
    protected $slave_dsn         = 'gree://slave/avatar_follow_count';
    protected $extra_dsn         = array();

    // cascade setting
    protected $primary_key       = 'user_id';
    protected $fetch_mode        = self::FETCH_MODE_ASSOC;
    // use primary_key
    protected $fetch_key         = NULL;
    protected $auto_increment    = false;

    // table and column setting
    protected $table_name        = 'count';
    protected $field_names       = array(
        'user_id',
        'following',
        'followed',
    );

    protected $queries = array(
        'create_table' => array(
            'sql' => '
              CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id`   bigint(20) UNSIGNED NOT NULL,
                `following` int(11)    UNSIGNED NOT NULL,
                `followed`  int(11)    UNSIGNED NOT NULL,
                PRIMARY KEY (`user_id`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ',
        ),
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'update_count' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__  (user_id, following, followed)
                    VALUES(:user_id, :following_number, :followed_number)
                    ON DUPLICATE KEY UPDATE following = :following_number, followed = :followed_number
            ',
        ),
        'increment_following' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__  (user_id, following, followed)
                    VALUES(:user_id, 1, 0)
                    ON DUPLICATE KEY UPDATE following = following + 1
            ',
        ),
        'increment_followed' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__  (user_id, following, followed)
                    VALUES(:user_id, 0, 1)
                    ON DUPLICATE KEY UPDATE followed = followed + 1
            ',
        ),
        'decrement_following' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET following = following - 1 WHERE user_id = :user_id and following > 0',
        ),
        'decrement_followed' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET followed = followed - 1 WHERE user_id = :user_id and followed > 0',
        ),
        'decrement_following_by_input' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET following = following - :decrement_num WHERE user_id = :user_id and following > 0',
        ),
        'decrement_followed_by_input' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET followed = followed - :decrement_num WHERE user_id = :user_id and followed > 0',
        ),
    );
}
