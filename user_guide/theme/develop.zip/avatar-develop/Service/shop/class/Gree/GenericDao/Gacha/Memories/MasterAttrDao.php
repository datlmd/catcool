<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Gacha/Memories/MasterAttrDao.php
 *
 * @package     GREE Avatar
 * @since       2018-06-08
 */

/**
 * MasterAttr form constructor
 * @access      public
 */
class Gree_GenericDao_Gacha_Memories_MasterAttrDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'gacha_memories_master_attr';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var field names */
    var $_field_names = array(
        'id',
        'memories_id',
        'name',
        'value',
        'mtime',
        'ctime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_memories_id'            => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE memories_id = :memories_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                         => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (memories_id, name, value, ctime) VALUES (:memories_id, :name, :value, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                        => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET memories_id = :memories_id, name = :name, value = :value WHERE id = :id',
        ),
        'delete_by_memories_id_and_name' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE memories_id = :memories_id AND name = :name',
        ),
        // }}}

        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `memories_id` INT UNSIGNED NOT NULL,
                `name` VARCHAR(255) NOT NULL,
                `value` VARCHAR(255) NOT NULL,
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY `name` (`memories_id`,`name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
