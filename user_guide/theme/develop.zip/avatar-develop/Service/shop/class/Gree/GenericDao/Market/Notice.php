<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/MarketFarmSelector.php';

/**
 * Gree_GenericDao_Market_Notice
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_NoticeDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'market_notice';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'id',
        'state',
        'title',
        'body',
        'start_time',
        'end_time',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        'find_title_start_by_state_time' => array(
            'sql' => 'SELECT id, title, start_time, end_time FROM __TABLE_NAME__ WHERE state = :state AND start_time <= :time ORDER BY start_time DESC',
        ),
        'find_by_state_time' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND start_time <= :time ORDER BY start_time DESC',
        ),
        'find_all_outline' => array(
            'sql' => 'SELECT id, state, title, start_time, end_time FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (state, title, body, start_time, end_time) VALUES (:state, :title, :body, :start_time, :end_time)',
        ),
        'update_by_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state, title = :title, body = :body, start_time = :start_time, end_time = :end_time WHERE id = :id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id          INT(11)         UNSIGNED NOT NULL AUTO_INCREMENT,
                    state       TINYINT(4)      UNSIGNED NOT NULL,
                    title       VARCHAR(100)    NOT NULL,
                    body        TEXT            NOT NULL,
                    start_time  INT(11)         UNSIGNED NOT NULL,
                    end_time    INT(11)         UNSIGNED NOT NULL,
                    ctime       DATETIME        NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime       TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    KEY (state, start_time)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );
}
