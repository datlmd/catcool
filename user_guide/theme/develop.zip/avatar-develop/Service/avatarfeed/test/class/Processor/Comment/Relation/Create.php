<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Comment_Relation_Create
 *
 * this test is comment relation create process
 *
 */
final class Gree_Service_Avatarfeed_Test_Processor_Comment_Relation_Create
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;
    var $entry_id;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');

        $this->module->setUserIDtoCtfy(UNIT_TEST_OFFICIAL_THEME_USER_ID_2);
        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
            sleep(2);
        } catch (Exception $e) {
        }
        $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);

        $this->module->setUserIDtoCtfy(UNIT_TEST_OFFICIAL_THEME_USER_ID_1);
        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            sleep(2);
        } catch (Exception $e) {
        }
        $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);

        // UNIT_TEST_USER_ID_4
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_4);
        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
            sleep(2);
        } catch (Exception $e) {
        }
        $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);

        // UNIT_TEST_USER_ID_3
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_3);
        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
            sleep(2);
        } catch (Exception $e) {
        }
        $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);

        // UNIT_TEST_USER_ID_2
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
            sleep(2);
        } catch (Exception $e) {
        }
        $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);

        // UNIT_TEST_USER_ID_1
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
            sleep(2);
        } catch (Exception $e) {
        }
        $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);

        sleep(2);

        // prepare (create entry)
        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_OFFICIAL_THEME_USER_ID_1,
            'category' => GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
            'limit'    => GREE_SERVICE_AVATARFEED_DEFAULT_GET_ENTRIES_LIMIT,
            'start_id' => null,
        );

        list($is_success_create_entry, $this->entry_id) = $this->_createEntry(UNIT_TEST_OFFICIAL_THEME_USER_ID_2, UNIT_TEST_OFFICIAL_THEME_USER_ID_1); 

        sleep(2);

    }

    /**
     * $stream_params = array(
     *      'user_id'  => UNIT_TEST_USER_ID_1,
     *      'entry_cateogory' => 'notification_comment_relation',
     *      'entry_id' => 'null',
     *      'notification_entry_id' => 'null',
     * );
     *
     * test: 1
     * entry has one comment
     * is_add_notification == false
     *
     * test: 2
     * entry has two comment
     * has_more == false, stream_data == array
     * is_add_notification == true
     *
     * test: 3
     * entry has three comment
     * has_more == false, stream_data == array
     * is_add_notification == true
     *
     * test: 4
     * entry has four comment
     * has_more == false, stream_data == array
     * is_add_notification == true
     *
     * test: 5
     * feed has five comment
     * has_more == false, stream_data == array
     * is_add_notification == true
     *
     * test: 6
     * feed has six comment(duplicate user comment)
     * has_more == false, stream_data == array
     * is_add_notification == true
     */
    public function test_create_comment_relation_1()
    {
        // test 1
        $stream_params = array();
        $stream_params = array(
            'text'              => 'comment_1',
            'entry_id'          => $this->entry_id,
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_2,
            'user_id'           => UNIT_TEST_USER_ID_1,
        );

        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $stream_params);
        $this->assertTrue($is_create_comment);

        sleep(2);

        $notification_params = array();
        $notification_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'entry_category' => 'notification_comment_relation',
            'entry_id' => $this->entry_id,
            'notification_entry_id' => $this->entry_id,
            'comment_id' => $comment_id,
        );
        $is_add_notification = $this->avatar_feed->process('comment_relation_create', $notification_params);
        $this->assertFalse($is_add_notification);

    }

    public function test_create_comment_relation_2()
    {
        $this->test_create_comment_relation_1();

        // test 2
        $stream_params = array();
        $stream_params = array(
            'text'              => 'comment_2',
            'entry_id'          => $this->entry_id,
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_2,
            'user_id'           => UNIT_TEST_USER_ID_2,
        );

        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $stream_params, UNIT_TEST_USER_ID_2);
        $this->assertTrue($is_create_comment);

        sleep(2);

        $notification_params = array();
        $notification_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
            'entry_category' => 'notification_comment_relation',
            'entry_id' => $this->entry_id,
            'notification_entry_id' => $this->entry_id,
            'comment_id' => $comment_id,
        );
        $is_add_notification = $this->avatar_feed->process('comment_relation_create', $notification_params);
        $this->assertTrue($is_add_notification);

        sleep(2);

        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );

        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_2, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_1);
    }

    
    public function test_create_comment_relation_3()
    {
        $this->test_create_comment_relation_2();

        // test 3
        $stream_params = array();
        $stream_params = array(
            'text'              => 'parent_comment',
            'entry_id'          => $this->entry_id,
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_2,
            'user_id'           => UNIT_TEST_USER_ID_3,
        );

        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $stream_params, UNIT_TEST_USER_ID_3);
        $this->assertTrue($is_create_comment);
        sleep(2);

        $notification_params = array();
        $notification_params = array(
            'user_id'  => UNIT_TEST_USER_ID_3,
            'entry_category' => 'notification_comment_relation',
            'entry_id' => $this->entry_id,
            'notification_entry_id' => $this->entry_id,
            'comment_id' => $comment_id,
        );
        $is_add_notification = $this->avatar_feed->process('comment_relation_create', $notification_params);
        $this->assertTrue($is_add_notification);

        sleep(2);

        // check
        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );
        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_3, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_1);

        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );

        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_2);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_3, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_2);
    }

    public function test_create_comment_relation_4()
    {
        $this->test_create_comment_relation_3();

        // test 4
        $stream_params = array();
        $stream_params = array(
            'text'              => 'parent_comment',
            'entry_id'          => $this->entry_id,
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_2,
            'user_id'           => UNIT_TEST_USER_ID_4,
        );

        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $stream_params, UNIT_TEST_USER_ID_4);
        $this->assertTrue($is_create_comment);
        sleep(2);

        $notification_params = array();
        $notification_params = array(
            'user_id'  => UNIT_TEST_USER_ID_4,
            'entry_category' => 'notification_comment_relation',
            'entry_id' => $this->entry_id,
            'notification_entry_id' => $this->entry_id,
            'comment_id' => $comment_id,
        );
        $is_add_notification = $this->avatar_feed->process('comment_relation_create', $notification_params);
        $this->assertTrue($is_add_notification);
        sleep(2);

        // check
        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );
        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_4, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_1);

        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_3,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );

        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_3);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_4, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_3);

    }

    public function test_create_comment_relation_5()
    {
        $this->test_create_comment_relation_4();

        // test 5
        $stream_params = array();
        $stream_params = array(
            'text'              => 'parent_comment',
            'entry_id'          => $this->entry_id,
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_2,
            'user_id'           => UNIT_TEST_USER_ID_5,
        );

        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $stream_params, UNIT_TEST_USER_ID_5);
        $this->assertTrue($is_create_comment);
        sleep(2);

        $notification_params = array();
        $notification_params = array(
            'user_id'  => UNIT_TEST_USER_ID_5,
            'entry_category' => 'notification_comment_relation',
            'entry_id' => $this->entry_id,
            'notification_entry_id' => $this->entry_id,
            'comment_id' => $comment_id,
        );
        $is_add_notification = $this->avatar_feed->process('comment_relation_create', $notification_params);
        $this->assertTrue($is_add_notification);
        sleep(2);

        // check
        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );
        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_4, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_1);

        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_4,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );

        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_4);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_5, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_4);

    }

    public function test_create_comment_relation_6()
    {
        $this->test_create_comment_relation_5();

        // test 6
        $stream_params = array();
        $stream_params = array(
            'text'              => 'parent_comment',
            'entry_id'          => $this->entry_id,
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_2,
            'user_id'           => UNIT_TEST_USER_ID_5,
        );

        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $stream_params, UNIT_TEST_USER_ID_5);
        $this->assertTrue($is_create_comment);
        sleep(2);

        $notification_params = array();
        $notification_params = array(
            'user_id'  => UNIT_TEST_USER_ID_5,
            'entry_category' => 'notification_comment_relation',
            'entry_id' => $this->entry_id,
            'notification_entry_id' => $this->entry_id,
            'comment_id' => $comment_id,
        );
        $is_add_notification = $this->avatar_feed->process('comment_relation_create', $notification_params);
        $this->assertTrue($is_add_notification);
        sleep(2);

        // check
        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );
        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more);
        $this->assertEquals(1, count($stream_data));
        $this->assertEquals(UNIT_TEST_USER_ID_4, $stream_data[0]['content']['sender_id']);
        $this->assertEquals('notification_comment_relation', $stream_data[0]['content']['attr']['entry_category']);
        $destination_user_info = explode(":", $stream_data[0]['destinations'][0]['value']);
        $destination_user_id = $destination_user_info[2];
        $this->assertEquals($destination_user_id, UNIT_TEST_USER_ID_1);

        $stream_params = array();
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_5,
            'category' => 'notification',
            'limit'    => 101,
            'start_id' => null,
        );

        $has_more = array();
        $stream_data = array();
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_5);
        $this->assertFalse($has_more);
        $this->assertEquals(0, count($stream_data));

    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_comment_relation',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}
