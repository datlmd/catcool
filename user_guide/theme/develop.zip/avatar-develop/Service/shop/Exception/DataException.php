<?php
/**
 *
 */
class Gree_Service_Shop_Exception_DataException
    extends Gree_Service_Shop_Exception_ServiceException
{
}
