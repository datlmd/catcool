<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
/**
 * Gree_GenericDao_AvapriUserSealTeicketDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_User_SealTicketDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'user_seal_ticket';
	/** @var primary key */
    var $_primary_key = 'user_tickect_id';
    /** @var auto increment */
    var $_auto_increment = false;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'user_tickect_id',
        'user_id',
        'ticket_id',
        'state',
        'seal_id',
        'ctime',
        'mtime'
    );

    var $_queries = array( 
        // select----------------------
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_user_id_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = :state',
        ),
        'find_by_user_id_and_ticket_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND ticket_id = :ticket_id',
        ),
        // update----------------------
        'insert_ticket' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, ticket_id, state, ctime) VALUES (:user_id, :ticket_id, :state, NOW())',
        ),
        'update_state' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state WHERE user_ticket_id = :user_ticket_id',
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `user_ticket_id` int(11) unsigned NOT NULL auto_increment,
                    `user_id` int(11) unsigned NOT NULL,
                    `ticket_id` int(11) unsigned NOT NULL,
                    `state` tinyint(4) unsigned NOT NULL default '1',
                    `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY  (`user_ticket_id`),
                    KEY `user_id_1` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'delete_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
    );
    function _init(){
        parent::_init();
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
?>