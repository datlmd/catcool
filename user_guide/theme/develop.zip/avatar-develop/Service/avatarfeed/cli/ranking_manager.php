<?php

require_once("/home/gree/xgree/avatar/Service/avatarfeed/cli/Base.php");

class Gree_Service_AvatarFeed_Cli_RankingManager
    extends Gree_Service_AvatarFeed_Cli_Base
{
    public function main()
    {
        $this->_initialize();

        $this->_print_header('ranking_manager');

        $this->short_opt = "m:u:d:";
        $this->opt_names = array(
            'cycle=',
            'category=',
            'value=',
        );
        $this->input_opt_list = $this->_get_parse_arg_list();

        try {
            $set_options = $this->_set_option_value();
            $this->_invoke($set_options);
        } catch (Exception $e) {
            printf("finish with error. \n");
            printf($e->getMessage() . " \n");
        }

        $this->_print_footer();
    }

    public function _find_input_option($option)
    {
        $option_name = null;
        $option_value = null;

        switch ($option[0]) {
            case 'm':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'mode';
                $option_value = $option[1];
                break;
            case 'u':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'user_id';
                $option_value = $option[1];
                break;
            case 'd':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'date';
                $option_value = $option[1];
                break;
            case '--cycle':
                $option_name = 'cycle';
                $option_value = $option[1];
                break;
            case '--category':
                $option_name = 'category';
                $option_value = $option[1];
                break;
            case '--value':
                $option_name = 'value';
                $option_value = $option[1];
                break;
            default:
                printf("please input mode \n");
                throw new Exception();
        }

        return array(
            $option_name,
            $option_value,
        );
    }

    public function _invoke($option)
    {
        switch ($option['mode']) {
            case 'add_key':
                if (!isset($option['cycle'])) {
                    printf("need cycle.\n");
                    throw new Exception();
                }
                if (!isset($option['category'])) {
                    printf("need category.\n");
                    throw new Exception();
                }
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['date'])) {
                    printf("need date.\n");
                    throw new Exception();
                }

                $this->_add_key($option);
                break;
            case 'get':
                if (!isset($option['cycle'])) {
                    printf("need cycle.\n");
                    throw new Exception();
                }
                if (!isset($option['category'])) {
                    printf("need category.\n");
                    throw new Exception();
                }
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['date'])) {
                    printf("need date.\n");
                    throw new Exception();
                }

                $this->_get($option);
                break;
            case 'get_list':
                if (!isset($option['cycle'])) {
                    printf("need cycle.\n");
                    throw new Exception();
                }
                if (!isset($option['category'])) {
                    printf("need category.\n");
                    throw new Exception();
                }
                if (!isset($option['date'])) {
                    printf("need date.\n");
                    throw new Exception();
                }

                $this->_get_list($option);
                break;
            case 'increment_key':
                if (!isset($option['cycle'])) {
                    printf("need cycle.\n");
                    throw new Exception();
                }
                if (!isset($option['category'])) {
                    printf("need category.\n");
                    throw new Exception();
                }
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['date'])) {
                    printf("need date.\n");
                    throw new Exception();
                }

                $this->_increment_key($option);
                break;
            case 'add_user_to_list':
                if (!isset($option['cycle'])) {
                    printf("need cycle.\n");
                    throw new Exception();
                }
                if (!isset($option['category'])) {
                    printf("need category.\n");
                    throw new Exception();
                }
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['date'])) {
                    printf("need date.\n");
                    throw new Exception();
                }
                if (!isset($option['value'])) {
                    printf("need value.\n");
                    throw new Exception();
                }


                $this->_add_user_to_list($option);
                break;
            default:
                printf("please input exist mode\n");
                throw new Exception();
        }
    }

    public function _add_key($option)
    {
        printf("add key \n");
        printf("cycle: " . $option['cycle'] . "\n");
        printf("category: " . $option['category'] . "\n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("date: " . $option['date'] . "\n");

        $key = $this->module_score->_getScoreKey($option['category'], $option['user_id'], $option['date']);
        $is_success = $this->module_score->add($option['cycle'], $key);

        printf("is_success: " . $is_success . "\n");
    }

    public function _increment_key($option)
    {
        printf("add key \n");
        printf("cycle: " . $option['cycle'] . "\n");
        printf("category: " . $option['category'] . "\n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("date: " . $option['date'] . "\n");

        $key = $this->module_score->_getScoreKey($option['category'], $option['user_id'], $option['date']);
        $incremented_value = $this->module_score->increment($option['cycle'], $key);

        printf("is_success: " . $incremented_value . "\n");
    }

    public function _get($option)
    {
        printf("get \n");
        printf("cycle: " . $option['cycle'] . "\n");
        printf("category: " . $option['category'] . "\n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("date: " . $option['date'] . "\n");

        $key = $this->module_score->_getScoreKey($option['category'], $option['user_id'], $option['date']);
        list($key_info, $token) = $this->module_score->get($option['cycle'], $key);

        printf("key_info is: " . $key_info . "\n");
    }

    public function _get_list($option)
    {
        printf("get list \n");
        printf("cycle: " . $option['cycle'] . "\n");
        printf("category: " . $option['category'] . "\n");
        printf("date: " . $option['date'] . "\n");

        $key = $this->module_score->_getTopScoreListKey($option['category'], $option['date']);
        list($key_info, $token) = $this->module_score->get($option['cycle'], $key);

        if (is_array($key_info)){
            printf("--------------------- \n");
            foreach($key_info as $key => $value){
                printf("key: " . $key . "\n");
                printf("value: " . $value . "\n");
            }
        } else {
            printf("failed get key.");
        }
    }

    public function _add_user_to_list($option)
    {
        printf("add user to list \n");
        printf("cycle: " . $option['cycle'] . "\n");
        printf("category: " . $option['category'] . "\n");
        printf("user_id: " . $option['user_id'] . "\n");
        printf("value:: " . $option['value'] . "\n");
        printf("date: " . $option['date'] . "\n");

        $key = $this->module_score->_getTopScoreListKey($option['category'], $option['date']);
        $value = array(
            $option['user_id'] => $option['value']
        );
        $is_success = $this->module_score->add($option['cycle'], $key, $value);

        printf("is_success: " . $is_success . "\n");
    }
}

$class = new Gree_Service_AvatarFeed_Cli_RankingManager();
$class->main();