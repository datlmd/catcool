<?php
/**
 * Service/shop/class/Gree/Data/User/Closet.php
 *
 * @author  Yuta Araki <yuta.araki@gree.net>
 * @package GREE
 */

/**
 * Gree_Service_Shop_Data_User_Closet
 *
 * @package GREE
 * @access  public
 */
class Gree_Service_Shop_Data_User_Closet
    extends Gree_Service_Shop_Data_Abstract
{
    /** ---- [ Properties ] -------------------------------- */
    /**
     * @var $_format        defines default property
     * @var $_life_service  class wide reference to life service object
     * @var $_closet_state  holds current closet state
     * @var $_closet        closet array object, format defined in _createCloset()
     * @var $_logger        class wide reference to statistic logger object
     */
    protected $_format = array(
        'user_id',
        'user_sex'
    );
    protected $_life_service    = null;
    protected $_closet_state    = null;
    protected $_closet          = null;
    protected $_logger          = null;
    protected $_log             = null;



    /** ---- [ Constants ] -------------------------------- */
    /**
     * Class CONSTs:
     * CLOSET_KEY       : used for data identity, distinguishes closet data from shop cart data
     * CLOSET_NAMESPACE : namespace for mysql cache DB,
     * CART_LIFETIME    : invalidates closet data after given period. 864000 = ten days
     */
    const SHOP_KEY          = 'avatar';
    const CLOSET_KEY        = 'shop_closet';
    const CART_KEY          = 'shop_cart';
    const CLOSET_NAMESPACE  = 'mshop_cart';
    const CART_LIFETIME     = 864000;

    /**
     * CLOSET STATES
     * used when it needs update, call the end function before returning data
     */
    const CLOSET_STATE_NEW      = 0;
    const CLOSET_STATE_OBTAINED = 1;
    const CLOSET_STATE_DIRTY    = 2;
    const CLOSET_STATE_UPDATED  = 3;


    /**
     * ITEM SELECTED STATE
     * key for filter by item selection state function
     */
    const ITEM_STATE_SELECTED   = 0;
    const ITEM_STATE_DESELECTED = 1;




    /**
     * Constructor for Gree_Service_Shop_Data_User_Closet
     * initialize accessor, life service and logger, retrieve closet
     *
     * @param $accessor
     */
    public function __construct($accessor)
    {
        parent::__construct($accessor);
        $this->_life_service    = getService('life');
        $this->_logger          = $this->_life_service->getStatisticsLogger();
        $this->_log             = getService('shop')->_log;
        $this->_getCloset();
    }

    /** ---- [ Public Methods ] -------------------------------- */
    /**
     * addAndSelectItem
     * Adds given item to closet and make the state selected
     * @param $item item array object or item id
     *
     * @throws Gree_Service_Shop_Exception_DataException
     */
    public function addAndSelectItem($item)
    {
        if (!is_numeric($item)){
            throw new Gree_Service_Shop_Exception_DataException("Failed to item_id.", 0);
        }
        $item = $this->_life_service->getItem($item);
        if (PEAR::isError($item) || empty($item)){
            throw new Gree_Service_Shop_Exception_DataException("Failed to get item info.", 0);
        }
        $item['item_id'] = $item['id'];
        $ret = $this->_addItem($item);
        if ($ret){
            $this->_selectItem($item);
            $this->_logger->tryItem($item, date('Y-m-d H:i:s'));
            /* treasure_data : write log */
            $try_log_record = array(
                'id' 	=>  $item['item_id'],
                'base_price'=> $item['price'],
            );
            $shop_service = getService('shop');
            $shop_service->getTdLogger()->writeTdLoggerLog('item_try',$try_log_record);
        }
    }

    /**
     * removeItem
     * Removes given item from closet
     * @param $item item array object or item id
     *
     * @throws Gree_Service_Shop_Exception_DataException
     */
    public function removeItem($item)
    {
        if (is_numeric($item)){
            $item = $this->_life_service->getItem($item);
            if (PEAR::isError($item)){
                throw new Gree_Service_Shop_Exception_DataException("Failed to get item info.", 0);
            }
        }
        $item['item_id'] = $item['id'];
        $this->_removeItem($item['id']);
    }

    /**
     * commit
     * Commit closet state to database
     * @return bool
     * @throws Gree_Service_Shop_Exception_DataException
     */
    public function commit()
    {
        if ($this->_closet_state != self::CLOSET_STATE_DIRTY){
            return false;
        }
        $result = null;
        if ($this->_validateCloset($this->_closet)){
            $cache_manager = CacheManager::getInstance('mysql');

            $result = $cache_manager->set($this->cache_key, $this->_closet, null, self::CLOSET_NAMESPACE);
            if (PEAR::isError($result)) {
                throw new Gree_Service_Shop_Exception_DataException("Failed to commit [". $result->getMessage() ."]");
            }
        } else {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Closet data");
        }
        if ($result === 0){
            //Really sorry code here, same logic exists in CartManager
            //Anyways, resets the closet state to newly updated one
            $closet_cache = $this->_closet;
            $this->reset();
            $this->_getCloset();
            $this->_closet = $closet_cache;
        }
        return true;
    }

    /**
     * getItemIdsForPreview
     * Generates list of ids for preview generation.
     * Automatically substitutes default item if cloth is taken off.
     * @throws Gree_Service_Shop_Exception_DataException
     * @return array
     */
    public function getItemIdsForPreview()
    {
        $item_id_list = $this->getItemId($this->filterBySelectionState($this->all_items));
        if (!is_array($item_id_list)){
            $item_id_list = $this->_life_service->getBodyDefaultItems($this->user_sex, LIFE_BODY_TYPE_AVATAR);
        }
        if (empty($item_id_list)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to item id list for preview");
        }
        $preview_item_ids = $this->_life_service->getGenerateItemIds($item_id_list);
        if (PEAR::isError($preview_item_ids)){
            throw new Gree_Service_Shop_Exception_DataException("Failed to generate item id list for preview");
        }
        return $preview_item_ids;
    }


    /**
     * finalizeCurrentItems
     * Takes currently selected items and wear them
     *
     * @throws Gree_Service_Shop_Exception_DataException
     */
    public function finalizeCurrentItems()
    {
        //Selected item ids without default items
        $selected_item_ids = $this->getItemId($this->filterDefaultItems($this->filterBySelectionState($this->all_items)));

        //Get detail of list of items selected/in closet from user, may contains duplicates.
        $all_items = $this->_life_service->findUserItemsByUserAndItems($this->user_id,$this->getItemId($this->filterDefaultItems($this->all_items)));

        //Get item master data needed for log.
        $item_master = array();
        foreach($all_items as $item){
            $item_master[$item['item_id']] = array("item_id"=>$item['item_id']);
        }
        $ret = $this->_life_service->populateItems($item_master);
        if (PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to get item info.");
        }

        //Stores list of items already processed. only needs to process first one
        $processed_ids = array();

        //Timestamp for log
        $time = date('Y-m-d H:i:s');

        //
        foreach($all_items as $item){
            //Get item's master id to work with
            $item_id = $item['item_id'];

            //If item id is already processed, skip
            if (in_array($item_id, $processed_ids)){
                continue;
            } else {
                $processed_ids[] = $item_id;
            }
            $item_master_info = $item_master[$item_id];

            //Unique id in life user item.
            $unique_id = $item['id'];
            $item['user_item_id'] = $unique_id;
            //Merge item's master data to user item data.
            $item_info = array_merge($item, $item_master_info);

            //If it is one of item selected by user
            if (in_array($item_id, $selected_item_ids)){
                $this->_logger->selectItem($item_info, $time);
                $ret = $this->_life_service->updateSelectUserItem($this->user_id, $unique_id);
                if (PEAR::isError($ret)) {
                    throw new Gree_Service_Shop_Exception_DataException(sprintf("Failed to select [%s : %s]", $item['item_id'], $unique_id));
                }
                if ($item_info['selected'] != LIFE_ITEM_SELECTED) {
                    $save_log_record = array(
                        'id'        =>  $item_info['item_id'],
                    );
                    $shop_service = getService('shop');
                    $shop_service->getTdLogger()->writeTdLoggerLog('item_save', $save_log_record);
                }
            } else {
                $this->_logger->unselectItem($item_info, $time);
                $ret = $this->_life_service->updateUnselectUserItem($this->user_id, $unique_id);
                if (PEAR::isError($ret)) {
                    throw new Gree_Service_Shop_Exception_DataException(sprintf("Failed to deselect [%s : %s]", $item['item_id'], $unique_id));
                }
            }
        }
        $this->reset();
        $current_connection = $this->_life_service->isUseMasterConnection();
        $this->_life_service->setUseMasterConnection(true);
        $this->_clearCloset();
        $this->_closet = $this->_createCloset();
        $this->all_items;
        $this->_life_service->setUseMasterConnection($current_connection);

        //Update Thumbnail 
        $this->_activateAvatar();
        $this->_life_service->clearForceAvaterKeyCache($this->user_id);

        $this->_clearCart();
    }


    /** ---- [ Protected Methods ] -------------------------------- */
    /**
     * _createCloset
     * Creates empty closet array object
     * @return array
     */
    protected function _createCloset()
    {
        return array(
            'user_id' => $this->user_id,
            'user_sex' => $this->user_sex,
            'items' => array(),
            'mtime' => strtotime('now'),
        );
    }


    public function _clearCloset()
    {
        $cache_manager = CacheManager::getInstance('mysql');
        $ret = $cache_manager->clear($this->cache_key, self::CLOSET_NAMESPACE);
        if (PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to clear closet.");
        }
        $this->_closet_state = self::CLOSET_STATE_NEW;

        $this->_closet = $this->_createCloset();
    }
    public function _clearCart()
    {
        $cache_manager = CacheManager::getInstance('mysql');
        $cache_key = sprintf("%s_%s", $this->user_id, self::CART_KEY);
        $ret = $cache_manager->clear($cache_key, self::CLOSET_NAMESPACE);
        if (PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to clear cart.");
        }
    }

    /**
     * Reads data from mysql cache
     * _getCloset
     *
     * @return boolean
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function _getCloset()
    {
        if (!is_null($this->_closet)){
            return $this->_closet;
        }
        $cache_manager = CacheManager::getInstance('mysql');
        $this->_closet = $cache_manager->get($this->cache_key, self::CART_LIFETIME, self::CLOSET_NAMESPACE);
        if (PEAR::isError($this->_closet)) {
            if ($this->_closet->getCode() == E_CACHE_NO_VALUE) {
                $this->_closet = false;
            } elseif ($this->_closet->getCode() == E_CACHE_EXPIRED) {
                $this->_closet = false;
            } else {
                throw new Gree_Service_Shop_Exception_DataException($this->_closet->getMessage());
            }
        }

        if (!$this->_closet || !$this->_validateCloset($this->_closet)){
            $this->_closet = $this->_createCloset();
            $this->_closet_state = self::CLOSET_STATE_NEW;
        } else {
            $this->_closet_state = self::CLOSET_STATE_OBTAINED;
        }

        return true;
    }

    /**
     * _validateCloset
     * Validate closet object type
     *
     * @param array $closet_array
     *
     * @return bool
     */
    protected function _validateCloset(array $closet_array)
    {
        $keys = array_keys($closet_array);
        $v_keys = array('user_id', 'user_sex', 'mtime', 'items');
        sort($keys);
        sort($v_keys);
        if($keys != $v_keys || !is_array($closet_array['items'])){
            return false;
        }
        return true;
    }

    /**
     * _addItem
     * Adds item to closet
     *
     * @param $item item array object
     */
    protected function _addItem($item){
        $item_id = $item['id'];
        $ret = $this->_getCloset();
        $user_item = $this->_life_service->findUserItemsByUserAndItems($this->user_id, array($item_id));
        if (empty($user_item)){
            return false;
        }
        if ($ret){
            if (!isset($this->_closet['items'][$item_id])){
                if ($item['sex'] == $this->_closet['user_sex'] || $item['sex'] == LIFE_ITEM_SEX_UNISEX){
                    $this->_closet['items'][$item_id] = array(
                        'item_id' => $item_id,
                        'body_type' => $item['body_type'],
                        'selected' => false,
                        'count' => 1);
                    $this->_closet_state = self::CLOSET_STATE_DIRTY;
                }else{
                    return false;
                }
            }
        } else {
            return false;
        }
        return true;
    }

    /**
     * _selectItem
     * Logic for selecting item in closet
     * @param $item_info
     *
     * @return bool
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function _selectItem($item_info){
        $item_list  = $this->_closet['items'];
        $item_ids   = array_keys($item_list);
        $items = $this->_life_service->getServiceManager('life_item')->findItemsByIdsToHash($item_ids);
        if (PEAR::isError($items)){
            throw new Gree_Service_Shop_Exception_DataException("Failed to get item info.", 1);
        }
        foreach ($item_list as $key => $item){
            if (!isset($items[$key])){
                unset($this->_closet['items'][$key]);
            }
        }
        $ret = $this->_life_service->populateItems($item_list);
        if (PEAR::isError($ret)){
            throw new Gree_Service_Shop_Exception_DataException("Failed to get item info.",2);
        }
        $conflicting_items = $this->_life_service->checkConflict($item_list, (int)$item_info['id']);
        if (PEAR::isError($conflicting_items)){
            throw new Gree_Service_Shop_Exception_DataException("Failed to get item info.",3);
        }
        foreach ($conflicting_items as $item){
            $this->_removeItem($item);
        }
        $ret = $this->_life_service->checkAndSetPetStand($this->user_id, $item_info['id'], true);
        if(PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to set pet stand.",0);
        }
        $this->_closet['items'][$item_info['id']]['selected'] = true;
        $this->_closet_state = self::CLOSET_STATE_DIRTY;
        return true;
    }

    /**
     * _removeItem
     * Remove item from closet
     * @param $item_id
     *
     * @return bool
     * @throws Gree_Service_Shop_Exception_DataException
     *
     */
    protected function _removeItem($item_id){
        if (empty($item_id)) {
            throw new Gree_Service_Shop_Exception_DataException("No item specified for removal");
        }

        $item = $this->_life_service->getItem($item_id);
        if (PEAR::isError($item)) {
            return $item;
        }
        if ($item === null) {
            throw new Gree_Service_Shop_Exception_DataException('Specified item not found.');
        }
        // Log
        $item['item_id'] = $item_id;
        $logger = $this->_life_service->getStatisticsLogger();
        $logger->exceptItem($item, date('Y-m-d H:i:s'));


        if (!isset($this->_closet['items'][$item_id])) {
            //check if item is worn by user
            $list = $this->_life_service->findUserItemsByUserAndItem($this->user_id, $item_id);
            if (PEAR::isError($list)) {
                return $list;
            }
            if (count($list) > 0) {
                // if worn by user, remove item from user.
                if (!$this->_isItemRemovable($item)) {
                    throw new Gree_Service_Shop_Exception_DataException('Specified item cannot be removed.');
                }
            }
            $this->_addItem($item);
            $this->_selectItem($item);
            //deselect
            $this->_closet['items'][$item_id]['selected'] = false;

        } else {
            unset($this->_closet['items'][$item_id]);
            $this->_closet_state = self::CLOSET_STATE_DIRTY;
        }


        //pet stand
        $ret = $this->_life_service->checkAndSetPetStand($this->user_id, $item_id, false);
        if(PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException('Failed to set petstand');
        }

        return true;
    }

    /**
     * Check if item is removable.
     *
     * @param $item item array
     *
     * @throws Gree_Service_Shop_Exception_DataException
     * @return    boolean   true if removable
     */
    protected function _isItemRemovable($item) {
        $category = $this->_life_service->getCategory($item['category_code']);
        if (PEAR::isError($category)) {
            throw new Gree_Service_Shop_Exception_DataException("Could not obtain category info");
        }
        if (!isset($category['can_except'])) {
            return true;
        }
        return $category['can_except'];
    }

    /**
     * _activateAvatar
     * Activate and/or update profile image on sns side
     *
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function _activateAvatar() {
        $profile_manager = $this->_life_service->getManager('profile');
        if (PEAR::isError($profile_manager)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to get profile manager.");
        }

        // ���Х�����ͭ����ʬ�����
        $ret = $profile_manager->isAvatar($this->user_id);
        if (PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to get avatar setting.");
        }

        if ($ret == false){
            return;
        }

        $sns = getService('sns');
        if (PEAR::isError($sns)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to get sns service.");
        }

        $activateavatar_disabled = Config::get('emergency_activateavatar_disabled');
        $ret = $sns->activateAvatar($this->user_id, $activateavatar_disabled);
        if (PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to activate avatar.");
        }
    }


    /**
     * _checkAccessorFormat
     * Checks accessor format
     *
     * @params array $accessor
     *
     * @return null
     */
    protected function _checkAccessorFormat(array $accessor)
    {
        parent::_checkAccessorFormat($accessor);
        $user = $accessor['user'];
        if (!($user instanceof Gree_Service_Shop_Data_User)) {
            $ex_msg = 'invalid accessor';
            throw new Gree_Service_Shop_Exception_DataException($ex_msg);
        }
    }

    // {{{ getCartItemsByShop
    /**
     *	���ߥ����Ȥ˳�Ǽ����Ƥ��뾦�ʤΰ�����������롣
     *
     *	@param	$cart		����������
     *	@param	$shop		����å�
     *	@return	array		���ʰ���
     */
    protected function _filterCartItem($items) {
        // �桼��������ͭ���Ƥ��뾦�ʰ����μ���
        $list = array();
        foreach ($items as $item_id => $item) {
            if ( isset($item['body_type']) && $item['body_type'] == LIFE_BODY_TYPE_AVATAR) {
                $list[$item_id] = $item;
            }
        }
        return $list;
    }
    // }}}

    /** ---- [ Getter Methods ] -------------------------------- */
    /**
     * UserItems        : User's item
     * ClosetItems      : Items in closet
     * AllItems         : User+Closet Items
     */

    /**
     * __readCacheKey
     * Generates cache key
     *
     * @return string
     */
    protected function __readCacheKey()
    {
        $cache_key = sprintf("%s_%s", $this->user_id, self::CLOSET_KEY);
        return $cache_key;
    }

    /**
     * __readUserItems
     * Get list of item user is wearing at the moment.
     * Sets $this->user_items
     * @return array
     */
    protected function __readUserItems()
    {
        $user_selected_items = $this->_life_service->findSelectedUserItemsByUserAndSexAndBodyType(
            $this->user_id,
            $this->user_sex,
            LIFE_BODY_TYPE_AVATAR
        );
        $user_items = $this->_life_service->getUserSelectedItems(
            $this->user_id,
            $this->user_sex,
            LIFE_BODY_TYPE_AVATAR,
            $user_selected_items
        );
        if (is_null($user_items)){
            return array();
        } else {
            //Check in closet items
            if ( isset($this->_closet['items'])){
                foreach ( $this->_closet["items"] as $closet_item){
                    if(isset($user_items[$closet_item['item_id']])){
                        $user_items[$closet_item['item_id']]['selected'] = $closet_item['selected'];
                    }
                }
            };
        }
        return $user_items;
    }


    /**
     * __readClosetItems
     * Get all items in closet
     * Sets $this->closet_items
     *
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function __readClosetItems()
    {
        if (is_null($this->_closet)){
            $closet = $this->_getCloset();
            if ($closet == false){
                throw new Gree_Service_Shop_Exception_DataException("Failed get closet data");
            }
        }
        if (isset($this->_closet['items'])){
            return $this->_filterCartItem($this->_closet['items']);
        }
        return array();
    }

    //
    /**
     * __readAllItems
     * get union of user item and closet items
     * Sets $this->all_items
     *
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function __readAllItems(){
        $all_items = $this->user_items + $this->closet_items;
        //Get item infos
        $ret = $this->_life_service->populateItems($all_items);
        if (PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException($ret->getMessage());
        }

        // check for conflict
        $ret = $this->_life_service->checkConflictList($all_items);
        if (PEAR::isError($ret)) {
            throw new Gree_Service_Shop_Exception_DataException($ret->getMessage());
        }
        return $all_items;
    }

    /** ---- [ Utility Methods ] -------------------------------- */
    /**
     * filterBySelectionState
     * Filter item by selection state, by default returns item that are selected.
     *
     * @param     $items
     * @param int $state ITEM_STATE_SELECTED/ITEM_STATE_DESELECTED
     *
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     *
     */
    public function filterBySelectionState($items, $state = self::ITEM_STATE_SELECTED)
    {
        if ($state != self::ITEM_STATE_SELECTED && $state != self::ITEM_STATE_DESELECTED){
            throw new Gree_Service_Shop_Exception_DataException("Incompatible state specified");
        }
        if (is_string($items)){
            $items = $this->$items;
        }
        if (!is_array($items)){
            return array();
        }
        $filtered_list = array();
        foreach ($items as $item_id => $item) {
            if ($item['selected'] == ($state == self::ITEM_STATE_SELECTED)) {
                $filtered_list[$item_id] = $item;
            }
        }
        return $filtered_list;
    }

    /**
     * getItemId
     * Creates array of item ids from array of item array object
     * Looking for item_id, then id attributes.
     * Returns empty array if not found.
     *
     * @param $items string|array if string, tries to get same name property in closet and return id lists
     *
     * @return array
     */
    public function getItemId($items)
    {
        if (is_string($items)){
            $items = $this->$items;
        }
        if (!is_array($items)){
            return array();
        }
        if (empty($items)){
            return $items;
        }
        $item_ids = Gree_Util::setAssocKey($items, 'item_id');
        if (empty($items)){
            $item_ids = Gree_Util::setAssocKey($items, 'id');
        }
        if (PEAR::isError($item_ids)){
            return array();
        }
        return array_keys($item_ids);
    }

    /**
     * filterDefaultItems
     * Remove default items from list of items.
     *
     * @param $items array of item array object
     *
     * @return mixed
     * @throws Gree_Service_Shop_Exception_DataException
     */
    public function filterDefaultItems(array $items)
    {

        $default_items = $this->_life_service->getBodyDefaultItems($this->user_sex, LIFE_BODY_TYPE_AVATAR);
        if (PEAR::isError($default_items)) {
            throw new Gree_Service_Shop_Exception_DataException("Failed to get default item sets");
        }
        $default_list = $this->getItemId($default_items);
        foreach($items as $key => $item){
            if (isset($item['id']) && in_array($item['id'], $default_list)){
                unset($items[$key]);
            } elseif (isset($item['item_id']) && in_array($item['item_id'], $default_list)){
                unset($items[$key]);
            }
        }
        return $items;
    }

}
