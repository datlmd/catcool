<?php

class Gree_Service_AvatarFeed_Processor_Followed_List_Count
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return int
     *
     * return the followed users total of a user
     */
    protected function invoke()
    {
        $mod_follow = self::getModule('Follow');

        $actual_followed_count = 0;
        $followed_count        = 0;
        try {
            // get �ºݤο�
            $actual_followed_count = $mod_follow->getFollowedCount($this->input_values['user_id']);
            // get �ޥ��ڡ���ɽ��
            list($following_count, $followed_count) = $mod_follow->getFollowCount($this->input_values['user_id']);
        } catch (Exception $e) {
            $msg     = 'failed get the followed users total';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $followed_count,
            $actual_followed_count,
        );
    }
}
