<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Incentive_AddTest
 *
 * this test is incentive add test
 */
final class Gree_Service_Avatarfeed_Test_Processor_Incentive_AddTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;
    var $setting_module;

    var $action_user   = UNIT_TEST_USER_ID_1;
    var $inaction_user = UNIT_TEST_USER_ID_2;

    var $today = null;

    var $point_manager = null;

    var $like_setting_info;
    var $liked_setting_info;

    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();
        $this->module      = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy($this->action_user);

        try {
            $get_params = array(
                'user_id'  => $this->action_user,
                'limit'    => 100,
                'start_id' => null
            );
            list($has_more, $like_data) = $this->module->getLikeTimeLine($get_params);

            foreach ($like_data as $entry) {
                $delete_params = array(
                    'entry_id' => $entry['parent']['body']['entry_id'],
                    'user_id'  => UNIT_TEST_USER_ID_1,
                    'liked_user_id' => UNIT_TEST_USER_ID_2
                );
                $this->module->removeLike($delete_params);
            }
        } catch (Exception $e) {
        }

        $this->today = date("Y-m-d H:i:s");

        $srv_shop            = getService('shop');
        $this->point_manager = $srv_shop->getPointManager();

        try {
            $this->point_manager->resetPointAndHistory($this->action_user, date('Ymd'));
            $this->point_manager->resetPointAndHistory($this->inaction_user, date('Ymd'));
        } catch (Exception $e) {
        }

        $this->setting_module = Gree_Service_AvatarFeed_Module::singleton('Setting');
        $start_date_time = date("Y-m-d H:i:s", mktime(date('H') -1));
        $end_date_time   = date("Y-m-d H:i:s", mktime(date('H') +1));

        $like_save_params     = array(
            'action_type'                 => 'like',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 10,
            'daily_limit_of_point'        => 50,
            'limit_of_point_to_same_user' => 3,
        );
        $this->setting_module->saveSettingInfoOfIncentive($like_save_params);

        $liked_save_params     = array(
            'action_type'                 => 'liked',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 20,
            'daily_limit_of_point'        => 100,
            'limit_of_point_to_same_user' => 5,
        );
        $this->setting_module->saveSettingInfoOfIncentive($liked_save_params);

        sleep(2);

        $this->like_setting_info  = $this->setting_module->getSettingInfoOfIncentive(array('action_type' => 'like'));
        $this->liked_setting_info = $this->setting_module->getSettingInfoOfIncentive(array('action_type' => 'liked'));


    }

    /**
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS
     *   added Point to action and inaction user
     */
    public function test_add_point_success()
    {
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_2);

        $this->assertTrue($is_success_create_entry);
        $this->assertFalse(empty($entry_id));

        sleep(2);

        $add_params = array(
            'entry_id' => $entry_id,
            'user_id'  => UNIT_TEST_USER_ID_1,
            'liked_user_id' => UNIT_TEST_USER_ID_2
        );
        list($is_success_like, $like_entry_id) = $this->module->addLike($add_params);

        $this->assertTrue($is_success_like);
        $this->assertEquals($entry_id, $like_entry_id);

        sleep(2);

        $incentive_params = array(
            'incentive_category' => 'point',
            'target_action'      => 'like',
            'user_id'            => $this->action_user,
            'target_entry_id'    => $entry_id,
            'target_date'        => $this->today,
            'liked_user_id'      => $this->inaction_user
        );
        $result_add_incentive = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

        $this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS, $result_add_incentive);

        sleep(2);

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(1, count($action_user_history));
        $action_user_history_data = array_shift($action_user_history);
        $this->assertEquals($this->action_user, $action_user_history_data['user_id']);
        $this->assertEquals($this->like_setting_info['point_per_action'], $action_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD, $action_user_history_data['type']);

        $this->assertEquals(1, count($inaction_user_history));
        $inaction_user_history_data = array_shift($inaction_user_history);
        $this->assertEquals($this->inaction_user, $inaction_user_history_data['user_id']);
        $this->assertEquals($this->liked_setting_info['point_per_action'], $inaction_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED, $inaction_user_history_data['type']);
    }

    /**
     * case: $like_setting_info['is_active'] == false && $liked_setting_info['is_active'] == false
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_DISABLED
     */
    public function test_setting_info_is_no_active()
    {
        $start_date_time = date("Y-m-d H:i:s", mktime(date('H') +1));
        $end_date_time   = date("Y-m-d H:i:s", mktime(date('H') +2));

        $like_save_params     = array(
            'action_type'                 => 'like',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 10,
            'daily_limit_of_point'        => 50,
            'limit_of_point_to_same_user' => 3,
        );
        $this->setting_module->saveSettingInfoOfIncentive($like_save_params);

        $liked_save_params     = array(
            'action_type'                 => 'liked',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 20,
            'daily_limit_of_point'        => 1000,
            'limit_of_point_to_same_user' => 5,
        );
        $this->setting_module->saveSettingInfoOfIncentive($liked_save_params);

        sleep(2);

        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_2);

        $incentive_params = array(
            'incentive_category' => 'point',
            'target_action'      => 'like',
            'user_id'            => $this->action_user,
            'target_entry_id'    => 'not need entry_id',
            'target_date'        => $this->today,
            'liked_user_id'      => $this->inaction_user
        );
        $result_add_incentive = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

        $this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_NO_ACTIVE, $result_add_incentive);
    }

    /**
     * case: $like_setting_info['is_active'] == false
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_DISABLED
     *   added Point to action or inaction user
     */
    public function test_add_point_active_one_side_1()
    {
        $start_date_time = date("Y-m-d H:i:s", mktime(date('H') +1));
        $end_date_time   = date("Y-m-d H:i:s", mktime(date('H') +2));

        $like_save_params     = array(
            'action_type'                 => 'like',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 10,
            'daily_limit_of_point'        => 50,
            'limit_of_point_to_same_user' => 3,
        );
        $this->setting_module->saveSettingInfoOfIncentive($like_save_params);

        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_2);

        $this->assertTrue($is_success_create_entry);
        $this->assertFalse(empty($entry_id));

        sleep(2);

        $add_params = array(
            'entry_id' => $entry_id,
            'user_id'  => UNIT_TEST_USER_ID_1,
            'liked_user_id' => UNIT_TEST_USER_ID_2
        );
        list($is_success_like, $like_entry_id) = $this->module->addLike($add_params);

        $this->assertTrue($is_success_like);
        $this->assertEquals($entry_id, $like_entry_id);

        sleep(2);

        $incentive_params = array(
            'incentive_category' => 'point',
            'target_action'      => 'like',
            'user_id'            => $this->action_user,
            'target_entry_id'    => $entry_id,
            'target_date'        => $this->today,
            'liked_user_id'      => $this->inaction_user
        );
        $result_add_incentive = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

        $this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_DISABLED, $result_add_incentive);
        sleep(2);

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(0, count($action_user_history));

        $this->assertEquals(1, count($inaction_user_history));
        $inaction_user_history_data = array_shift($inaction_user_history);
        $this->assertEquals($this->inaction_user, $inaction_user_history_data['user_id']);
        $this->assertEquals($this->liked_setting_info['point_per_action'], $inaction_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED, $inaction_user_history_data['type']);
    }

    /**
     * case: $liked_setting_info['is_active'] == false
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS
     *   added Point to action or inaction user
     */
    public function test_add_point_active_one_side_2()
    {
        $start_date_time = date("Y-m-d H:i:s", mktime(date('H') +1));
        $end_date_time   = date("Y-m-d H:i:s", mktime(date('H') +2));

        $liked_save_params     = array(
            'action_type'                 => 'liked',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 10,
            'daily_limit_of_point'        => 50,
            'limit_of_point_to_same_user' => 3,
        );
        $this->setting_module->saveSettingInfoOfIncentive($liked_save_params);

        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_2);

        $this->assertTrue($is_success_create_entry);
        $this->assertFalse(empty($entry_id));

        sleep(2);

        $add_params = array(
            'entry_id' => $entry_id,
            'user_id'  => UNIT_TEST_USER_ID_1,
            'liked_user_id' => UNIT_TEST_USER_ID_2
        );
        list($is_success_like, $like_entry_id) = $this->module->addLike($add_params);

        $this->assertTrue($is_success_like);
        $this->assertEquals($entry_id, $like_entry_id);

        sleep(2);

        $incentive_params = array(
            'incentive_category' => 'point',
            'target_action'      => 'like',
            'user_id'            => $this->action_user,
            'target_entry_id'    => $entry_id,
            'target_date'        => $this->today,
            'liked_user_id'      => $this->inaction_user
        );
        $result_add_incentive = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

        $this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS, $result_add_incentive);
        sleep(2);

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(1, count($action_user_history));
        $action_user_history_data = array_shift($action_user_history);
        $this->assertEquals($this->action_user, $action_user_history_data['user_id']);
        $this->assertEquals($this->like_setting_info['point_per_action'], $action_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD, $action_user_history_data['type']);

        $this->assertEquals(0, count($inaction_user_history));
    }

    /**
     * case: $same_user_count <= $setting_info['limit_of_point_to_same_user']
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS
     *   added Point to action and inaction user
     *   $expect_point = $this->setting_info['point_per_action'] * count($created_entry_id);
     */
    public function test_add_point_in_range_same_user_limit_1()
    {
        $created_entry_id = array();
        for ($i = 0; $i < $this->like_setting_info['limit_of_point_to_same_user']; $i++) {
            list($is_success_create_entry, $entry_id) = $this->_createEntry($this->inaction_user, $this->inaction_user);
            $this->assertTrue($is_success_create_entry);
            $created_entry_id[$i] = $entry_id;
        }

        $this->assertEquals($this->like_setting_info['limit_of_point_to_same_user'], count($created_entry_id));
        $this->assertFalse(empty($created_entry_id));

        sleep(2);

        foreach ($created_entry_id as $entry_id) {
            $add_params = array(
                'entry_id' => $entry_id,
                'user_id'  => UNIT_TEST_USER_ID_1,
                'liked_user_id' => UNIT_TEST_USER_ID_2
            );
            list($is_success_like, $like_entry_id) = $this->module->addLike($add_params);
            $this->assertTrue($is_success_like);
            $this->assertEquals($entry_id, $like_entry_id);

            sleep(2);

            $incentive_params = array(
                'incentive_category' => 'point',
                'target_action'      => 'like',
                'user_id'            => $this->action_user,
                'target_entry_id'    => $entry_id,
                'target_date'        => $this->today,
                'liked_user_id'      => $this->inaction_user
            );
            $return_code      = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

            //$this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS, $return_code);
        }

        sleep(2);

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(1, count($action_user_history));
        $action_user_history_data = array_shift($action_user_history);
        $this->assertEquals($this->action_user, $action_user_history_data['user_id']);
        $expect_like_point = $this->like_setting_info['point_per_action'] * count($created_entry_id);
        $this->assertEquals($expect_like_point, $action_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD, $action_user_history_data['type']);

        $this->assertEquals(1, count($inaction_user_history));
        $inaction_user_history_data = array_shift($inaction_user_history);
        $this->assertEquals($this->inaction_user, $inaction_user_history_data['user_id']);
        $expect_liked_point = $this->liked_setting_info['point_per_action'] * count($created_entry_id);
        $this->assertEquals($expect_liked_point, $inaction_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED, $inaction_user_history_data['type']);
    }

    /**
     * case: $same_user_count <= $setting_info['limit_of_point_to_same_user']
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS
     *   added Point to action and inaction user
     *   $expect_point = $this->setting_info['point_per_action'] * count($created_entry_id);
     */
    public function test_add_point_in_range_same_user_limit_2()
    {
        $created_entry_id = array();
        for ($i = 0; $i < $this->liked_setting_info['limit_of_point_to_same_user']; $i++) {
            list($is_success_create_entry, $entry_id) = $this->_createEntry($this->inaction_user, $this->inaction_user);
            $this->assertTrue($is_success_create_entry);
            $created_entry_id[$i] = $entry_id;
        }

        $this->assertEquals($this->liked_setting_info['limit_of_point_to_same_user'], count($created_entry_id));
        $this->assertFalse(empty($created_entry_id));

        sleep(2);

        foreach ($created_entry_id as $entry_id) {
            $add_params = array(
                'entry_id' => $entry_id,
                'user_id'  => UNIT_TEST_USER_ID_1,
                'liked_user_id' => UNIT_TEST_USER_ID_2
            );
            list($is_success_like, $like_entry_id) = $this->module->addLike($add_params);
            $this->assertTrue($is_success_like);
            $this->assertEquals($entry_id, $like_entry_id);

            sleep(2);

            $incentive_params = array(
                'incentive_category' => 'point',
                'target_action'      => 'like',
                'user_id'            => $this->action_user,
                'target_entry_id'    => $entry_id,
                'target_date'        => $this->today,
                'liked_user_id'      => $this->inaction_user
            );
            $return_code      = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

            //$this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS, $return_code);
        }

        sleep(4);

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(1, count($action_user_history));
        $action_user_history_data = array_shift($action_user_history);
        $this->assertEquals($this->action_user, $action_user_history_data['user_id']);
        $expect_like_point = $this->like_setting_info['point_per_action'] * $this->like_setting_info['limit_of_point_to_same_user'];
        $this->assertEquals($expect_like_point, $action_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD, $action_user_history_data['type']);

        $this->assertEquals(1, count($inaction_user_history));
        $inaction_user_history_data = array_shift($inaction_user_history);
        $this->assertEquals($this->inaction_user, $inaction_user_history_data['user_id']);
        $expect_liked_point = $this->liked_setting_info['point_per_action'] * count($created_entry_id);
        $this->assertEquals($expect_liked_point, $inaction_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED, $inaction_user_history_data['type']);
    }

    /**
     * case: $same_user_count < $setting_info['limit_of_point_to_same_user']
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS
     *   added Point to action and inaction user
     *   $expect_point = $this->setting_info['point_per_action'] * $this->setting_info['limit_of_point_to_same_user']
     */
    public function test_add_point_over_same_user_limit_1()
    {
        $created_entry_id = array();
        for ($i = 0; $i <= $this->like_setting_info['limit_of_point_to_same_user']; $i++) {
            list($is_success_create_entry, $entry_id) = $this->_createEntry($this->inaction_user, $this->inaction_user);
            $this->assertTrue($is_success_create_entry);
            $created_entry_id[$i] = $entry_id;
        }

        $this->assertEquals($this->like_setting_info['limit_of_point_to_same_user'] + 1, count($created_entry_id));
        $this->assertFalse(empty($created_entry_id));

        sleep(2);

        foreach ($created_entry_id as $entry_id) {
            $add_params = array(
                'entry_id' => $entry_id,
                'user_id'  => UNIT_TEST_USER_ID_1,
                'liked_user_id' => UNIT_TEST_USER_ID_2
            );
            list($is_success_like, $like_entry_id) = $this->module->addLike($add_params);
            $this->assertTrue($is_success_like);
            $this->assertEquals($entry_id, $like_entry_id);

            sleep(2);

            $incentive_params = array(
                'incentive_category' => 'point',
                'target_action'      => 'like',
                'user_id'            => $this->action_user,
                'target_entry_id'    => $entry_id,
                'target_date'        => $this->today,
                'liked_user_id'      => $this->inaction_user
            );
            $return_code      = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

            //$this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS, $return_code);
        }

        sleep(2);

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(1, count($action_user_history));
        $action_user_history_data = array_shift($action_user_history);
        $this->assertEquals($this->action_user, $action_user_history_data['user_id']);
        $expect_like_point = $this->like_setting_info['point_per_action'] * $this->like_setting_info['limit_of_point_to_same_user'];
        $this->assertEquals($expect_like_point, $action_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD, $action_user_history_data['type']);

        $this->assertEquals(1, count($inaction_user_history));
        $inaction_user_history_data = array_shift($inaction_user_history);
        $this->assertEquals($this->inaction_user, $inaction_user_history_data['user_id']);
        $expect_liked_point = $this->liked_setting_info['point_per_action'] * count($created_entry_id);
        $this->assertEquals($expect_liked_point, $inaction_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED, $inaction_user_history_data['type']);
    }

    /**
     * case: $same_user_count < $setting_info['limit_of_point_to_same_user']
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS
     *   added Point to action and inaction user
     *   expect_point = $this->setting_info['point_per_action'] * $this->setting_info['limit_of_point_to_same_user']
     */
    public function test_add_point_over_same_user_limit_2()
    {
        $created_entry_id = array();
        for ($i = 0; $i <= $this->liked_setting_info['limit_of_point_to_same_user']; $i++) {
            list($is_success_create_entry, $entry_id) = $this->_createEntry($this->inaction_user, $this->inaction_user);
            $this->assertTrue($is_success_create_entry);
            $created_entry_id[$i] = $entry_id;
        }

        $this->assertEquals($this->liked_setting_info['limit_of_point_to_same_user'] + 1, count($created_entry_id));
        $this->assertFalse(empty($created_entry_id));

        sleep(2);

        foreach ($created_entry_id as $entry_id) {
            $add_params = array(
                'entry_id' => $entry_id,
                'user_id'  => UNIT_TEST_USER_ID_1,
                'liked_user_id' => UNIT_TEST_USER_ID_2
            );
            list($is_success_like, $like_entry_id) = $this->module->addLike($add_params);
            $this->assertTrue($is_success_like);
            $this->assertEquals($entry_id, $like_entry_id);

            sleep(2);

            $incentive_params = array(
                'incentive_category' => 'point',
                'target_action'      => 'like',
                'user_id'            => $this->action_user,
                'target_entry_id'    => $entry_id,
                'target_date'        => $this->today,
                'liked_user_id'      => $this->inaction_user
            );
            $return_code      = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

            //$this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS, $return_code);
        }

        sleep(2);

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(1, count($action_user_history));
        $action_user_history_data = array_shift($action_user_history);
        $this->assertEquals($this->action_user, $action_user_history_data['user_id']);
        $expect_like_point = $this->like_setting_info['point_per_action'] * $this->like_setting_info['limit_of_point_to_same_user'];
        $this->assertEquals($expect_like_point, $action_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD, $action_user_history_data['type']);

        $this->assertEquals(1, count($inaction_user_history));
        $inaction_user_history_data = array_shift($inaction_user_history);
        $this->assertEquals($this->inaction_user, $inaction_user_history_data['user_id']);
        $expect_liked_point = $this->liked_setting_info['point_per_action'] * $this->liked_setting_info['limit_of_point_to_same_user'];
        $this->assertEquals($expect_liked_point, $inaction_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED, $inaction_user_history_data['type']);
    }

    /**
     * case: $target_points[$type] >= $setting_info['daily_limit_of_point']
     * expect:
     *   return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS
     *   added Point to action and inaction user
     *   $expect_point = $this->setting_info['daily_limit_of_point']
     */
    public function test_add_point_over_point_limit()
    {
        $created_entry_id = array();
        for ($i = 0; $i < $this->liked_setting_info['limit_of_point_to_same_user']; $i++) {
            list($is_success_create_entry, $entry_id) = $this->_createEntry($this->inaction_user, $this->inaction_user);
            $this->assertTrue($is_success_create_entry);
            $created_entry_id[] = $entry_id;

            list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_3);
            $this->assertTrue($is_success_create_entry);
            $created_entry_id[] = $entry_id;
        }

        $this->assertEquals($this->liked_setting_info['limit_of_point_to_same_user'] * 2, count($created_entry_id));
        $this->assertFalse(empty($created_entry_id));

        sleep(2);

        foreach ($created_entry_id as $entry_id) {
            $incentive_params = array(
                'incentive_category' => 'point',
                'target_action'      => 'like',
                'user_id'            => $this->action_user,
                'target_entry_id'    => $entry_id,
                'target_date'        => $this->today,
                'liked_user_id'      => $this->inaction_user
            );
            $return_code      = $this->avatar_feed->process('incentive_add', $incentive_params, $this->action_user);

            //$this->assertEquals(Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS, $return_code);

            sleep(2);
        }

        $action_user_history   = $this->point_manager->getHistory($this->action_user, 0, 10);
        $inaction_user_history = $this->point_manager->getHistory($this->inaction_user, 0, 10);

        $this->assertEquals(1, count($action_user_history));
        $action_user_history_data = array_shift($action_user_history);
        $this->assertEquals($this->action_user, $action_user_history_data['user_id']);
        $this->assertEquals($this->like_setting_info['daily_limit_of_point'], $action_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD, $action_user_history_data['type']);

        $this->assertEquals(1, count($inaction_user_history));
        $inaction_user_history_data = array_shift($inaction_user_history);
        $this->assertEquals($this->inaction_user, $inaction_user_history_data['user_id']);
        $this->assertEquals($this->liked_setting_info['daily_limit_of_point'], $inaction_user_history_data['point']);
        $this->assertEquals(GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED, $inaction_user_history_data['type']);
    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_incentive_add',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}