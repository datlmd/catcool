<?php
/**
 * Gree_GenericDao_Quiz_UserDao
 *
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

class Gree_GenericDao_Quiz_UserDao extends Gree_GenericDao
{
    /** @public table name */
    public $_table_name = 'quiz_user_clear';
    /** @public primary key */
    public $_primary_key = 'id';
    /** @public auto increment */
    public $_auto_increment = true;
    /** @public updated at column */
    public $_updated_at_column = 'mtime';
    /** @public create at column */
    public $_created_at_column = 'ctime';
    /** @public master dsn */
    public $_master_dsn = 'gree://master/avatar_quiz';
    /** @public slave dsn */
    public $_slave_dsn = 'gree://slave/avatar_quiz';
    /** @public field names */
    public $_field_names = [
        'id',
        'user_id',
        'event_id',
        'clear_count',
        'ctime',
        'mtime',
    ];
    public $_queries = [
        // --select
        'find_by_user_id_and_event_id'             => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND event_id = :event_id',
        ],
        'show_table'                               => [
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ],
        'find_by_event_id'                         => [
            'sql' => 'SELECT user_id, clear_count FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ],
        'count_by_event_id'                        => [
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ],
        // --insert & update
        'insert_user'                              => [
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, event_id, ctime) VALUES (:user_id, :event_id, NOW())',
        ],
        'update_count_by_event_id_and_clear_count' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET clear_count = clear_count + 1, mtime = :mtime WHERE user_id = :user_id AND event_id = :event_id AND clear_count = :clear_count',
        ],
        // --create table
        'create_table'                             => [
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT(10) UNSIGNED NOT NULL,
                `event_id` TINYINT(3) UNSIGNED NOT NULL,
                `clear_count` TINYINT(3) UNSIGNED NOT NULL DEFAULT 0, 
                `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `user_id` (`user_id`, `event_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
    ];
    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Quiz_UserFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Quiz_UserFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    // public string �ơ��֥�ե������ֹ�ե����ޥå�
    public $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     * @param      $dao        DAO���饹
     * @param      $type       ���������ס�
     * @param      $hint       �ơ��֥�����ҥ��
     * @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        if (empty($hint)) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾�˥ե�������ɲ�
        $table_suffix = sprintf($this->_table_suffix_format, $hint['event_id']);
        $table_name   = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
