<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Entry_Limited_Show
 */
class Gree_Service_AvatarFeed_Processor_Entry_Limited_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return array has is_exist, entry_data
     *
     * check is_block status
     * if block status is true then return array(false, array())
     *
     * entry data appended user_info
     */
    protected function invoke()
    {
        $entry  = array();
        $is_exist    = false;
        $mod_appfeed = self::getModule('AppFeed');

        try {
            list($is_exist, $entry) = $mod_appfeed->getEntry($this->input_values['entry_id']);
        } catch (Exception $e) {
            $msg     = 'failed get limited entry.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_SHOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array(
                $is_exist,
                array()
            );
        }

        if ($is_exist == false || empty($entry)) {
            return array(
                false,
                array()
            );
        }
        $entry = array_shift($entry);

        // check visibility
        $mod_block = self::getModule('Block');
        $is_block  = $mod_block->getBlockUser($this->_certified_user->my['user_id'], $entry['content']['sender_id']);
        if ($is_block) {
            return array(
                false,
                $entry
            );
        }

        return array(
            $is_exist,
            $entry
        );
    }
}
