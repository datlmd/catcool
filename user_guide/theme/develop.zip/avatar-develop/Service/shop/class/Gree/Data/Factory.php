<?php
/**
 * Service/shop/class/Gree/Data/Factory.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */

/**
 * Gree_Service_Shop_Data_Factory
 *
 * @package GREE
 * @access  public
 */
abstract class Gree_Service_Shop_Data_Factory
{
    // ----[ Properties ]-------------------------------------------------------
    private static $mappers = array();

    // ----[ Methods ]----------------------------------------------------------
    /**
     * get instance of data object by key
     * - data name ex) Gacha_Master_Attr
     *
     * @access  public
     * @static
     * @param   string  $data_name      php < 5.3で遅延静的束縛ができないのでしかたなく
     * @param   mixed   $key            the key
     * @param   array   $hint           the farm hint
     * @return  Gree_Service_Shop_AbstractData
     */
    public static function getData($data_name, $primary_key, $hint = null)
    {
        return getService('shop')
            ->getDataMapper($data_name)
            ->get($primary_key, $hint);
    }

    /**
     * get instances of data object by keys
     * - data name ex) Gacha_Master_Attr
     *
     * @param   string
     * @param   array
     * @param   hint
     * @return  array   the instance list
     */
    public static function getDataList($data_name, $primary_keys, $hint = null)
    {
        return getService('shop')
            ->getDataMapper($data_name)
            ->mget($primary_keys, $hint);
    }

    /**
     * instantiate data object by record
     * - data name ex) Gacha_Master_Attr
     *
     * @access  public
     * @static
     * @param   string  $data_name
     * @param   array   $record
     */
    public static function instantiate($data_name, $record)
    {
        return getService('shop')
            ->getDataMapper($data_name)
            ->instantiate($record);
    }

    /**
     * instantiate data object by records
     * - data name ex) Gacha_Master_Attr
     *
     * @access  public
     * @param   string  $data_name
     * @param   array   $records
     * @return  array   the object list
     */
    public static function instantiateList($data_name, $records)
    {
        return getService('shop')
            ->getDataMapper($data_name)
            ->minstantiate($records);
    }
}
