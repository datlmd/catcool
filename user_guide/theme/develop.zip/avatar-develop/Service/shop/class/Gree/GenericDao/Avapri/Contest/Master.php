<?php
/**
 * Gree_GenericDao_AvapriContestMasterDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Contest_MasterDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'master_contest';
	/** @var primary key */
    var $_primary_key = 'contest_id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'contest_id',
        'name',
        'state',
        'type',
        'open_datetime',
        'close_datetime',
        'entry_open_datetime',
        'entry_close_datetime',
        'vote_open_datetime',
        'vote_close_datetime',
        'entry_seal_open_datetime',
        'entry_seal_close_datetime',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        // select----------------------
        'find_by_contest_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id',
        ),
        'get_all_master' => array(// for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        // update----------------------
        'update_master' => array( // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET 
                            name = :name,
                            state = :state,
                            open_datetime = :open_datetime, 
                            close_datetime=:close_datetime, 
                            entry_open_datetime = :entry_open_datetime, 
                            entry_close_datetime = :entry_close_datetime, 
                            vote_open_datetime = :vote_open_datetime, 
                            vote_close_datetime = :vote_close_datetime, 
                            entry_seal_open_datetime = :entry_seal_open_datetime, 
                            entry_seal_close_datetime = :entry_seal_close_datetime 
                        WHERE 
                            contest_id =:contest_id',
        ),
        // insert----------------------
        'insert_master' => array( // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ 
                            (name, open_datetime, close_datetime, entry_open_datetime, entry_close_datetime, vote_open_datetime, vote_close_datetime, entry_seal_open_datetime, entry_seal_close_datetime, ctime) 
                         VALUES 
                            (:name, :open_datetime, :close_datetime, :entry_open_datetime, :entry_close_datetime, :vote_open_datetime, :vote_close_datetime, entry_seal_open_datetime, entry_seal_close_datetime, NOW())',
        ),  
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `contest_id`        INT(11)     UNSIGNED NOT NULL AUTO_INCREMENT,
                    `name`     VARCHAR(255)   NOT NULL DEFAULT '',
                    `state`     INT(11)   NOT NULL DEFAULT 0,
                    `open_datetime`     DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `close_datetime`     DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `entry_open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `entry_close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `vote_open_datetime` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                    `vote_close_datetime` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                    `entry_seal_open_datetime` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                    `entry_seal_close_datetime` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                    `mtime`     TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                    `ctime`     DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`contest_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),//ALTER TABLE master_contest ADD COLUMN state INT(11) NOT NULL DEFAULT 0 AFTER name;
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );
    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
?>
