<?php
/**
 *
 */
class Gree_Service_Shop_Exception_DBException
    extends Gree_Service_Shop_Exception_ServiceException
{
}
