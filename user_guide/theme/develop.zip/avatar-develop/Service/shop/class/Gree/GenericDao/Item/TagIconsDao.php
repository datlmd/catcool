<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Item/TagIconsDao.php
 *
 * @package     GREE Avatar
 * @since       2018-02-08
 */

require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserLightFarmSelector.php');

/**
 * TagIcons form constructor
 * @access      public
 */
class Gree_GenericDao_Item_TagIconsDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'tag_icons';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_item_tags';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_item_tags';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'tag_id',
        'icon_id',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_tag_id'     => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE tag_id = :tag_id AND user_id = :user_id',
        ),
        'find_by_tag_ids'   => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE tag_id IN (:tag_ids) AND user_id = :user_id',
        ),
        // }}}
        // {{{ update queries
        'delete_by_tag_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE tag_id = :tag_id AND user_id = :user_id',
        ),
        'insert_or_update' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ 
                        (user_id, tag_id, icon_id, ctime) 
                      VALUES 
                        (:user_id, :tag_id, :icon_id, NOW())
                      ON DUPLICATE KEY UPDATE 
                        tag_id    = :tag_id,
                        icon_id = :icon_id
                      "
        ),
        'entry' => array(
            'sql' => "INSERT IGNORE INTO __TABLE_NAME__ (user_id, tag_id, icon_id, ctime) VALUES (:user_id, :tag_id, :icon_id, NOW())",
        ),
        'update' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET icon_id = :icon_id WHERE id = :id",
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT(10) UNSIGNED NOT NULL,
                `tag_id` INT(10) UNSIGNED NOT NULL,
                `icon_id` TINYINT(4) UNSIGNED NOT NULL,
                `ctime` DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                PRIMARY KEY (`id`),
                UNIQUE KEY `user_tag` (`tag_id`, `user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'add_column_user_id' => array(
            'sql' => 'ALTER TABLE __TABLE_NAME__ ADD COLUMN `user_id` INT(10) UNSIGNED NOT NULL'
        ),
        // }}}
    );

    public function _init()
    {
        parent::_init();
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
}
