<?php

class Gree_Service_AvatarFeed_Processor_Like_Remove
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $delete_result = true;

        $mod_appfeed = self::getModule('AppFeed');

        try {
            $delete_result = $mod_appfeed->removeLike($this->input_values);
        } catch (Exception $e) {
            $msg = 'failed remove like.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_LIKE_DELETE;
            $context = $this->input_values;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            $delete_result = false;
        }

        return $delete_result;
    }
}
