<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Greeting/ItazuraMasterDao.php
 *
 * @author      Thien Nguyen <z.thanhthien.nguyen@gree.net>
 * @package     GREE Avatar
 * @since       2016-09-15
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * ItazuraMaster form constructor
 * @access      public
 */
class Gree_GenericDao_Greeting_ItazuraMasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'itazura_master';

    /** @var primary key */
    var $_primary_key = 'event_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'event_id',
        'date_start',
        'date_secret_open',
        'date_event_end',
        'date_end',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY event_id DESC',
        ),
        'find_by_event_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ),
        'find_by_date_start'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE date_start <= :date_start AND :date_start < date_end',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (date_start, date_secret_open, date_event_end, date_end, ctime) VALUES (:date_start, :date_secret_open, :date_event_end, :date_end, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET date_start = :date_start, date_secret_open = :date_secret_open, date_event_end = :date_event_end, date_end = :date_end WHERE event_id = :event_id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `event_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `date_start` DATETIME NOT NULL,
                `date_secret_open` DATETIME NOT NULL,
                `date_event_end` DATETIME NOT NULL,
                `date_end` DATETIME NOT NULL,
                ctime             DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                mtime             TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                PRIMARY KEY (`event_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ),
        // }}}
    );
}