<?php
/**
 * Gree_GenericDao_UserPresentState
 * 
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */

class Gree_GenericDao_Avapri_Greeting_UserPresentStateDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'greeting_present_state';
    /** @var primary key */
    var $_primary_key = array('user_id', 'present_id', 'sex');
    /** @var auto increment */
    var $_auto_increment = false;
    /** @var updated at column */
    var $_updated_at_column = 'mtime';
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';

    /** @var field names */
    var $_field_names = array(
        'user_id',
        'present_id',
        'sex',
        'ctime',
        'mtime'
    );

    var $_queries = array(
    // --select
        'find_by_user_id_and_present_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND present_id = :present_id AND sex = :sex',
        ),
        'find_by_user_id_and_sex' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND sex = :sex',
        ),
        'count_by_user_id' => array(
            'sql' => 'SELECT count(*) as cnt FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
    // --insert & update
        'insert_user_present' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, present_id, sex, ctime) VALUES (:user_id, :present_id, :sex, NOW())',
        ),
    // --create table
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` INT(10) UNSIGNED NOT NULL,
                `present_id` INT(10) UNSIGNED NOT NULL,
                `sex` TINYINT(3) UNSIGNED NOT NULL,
                `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`user_id`, `present_id`, `sex`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Avapri_Greeting_EventFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Avapri_Greeting_EventFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    // var string �ơ��֥�ե������ֹ�ե����ޥå�
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        if (empty($hint)) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾�˥ե�������ɲ�
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['book_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
