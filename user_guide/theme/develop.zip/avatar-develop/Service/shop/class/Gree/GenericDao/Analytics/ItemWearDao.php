<?php

    require_once('AnalyticsDao.php');

    class Gree_GenericDao_Analytics_ItemWearDao extends Gree_GenericDao_Analytics
    {
        /** #@+
         * @access private
         */

        /** @var テーブル名 */
        public $_table_name = 'item_wear';
        /** @var 主キー。複合キーはarrayハッシュで指定する。 */
        public $_primary_key = 'id';
        /** @var 更新日カラム名 */
        public $_updated_at_column = 'mtime';
        /** @var 登録日カラム名 */
        public $_created_at_column = 'ctime';
        /** @var マスターデータベースの接続文字列 */
        public $_master_dsn = 'gree://master/avatar_analytics';
        /** @var 登録日カラム名 */
        public $_slave_dsn = 'gree://slave/avatar_analytics';
        /** @var オートインクリメント */
        public $_auto_increment = true;
        /** @var フィールド名 */
        public $_field_names = [
            'gacha_id',
            'item_id',
            'service',
            'sex',
            'owner_uu',
            'try_uu',
            'save_uu',
        ];
        /**
         * @var クエリ定義。
         */
        public $_queries = [
            // {{{ 更新系
            'create_table'                 => [
                'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                      `gacha_id` int(10) unsigned NOT NULL,
                      `item_id` int(10) unsigned NOT NULL,
                      `service` varchar(8) NOT NULL,
                      `sex` varchar(8) NOT NULL,
                      `owner_uu` int(10) unsigned NOT NULL DEFAULT '0',
                      `try_uu` int(10) unsigned NOT NULL DEFAULT '0',
                      `save_uu` int(10) unsigned NOT NULL DEFAULT '0',
                      UNIQUE KEY `unq_item_gacha_sex` (`gacha_id`,`item_id`,`service`,`sex`)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
            ],

            // 以下、tool用
            'get_summary_by_gacha_id'      => [
                'sql' => '
                SELECT
                    *
                FROM __TABLE_NAME__
                WHERE gacha_id = :gacha_id',
            ],
            'get_summary_by_gacha_id_and_item_id_and_sex'      => [
                'sql' => '
                SELECT
                    item_id,
                    sum(try_uu) as try_uu,
                    sum(owner_uu) as owner_uu
                FROM __TABLE_NAME__
                WHERE gacha_id = :gacha_id
                AND `item_id` = :item_id
                AND `sex` = :sex
                GROUP BY `item_id`
                ',
            ],
            'insert_item_wear_owner_uu'    => [
                'sql' => 'INSERT INTO __TABLE_NAME__ (`gacha_id`, `item_id`, `service`, `sex`, `owner_uu`)
                      VALUES (:gacha_id, :item_id, :service, :sex, :owner_uu)
                      ON DUPLICATE KEY UPDATE `owner_uu` = VALUES (owner_uu)',
            ],
            'insert_item_wear_try_uu'      => [
                'sql' => 'INSERT INTO __TABLE_NAME__ (`gacha_id`, `item_id`, `service`, `sex`, `try_uu`)
                      VALUES (:gacha_id, :item_id, :service, :sex, :try_uu)
                      ON DUPLICATE KEY UPDATE `try_uu` = VALUES (try_uu)',
            ],
            'insert_item_wear_save_uu'     => [
                'sql' => 'INSERT INTO __TABLE_NAME__ (`gacha_id`, `item_id`, `service`, `sex`, `save_uu`)
                      VALUES (:gacha_id, :item_id, :service, :sex, :save_uu)
                      ON DUPLICATE KEY UPDATE `save_uu` = VALUES (save_uu)',
            ],
            'delete_item_wear_by_gacha_id' => [
                'sql' => 'DELETE FROM ___TABLE_NAME__ WHERE `gacha_id` = :gacha_id',
            ],

        ];
        /** #@- */
    }
