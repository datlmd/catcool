<?php

/**
 * Gree_GenericDao_Shop_Mypage_UserStandbyDao
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Mypage_UserStandbyDao extends Gree_GenericDao_Shop_Mypage_UserDao
{
    /** @var slave dsn */
    var $_slave_dsn         = 'gree://standby/avatar_user';

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'get_all' => array(  // for batch
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        // }}}
    );
}
