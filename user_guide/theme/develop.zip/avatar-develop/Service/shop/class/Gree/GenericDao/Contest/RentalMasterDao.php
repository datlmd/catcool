<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 * Class Gree_GenericDao_Contest_RentalMasterDao
 * @author z.shintaro.okada
 * @package  GREE
 */
class Gree_GenericDao_Contest_RentalMasterDao extends Gree_GenericDao_Apc
{
    /** @var テーブル名 */
    var $_table_name = 'contest_rental_master';

    /** @var 主キー。複合キーはarrayハッシュで指定する。*/
    var $_primary_key = 'id';

    /** @var 更新日カラム名 */
    var $_updated_at_column = 'mtime';

    /** @var 登録日カラム名 */
    var $_created_at_column = 'ctime';

    /** @var マスターデータベースの接続文字列 */
    var $_master_dsn = 'gree://master/avatar_contest';

    /** @var スレーブデータベースの接続文字列 */
    var $_slave_dsn = 'gree://slave/avatar_contest';

    /** @var オートインクリメント*/
    var $_auto_increment = true;

    /** @var フィールド名 */
    var $_field_names = array('id', 'contest_id', 'description', 'user_sex', 'item_ids', 'open_datetime', 'close_datetime', 'ctime', 'mtime');

    /** @var クエリ */
    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`              INT(10) UNSIGNED  NOT NULL AUTO_INCREMENT,
                    `contest_id`      INT(10) UNSIGNED  NOT NULL,
                    `description`     VARCHAR(255)      NOT NULL,
                    `user_sex`        TINYINT(2)        NOT NULL DEFAULT '1',
                    `item_ids`        TEXT                  NULL DEFAULT NULL,
                    `open_datetime`   DATETIME          NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `close_datetime`  DATETIME          NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `ctime`           DATETIME          NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `mtime`           TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY  (`id`),
                    KEY `contest_id_and_user_sex` (`contest_id`, `user_sex`)
                ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=ujis
            ",
        ),
        /** @var 更新系 */
        'find_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id'
        ),
        'find_by_contest_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id'
        ),
        'find_by_contest_id_and_user_sex' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND user_sex = :user_sex'
        ),

        'delete_by_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id'
        ),
    );
}
