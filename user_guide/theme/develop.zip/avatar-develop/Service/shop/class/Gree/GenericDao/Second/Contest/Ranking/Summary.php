<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Second/Contest/Ranking/Summary.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 *  @version  $Id$
 */
class Gree_GenericDao_Second_Contest_Ranking_SummaryDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'second_contest_ranking_summary';

    var $_primary_key ='min_point';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_second_contest';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_second_contest';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array('min_point', 'max_point', 'num', 'mtime', 'ctime');
      
    /** @var ������ */
    var $_queries = array(
		'sum_num_by_min_point' => array(
			'sql' => 'SELECT SUM(num) + 1 FROM __TABLE_NAME__ WHERE :min_point < min_point',
		),
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `min_point`             int(11) unsigned NOT NULL,
                    `max_point`             int(11) unsigned NOT NULL,
                    `num`                   int(11) unsigned NOT NULL DEFAULT 0,
                    `mtime`                 timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`                 datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`min_point`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'update_diff_num_by_dec_min_point' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET num = num - 1 WHERE min_point = :dec_min_point AND num > 0',
        ), 
        'update_diff_num_by_inc_min_point' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET num = num + 1 WHERE min_point = :inc_min_point',
        ),
        'update_num_by_min_point' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET num = :num WHERE min_point = :min_point',
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (min_point, max_point) VALUES (:min_point, :max_point)',
        ), 
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Second_Contest_Ranking_SummaryFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Second/Contest/Ranking/SummaryFarmSelector.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 */
class Gree_GenericDao_Second_Contest_Ranking_SummaryFarmSelector extends Gree_GenericDao_FarmSelector
{

    // {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 1;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['contest_id'])) {
            trigger_error("hint is empty. dao=" . get_class($dao) . "];");
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $contest_id = $hint['contest_id'];
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            trigger_error("original table name is empty. dao=" . get_class($dao) . "];");
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }

        $farm = sprintf($this->_table_suffix_format, $contest_id);

        if (empty($farm)) {
            trigger_error("farm is blank. contest_id=" . $contest_id);
            return PEAR::raiseError("farm is blank. contest_id=" . $contest_id);
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}

}
