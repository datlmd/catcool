<?php

/**
 * Gree_GenericDao_Shop_Market_BidStandbyDao
 *
 * @author  Shingo Harada <shingo.harada@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_BidStandbyDao extends Gree_GenericDao_Shop_Market_BidDao
{
    /** @var slave dsn */
    var $_slave_dsn         = 'gree://standby/avatar_market';

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'get_item_count' => array(  // for batch
            'sql' => 'SELECT item_id, count(item_id) as count FROM __TABLE_NAME__ Group by item_id',
        ),
        // }}}
    );
}
