<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Comment_Relation_Create
 */
class Gree_Service_AvatarFeed_Processor_Comment_Relation_Create
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return is_add_notification
     * if failed create then
     *  is_create  == false,
     */
    protected function invoke()
    {
        $avatar_feed = Gree_Service_AvatarFeed::getInstance();
        $mod_appfeed = self::getModule('AppFeed');
        $mod_user    = self::getModule('User');

        $comments = array();
        $has_more = false;
        $is_add_notification = false;


        $parameter = array(
            'user_id'        => $this->input_values['user_id'],
            'entry_category' => $this->input_values['entry_category'],
            'entry_id'       => $this->input_values['entry_id'],
        );

        // async����������ʤ�
        $this->setUserIDtoCtfy($parameter['user_id']);

        // ��˿ƥ���ȥ꡼��nick_name�����
        if ($this->input_values['entry_category'] == 'notification_comment_relation' || $this->input_values['entry_category'] == 'lounge_notification_comment_relation') {
            $parent_user_id = $this->input_values['parent_entry_user_id'];
            //$parent_entry_user_info = $mod_user->_getUserInfo(array($parent_user_id));
            //$parameter['parent_entry_nick_name'] = $parent_entry_user_info[(int)$parent_user_id]['nick_name'];
            $parameter['parent_entry_user_id'] = $parent_user_id;
            //$parameter['parent_thumbnail']     = $parent_entry_user_info[(int)$parent_user_id]['thumbnail_url'];
        }

        try {
            $notification_add_list = array();
            list($has_more, $comments) = $mod_appfeed->getCommentList($parameter['entry_id'], GREE_SERVICE_AVATARFEED_DEFAULT_GET_DETAIL_COMMENTS_LIMIT, $this->input_values['comment_id']);

            if (!empty($comments)) {
                $comments = array_reverse($comments);
                foreach ($comments as $comment_info) {
                    // ��ʬ�Ǥʤ���ġ��ƥ���ȥ꡼�Ǥʤ�������Τ�����
                    if ($comment_info['content']['sender_id'] != $this->_certified_user->my['user_id'] &&
                       ($comment_info['content']['sender_id'] != $parent_user_id)) {
                        $notification_add_list[] = $comment_info['content']['sender_id'];
                    }
                }
                $notification_add_list = array_unique($notification_add_list);

                if ($notification_add_list) {
                    $notification_params = $parameter;
                    foreach ($notification_add_list as $destination_user) {
                        $notification_params['destination_user'] = $destination_user;
                        $notification_params['notification_entry_id'] = $this->input_values['notification_entry_id'];
                        $notification_params['theme_id'] = $this->input_values['theme_id'];
                        $is_add_notification = $avatar_feed->process('notification_add', $notification_params);
                    }
                }
            }

        } catch(Exception $e) {
            $msg     = 'failed create comment relation.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_COMMENT_RELATION_CREATE;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return $is_add_notification;
    }
}
