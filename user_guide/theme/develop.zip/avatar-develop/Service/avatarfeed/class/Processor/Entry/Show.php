<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Entry_Show
 */
class Gree_Service_AvatarFeed_Processor_Entry_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return array has is_exist, entry_data
     *
     * check is_block status
     * if block status is true then return array(false, array())
     *
     * entry data appended user_info
     */
    protected function invoke()
    {
        $entry_data  = array();
        $is_exist    = false;
        $mod_appfeed = self::getModule('AppFeed');
        $comments_limit = GREE_SERVICE_AVATARFEED_DEFAULT_GET_DETAIL_COMMENTS_LIMIT;

        try {
            list($is_exist, $entry) = $mod_appfeed->getEntry($this->input_values['entry_id']);
        } catch (Exception $e) {
            $msg     = 'failed get entry.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_SHOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array(
                $is_exist,
                $entry_data
            );
        }

        if ($is_exist == false) {
            return array(
                $is_exist,
                $entry_data
            );
        }

        // check visibility
        $mod_block = self::getModule('Block');
        $is_block  = $mod_block->getBlockUser($this->_certified_user->my['user_id'], $entry[0]['content']['sender_id']);
        if ($is_block) {
            return array(
                false,
                $entry_data
            );
        }

        $entry      = $mod_appfeed->appendCommentInfo($entry, $comments_limit);
        $entry      = $mod_appfeed->appendEntryInfo($entry);
        $mod_user   = self::getModule('User');
        $entry_data = $mod_user->appendUserInfo($entry);

        return array(
            $is_exist,
            array_shift($entry_data),
        );
    }
}
