<?php

class Gree_GenericDao_Analytics_GachaReport_PayGachaMinutelyDao extends Gree_GenericDao
{
    var $_table_name = 'pay_gacha_minutely';

    var $_primary_key = 'id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_analytics';

    var $_slave_dsn = 'gree://slave/avatar_analytics';

    var $_auto_increment = true;

    var $_field_names = array(
        'id',
        'date',
        'hour',
        'minute',
        'gacha_id',
        'type_id',
        'sex',
        'pay',
        'pay_count',
        'pay_uu',
        'mtime',
        'ctime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `date` DATE NOT NULL,
                    `hour` TINYINT UNSIGNED NOT NULL,
                    `minute` TINYINT UNSIGNED NOT NULL,
                    `gacha_id` INT NOT NULL,
                    `type_id` INT NOT NULL,
                    `sex` TINYINT UNSIGNED NOT NULL,
                    `pay` INT UNSIGNED NOT NULL DEFAULT 0,
                    `pay_count` INT UNSIGNED NOT NULL DEFAULT 0,
                    `pay_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    UNIQUE (date, hour, minute, gacha_id, type_id, sex),
                    INDEX gacha_id (gacha_id),
                    INDEX type_id (type_id)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),

        'insert_or_update_pay' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ (date, hour, minute, gacha_id, type_id, sex, pay, pay_count, pay_uu, ctime)
                      VALUES (:date, :hour, :minute, :gacha_id, :type_id, :sex, :pay, :pay_count, :pay_uu, NOW())
                      ON DUPLICATE KEY UPDATE pay = VALUES(pay), pay_count = VALUES(pay_count), pay_uu = VALUES(pay_uu)",
        ),
        'find_by_date' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE date = :date order by date, hour, minute, sex",
        ),
        'find_by_gacha_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id order by date, hour, minute, sex",
        ),
        'find_by_range_and_type_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE date >= :sdate and date <= :edate and type_id = :type_id order by date, hour, minute, sex",
        ),
        'find_sum_by_range_and_type_id' => array(
            'sql' => "SELECT date, hour, minute, gacha_id, type_id, sum(pay) as pay FROM __TABLE_NAME__ WHERE date >= :sdate and date <= :edate and type_id = :type_id group by date, hour, minute order by date, hour, minute",
        ),
    );
}
