<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Follow_Status_ShowTest
 *
 * this test is follow status
 */
final class Gree_Service_Avatarfeed_Test_Processor_Follow_Status_ShowTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        // initialize follow status
        try {
            $this->module->updateFollowCount(UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_1);

            $this->module->updateFollowCount(UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_2);


        } catch (Exception $e) {
        }
    }

    /**
     * test1: no following and followed, show my status
     * expect:
     *   is_following    == false
     *   is_followed     == false
     *   following_count == 0
     *   followed_count  == 0
     *
     * test2: no following and followed, show other status, did not follow and followed
     * expect:
     *   is_following    == false
     *   is_followed     == false
     *   following_count == 0
     *   followed_count  == 0
     *
     * test3: exist following and followed, show my status
     * expect:
     *   is_following    == false
     *   is_followed     == false
     *   following_count == 1
     *   followed_count  == 1
     *
     * test3: exist following and followed, show other status, did follow and followed
     * expect:
     *   is_following    == true
     *   is_followed     == true
     *   following_count == 1
     *   followed_count  == 1
     */
    public function test_show_follow_status()
    {

        // test1
        $follow_params_test_1 = array(
            'user_id' => UNIT_TEST_USER_ID_1,
        );
        list($is_following_test_1,
            $is_followed_test_1,
            $following_count_test_1,
            $followed_count_test_1) = $this->avatar_feed->process('follow_status_show', $follow_params_test_1);

        $this->assertFalse($is_following_test_1);
        $this->assertFalse($is_followed_test_1);
        $this->assertEquals(0, $following_count_test_1);
        $this->assertEquals(0, $followed_count_test_1);

        // test2
        $follow_params_test_2 = array(
            'user_id' => UNIT_TEST_USER_ID_2,
        );
        list($is_following_test_2,
            $is_followed_test_2,
            $following_count_test_2,
            $followed_count_test_2) = $this->avatar_feed->process('follow_status_show', $follow_params_test_2);

        $this->assertFalse($is_following_test_2);
        $this->assertFalse($is_followed_test_2);
        $this->assertEquals(0, $following_count_test_2);
        $this->assertEquals(0, $followed_count_test_2);

        // test3
        $this->module->updateFollowCount(UNIT_TEST_USER_ID_1, 1, 1);

        $follow_params_test_3 = array(
            'user_id' => UNIT_TEST_USER_ID_1,
        );
        list($is_following_test_3,
            $is_followed_test_3,
            $following_count_test_3,
            $followed_count_test_3) = $this->avatar_feed->process('follow_status_show', $follow_params_test_3);

        $this->assertFalse($is_following_test_3);
        $this->assertFalse($is_followed_test_3);
        $this->assertEquals(1, $following_count_test_3);
        $this->assertEquals(1, $followed_count_test_3);

        // test4
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
        $this->module->addFollowingUser(UNIT_TEST_USER_ID_1);
        $this->module->addFollowedUser(UNIT_TEST_USER_ID_1);
        $this->module->updateFollowCount(UNIT_TEST_USER_ID_2, 1, 1);
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        $follow_params_test_4 = array(
            'user_id' => UNIT_TEST_USER_ID_2,
        );
        list($is_following_test_4,
            $is_followed_test_4,
            $following_count_test_4,
            $followed_count_test_4) = $this->avatar_feed->process('follow_status_show', $follow_params_test_4);

        $this->assertFalse($is_following_test_4);
        $this->assertFalse($is_followed_test_4);
        $this->assertEquals(1, $following_count_test_4);
        $this->assertEquals(1, $followed_count_test_4);
    }
}