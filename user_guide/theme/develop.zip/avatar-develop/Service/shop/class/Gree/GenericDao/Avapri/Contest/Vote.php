<?php
/**
 * Gree_GenericDao_AvapriContestVoteDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Contest_VoteDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'contest_vote';
	/** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'target_user_id',
        'target_seal_id',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        // select----------------------
        'get_ranking' => array(// create ranking batch only
             'sql' => 'SELECT COUNT(*) as win,target_user_id  FROM __TABLE_NAME__ GROUP BY target_user_id ORDER BY win desc',
        ),
        'count_vote_to_by_user_id' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'count_vote_from_by_target_user_id' => array(
             'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE target_user_id = :target_user_id',
        ),
        'count_vote_to_by_user_id_and_ctime' => array(
             'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE user_id = :user_id AND ctime >= :start_ctime AND ctime <= :end_ctime',
        ),
        // insert----------------------
        'insert_vote' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, target_user_id, target_seal_id, ctime) VALUES (:user_id, :target_user_id, :target_seal_id, :ctime)',
            'return_last_insert_id' => true,
        ),  
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`        INT(11)     UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`   INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                    `target_user_id` INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                    `target_seal_id` INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                    `mtime`     TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                    `ctime`     DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY `ids` (`user_id`, `target_user_id`, `target_seal_id`),
                KEY `target_user_id` (`target_user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE IF EXISTS __TABLE_NAME__',
        ),
    );

    // {{{ _initFarmSelector
    function _initFarmSelector() {
        $this->_farm_selector = new Gree_GenericDao_Avapri_Contest_VoteFarmSelector();
    }
    // }}}
}
/**
 *  /home/gree/service/shop/class/GenericDao/Avapri/Contest/VoteFarmSelector.php
 *
 *  @author   Norie Matsuda <norie.matsuda@gree.net>
 *  @package  GREE
 */
class Gree_GenericDao_Avapri_Contest_VoteFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ getTableName
    /**
    *  get table name
    *
    *  @param      $dao        Dao class
    *  @param      $type       type
    *  @param      $hint       table hint
    *  @return     string      table name
    */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['contest_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $contest_id = $hint['contest_id'];

        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is emptry. dao=" . get_class($dao) . "];");
        }
        $farm = $contest_id;
        $table_name = $original_table_name .'_'. $farm;
        return $table_name;
    }
    // }}}
}
