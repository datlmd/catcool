<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/DailyUserSummaryDao.php
 *
 *  @author   Koichi Osanai <koichi.osanai@gree.net>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_MonthlyUserSummaryDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var テーブル名 */
    var $_table_name = 'user_summary';

    /** @var 主キー。複合キーはarrayハッシュで指定する。*/
    var $_primary_key = 'user_id';

    /** @var 更新日カラム名 */
    var $_updated_at_column = 'mtime';

    /** @var 登録日カラム名 */
    var $_created_at_column = 'ctime';

    /** @var マスターデータベースの接続文字列 */
    var $_master_dsn = 'gree://master/avatar_analytics';

    /** @var 登録日カラム名 */
    var $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var オートインクリメント*/
    var $_auto_increment = false;

    /** @var フィールド名 */
    var $_field_names = array(
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'purchase_spent_coin',
        'gacha_spent_coin',
        'spent_coin',
        'purchase_count',
        'purchase_count_boy',
        'purchase_count_girl',
        'gacha_single_count',
        'gacha_multi_count',
        'gacha_count',
        'free_gacha_count',
        'purchase_item_kind_count',
        'item_count_max',
        'gacha_single_kind_count',
        'mixer_spent_coin',
        'use_mixer_count',
        'gift_spent_coin',
        'spent_coin_sun',
        'spent_coin_mon',
        'spent_coin_tue',
        'spent_coin_wed',
        'spent_coin_thu',
        'spent_coin_fri',
        'spent_coin_sat',
        'spent_coin_firstday',
        'mtime',
        'ctime',
    );

    /**
     * @var クエリ定義。
     */
    var $_queries = array(
        // {{{ 更新系
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                user_id BIGINT(20) UNSIGNED NOT NULL,
                user_sex TINYINT(4),
                user_age TINYINT(4),
                phone_carrier TINYINT(4),
                purchase_spent_coin INT(10) UNSIGNED, #ガチャ以外の買い物のみ
                gacha_spent_coin INT(10) UNSIGNED, #ガチャのみ
                spent_coin INT(10) UNSIGNED, #合計額
                purchase_count INT(10) UNSIGNED,
                purchase_count_boy INT(10) UNSIGNED,
                purchase_count_girl INT(10) UNSIGNED,
                gacha_single_count INT(10) UNSIGNED, #１連ガチャのみ
                gacha_multi_count INT(10) UNSIGNED, #３連ガチャのみ
                gacha_count INT(10) UNSIGNED, #合計回数
                free_gacha_count INT(10) UNSIGNED, #無料ガチャ
                purchase_item_kind_count INT(10) UNSIGNED, #買ったアイテムの種類数
                item_count_max INT(10) UNSIGNED, #同種のアイテムの購入個数の最大値
                gacha_single_kind_count INT(10) UNSIGNED,
                mixer_spent_coin INT(10) UNSIGNED,
                use_mixer_count INT(10) UNSIGNED,
                gift_spent_coin INT(10) UNSIGNED,
                spent_coin_sun DOUBLE UNSIGNED,
                spent_coin_mon DOUBLE UNSIGNED,
                spent_coin_tue DOUBLE UNSIGNED,
                spent_coin_wed DOUBLE UNSIGNED,
                spent_coin_thu DOUBLE UNSIGNED,
                spent_coin_fri DOUBLE UNSIGNED,
                spent_coin_sat DOUBLE UNSIGNED,
                spent_coin_firstday DOUBLE UNSIGNED,
                mtime TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                ctime DATETIME NOT NULL,
                PRIMARY KEY (user_id),
                KEY user_sex (user_sex),
                KEY user_age (user_age),
                KEY phone_carrier (phone_carrier),
                KEY purchase_spent_coin (purchase_spent_coin),
                KEY gacha_spent_coin (gacha_spent_coin),
                KEY spent_coin (spent_coin),
                KEY purchase_count (purchase_count),
                KEY gacha_single_count (gacha_single_count),
                KEY gacha_multi_count (gacha_multi_count),
                KEY gacha_count (gacha_count),
                KEY purchase_item_kind_count (purchase_item_kind_count),
                KEY item_count_max (item_count_max),
                KEY gacha_single_kind_count (gacha_single_kind_count),
                KEY mixer_spent_coin (mixer_spent_coin),
                KEY use_mixer_count (use_mixer_count),
                KEY gift_spent_coin (gift_spent_coin),
                KEY spent_coin_sun (spent_coin_sun),
                KEY spent_coin_mon (spent_coin_mon),
                KEY spent_coin_tue (spent_coin_tue),
                KEY spent_coin_wed (spent_coin_wed),
                KEY spent_coin_thu (spent_coin_thu),
                KEY spent_coin_fri (spent_coin_fri),
                KEY spent_coin_sat (spent_coin_sat),
                KEY spent_coin_firstday (spent_coin_firstday)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE IF EXISTS __TABLE_NAME__',
        ),
        // }}}
        // {{{ 参照系
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
    );
    /** #@- */
}
