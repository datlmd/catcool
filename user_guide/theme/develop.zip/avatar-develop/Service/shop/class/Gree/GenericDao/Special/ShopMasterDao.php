<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Special/ShopMasterDao.php
 *
 *  @author   Yuta Araki <yuta.araki@gree.net>
 *  @package  GREE
 */
class Gree_GenericDao_Special_ShopMasterDao extends Gree_GenericDao
{
    /** @var �ơ��֥�̾ */
    var $_table_name = 'special_shop_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'shop_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/shop';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/shop';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'shop_id',
        'type_id',
        'state',
        'name',
        'start_time',
        'end_time',
        'mtime',
        'ctime',
    );

    /** @var ������ */
    var $_queries = array(
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `shop_id`     INT(11)       UNSIGNED NOT NULL AUTO_INCREMENT,
                `state`       TINYINT(2)    UNSIGNED NOT NULL default '0',
                `type_id`     TINYINT(2)    UNSIGNED NOT NULL default '0',
                `name`        varchar(255)  NOT NULL default '',
                `start_time`  datetime      NOT NULL default '0000-00-00 00\:00\:00',
                `end_time`    datetime      NOT NULL default '0000-00-00 00\:00\:00',
                `ctime`       DATETIME      NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime`       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY     (`shop_id`),
                KEY `type_id`   (`type_id`),
                KEY `end_time`  (`end_time`),
                KEY `state`     (`state`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'find_by_shop_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE shop_id = :shop_id'
        ),
        'find_by_shop_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE shop_id IN (:shop_ids)'
        ),
        'find_by_type_id'  => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE type_id = :type_id'
        ),
        'find_by_end_time'  => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE end_time >= :end_time ORDER BY shop_id DESC'
        ),
        'find_by_date'  => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE :start_time <= end_time AND start_time <= :end_time'
        ),
        'find_by_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state',
        ),
        'find_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ order by shop_id desc limit 20'
        ),
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ order by shop_id desc'
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
// vim: sts=4 sw=4 ts=4 fdm=marker
