<?php

class Gree_Service_AvatarFeed_Processor_Follow_Import_Official
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $mod_appfeed   = self::getModule('AppFeed');

        $user_id = $this->input_values['user_id'];

        try {
            $add_params = array(
                'user_id'        => GREE_SERVICE_SHOP_AVATAR_OFFICIAL_USER_ID,
                'certified_user' => $user_id,
                'is_async'       => true
            );

            $follow_add_result = Gree_Service_AvatarFeed_Processor::execute(
                'following_add',
                $add_params
            );

            // destination entry
            list($has_more, $stream_data) = $mod_appfeed->getEntriesByFeedKey(
                GREE_SERVICE_SHOP_AVATAR_OFFICIAL_USER_ID,
                'user',
                10,
                null,
                'batch'
            );

            foreach ($stream_data as $entry) {
                $destinations   = array();
                $destinations[] = array(
                    'type'  => 'feed_key',
                    'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' .
                    GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $user_id
                );
                $add_params = array(
                    'entry_id'     => $entry['entry_id'],
                    'destinations' => $destinations
                );

                $mod_appfeed->addDestination($add_params);
            }
        } catch (Exception $e) {
            return false;
        }

        return true;
    }
}
