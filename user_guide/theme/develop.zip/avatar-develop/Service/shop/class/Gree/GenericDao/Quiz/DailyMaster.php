<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 *  /home/gree/service/shop/class/GenericDao/Quiz/DailyMaster.php
 *
 *  @author   Masayoshi Yoshino <masayoshi.yoshino@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_Quiz_DailyMasterDao extends Gree_GenericDao_Apc {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'quiz_daily_master';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_quiz';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_quiz';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
                            'id',
                            'event_id',
                            'quiz_id',
                            'day',
                            'type',
                            'mtime',
                            'ctime'
                        );
      
	/** @var ������ */
	var $_queries = array(
        'find_quiz_by_event_id' => array(
            'sql' => "SELECT * from __TABLE_NAME__ WHERE event_id = :event_id",
        ),
        'find_quiz_by_event_id_day' => array(
            'sql' => "SELECT * from __TABLE_NAME__ WHERE event_id = :event_id AND day = :day",
        ),
        'insert_quiz_daily' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (event_id, quiz_id, day, type, ctime) VALUES (:event_id, :quiz_id, :day, :type, NOW())',
            'return_last_insert_id' => true
        ),
        'delete_quiz_daily' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `event_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                `quiz_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                `day` TINYINT(2) UNSIGNED NOT NULL DEFAULT '1',
                `type` TINYINT(2) UNSIGNED NOT NULL DEFAULT '0',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                KEY `event_id` (`event_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        // }}}
    ); 
}
