<?php

class Gree_Service_AvatarFeed_Processor_Following_List_Count
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return int
     *
     * return the following users total of a user
     */
    protected function invoke()
    {
        $mod_follow = self::getModule('Follow');

        $actual_following_count = 0;
        $following_count        = 0;
        try {
            // get �ºݤο�
            $actual_following_count = $mod_follow->getFollowingCount($this->input_values['user_id']);
            // get �ޥ��ڡ���ɽ��
            list($following_count, $followed_count) = $mod_follow->getFollowCount($this->input_values['user_id']);
        } catch (Exception $e) {
            $msg     = 'failed get the following users total';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $following_count,
            $actual_following_count,
        );
    }
}
