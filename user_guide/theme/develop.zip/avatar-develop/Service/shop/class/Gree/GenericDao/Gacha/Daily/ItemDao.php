<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Daily/ItemDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: ItemDao.php 140771 2011-11-04 14:19:50Z takashi-taniguchi $
 */
class Gree_GenericDao_Gacha_Daily_ItemDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */ 

    /** @var �ơ��֥�̾ */
    var $_table_name = 'gacha_daily_item';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = array('gacha_id', 'item_id');

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gacha_daily';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'gacha_id',
        'item_id',
        'count',
        'mtime',
        'ctime',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  gacha_id      int(10) unsigned NOT NULL default '0',
                  item_id       int(10) unsigned NOT NULL default '0',
                  count         int(10) unsigned NOT NULL default '0',
                  mtime         timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  ctime         datetime NOT NULL default \"0000-00-00 00\:00\:00\",
                  PRIMARY KEY (gacha_id,item_id),
                  KEY item_id (item_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),
        //'drop_table' => array(
        //    'sql' => 'DROP TABLE __TABLE_NAME__',
        //),
        'increment_count' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET `count` = `count` + 1 WHERE gacha_id = :gacha_id AND item_id = :item_id",
        ),
        // }}}

        // {{{ ���ȷ�
        'find_by_gacha_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id',
        ),
        'find_by_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = :item_id',
        ),
        'find_by_item_idl' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id IN (:item_idl)',
        ),
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_by_gacha_ids' => array(
            'sql' => 'SELECT gacha_id,item_id FROM __TABLE_NAME__ WHERE gacha_id IN (:gacha_ids)',
        ),
        'count_sum_by_gacha_id' => array(
            'sql' => 'SELECT SUM(count) FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id',
        ),
        // }}}
    );
}
?>
