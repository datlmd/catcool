<?php
/**
 * service/shop/class/Flare/FollowNotificationSilencer.php
 * @package GREE
 *
 * AvaMeeのフォロー/アンフォローを同一ユーザーに連続で行った際に
 * 一定期間通知されないようにするためのマーカーとしてのFlare
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare.php';

class Gree_Service_Shop_Flare_FollowNotificationSilencer extends Gree_Service_Shop_Flare
{
    const FLARE_NAMESPACE  = 'notification';
    const FLARE_KEY_PREFIX = 'follow_notification_silencer_';
    const EXPIRE_TIME      = 600; // 10 minutes

    protected function getExpireTime()
    {
        return self::EXPIRE_TIME;
    }

    protected function getNameSpace()
    {
        return self::FLARE_NAMESPACE;
    }

    protected function getKey($user_id)
    {
        return self::FLARE_KEY_PREFIX . $user_id;
    }

    public function isSilentTime($user_id, $target_user_id)
    {
        $key = $this->getKey($user_id);
        try {
            list($ret, $var) = parent::get($key);
        } catch (Exception $e) {
            return false;
        }

        if (empty($ret) || !isset($ret[$target_user_id])) {
            return false;
        }

        $current_time = strtotime(getService('shop')->getDate());
        $set_time = strtotime($ret[$target_user_id]);
        if ($current_time - $set_time > self::EXPIRE_TIME) {
            return false;
        }

        return true;
    }

    public function setSilencer($user_id, $target_user_id)
    {
        $key = $this->getKey($user_id);

        try {
            list($ret, $var) = parent::get($key);
            if (empty($ret)) {
                $ret = array();
            }
            $ret[$target_user_id] = getService('shop')->getDate();
            $ret = parent::set($key, $ret);
        } catch (Exception $e) {
            // no action for exception
        }

        if (empty($ret) || $ret !== true) {
            return false;
        }

        return true;
    }
}
