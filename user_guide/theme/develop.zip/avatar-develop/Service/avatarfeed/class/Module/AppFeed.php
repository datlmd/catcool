<?php

class Gree_Service_AvatarFeed_Module_AppFeed
    extends Gree_Service_AvatarFeed_Module_Base
{
    public function createFeed($category = GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY)
    {
        $is_create_success = false;
        $feed_id           = null;

        $user_id = $this->_certified_user->my['user_id'];

        $mod_request          = self::getModule('Request');
        $mod_request->path    = GREE_SERVICE_AVATARFEED_PATH . 'feed/' . $category . '/' . $user_id . '/:create';
        $mod_request->method  = 'POST';
        $mod_request->type    = 'batch';
        $mod_request->body    = array();
        list($code,$response) = $mod_request->invoke();

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $user_id;
        $mod_tdlog->feed_id = $response['entry']['feed_id'];
        $mod_tdlog->result = $code;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedTableName());

        $this->_checkResponse($response);

        $is_create_success = true;
        $feed_id           = $response['entry']['feed_id'];

        return array(
            $is_create_success,
            $feed_id
        );
    }

    public function deleteFeed($category = GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY)
    {
        $is_delete_success = false;
        $feed_id           = null;

        $user_id = $this->_certified_user->my['user_id'];

        $mod_request          = self::getModule('Request');
        $mod_request->path    = GREE_SERVICE_AVATARFEED_PATH . 'feed/' . $category . '/' . $user_id . '/:delete';
        $mod_request->method  = 'POST';
        $mod_request->type    = 'batch';
        $mod_request->body    = array();
        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);

        $is_delete_success = true;

        return $is_delete_success;
    }
    
    public function getEntriesByFeedKey($user_id  = null,
                                        $category = GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
                                        $limit    = GREE_SERVICE_AVATARFEED_DEFAULT_GET_ENTRIES_LIMIT,
                                        $start_id = null,
                                        $request_type = 'request')
    {
        if (is_null($user_id)){
            $user_id = $this->_certified_user->my['user_id'];
        }
        $query = '?limit=' . $limit;
        if (isset($start_id)){
            $query = $query . '&start_id=' . $start_id;
        }

        $mod_request          = self::getModule('Request');
        $mod_request->path    = GREE_SERVICE_AVATARFEED_PATH . 'entry/timeline/' . GREE_SERVICE_AVATARFEED_APP_ID . ':' . $category . ':' . $user_id . $query;
        $mod_request->method  = 'GET';
        $mod_request->type    = $request_type;
        $mod_request->body    = null;
        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);
        $response_entry = $this->_alignFormatOfTime($response['entry']);

        return array(
            $response['has_more'],
            $response_entry
        );
    }

    public function getEntries($feed_id)
    {
        $mod_request         = self::getModule('Request');
        $mod_request->path   = GREE_SERVICE_AVATARFEED_PATH . 'entry/timeline/' . $feed_id;
        $mod_request->method = 'GET';
        $mod_request->type   = 'batch';

        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);

        return array(
            $response['has_more'],
            $response['entry']
        );
    }

    public function getEntry($entry_id)
    {
        $mod_request         = self::getModule('Request');
        $mod_request->path   = GREE_SERVICE_AVATARFEED_PATH . 'entry/' . $entry_id;
        $mod_request->method = 'GET';
        $mod_request->type   = 'request';
        $mod_request->body   = null;

        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);

        if (is_null($response['entry'])){
            $is_exist = false;
        } else {
            $is_exist = true;
        }

        $response_entry = $this->_alignFormatOfTime(array($response['entry']));

        return array(
            $is_exist,
            $response_entry
        );
    }

    public function createEntry($create_params)
    {
        $is_create_success = false;
        $entry_id          = null;

        $mod_request         = self::getModule('Request');
        $mod_request->path   = GREE_SERVICE_AVATARFEED_PATH . 'entry/:create';
        $mod_request->method = 'POST';
        $mod_request->type   = 'request';
        $mod_request->body   = $create_params;

        list($code, $response) = $mod_request->invoke();
        $this->_checkResponse($response);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $create_params['content']['sender_id'];
        $mod_tdlog->entry_id = $response['entry']['entry_id'];
        $mod_tdlog->entry_category = $create_params['content']['attr']['entry_category'];
        $mod_tdlog->state = $mod_tdlog->getInsertState();
        $mod_tdlog->result = $code;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedStreamTableName());

        $is_create_success = true;
        $entry_id          = $response['entry']['entry_id'];

        return array(
            $is_create_success,
            $entry_id,
        );
    }

    public function deleteEntry($delete_params)
    {
        $is_delete_success = false;
        $entry_id          = null;

        $mod_request         = self::getModule('Request');
        $mod_request->path   = GREE_SERVICE_AVATARFEED_PATH . 'entry/' . $delete_params['entry_id'] . '/:delete';
        $mod_request->method = 'POST';
        $mod_request->type   = 'batch';
        $mod_request->body   = array();

        list($code, $response) = $mod_request->invoke();

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $this->_certified_user->my['user_id'];;
        $mod_tdlog->entry_id = $delete_params['entry_id'];
        $mod_tdlog->entry_category = null;// do not need yet..
        $mod_tdlog->state = $mod_tdlog->getDeleteState();
        $mod_tdlog->result = $code;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedStreamTableName());

        $this->_checkResponse($response);

        $is_delete_success = true;
        $entry_id          = $response['entry']['entry_id'];

        return array(
            $is_delete_success,
            $entry_id,
        );
    }

    public function appendEntryInfo($entries)
    {
        foreach($entries as $index => $entry){
            if (isset($entry['content']['attr']['entry_category']) == false){
                continue;
            }

            $mod_avatar = self::getModule('Avatar');
            switch($entry['content']['attr']['entry_category']){
                case 'change':
                case 'avapri':
                case 'change_mood':
                case 'unsupported_change_mood':
                case 'unsupported_change':
                case 'unsupported_avapri':
                    $url = $mod_avatar->getAvatarImgUrlByKey($entry['content']['attr']['avatar_key'], GREE_SERVICE_AVATARFEED_CHANGE_IMG_SIZE);
                    $entries[$index]['content']['attr']['avatar_change_img_url'] = $url;

                    if (!empty($entry['content']['attr']['effect_id'])) {
                        $effect_url = $mod_avatar->getEffectImgUrlById($entry['content']['attr']['effect_id']);
                        $entries[$index]['content']['attr']['effect_url'] = $effect_url;
                    } else {
                        $effect_url = $mod_avatar->getEffectImgUrlById(DEFAULT_LIKE_EFFECT_ID);
                        $entries[$index]['content']['attr']['effect_url'] = $effect_url;
                    }

                    if ($entry['content']['sender_id'] == GREE_SERVICE_SHOP_AVATAR_OFFICIAL_USER_ID) {
                        $entries[$index]['content']['text'] = str_replace(GREE_SERVICE_AVATARFEED_FEED_TEXT_REPLACE_COIN, Gree_Service_Shop_Util::getCurrencyUnit(), $entry['content']['text']);
                    }
                    break;
                default:
            }
        }

        return $entries;
    }

    public function addDestination($add_params)
    {
        $mod_request         = self::getModule('Request');
        $mod_request->path   = GREE_SERVICE_AVATARFEED_PATH . 'entry/' . $add_params['entry_id'] . '/destination/:create';
        $mod_request->method = 'POST';
        $mod_request->type   = 'batch';
        $mod_request->body   = $add_params;

        list($code, $response) = $mod_request->invoke();

        $this->_checkResponse($response, array($add_params['entry_id']));

        return true;
    }

    public function createComment($create_params)
    {
        $is_create_success = false;
        $comment_id        = null;
        $category          = 'comment';

        $mod_request         = self::getModule('Request');
        $mod_request->path   =  GREE_SERVICE_AVATARFEED_PATH . 'comment/'. $create_params['entry_id'] . '/:create';
        $mod_request->method =  'POST';
        $mod_request->type   =  'request';
        $mod_request->body   = array(
            'content' => array(
                'sender_id' => $this->_certified_user->my['user_id'],
                'text'      => $create_params['text'],
            ),
        );

        if (isset($create_params['attr'])) {
            $mod_request->body['content']['attr'] = $create_params['attr'];
            if (isset($create_params['attr']['comment_category'])) {
                $category = $create_params['attr']['comment_category'];
            }
        }

        if (isset($create_params['skip_moderation']) && $create_params['skip_moderation'] == true) {
            $mod_request->body['write_options']['skip_moderation'] = true;
        }

        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $create_params['user_id'];
        $mod_tdlog->entry_id = $create_params['entry_id'];
        $mod_tdlog->commented_user_id = $create_params['commented_user_id'];
        $mod_tdlog->comment_id = $response['entry']['comment_id'];
        $mod_tdlog->state = $mod_tdlog->getInsertState();
        $mod_tdlog->comment_category = $category;
        $mod_tdlog->result = $code;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedCommentTableName());

        $is_create_success = true;
        $comment_id        = $response['entry']['comment_id'];

        return array(
            $is_create_success,
            $comment_id,
        );
    }
    
     public function deleteComment($delete_params)
    {
        $is_delete_success = false;
        $comment_id        = null;

        $mod_request         = self::getModule('Request');
        $mod_request->path   =  GREE_SERVICE_AVATARFEED_PATH . 'comment/'. $delete_params['parent_entry_id'] . '/' . $delete_params['comment_id'] . '/:delete';
        $mod_request->method = 'POST';
        $mod_request->type   = 'batch';
        $mod_request->body   = array();

        list($code,$response) = $mod_request->invoke();

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $delete_params['user_id'];
        $mod_tdlog->entry_id = $delete_params['parent_entry_id'];
        $mod_tdlog->commented_user_id = $delete_params['commented_user_id'];
        $mod_tdlog->comment_id = $delete_params['comment_id'];
        $mod_tdlog->state = $mod_tdlog->getDeleteState();
        $mod_tdlog->result = $code;
        $mod_tdlog->createFeedTdLog( $mod_tdlog->getAvatarFeedCommentTableName());

        $this->_checkResponse($response);

        $is_delete_success = true;
        $comment_id        = $response['entry']['comment_id'];

        return array(
            $is_delete_success,
            $comment_id,
        );
    }

    public function getCommentList($entry_id,
                                   $limit    = GREE_SERVICE_AVATARFEED_DEFAULT_GET_COMMENTS_LIMIT,
                                   $start_id = null)
    {
        $query = '?limit=' . $limit;
        if (isset($start_id)){
            $query = $query . '&start_id=' . $start_id;
        }

        $mod_request          = self::getModule('Request');
        $mod_request->path    = GREE_SERVICE_AVATARFEED_PATH . 'comment/list/' . $entry_id . $query;
        $mod_request->method  = 'GET';
        $mod_request->type    = 'batch';
        $mod_request->body    = null;
        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);
        $response_entry = $this->_alignFormatOfTime($response['entry']);
        $response_entry = $this->_appendStampInfo($response_entry);

        return array(
            $response['has_more'],
            $response_entry,
        );
    }

    public function getComment($get_params)
    {
        $mod_request          = self::getModule('Request');
        $mod_request->path    = GREE_SERVICE_AVATARFEED_PATH . 'comment/' . $get_params['parent_entry_id'] . '/' . $get_params['comment_id'];
        $mod_request->method  = 'GET';
        $mod_request->type    = 'batch';
        $mod_request->body    = null;
        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);
        $response_entry = $this->_alignFormatOfTime(array($response['entry']));
        $response_entry = $this->_appendStampInfo($response_entry);

        if (is_null($response['entry'])){
            $is_exist = false;
        } else {
            $is_exist = true;
        }

        return array(
            $is_exist,
            $response_entry,
        );
    }

    private function _appendStampInfo($comment_list)
    {
        $mod_avatar = self::getModule('Avatar');
        foreach ($comment_list as $comment_index => $comment) {
            if (isset($comment['content']['attr']['stamp_id'])) {
                $comment_list[$comment_index]['content']['attr']['stamp_image_url'] = $mod_avatar->getStampImgUrlByStampId($comment['content']['attr']['stamp_id']);
            }
        }

        return $comment_list;
    }

    public function appendCommentInfo($entries, $limit = GREE_SERVICE_AVATARFEED_DEFAULT_GET_COMMENTS_LIMIT)
    {
        foreach($entries as $index => $entry){
            if ($entry['comment']['count'] > 0){
                try {
                    list($has_more, $comment_list) = $this->getCommentList($entry['entry_id'], $limit);
                } catch(Exception $e) {
                    //Todo: log
                    $has_more     = false;
                    $comment_list = array();
                }
                $entries[$index]['comment']['has_more'] = $has_more;
                $entries[$index]['comment']['list']     = $comment_list;
            }
        }

        return $entries;
    }

    public function addLike($add_params)
    {
        $is_add_success = false;
        $entry_id       = null;

        $mod_request         = self::getModule('Request');
        $mod_request->path   =  GREE_SERVICE_AVATARFEED_PATH . 'like/'. $add_params['entry_id'] . '/:create';
        $mod_request->method =  'POST';
        $mod_request->type   =  'request';
        $mod_request->body   = array();
        list($code,$response) = $mod_request->invoke();

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $add_params['user_id'];
        $mod_tdlog->liked_user_id = $add_params['liked_user_id'];
        $mod_tdlog->entry_id = $add_params['entry_id'];
        $mod_tdlog->state = $mod_tdlog->getInsertState();
        $mod_tdlog->result = $code;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedTableLikeName());

        $this->_checkResponse($response);

        $is_add_success = true;
        $entry_id       = $response['entry']['parent_id'];

        return array(
            $is_add_success,
            $entry_id,
        );
    }

    public function removeLike($remove_params)
    {
        $is_remove_success = false;
        $entry_id          = null;

        $mod_request         = self::getModule('Request');
        $mod_request->path   =  GREE_SERVICE_AVATARFEED_PATH . 'like/'. $remove_params['entry_id'] . '/' .$this->_certified_user->my['user_id'] . '/:delete';
        $mod_request->method =  'POST';
        $mod_request->type   =  'batch';
        $mod_request->body   = array();
        list($code,$response) = $mod_request->invoke();

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $remove_params['user_id'];
        $mod_tdlog->liked_user_id = $remove_params['liked_user_id'];
        $mod_tdlog->entry_id = $remove_params['entry_id'];
        $mod_tdlog->state = $mod_tdlog->getDeleteState();
        $mod_tdlog->result = $code;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedTableLikeName());

        $this->_checkResponse($response);

        $is_remove_success = true;

        return $is_remove_success;
    }

    public function getLikeList($get_params)
    {
        if (isset($get_params['limit'])){
            $limit =  $get_params['limit'];
        } else {
            $limit = GREE_SERVICE_AVATARFEED_DEFAULT_GET_LIKE_LIMIT;
        }
        $query = '?limit=' . $limit;

        // start_id is sender_id
        if (isset($get_params['start_id'])){
            $query = $query . '&start_id=' . $get_params['start_id'];
        }

        $mod_request          = self::getModule('Request');
        $mod_request->path    = GREE_SERVICE_AVATARFEED_PATH . 'like/list/' . $get_params['entry_id'] . $query;
        $mod_request->method  = 'GET';
        $mod_request->type    = 'batch';
        $mod_request->body    = null;
        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);

        $result = $this->_alignFormatOfEntry($response['entry']['data'], 'sender_id');

        return array(
            $response['entry']['has_more'],
            $result,
        );
    }

    public function getLikeTimeLine($get_params=array())
    {
        if (isset($get_params['user_id'])){
            $user_id = $get_params['user_id'];
        } else {
            $user_id = $this->_certified_user->my['user_id'];
        }

        if (isset($get_params['limit'])){
            $limit =  $get_params['limit'];
        } else {
            $limit = GREE_SERVICE_AVATARFEED_DEFAULT_MAX_COUNT_LIKE_LIMIT;
        }
        $query = '?limit=' . $limit;

        if (isset($get_params['start_id'])){
            $query = $query . '&start_id=' . $get_params['start_id'];
        }

        $mod_request          = self::getModule('Request');
        $mod_request->path    = GREE_SERVICE_AVATARFEED_PATH . 'like/timeline/' . $user_id . $query;
        $mod_request->method  = 'GET';
        $mod_request->type    = 'batch';
        $mod_request->body    = null;
        list($code,$response) = $mod_request->invoke();

        $this->_checkResponse($response);
        $response_entry = $this->_alignFormatOfTime($response['entry']['data']);

        return array(
            $response['entry']['has_more'],
            $response_entry,
        );
    }

    public function _checkResponse($response, $context=null)
    {
        if (is_array($response) == false) {
            $msg = 'appfeed module response is not array';
            throw new Gree_Service_AvatarFeed_Exception($msg, Gree_Service_AvatarFeed_Exception::E_APINET_UNKNOWN, $context);
        }

        if (array_key_exists('code', $response)){
            if (array_key_exists('messages', $response) == false) {
                $response['messages'] = 'unknown messages';
            }

            switch ($response['code']){
                case Gree_Service_AvatarFeed_Exception::E_APINET_DATA_NOT_FOUND:
                    throw new Gree_Service_AvatarFeed_Exception($response['messages'], Gree_Service_AvatarFeed_Exception::E_APINET_DATA_NOT_FOUND, $context);
                    break;
                default:
                    throw new Gree_Service_AvatarFeed_Exception($response['messages'], Gree_Service_AvatarFeed_Exception::E_APINET_UNKNOWN, $context);
            }
        }
    }

    public function _alignFormatOfTime($response)
    {
        if (!is_array($response) || empty($response)){
            return $response;
        }

        static $timezone = null;
        if (is_null($timezone)) {
            $timezone = new DateTimeZone('Asia/Tokyo');
        }

        foreach($response as $index => $entry){
            $t = new DateTime($entry['created_time']);
            $t->setTimeZone($timezone);
            $response[$index]['created_time'] = $t->format('Y-m-d H:i:s');
        }

        return $response;
    }
}
