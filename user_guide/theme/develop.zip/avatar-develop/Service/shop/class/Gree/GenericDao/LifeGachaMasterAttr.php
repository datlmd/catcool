<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_LifeGachaMasterAttrDao extends Gree_GenericDao_Apc {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'life_gacha_master_attr';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/shop';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/shop';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
    var $_field_names = array('id','gacha_id','name','value','mtime', 'ctime');

	/** @var ������ */
	var $_queries = array(
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(10) unsigned NOT NULL auto_increment,
                `gacha_id` int(10) unsigned NOT NULL default '0',
                `name` varchar(255) NOT NULL,
                `value` varchar(255) NOT NULL,
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                UNIQUE KEY `gacha_id` (`gacha_id`,`name`)
            ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
            'find_by_gacha_id' => array(
				'sql' => 'SELECT * FROM life_gacha_master_attr WHERE gacha_id = :gacha_id'
			),
			'find_by_id' => array(
				'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id'
			),
			'find_by_gacha_id_and_name' => array(
				'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id AND name = :name'
			),
			'find_by_gacha_ids_and_name' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id in (:gacha_ids) AND name = :name ORDER BY gacha_id DESC'
			),
            'find_gacha_ids_by_attr_name' => array(
                'sql' => 'SELECT gacha_id FROM life_gacha_master_attr WHERE name = :name'
            ),
			'delete_by_gacha_id_and_name' => array(
				'sql' => 'DELETE FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id AND name = :name'
			),
	);

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
