<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/DeckDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-18
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Deck form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_DeckDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'deck';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'type',
        'item_ids',
        'sex',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'find_max_id'             => array(
            'sql' => 'SELECT MAX(id) as max_id FROM __TABLE_NAME__',
        ),
        'find_by_not_user'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id NOT IN (:user_id)',
        ),
        'find_by_user_id_and_type'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id IN (:user_id) AND type IN (:type)',
        ),
        'find_by_user_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY type',
        ),
        'find_all_user_id'               => array(
            'sql' => 'SELECT user_id FROM __TABLE_NAME__ GROUP BY user_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, type, item_ids, sex, ctime) VALUES (:user_id, :type, :item_ids, :sex, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET user_id = :user_id, type = :type, item_ids = :item_ids, sex = :sex WHERE id = :id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'delete_uid'             => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id` INT(11) UNSIGNED NOT NULL,
                    `type` TINYINT(4) UNSIGNED NOT NULL,
                    `item_ids` VARCHAR(255) NOT NULL DEFAULT '',  
                    `sex` TINYINT(1) UNSIGNED NOT NULL,    
                    `mtime`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`         DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                KEY `user_id` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Osacolo_DeckFarmSelector();
    }
}

class Gree_GenericDao_Osacolo_DeckFarmSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%02d"; //[osacolo_id]

    function getTableName($dao, $type, $hint)
    {
        if (empty($hint) || !isset($hint['osacolo_id'])) {
            return PEAR::raiseError("hint is empty osacolo_id. dao=" . get_class($dao) . "];");
        }

        $table_suffix = sprintf($this->_table_suffix_format, $hint['osacolo_id']);
        $table_name   = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
}
