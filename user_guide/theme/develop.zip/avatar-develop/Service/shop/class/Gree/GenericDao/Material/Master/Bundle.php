<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Material_Master_BundleDao extends Gree_GenericDao_Apc
{
    var $_table_name = 'material_bundle_master';

    var $_primary_key = 'bundle_id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_studio';

    var $_slave_dsn = 'gree://slave/avatar_studio';

    var $_auto_increment = false;

    var $_field_names = array(
        'bundle_id',
        'type',
        'name',
        'bundle_info',
        'mtime',
        'ctime'
    );

    var $_queries = array(

        //Refer query
        'find_bundle' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE bundle_id = :bundle_id"
        ),

        'find_all' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ ORDER BY bundle_id",
        ),

        'find_bundle_by_ids' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE bundle_id in (:bundle_ids) ORDER BY bundle_id",
        ),

        //Update
        'update_all' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET 
            name        = :name,
            type        = :type,
            bundle_info = :bundle_info
            where bundle_id = :bundle_id",
        ),

        //Insert
        'insert' => array(
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    name,
                    type,
                    bundle_info,
                    ctime
                )
                VALUES (
                    :name,
                    :type,
                    :bundle_info,
                    NOW()
                )
            ",
        ),

        //Create table
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `bundle_id` int(11) unsigned auto_increment,
                    `type`      tinyint(4) unsigned NOT NULL,
                    `name`      varchar(255) NOT NULL,
                    `bundle_info`    text NOT NULL,
                    `mtime`     timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`     datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`bundle_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
    );

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
