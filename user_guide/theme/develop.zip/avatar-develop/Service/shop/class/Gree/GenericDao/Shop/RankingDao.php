<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	CartDao.php
 *
 *	����åץ�󥭥󥰥ơ��֥�
 *
 *	@author		Masaki Inoue <inoue@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: RankingDao.php 20711 2007-08-16 03:28:06Z  $
 */
class Gree_GenericDao_Shop_RankingDao extends Gree_GenericDao {

	var $_table_name = 'shop_ranking';
	var $_primary_key = 'id';
	var $_auto_increment = true;
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';
	var $_queries = array(
						  // �桼��������ͭ���뾦�ʤǺ������Ƥ��ʤ���Τΰ�����
						  'find_by_date' => array(
												  'sql' => 'SELECT * FROM shop_ranking WHERE date = :date'
												  ),
						  'get_max_date' => array(
												  'sql' => 'select max(date) as max  from shop_ranking'
												  ),
						  'get_ranking' =>  array(
												  'sql' => 'select * from shop_ranking where sex <> :sex and date = :date order by count desc'
												  ),
						  );

}
?>