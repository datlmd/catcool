<?php

class Gree_Service_AvatarFeed_Module_Score
    extends Gree_Service_AvatarFeed_Module_Base
{

    public function increment($cycle, $key, $offset = 1)
    {
        $accessor = $this->_getAccessor($cycle);

        $incremented_value = $accessor->increment($key, $offset);

        return $incremented_value;
    }

    public function add($cycle, $key, $value = 1, $expire_time = 3600)
    {
        $accessor = $this->_getAccessor($cycle);

        $is_success = $accessor->add($key, $value, $expire_time);

        return $is_success;
    }

    public function get($cycle, $key)
    {
        $accessor = $this->_getAccessor($cycle);

        $key_info = $accessor->get($key);

        return $key_info;
    }

    public function cas($cycle, $token, $key, $value)
    {
        $accessor = $this->_getAccessor($cycle);

        $is_success = $accessor->cas($token, $key, $value);

        return $is_success;
    }

    public function delete($cycle, $key)
    {
        $accessor = $this->_getAccessor($cycle);

        $is_success = $accessor->delete($key);

        return $is_success;
    }

    public function _getAccessor($cycle)
    {
        $namespace = 'avatar_feed#score_'. $cycle . 'kvs';
        return Cascade::getAccessor($namespace);
    }

    public function _getScoreKey($category, $user_id, $date)
    {
        return $category . '_' . $user_id . '_' . $date;
    }

    public function _getTopScoreListKey($category, $date)
    {
        return $category . '_list_' . $date;
    }
}