<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
/**
 * Gree_GenericDao_Avapri_Seal_AvatarSealMemberInfoDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Seal_AvatarSealMemberInfoDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'avatar_seal_member_info';
	/** @var primary key */
    var $_primary_key = 'member_id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'member_id',
        'user_id',
        'item_ids',
        'ctime',
        'mtime'
    );

    var $_queries = array(
        // select----------------------
        'find_by_user_id' => array( //use.
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_member_id' => array( //use.
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE member_id = :member_id',
        ),
        'find_by_member_id_and_user_id' => array( //use.
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE member_id = :member_id and user_id = :user_id',
        ),
        // insert----------------------
        'insert_member_info' => array(
                'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, item_ids, ctime) VALUE (:user_id, :item_ids, NOW() )',
                'return_last_insert_id' => true,
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `member_id` int(11) unsigned NOT NULL auto_increment,
                  `user_id` int(11) unsigned NOT NULL,
                  `item_ids` varchar(255) NOT NULL,
                  `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                  `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  PRIMARY KEY  (`member_id`),
                  KEY `avatar_seal_member_info_1` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );
    
    function _init()
    {
        parent::_init();
    
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
?>
