<?php

require_once PATH_SRC_CLASS . 'Gree/GenericDao/UserIdFarmSelector.php';

class Gree_GenericDao_PushNotification_SubscriptionDao extends Gree_GenericDao
{
    var $_table_name        = 'push_notification_subscription';

    var $_primary_key       = 'id';

    var $_auto_increment    = true;

    var $_created_at_column = 'ctime';

    var $_updated_at_column = 'mtime';

    var $_master_dsn        = 'gree://master/avatar_oauth';

    var $_slave_dsn         = 'gree://slave/avatar_oauth';

    var $_field_names       = array(
        'id',
        'user_id',
        'subscription_type',
        'udid',
        'subscription_token',
        'ctime',
        'mtime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id                 INT(11)      UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id            INT(11)      UNSIGNED NOT NULL,
                    subscription_type  INT(3)       UNSIGNED NOT NULL,
                    udid               VARCHAR(255) NOT NULL,
                    subscription_token VARCHAR(255) NOT NULL,
                    ctime              DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    mtime              TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    UNIQUE subscription (user_id, subscription_type, udid)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),

        'insert' => array(
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    user_id,
                    subscription_type,
                    udid,
                    subscription_token,
                    ctime
                )
                VALUES (
                    :user_id,
                    :subscription_type,
                    :udid,
                    :subscription_token,
                    NOW()
                )
            ",
            'return_last_insert_id' => true,
        ),

        'find_by_user_id_and_udid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and udid = :udid',
        ),

        'find_by_user_id_and_subscription_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and subscription_type = :subscription_type',
        ),

        'delete_subscription' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id and subscription_type = :subscription_type and udid = :udid',
        ),

        'delete_by_user_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),

    );

    function _initFarmSelector()
    {
        $table_nums = 10;

        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = 2;
        }

        $this->_farm_selector   = new Gree_GenericDao_UserIdFarmSelector($table_nums);
    }
}
