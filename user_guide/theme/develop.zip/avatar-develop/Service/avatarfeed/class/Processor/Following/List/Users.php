<?php

class Gree_Service_AvatarFeed_Processor_Following_List_Users
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $mod_follow = self::getModule('Follow');
        $following_user_ids = [];
        try {
          $following_user_ids = $mod_follow->getFollowingListUser(
            $this->input_values['following_user_ids'],
            $this->input_values['user_id']
          );
        } catch (Exception $e) {
            $msg     = 'failed get following users';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return $following_user_ids;
    }
}
