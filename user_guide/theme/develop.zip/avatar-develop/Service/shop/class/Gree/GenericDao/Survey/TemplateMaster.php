<?php

class Gree_GenericDao_Survey_TemplateMasterDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'customer_survey_templates';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = [
        'id',
        'type_id',
        'answer_type',
        'required',
        'section_id',
        'question_order',
        'question',
        'choices',
        'max_ans_num',
        'min_ans_num',
        'is_deleted',
        'mtime',
        'ctime',
    ];

    var $_queries = [
        //Refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE is_deleted = 0 ORDER BY id DESC',
        ],
        'find_by_type' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE is_deleted = 0 AND type_id = :type_id ORDER BY section_id, question_order',
        ],
        'find_by_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id AND is_deleted = 0',
        ],
        'find_by_section' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE type_id = :type_id AND section_id = :section_id AND is_deleted = 0 ORDER BY question_order',
        ],
        //Update queries
        'update_delete_order' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET is_deleted = :is_deleted, question_order = :after_order WHERE id = :id'
        ],
        'update_order' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET question_order = :new_question_order WHERE id = :id'
        ],
        'update_all' => [
            'sql' => '
            UPDATE __TABLE_NAME__ SET
                    type_id        = :type_id,
                    answer_type    = :answer_type,
                    required       = :required,
                    section_id     = :section_id,
                    question_order = :question_order,
                    question       = :question,
                    choices        = :choices,
                    max_ans_num    = :max_ans_num,
                    min_ans_num    = :min_ans_num
                WHERE
                    id = :id
            ',
        ],

        //Insert query
        'insert' => [
            'sql' => "
            INSERT IGNORE INTO __TABLE_NAME__ (
                    type_id,
                    answer_type,
                    required,
                    section_id,
                    question_order,
                    question,
                    choices,
                    max_ans_num,
                    min_ans_num,
                    ctime
                )
                VALUES(
                    :type_id,
                    :answer_type,
                    :required,
                    :section_id,
                    :question_order,
                    :question,
                    :choices,
                    :max_ans_num,
                    :min_ans_num,
                    NOW()
                )
            ",
        ],

        //Create table query 
        'create' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `type_id` INT UNSIGNED NOT NULL,
                `answer_type` INT UNSIGNED NOT NULL,
                `required` INT UNSIGNED NOT NULL,
                `section_id` INT UNSIGNED NOT NULL,
                `question_order` INT UNSIGNED NOT NULL,
                `question` varchar(255) NOT NULL,
                `choices` text NOT NULL,
                `max_ans_num` INT UNSIGNED NOT NULL,
                `min_ans_num` INT UNSIGNED NOT NULL,
                `is_deleted` INT UNSIGNED NOT NULL DEFAULT 0,
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                KEY `survey_section_order_idx` (`type_id`, `section_id`, `question_order`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
        // only debug
        'update_filed_status' => [
            'sql' => 'ALTER TABLE __TABLE_NAME__ DROP COLUMN `status`, ADD COLUMN `is_deleted` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `min_ans_num`;'
        ],
    ];

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
