<?php
class Gree_Service_AvatarFeed_Module_Tdlog
    extends Gree_Service_AvatarFeed_Module_Base
{
    const DELETE_STATE = 0;
    const INSERT_STATE = 1;
    
    const TD_TABLE_AVATAR_FEED = 'avatar_feed';
    const TD_TABLE_AVATAR_FEED_LIKE = 'avatar_feed_like';
    const TD_TABLE_AVATAR_FEED_FOLLOWED = 'avatar_feed_followed';
    const TD_TABLE_AVATAR_FEED_FOLLOWING = 'avatar_feed_following';
    const TD_TABLE_AVATAR_FEED_COMMENT = 'avatar_feed_comment';
    const TD_TABLE_AVATAR_FEED_STREAM = 'avatar_feed_stream';
    const TD_TABLE_AVATAR_FEED_BLOCK = 'avatar_feed_block';
    
    //var $table_name = null;
    
    var $uid = null;
    var $state =null;
    var $result =null;

    var $entry_id = null;
    var $feed_id = null;
    var $commented_user_id = null;
    var $comment_id = null;
    var $comment_category = null;
    var $liked_user_id = null;
    var $following_user_id = null;
    var $followed_user_id = null;
    var $block_user_id = null;
    var $entry_category = null;
    
    public function createFeedTdLog($table_name) {
        if (!$table_name) { return; }
        
        // must td param
        $td_log_data = array(
            'uid' => $this->uid,
            'result' => $this->result,
        );
        $user_id = null;

        switch ($table_name) {
            case self::TD_TABLE_AVATAR_FEED:
                $td_log_data['feed_id'] = $this->feed_id;
                break;

            case self::TD_TABLE_AVATAR_FEED_LIKE:
                $td_log_data['liked_user_id'] = $this->liked_user_id;
                $td_log_data['entry_id'] = $this->entry_id;
                $td_log_data['state'] = $this->state;
                break;

            case self::TD_TABLE_AVATAR_FEED_FOLLOWED:
                $td_log_data['followed_user_id'] = $this->followed_user_id;
                $td_log_data['state'] = $this->state;
                $user_id = $this->uid;
                break;

            case self::TD_TABLE_AVATAR_FEED_FOLLOWING:
                $td_log_data['following_user_id'] = $this->following_user_id;
                $td_log_data['state'] = $this->state;
                break;
                
            case self::TD_TABLE_AVATAR_FEED_BLOCK:
                $td_log_data['block_user_id'] = $this->block_user_id;
                $td_log_data['state'] = $this->state;
                break;

            case self::TD_TABLE_AVATAR_FEED_COMMENT:
                $td_log_data['entry_id'] = $this->entry_id;
                $td_log_data['commented_user_id'] = $this->commented_user_id;
                $td_log_data['comment_id'] = $this->comment_id;
                $td_log_data['state'] = $this->state;
                $td_log_data['comment_category'] = $this->comment_category;
                break;

            case self::TD_TABLE_AVATAR_FEED_STREAM:
                $td_log_data['entry_id'] = $this->entry_id;
                $td_log_data['state'] = $this->state;
                $td_log_data['entry_category'] = $this->entry_category;
                break;

            default:
                return;
        }

        $service_shop = getService('shop');
        $service_shop->getTdLogger()->writeTdLoggerLog($table_name, $td_log_data, $user_id);
    }
    /* getter */
    public static function getInsertState() { return self::INSERT_STATE; }
    public static function getDeleteState() { return self::DELETE_STATE; }
    public static function getAvatarFeedTableName() { return self::TD_TABLE_AVATAR_FEED; }
    public static function getAvatarFeedTableLikeName() { return self::TD_TABLE_AVATAR_FEED_LIKE; }
    public static function getAvatarFeedFollowedTableName() { return self::TD_TABLE_AVATAR_FEED_FOLLOWED; }
    public static function getAvatarFeedFollowingTableName() { return self::TD_TABLE_AVATAR_FEED_FOLLOWING; }
    public static function getAvatarFeedBlockTableName() { return self::TD_TABLE_AVATAR_FEED_BLOCK; }
    public static function getAvatarFeedCommentTableName() { return self::TD_TABLE_AVATAR_FEED_COMMENT; }
    public static function getAvatarFeedStreamTableName() { return self::TD_TABLE_AVATAR_FEED_STREAM; }
}
