<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Shop/LuckyBag/User.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Shop_LuckyBag_UserDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'lucky_bag_user';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/shop';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/shop';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'lucky_bag_id',
        'lucky_bag_info_id',
        'gacha_cnt',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        'find_by_lucky_bag_info_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND lucky_bag_info_id=:lucky_bag_info_id',
        ),
        'find_by_lucky_bag_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND lucky_bag_id=:lucky_bag_id',
        ],
        // {{{ �������������������
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, lucky_bag_id, lucky_bag_info_id, ctime) VALUES(:user_id, :lucky_bag_id, :lucky_bag_info_id, NOW())',
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET gacha_cnt=:gacha_cnt WHERE id=:id AND user_id=:user_id AND gacha_cnt=:old_gacha_cnt',
        ),

        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                int(11) unsigned NOT NULL auto_increment,
                    `user_id`           int(11) unsigned NOT NULL default '0',
                    `lucky_bag_id`      int(11) unsigned NOT NULL default '0',
                    `lucky_bag_info_id` int(11) unsigned NOT NULL default '0',
                    `gacha_cnt`         int(11) unsigned NOT NULL default '1',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `lucky_bag_info_id` (`user_id`,`lucky_bag_info_id`),
                    KEY `lucky_bag_id` (`user_id`,`lucky_bag_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'truncate_table' => array(      // for batch
            'sql' => "TRUNCATE TABLE __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'delete' => array(          // debug tool for debug environment
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id=:user_id AND lucky_bag_id=:lucky_bag_id',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Shop_LuckyBag_UserSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Shop/LuckyBag/User.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Shop_LuckyBag_UserSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ TABLE_DIVIDE_NUM
    /* �ơ��֥�ʬ��� */
    const TABLE_DIVIDE_NUM = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%02d";   // user id/TABLE_DIVIDE_NUM (shading no)
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['user_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, ($hint['user_id'] % self::TABLE_DIVIDE_NUM));

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
