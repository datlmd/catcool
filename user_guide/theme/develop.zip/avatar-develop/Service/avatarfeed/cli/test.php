<?php

$start_time = microtime(true);
require "/home/gree/src/Gree_Bootstrap.php";
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once PATH_SRC_CLASS.'/Gree/CLI.php';
echo '-------------------------------------------' . PHP_EOL;
echo ' Test Cli... ' . PHP_EOL;
echo '-------------------------------------------' . PHP_EOL;

$srv_shop   = getService('shop');
$mgr_mypage = $srv_shop->getMypageManager();

$check_list = $mgr_mypage->getWatchList(528173);

echo print_r($check_list);





$srv_sns    = getService('sns');
$link_list = array(
    519883,
    519888,
    519759,
    521149,
    408127,
);
//$official_users_info = $srv_sns->getMultiUserAttr($link_list, 'official');
//$mgr_friend = $srv_sns->getFriendManager();
//$link_list = $mgr_friend->getLinkHash(519883, 0, 100);
//echo print_r($link_list);
//echo print_r($official_users_info);

//Gree_Async::add('shop::avatarfeed', 'addDestination', null, 'test');
/*
$accessor = Cascade::getAccessor('avatar_feed#following');
$find_values = array(
    'user_id' => 519883,
);
$add_values = array(
    'following_user_id' => 10,
    'user_id'           => 519883,
);
$add_result = $accessor->execute('add_following', $add_values);
echo print_r($add_result);
*/

echo "[DONE]\t" . sprintf('%.3f', (microtime(TRUE) - $start_time)) . PHP_EOL;