<?php
class Gree_GenericDao_Analytics_DateFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ getTableName($dao, $type, $hint)
    /**
     *  テーブル名を取得する。
     *
     *  @param      $dao        DAOクラス
     *  @param      $type       処理タイプ
     *  @param      $hint       テーブル選択ヒント
     *  @return     string      テーブル名
     */
    function getTableName($dao, $type, $hint)
    {
        // 参照するテーブルを確定
        if (isset($hint['ctime']) === TRUE) {
            $postfix = date('Y-m-d H:i:s', strtotime($hint['ctime']));
        } elseif (isset($hint['date']) === TRUE) {
            $postfix = date('Y-m-d H:i:s', strtotime($hint['date']));
        } else {
            $postfix = date('Y-m-d H:i:s');
        }

        if (isset($hint['format'])) {
            $format = $hint['format'];
        } else {
            $format = 'Ymd';
        }
        $postfix = date($format, strtotime($postfix));


        // テーブル名確定
        $table_suffix   = sprintf("_%s", $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
