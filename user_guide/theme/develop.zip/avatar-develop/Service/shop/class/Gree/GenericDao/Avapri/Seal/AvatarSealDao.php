<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserFarmSelector.php');
/**
 * Gree_GenericDao_Avapri_Seal_AvatarSealDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Seal_AvatarSealDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'avatar_seal';
	/** @var primary key */
    var $_primary_key = 'seal_id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'seal_id',
        'user_id',
        'snap_key',
        'frame_item_id',
        'background_item_id',
        'stamp_ids',
        'scale_type',
        'date_stamp',
        'ctime',
        'mtime'
    );

    var $_queries = array(
        // select----------------------
        'find_by_seal_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE seal_id = :seal_id',
        ),
        'find_by_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state order by seal_id desc',
        ),
        'find_by_user_id_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND user_id = :user_id',
        ),
        'find_by_seal_id_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND seal_id=:seal_id',
        ),

        //for support tool
        'find_by_user_id' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id order by seal_id desc',
        ),
        // find_all_by_user_id all(for debug)
        'count_all_by_user_id' => array(
            'sql' => 'SELECT count(*) as cnt FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // update----------------------
        'update_try_material' => array(// use.
            'sql' =>  'UPDATE __TABLE_NAME__ SET background_item_id = :background_item_id, frame_item_id = :frame_item_id,  stamp_ids = :stamp_ids, date_stamp = :date_stamp, snap_key = :snap_key  WHERE seal_id=:seal_id AND state=:state'
        ),
            
        'update_state_by_seal_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :new_state WHERE seal_id = :seal_id AND state=:state',
        ),
        'update_state_and_snapkey_by_seal_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :new_state , snap_key=:snap_key WHERE seal_id = :seal_id AND state=:state',
        ),
        'update_try_bg_material' => array(
            'sql' =>  'UPDATE __TABLE_NAME__ SET background_item_id = :background_item_id WHERE seal_id=:seal_id AND state=:state'
        ),
        'update_try_frame_material' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET frame_item_id = :frame_item_id WHERE user_id =:user_id AND state=:state'
        ),
        'update_try_seal_material_stamp' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET stamp_ids = :stamp_id WHERE user_id =:user_id AND state=:state'
        ),
        'update_try_seal_material_date_stamp' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET date_stamp = NOW() WHERE user_id =:user_id AND state=:state'
        ),
        // insert----------------------
        'create_avatar_seal' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, frame_item_id, background_item_id, stamp_ids, scale_type, date_stamp, ctime) 
                          VALUE (:user_id, :frame_item_id, :background_item_id , :stamp_id, :scale_type, :date_stamp, NOW() )',
            'return_last_insert_id' => true,
        ),
            
        // create table------------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `seal_id` int(11) unsigned NOT NULL auto_increment,
                  `user_id` int(11) unsigned NOT NULL,
                  `frame_item_id` int(11) unsigned default NULL,
                  `background_item_id` int(11) unsigned default NULL,
                  `snap_key` varchar(1023) default NULL,
                  `stamp_ids` varchar(255) default NULL,
                  `scale_type` tinyint(4) unsigned default '1',
                  `state` tinyint(4) unsigned default '0',
                  `date_stamp` datetime default NULL,
                  `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                  `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  PRIMARY KEY  (`seal_id`),
                  KEY `avatar_seal_1` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // for gs query
        'gc_records' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE seal_id = :seal_id AND state=:state',
        ),
        'find_by_gc_record' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state order by seal_id',
        ),

        // for support tool
        'alter_table' => [
            'sql' => 'ALTER TABLE __TABLE_NAME__ MODIFY COLUMN snap_key varchar(1023)',
        ],
    );
    
    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
?>
