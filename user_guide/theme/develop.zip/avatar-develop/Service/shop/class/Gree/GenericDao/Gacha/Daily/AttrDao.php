<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Daily/AttrDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: AttrDao.php 140771 2011-11-04 14:19:50Z takashi-taniguchi $
 */
class Gree_GenericDao_Gacha_Daily_AttrDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */ 

    /** @var �ơ��֥�̾ */
    var $_table_name = 'gacha_daily_attr';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'gacha_id',
        'name',
        'value',
        'mtime',
        'ctime'
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` int(10)  unsigned NOT NULL auto_increment,
                  `gacha_id`    int(10) unsigned NOT NULL default '0',
                  `name`        varchar(255) NOT NULL,
                  `value`       varchar(255) NOT NULL,
                  `mtime`       timestamp NOT NULL default CURRENT_TIMESTAMP,
                  `ctime`       datetime NOT NULL default '0000-00-00 00\:00\:00',
                  PRIMARY   KEY  (`id`),
                  UNIQUE    KEY `gacha_id` (`gacha_id`,`name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),
        //'drop_table' => array(
        //    'sql' => 'DROP TABLE __TABLE_NAME__',
        //),
        'delete_by_gacha_id_and_name' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id AND name = :name'
        ),
        // }}}

        // {{{ ���ȷ�
        'find_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id'
        ),
        'find_by_gacha_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id'
        ),
        'find_by_gacha_id_and_name' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id AND name = :name'
        ),
        // }}}

        // {{{ ������
        'insert_gacha_daily_attr' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (gacha_id, name, value, mtime, ctime) VALUES(:gacha_id, :name, :value, NOW(), NOW()) ON DUPLICATE KEY UPDATE value = :value, mtime = NOW()',
            'return_last_insert_id' => true,
        ),
        // }}}
    );
}
