<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Follow_Import_CheckTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Follow_Import_CheckTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module_follow;
    var $mgr_mypage;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        // initialize follow status
        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_follow->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        try {
            $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1);
            list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
                UNIT_TEST_USER_ID_1,
                100,
                0
            );

            foreach ($following_user_ids as $following_user_id) {
                $this->module_follow->removeFollowingUser($following_user_id['content']['sender_id'], UNIT_TEST_USER_ID_1);
                $this->module_follow->removeFollowedUser(UNIT_TEST_USER_ID_1, $following_user_id['content']['sender_id']);
            }
        } catch (Exception $e) {
        }

        sleep(2);

        list($has_more, $empty_following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_following_user_ids));

        // initialize check list
        $srv_shop         = getService('shop');
        $this->mgr_mypage = $srv_shop->getMypageManager();

        try {
            $this->mgr_mypage->setUser(UNIT_TEST_USER_ID_1);
            $this->mgr_mypage->setUser(UNIT_TEST_USER_ID_2);
            $this->mgr_mypage->setUser(UNIT_TEST_USER_ID_3);
            $this->mgr_mypage->setUser(UNIT_TEST_USER_ID_4);
        } catch (Exception $e) {
        }

        $check_list = $this->mgr_mypage->getWatchList(UNIT_TEST_USER_ID_1);
        if (empty($check_list)) {
            return;
        }

        foreach ($check_list as $user) {
            $this->mgr_mypage->unWatch(UNIT_TEST_USER_ID_1, $user['watch_user_id']);
        }

        sleep(2);
    }

    public function test_success_import_check()
    {
        $check_user = array(
            UNIT_TEST_USER_ID_2,
            UNIT_TEST_USER_ID_3,
            UNIT_TEST_USER_ID_4
        );

        foreach ($check_user as $user_id) {
            $watch_result = $this->mgr_mypage->watch(UNIT_TEST_USER_ID_1, $user_id);
            $this->assertEquals(1, $watch_result);
        }

        sleep(2);

        $checked_users = $this->mgr_mypage->getWatchList(UNIT_TEST_USER_ID_1);
        $this->assertEquals(count($check_user), count($checked_users));

        $import_params       = array(
            'user_id' => UNIT_TEST_USER_ID_1
        );
        $result_import_check = $this->avatar_feed->process('follow_import_check', $import_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($result_import_check);

        sleep(2);

        list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(count($check_user), count($following_user_ids));
    }

    /**
     * test1:
     *   case  : no exist check user
     *   expect: $result_import_check == false
     */
    public function test_failed_import_check()
    {
        // test1
        $import_params       = array(
            'user_id' => UNIT_TEST_USER_ID_1
        );
        $result_import_check = $this->avatar_feed->process('follow_import_check', $import_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($result_import_check);
    }
}