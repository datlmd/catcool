<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/MasterDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-17
 */


/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_MasterDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'master';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'open_dt',
        'secret_open_dt',
        'end_dt',
        'close_dt',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (open_dt, secret_open_dt, end_dt, close_dt, ctime) VALUES (:open_dt, :secret_open_dt, :end_dt, :close_dt, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET open_dt = :open_dt, secret_open_dt = :secret_open_dt, end_dt = :end_dt, close_dt = :close_dt WHERE id = :id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                INT(10)     UNSIGNED NOT NULL AUTO_INCREMENT,
                    `open_dt`           DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `secret_open_dt`    DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `end_dt`            DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `close_dt`          DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `mtime`             TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                    `ctime`             DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}