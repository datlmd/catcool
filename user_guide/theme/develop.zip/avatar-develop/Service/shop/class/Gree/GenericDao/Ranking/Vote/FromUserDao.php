<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Ranking/Vote/FromUserDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: FromUserDao.php 142624 2011-12-20 16:28:49Z ibuki $
 */
class Gree_GenericDao_Ranking_Vote_FromUserDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */ 

    /** @var �ơ��֥�̾ */
    var $_table_name = 'vote_from_user';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_ranking_vote';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_ranking_vote';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'from_user_count',
        'from_user_csv',
        'mtime',
        'ctime',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`         INT(10) UNSIGNED NOT NULL,
                  `from_user_count` INT(10) UNSIGNED NOT NULL DEFAULT '0',
                  `from_user_csv`   TEXT,
                  `mtime`           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `ctime`           DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`user_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        'create' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ SET user_id = :user_id, from_user_count = 1, from_user_csv = :from_id, ctime = NOW()'
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET from_user_count = from_user_count + 1, from_user_csv = :from_user_csv WHERE user_id = :user_id AND from_user_count = :from_user_count'
        ),
        // }}}
        // {{{ ���ȷ�
        'find_by_primary_key' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'find_by_primary_key_with_date' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND ctime BETWEEN :date_from AND :date_to'
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        'delete_by_user_id' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE user_id=:user_id",
        ),
        // }}}
    );
    /** #@- */

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Ranking_Vote_FromUserFarmSelector();
    }
    // }}}
}

/**
 *  vote_from_user�ơ��֥��Farm Selector���
 *  
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @access   public
 *  @package  GREE
 */
class Gree_GenericDao_Ranking_Vote_FromUserFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 100;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%s_%02d";
    // }}}

    // {{{ getTableName($dao, $type, $hint)
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ����������
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        // user_id��contest_id��ɬ��
        if (empty($hint['user_id']) || empty($hint['contest_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾����
        $user_id = $hint['user_id'];
        $farm_no = (int)(((int)$user_id) % $this->_table_nums);
        if ($farm_no < 0) {
            return PEAR::raiseError("System Error");
        }
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['contest_id'], $farm_no);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
