<?php

class Gree_Service_AvatarFeed_Processor_Followed_List_Delete
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        if (empty($this->input_values['dead_followed_list'])) {
            return;
        }

        $mod_follow = self::getModule('Follow');
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;

        $success_count = 0;

        try {
            foreach ($this->input_values['dead_followed_list'] as $user) {
                $user_info = $mod_user->selectByID($user["content"]["sender_id"], USER_STATUS_ALL);
                if (empty($user_info) || in_array($user_info['status'], array(USER_STATUS_DELETE_RESERVE, USER_STATUS_DELETE))) {
                    $ret = $mod_follow->removeFollowedUser($user["content"]["sender_id"]);
                    if ($ret) {
                        $success_count++;
                    }
                }

                if ($success_count >= GREE_SERVICE_AVATARFEED_USER_AUTO_DELETE_FOLLOWS_MAX) {
                    break;
                }
            }

            if ($success_count == 0) {
                return;
            }

            $mod_follow->decrementFollowCountByInput('followed', $success_count);
        } catch (Exception $e) {
            $msg     = 'failed delete followed user.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOWED_DELETE;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return;
    }
}
