<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Setting_Incentive_Point_Get
 */
class Gree_Service_AvatarFeed_Processor_Setting_Incentive_Point_Get
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $mod_setting  = self::getModule('Setting');
        $is_success   = false;
        $setting_info = null;

        try {
            $setting_info = $mod_setting->getSettingInfoOfIncentive($this->input_values);
            if (isset($setting_info['start_date_time'])) {
                $is_active                 = $mod_setting->isActiveSettingOfIncentive($this->input_values['target_date'], $setting_info['start_date_time']);
                $setting_info['is_active'] = $is_active;
                $is_success                = true;
            }
        } catch (Exception $e) {

        }

        return array(
            $is_success,
            $setting_info
        );
    }
}