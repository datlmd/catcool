<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Special/Medal/MasterAttrDao.php
 * @package     GREE Avatar
 * @since       2018-11-08
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * MasterAttr form constructor
 * @access      public
 */
class Gree_GenericDao_Special_Medal_MasterAttrDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'special_medal_master_attr';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'master_medal_id',
        'name',
        'value',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_master_medal_id'            => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_medal_id = :master_medal_id',
        ],
        // }}}

        // {{{ update queries
        'entry'                              => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (master_medal_id, name, value, ctime) VALUES (:master_medal_id, :name, :value, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'                             => [
            'sql' => 'UPDATE __TABLE_NAME__ SET master_medal_id = :master_medal_id, name = :name, value = :value WHERE id = :id',
        ],
        'delete_by_master_medal_id_and_name' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE master_medal_id = :master_medal_id AND name = :name',
        ],
        // }}}

        'create_table' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `master_medal_id`   INT UNSIGNED NOT NULL,
                `name`              VARCHAR(255) NOT NULL,
                `value`             VARCHAR(255) NOT NULL,
                `mtime`             TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime`             DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY `name` (`master_medal_id`,`name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
    ];
}
