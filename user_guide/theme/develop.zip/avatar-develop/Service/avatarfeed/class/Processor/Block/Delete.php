<?php

class Gree_Service_AvatarFeed_Processor_Block_Delete
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $delete_result = true;

        $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_BLOCK_DELETE;
        $context = $this->input_values;

        $mod_block  = self::getModule('Block');
        $mod_follow = self::getModule('Follow');

        try {
            $delete_block_result = $mod_block->removeBlockUser($this->input_values['user_id']);

            if ($delete_block_result == false) {
                $msg = 'failed delete block user.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }

            // check block user following me
            $is_following = $mod_follow->getFollowingUser(
                $this->_certified_user->my['user_id'],
                $this->input_values['user_id']
            );

            if ($is_following) {
                $add_following_result = $mod_follow->addFollowedUser($this->input_values['user_id']);

                if ($add_following_result == false) {
                    $msg = 'failed add followed user';
                    new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                    return false;
                }

                $increment_followed_result = $mod_follow->incrementFollowCount(
                    'followed'
                );

                if ($increment_followed_result == false) {
                    $msg = 'failed increment followed count.';
                    new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                    return false;
                }
            }
        } catch (Exception $e) {
            $msg = 'failed delete block user.';
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            $delete_result = false;
        }

        return $delete_result;
    }
}