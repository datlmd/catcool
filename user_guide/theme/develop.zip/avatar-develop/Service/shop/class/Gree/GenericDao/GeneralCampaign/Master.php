<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Quiz/Master.php
 *
 *  @author   Masayoshi Yoshino <masayoshi.yoshino@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_GeneralCampaign_MasterDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'general_campaign_master';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'campaign_id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/shop';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/shop';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
                'campaign_id',
                'status',
                'title',
                'start_datetime',
                'end_datetime',
                'open_datetime',
                'close_datetime',
                'mtime',
                'ctime'
    );
      
	/** @var ������ */
	var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY campaign_id DESC'
        ),
        'find_by_campaign_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE campaign_id = :campaign_id'
        ),
        // open campaign page
        'find_active' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = 1 AND :time BETWEEN open_datetime AND close_datetime '
        ),
        // active campaign
        'find_active_campaign' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = 1 AND :time BETWEEN start_datetime AND end_datetime '
        ),
        // }}}
        // {{{ ������
        'insert_master' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (title, start_datetime, end_datetime, open_datetime, close_datetime, ctime) VALUES (:title, :start_datetime, :end_datetime, :open_datetime, :close_datetime, now())'
        ),
        'update_master' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status, title = :title, start_datetime = :start_datetime, end_datetime = :end_datetime, open_datetime = :open_datetime, close_datetime = :close_datetime WHERE campaign_id = :campaign_id'
        ),
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `campaign_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `status` TINYINT(2) NOT NULL DEFAULT 0,
                `title` varchar(255) NOT NULL default 'empty',
                `start_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`campaign_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        // }}}
    ); 
}
