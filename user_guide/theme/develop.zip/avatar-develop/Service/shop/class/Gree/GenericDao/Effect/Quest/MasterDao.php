<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 *  /home/gree/service/shop/class/GenericDao/Effect/Quest/MasterDao.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */

class Gree_GenericDao_Effect_Quest_MasterDao extends Gree_GenericDao_Apc {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'master_effect_quest';

    /** @var primary key */
    var $_primary_key = 'quest_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_effect';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_effect';

    /** @var �ե������̾ */
    var $_field_names = array(
        'quest_id',
        'state',
        'condition_type',
        'condition_value',
        'incentive_type',
        'incentive_value',
        'quest_text',
        'open_date',
        'close_date',
        'ctime',
        'mtime',
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY quest_id DESC',
        ),
        'find_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE quest_id = :quest_id',
        ),
        'find_by_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state IN (:state)',
        ),
        'find_by_state_and_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE condition_type = :condition_type AND state IN (:state)',
        ),
        // }}}
        // {{{ ������
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (
                        state,
                        condition_type,
                        condition_value,
                        incentive_type,
                        incentive_value,
                        quest_text,
                        open_date,
                        close_date,
                        ctime
                    ) VALUES (
                        :state,
                        :condition_type,
                        :condition_value,
                        :incentive_type,
                        :incentive_value,
                        :quest_text,
                        :open_date,
                        :close_date,
                        NOW()
                    )',
                ),
        'update' => array(  // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET state=:state, quest_text = :quest_text, condition_type = :condition_type, condition_value = :condition_value, incentive_type = :incentive_type, incentive_value = :incentive_value, open_date=:open_date, close_date = :close_date WHERE quest_id = :quest_id',
        ),

        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `quest_id`          INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `state`             INT(10) UNSIGNED NOT NULL,
                    `condition_type`    INT(10) UNSIGNED NOT NULL,
                    `condition_value`   VARCHAR(128) NOT NULL DEFAULT '',
                    `incentive_type`    INT(10) UNSIGNED NOT NULL,
                    `incentive_value`   VARCHAR(128) NOT NULL DEFAULT '',
                    `quest_text`        VARCHAR(128) NOT NULL DEFAULT '',
                    `open_date`         DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `close_date`        DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `ctime`             DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime`             TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`quest_id`),
                    KEY `state` (`state`, `condition_type`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
