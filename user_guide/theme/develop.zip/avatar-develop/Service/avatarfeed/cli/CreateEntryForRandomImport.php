<?php

require_once("/home/gree/xgree/avatar/Service/avatarfeed/cli/Base.php");



class Gree_Service_AvatarFeed_Cli_CreateEntryForRandomImport
    extends Gree_Service_AvatarFeed_Cli_Base
{
    public function main()
    {
        if (Config::get('state') != 'dev') {
            printf("this cli is dev only\n");
            return;
        }

        $this->_initialize();

        $this->_print_header('create entry for random import');

        $enable_user_list = $this->_get_enable_user();
        $create_count = 0;
        while ($create_count < 100) {
            $index = mt_rand(0, count($enable_user_list) - 1);
            $this->module->setUserIDtoCtfy($enable_user_list[$index]);

            list($is_success, $entry_id) = $this->_createEntry($enable_user_list[$index], GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);

            $create_count++;
            printf("count\n");
            printf("- ($create_count)\n");
            printf("- ($is_success)\n");

        }

        $this->_print_footer();
    }
}

$class = new Gree_Service_AvatarFeed_Cli_CreateEntryForRandomImport();
$class->main();