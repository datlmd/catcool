<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Oauth
    extends Cascade_DB_SQL_DataFormat
{
    protected $master_dsn = 'gree://master/avatar_oauth';
    // @var string  slave DSN
    protected $slave_dsn = 'gree://slave/avatar_oauth';
    // @var array   list of extra DSN
    protected $extra_dsn = array();
    // @var mixed   PRIMARY-KEY   (if multi-column-index, use array)
    protected $primary_key = 'user_id';
    // @var mixed   fetch mode (assoc/num)
    protected $fetch_mode = self::FETCH_MODE_ASSOC;
    // @var mixed   fetch KEY (if null, primary key is used)
    protected $fetch_key = NULL;
    // @var boolean flag representing whether use auto increment or not
    protected $auto_increment = false;
    // @var string  create date column name
    protected $created_at_column = 'ctime';
    // @var string  table name
    protected $table_name = 'access_token';
    // @var array   list of field names
    protected $field_names = array(
        'user_id',
        'access_key',
        'access_secret',
        'ctime'
    );
    // @var array   queries
    protected $queries = array(
        'create_table'    => array(
            'sql' => '
              CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id`       bigint(20)   UNSIGNED NOT NULL,
                `access_key`    varchar(255)          NOT NULL,
                `access_secret` varchar(255)          NOT NULL,
                `ctime`         datetime              NOT NULL,
                PRIMARY KEY (`user_id`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ',
        ),
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY ctime DESC',
        ),
        'save'            => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__  (user_id,access_key,access_secret,ctime) VALUES(:user_id, :access_key, :access_secret, NOW())'
        )

    );
}
