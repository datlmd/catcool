<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	CartDao.php
 *
 *	GREE LIFE ������
 *
 *	@author		Masaki Inoue <inoue@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: CartDao.php 18530 2007-06-29 03:27:49Z  $
 */
class Gree_GenericDao_Shop_CartDao extends Gree_GenericDao {
	var $_table_name = 'shop_cart';
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';
	var $_primary_key = 'id';
	var $_auto_increment = true;
	var $_queries = array(
			'find_by_user_and_key' => array(
					'sql' => 'SELECT * FROM shop_cart WHERE user_id=:user_id AND cart_key=:cart_key'
			),
			'update_blank_by_user' => array(
					'sql' => 'UPDATE shop_cart SET value=\'\' WHERE user_id=:user_id'
			),
	);
}
?>
