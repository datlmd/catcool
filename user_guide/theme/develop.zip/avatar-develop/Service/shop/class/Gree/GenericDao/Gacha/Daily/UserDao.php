<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Daily/UserDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: UserDao.php 140771 2011-11-04 14:19:50Z takashi-taniguchi $
 */
class Gree_GenericDao_Gacha_Daily_UserDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */ 

    /** @var �ơ��֥�̾ */
    var $_table_name = 'gacha_daily_user';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �ե�����ɥ����̾ */
    var $_field_names = array(
        'user_id',
        'gacha_id',
        'item_id',
        'brank_count',
        'continue_count',
        'total_count',
        'usable_time',
        'mtime',
        'ctime',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  user_id        int(11) UNSIGNED NOT NULL,
                  gacha_id       int(11) UNSIGNED NOT NULL,
                  item_id        int(11) UNSIGNED NOT NULL,
                  brank_count    int(11) UNSIGNED NOT NULL,
                  continue_count int(11) UNSIGNED NOT NULL,
                  total_count    int(11) UNSIGNED NOT NULL,
                  usable_time    datetime NOT NULL DEFAULT \"0000-00-00 00\:00\:00\",
                  mtime          timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  ctime          datetime NOT NULL DEFAULT \"0000-00-00 00\:00\:00\",
                  PRIMARY KEY (user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),
        //'drop_table' => array(
        //    'sql' => 'DROP TABLE __TABLE_NAME__',
        //),
        'create' => array(
            'sql' => "
                INSERT INTO __TABLE_NAME__
                    (user_id, gacha_id, item_id, brank_count, continue_count, total_count, usable_time, ctime)
                VALUE
                    (:user_id, :gacha_id, :item_id, :brank_count, :continue_count, :total_count, :usable_time, NOW())
            ",
        ),
        'update' => array(
            'sql' => "
                UPDATE __TABLE_NAME__
                SET
                  gacha_id          = :gacha_id,
                  item_id           = :item_id,
                  brank_count       = :brank_count,
                  continue_count    = :continue_count,
                  total_count       = :total_count,
                  usable_time       = :usable_time
                WHERE user_id = :user_id
            ",
        ),
        // for support only
        'create_or_increment' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__
                        (user_id, gacha_id, item_id, brank_count, continue_count, total_count, usable_time, ctime)
                      VALUES
                        (:user_id, :gacha_id, :item_id, :brank_count, :continue_count, :total_count, :usable_time, NOW())
                      ON DUPLICATE KEY UPDATE
                        total_count = :total_count,
                        usable_time = :usable_time
                      ',
        ),

        // }}}

        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
        // }}}
    );
    /** #@- */

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Gacha_Daily_UserFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Daily/UserFarmSelector.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: UserDao.php 140771 2011-11-04 14:19:50Z takashi-taniguchi $
 */
class Gree_GenericDao_Gacha_Daily_UserFarmSelector extends Gree_GenericDao_FarmSelector
{
	// {{{ _table_nums
	/** var int �ơ��֥�ʬ��� */
	var $_table_nums = 100;
	// }}}

	// {{{ _table_suffix_format
	/** var string �ơ��֥�ե������ֹ�ե����ޥå� */
	var $_table_suffix_format = "_%02d";
	// }}}

	// {{{ getTableName
	/**
	 *	�ơ��֥�̾��������롣
	 *
	 *	@param		$dao		DAO���饹
	 *	@param		$type		���������ס�
	 *	@param		$hint		�ơ��֥�����ҥ��
	 *	@return		string		�ơ��֥�̾
	 */
	function getTableName($dao, $type, $hint) {

		if (!isset($hint['user_id']) || empty($hint['user_id'])) {
			$type = !isset($hint['user_id']) ? 'missing' : 'empty';
			return PEAR::raiseError("farm hint user_id is $type. hint=[" . var_export($hint, true) . "];");	
		}
		$user_id = $hint['user_id'];

		// �ơ��֥�̾�μ���
		$original_table_name = $dao->_getTableName();
		if (PEAR::isError($original_table_name)) {
			return $original_table_name;
		}
		if (empty($original_table_name)) {
			return PEAR::raiseError("original table name is emptry. dao=" . get_class($dao) . "];");
		}

		// �ơ��֥�̾�˥ե�������ɲ�
		$farm_no = (int)(((int)$user_id) % $this->_table_nums);
		$farm = sprintf($this->_table_suffix_format, $farm_no);
		if (empty($farm)) {
			return PEAR::raiseError("farm is blank. user_id=[$user_id];");
		}
	
		$table_name = $original_table_name . $farm;
		return $table_name;
	}
	// }}}
}
