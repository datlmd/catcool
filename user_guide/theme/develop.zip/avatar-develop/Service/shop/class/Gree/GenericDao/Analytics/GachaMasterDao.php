<?php
    require_once('AnalyticsDao.php');

    class Gree_GenericDao_Analytics_GachaMasterDao extends Gree_GenericDao_Analytics
    {
        /** #@+
         * @access private
         */

        /** @var テーブル名 */
        public $_table_name = 'gacha_master';
        /** @var 主キー。複合キーはarrayハッシュで指定する。 */
        public $_primary_key = 'gacha_id';
        /** @var 更新日カラム名 */
        public $_updated_at_column = null;
        /** @var 登録日カラム名 */
        public $_created_at_column = null;
        /** @var マスターデータベースの接続文字列 */
        public $_master_dsn = 'gree://master/avatar_analytics';
        /** @var 登録日カラム名 */
        public $_slave_dsn = 'gree://slave/avatar_analytics';
        /** @var オートインクリメント */
        public $_auto_increment = true;
        /** @var フィールド名 */
        public $_field_names = [
            'gahca_id',
            'name',
            'gacha_type',
            'stat_time',
            'start_time',
        ];
        /**
         * @var クエリ定義。
         */
        public $_queries = [
            // {{{ 更新系
            'create_table'  => [
                'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                      `gacha_id` int(10) unsigned NOT NULL,
                      `name` varchar(64) NOT NULL,
                      `gacha_type` tinyint(4) NOT NULL,
                      `stat_time` datetime DEFAULT NULL,
                      `start_time` datetime DEFAULT NULL,
                      PRIMARY KEY (`gacha_id`)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
            ],
            'all'           => [
                'sql' => 'SELECT * FROM __TABLE_NAME__',
            ],
            'insert_master' => [
                'sql' => 'INSERT INTO __TABLE_NAME__ (`gacha_id`, `name`, `gacha_type`, `stat_time`, `start_time`)
                          VALUE (:gacha_id, :name, :gacha_type, :start_time, :start_time)',
            ],
            'find_all'          => [
                'sql' => 'select `gacha_id`, `name`, `gacha_type` as type_id, start_time from __TABLE_NAME__ ORDER BY `gacha_id` DESC',
            ],
            'find_by_gacha_id'  => [
                'sql' => 'select * from __TABLE_NAME__ WHERE `gacha_id` = :gacha_id',
            ],
            'find_by_gacha_type' => [
                'sql' => 'select * from __TABLE_NAME__ WHERE `gacha_type` = :gacha_type order by gacha_id DESC',
            ],
            'update_start_time' => [
                'sql' => 'update __TABLE_NAME__ set start_time = :start_time where gacha_id = :gacha_id AND start_time is null',
            ],
        ];
        /** #@- */
    }
