<?php
/**
 * MapperHolder.php
 */
require_once sprintf('%s/Mapper.php', dirname(__FILE__));

class Gree_Service_Shop_Data_MapperHolder
{
    // ----[ Constants ]--------------------------------------------------------
    const DATA_CLASS_FORMAT   = 'Gree_Service_Shop_Data_%s';
    const MAPPER_CLASS_FORMAT = 'Gree_Service_Shop_Data_%sMapper';

    // ----[ Properties ]-------------------------------------------------------
    /**
     * @string  class name
     */
    private $mappers = array();

    // ----[ Methods ]----------------------------------------------------------
    /**
     * get mapper
     *
     * @param   string
     * @return  Gree_Service_Shop_Data_Mapper
     */
    public function get($data_name)
    {
        $data_class = sprintf(self::DATA_CLASS_FORMAT, $data_name);
        if (!class_exists($data_class)) {
            // require class
            $rel_path = str_replace('_', '/', $data_name);
            $abs_path = realpath(sprintf('%s/../Shop/%s.php', dirname(__FILE__), $rel_path));
            if ($abs_path){
                require_once($abs_path);
            } else {
                throw new Gree_Service_Shop_Exception_DataException("Data class not found.");
            }
        }

        // load and cache Mapper at first
        if (!array_key_exists($data_class, $this->mappers)) {
            $rel_path = str_replace('_', '/', $data_name) . 'Mapper';
            $abs_path = realpath(sprintf('%s/../Shop/%s.php', dirname(__FILE__), $rel_path));
            if (is_readable($abs_path)) {
                require_once($abs_path);
                $mapper_class = sprintf(self::MAPPER_CLASS_FORMAT, $data_name);
                $mapper       = new $mapper_class($data_class);
            } else {
                // default mapper
                $mapper = new Gree_Service_Shop_Data_Mapper($data_class);
            }
            $this->mappers[$data_class] = $mapper;
        }

        return $this->mappers[$data_class];
    }
}
