<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Avapri/Master/TagDao.php
 *
 * @package     GREE Avatar
 */

/**
 * Tag form constructor
 * @access      public
 */
class Gree_GenericDao_Avapri_Master_TagDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'master_tag';

    /** @var primary key */
    var $_primary_key = 'tag_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';

    /** @var field names */
    var $_field_names = array(
        'tag_id',
        'tag_name',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'         => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_by_id'       => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE tag_id = :tag_id',
        ),
        'find_by_tag_name' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE tag_name LIKE :tag_name',
        ),
        // }}}

        // {{{ update queries
        'entry'            => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (tag_name, ctime) VALUES (:tag_name, NOW())',
            'return_last_insert_id' => true
        ),
        'update'           => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET tag_name = :tag_name WHERE tag_id = :tag_id',
        ),
        'delete'           => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE tag_id = :tag_id',
        ),
        'create_table'     => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `tag_id` INT(11) unsigned NOT NULL auto_increment,
                  `tag_name` VARCHAR(20) NOT NULL,
                  `ctime`                 DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`tag_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
