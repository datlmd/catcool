<?php
$start_time = microtime(true);
require "/home/gree/src/Gree_Bootstrap.php";
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once "/home/gree/xgree/avatar/Service/avatarfeed/service.php";
echo '-------------------------------------------' . PHP_EOL;
echo ' import entries... ' . PHP_EOL;
echo '-------------------------------------------' . PHP_EOL;

$item_entries = array(
    130966 => array(
    ),
    115856 => array(
    ),
    114273 => array(
    ),
    91731 => array(
    ),
    88838 => array(
    ),
    58949 => array(
    ),
    56735 => array(
    ),
    49472 => array(
    ),
    130960 => array(
    ),
    118691 => array(
    ),
    115855 => array(
    ),
    112169 => array(
    ),
    91729 => array(
    ),
    88403 => array(
    ),
    58749 => array(
    ),
    53940 => array(
    ),
);

try {
    $shop_service = getService('shop');
    $tutorial_coordinate_manger = $shop_service->getTutorialCoordinateManager();

    $avatar_feed = Gree_Service_AvatarFeed::getInstance();

    foreach($item_entries as $item_id => $entries) {
        $feed_info = $tutorial_coordinate_manger->getFeedInfoByItem($item_id);
        if (empty($feed_info)) {
            echo 'wrong item_id ' . $item_id;
            return;
        }

        echo 'item_id : ' . $item_id . PHP_EOL;

        $user_id       = $feed_info['user_id'];
        $feed_category = $feed_info['feed_category'];

        foreach ($entries as $entry_id) {
            echo 'import entry : ' . $entry_id . PHP_EOL;
            $params = array(
                'entry_id' => $entry_id,
                'user_id' => $feed_info['user_id'],
                'feed_category' => $feed_info['feed_category'],
            );
            $avatar_feed->process('tutorial_coordinate_destination_add', $params);
        }
    }

} catch (Exception $e) {
    echo $e->getMessage(),PHP_EOL;
    exit();
}

echo "[DONE]\t" . sprintf('%.3f', (microtime(TRUE) - $start_time)) . PHP_EOL;
