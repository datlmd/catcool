<?php
/**
 *	CampaignTokenDao.php
 *
 *	@author		Eiji Araki <araki@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: TokenDao.php 64269 2010-01-28 10:29:15Z sato $
 */
class Gree_GenericDao_Shop_Campaign_TokenDao extends Gree_GenericDao 
{
	var $_table_name = 'shop_campaign_token';
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';

	var $_field_names = array('token' ,'state' ,'campaign_id' ,'user_id', 'mtime' ,'ctime');
	var $_primary_key = 'token';
	var $_updated_at_column = 'mtime';
	var $_created_at_column = 'ctime';
	var $_auto_increment = false;
	
	var $_queries = array(
		'findByCampaignId' => array(
			'sql' => 'SELECT * FROM shop_campaign_token WHERE campaign_id = :campaign_id'
		),
		'findByCampaignIdUnused' => array(
			'sql' => 'SELECT * FROM shop_campaign_token WHERE campaign_id = :campaign_id AND state = 0 AND user_id IS NULL LIMIT 1'
		),
		'findByUserId' => array(
			'sql' => 'SELECT * FROM shop_campaign_token WHERE user_id = :user_id',
		),
		'findByToken' => array(
			'sql' => 'SELECT * FROM shop_campaign_token WHERE token = :token',
		),
		'useToken' => array(
			'sql' => 'UPDATE shop_campaign_token SET state = 1, user_id = :user_id, mtime = NOW() WHERE token = :token AND state = 0',
		),
	);
}
?>
