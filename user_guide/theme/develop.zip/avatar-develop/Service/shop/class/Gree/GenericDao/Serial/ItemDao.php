<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

class Gree_GenericDao_Serial_ItemDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'serial_item';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'id',
        'item',
        'count',
        'team',
        'status',
		'start',
		'expire',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_all_and_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :status ORDER BY id DESC',
        ),
        'find_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id IN (:id)',
        ),
        'find_id_and_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id IN (:id) AND status = :status',
        ),
        // }}}

        // {{{ update queries
        'entry'=> array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (item, count, team, start, expire, ctime) VALUES (:item, :limit, :team, :start, :expire, NOW())',
            'return_last_insert_id' => true
        ),
        'update'=> array(
            'sql' => 'UPDATE __TABLE_NAME__ SET item = :item, count = :limit, team = :team, start = :start, expire = :expire, status = :status WHERE id = :id',
        ),
        'update_team'=> array(
            'sql' => 'UPDATE __TABLE_NAME__ SET team = :team WHERE id IN (:id)',
        ),
        'update_status'=> array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE id = :id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `item` VARCHAR(255) NOT NULL DEFAULT '',
                    `count` INT(11) UNSIGNED NOT NULL DEFAULT 0,
                    `team` VARCHAR(255) NOT NULL DEFAULT '',
                    `status` INT(11) UNSIGNED NOT NULL DEFAULT 0,
					`start` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
					`expire` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
