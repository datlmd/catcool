<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Contest/Entry.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: EntryDao.php 142658 2011-12-21 05:21:25Z takashi-taniguchi $
 */

class Gree_GenericDao_Contest_EntryDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'contest_entry';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key ='id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_contest';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_contest';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
	                          'id',
							  'user_id',
							  'sex',
							  'title',
							  'item_ids',
							  'mtime',
							  'ctime'
							 );

	/** @var ������ */
	var $_queries = array(
	    // {{{ ���ȷ�
		'find_by_user' => array(
		    'sql' => "SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id",
		),
        'find_max_id' => array(
            'sql' => 'SELECT max(id) FROM __TABLE_NAME__'
        ),
		// }}}

		// {{{ ������
		'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                 `user_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                 `sex` TINYINT(2) NOT NULL DEFAULT '1',
                 `title` VARCHAR(60) NOT NULL DEFAULT '',
                 `item_ids` VARCHAR(255) NOT NULL DEFAULT '',
                 `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                 `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                 PRIMARY KEY  (`id`),
                 UNIQUE KEY `user_id` (`user_id`)
             ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
		),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__"
        ),
        'replace' => array(
            'sql' => "REPLACE INTO __TABLE_NAME__ (id, user_id, sex, title, item_ids, mtime, ctime) values (:id, :user_id, :sex, :title, :item_ids, :modify_time, :ctime)"
        ),
        'insert' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ (user_id, sex, title, item_ids) values (:user_id, :sex, :title, :item_ids)"
        ),
        'show_tables' => array(
            'sql' => 'show tables like "__TABLE_NAME__"'
        ),
        'delete_user_for_debug' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE user_id=:user_id",
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Contest_EntryFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Contest/EntryFarmSelector.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: EntryDao.php 142658 2011-12-21 05:21:25Z takashi-taniguchi $
 */
class Gree_GenericDao_Contest_EntryFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['contest_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        if (empty($hint['user_sex'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $contest_id = $hint['contest_id'];
        $user_sex = $hint['user_sex'];
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }

        // �ơ��֥�̾�˥ե�������ɲ�
        $farm = sprintf($this->_table_suffix_format, $contest_id, $user_sex);

        if (empty($farm)) {
            return PEAR::raiseError("farm is blank. contest_id=" . $contest_id . " user_sex=" . $user_sex);
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}

}
