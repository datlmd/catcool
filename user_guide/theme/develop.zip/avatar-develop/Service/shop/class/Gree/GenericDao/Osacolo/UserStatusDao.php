<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/UserStatusDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-24
 */

/**
 * UserStatus form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_UserStatusDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'user_status';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'stamina_count',
        'npc_stage_count',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_user_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_all_user_id'               => array(
            'sql' => 'SELECT user_id FROM __TABLE_NAME__',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, stamina_count, npc_stage_count, ctime) VALUES (:user_id, :stamina_count, :npc_stage_count, NOW())',
            'return_last_insert_id' => true
        ),
        'update_stage_up'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET npc_stage_count = npc_stage_count + 1 WHERE user_id = :user_id',
        ),
        'update_stamina'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET stamina_count = :stamina_count WHERE user_id = :user_id',
        ),
        'decrease_stamina'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET stamina_count = stamina_count - 1 WHERE user_id = :user_id AND stamina_count > 0',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                  `user_id` INT(11) UNSIGNED NOT NULL,
                  `stamina_count` TINYINT(1) UNSIGNED NOT NULL DEFAULT '6',
                  `npc_stage_count` TINYINT(1) UNSIGNED NOT NULL DEFAULT '1',
                  `mtime`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  `ctime`         DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        'alter_unique_user_id'                 => array(
            'sql' => 'ALTER TABLE __TABLE_NAME__ ADD UNIQUE (user_id)',
        ),
        // }}}
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Osacolo_UserStatusFarmSelector();
    }
}

class Gree_GenericDao_Osacolo_UserStatusFarmSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%02d"; //[osacolo_id]

    function getTableName($dao, $type, $hint)
    {

        if (empty($hint) || !isset($hint['osacolo_id'])) {
            return PEAR::raiseError("hint is empty osacolo_id. dao=" . get_class($dao) . "];");
        }

        $table_suffix = sprintf($this->_table_suffix_format, $hint['osacolo_id']);
        $table_name   = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
}