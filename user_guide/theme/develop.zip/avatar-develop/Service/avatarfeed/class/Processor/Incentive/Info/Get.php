<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Incentive_Info_Get
 */
class Gree_Service_AvatarFeed_Processor_Incentive_Info_Get
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $point_manager;

    protected function invoke()
    {
        $mod_incentive = self::getModule('Incentive');
        $mod_setting = self::getModule('Setting');

        $get_like_params = array(
            'action_type' => 'like',
        );
        $get_liked_params = array(
            'action_type' => 'liked',
        );
        try {
            //$point_info = array(
            //  'current'   => 0,
            //  'by_like'   => 0,
            //  'by_liked'  => 0,
            //  'by_lounge' => 0,
            //  'total'     => 0,
            //);
            $point_info = $mod_incentive->getPointInfo($this->input_values['user_id'], $this->input_values['target_date']);

            $already_get_lounge = $mod_incentive->getPointInfoBorder($this->input_values['user_id'], GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LOUNGE_POST);
            if ($already_get_lounge == true) {
                $point_info['by_lounge'] = 5;
                $point_info['total'] += 5;
            }
            $already_get_second = $mod_incentive->getPointInfoBorder($this->input_values['user_id'], GREE_SERVICE_SHOP_POINT_RECENT_TYPE_SECOND_AVATAR_CAMPAIGN);
            if ($already_get_second == true) {
                $point_info['by_second'] = GREE_SERVICE_SHOP_SECOND_CAMPAIGN_POINT;
                $point_info['total'] += GREE_SERVICE_SHOP_SECOND_CAMPAIGN_POINT;
            }

            $like_setting = array();
            // setting_info = array(
            //[action_type] => like
            //[start_date_time] => 2014-08-19 16:46:12
            //[end_date_time] => 2014-08-19 18:46:12
            //[point_per_action] => 10
            //[daily_limit_of_point] => 50
            //[limit_of_point_to_same_user] => 3
            //[ctime] => 2014-05-30 07:23:29
            //);
            $like_setting_info = $mod_setting->getSettingInfoOfIncentive($get_like_params);
            $like_setting['is_active'] = $mod_setting->isActiveSettingOfIncentive($this->input_values['target_date'], $like_setting_info['start_date_time']);
            $like_setting['point_per_action'] = $like_setting_info['point_per_action'];
            $like_setting['limit_number'] = $like_setting_info['daily_limit_of_point'] / $like_setting_info['point_per_action'];
            $like_setting['current_number'] = $point_info['by_like'] / $like_setting_info['point_per_action'];
            $like_setting['is_achieved'] = false;
            if ($like_setting['limit_number'] <= $like_setting['current_number']){
                $like_setting['is_achieved'] = true;
            }

            $liked_setting = array();
            $liked_setting_info = $mod_setting->getSettingInfoOfIncentive($get_liked_params);
            $liked_setting['is_active'] = $mod_setting->isActiveSettingOfIncentive($this->input_values['target_date'], $liked_setting_info['start_date_time']);
            $liked_setting['point_per_action'] = $liked_setting_info['point_per_action'];
            $liked_setting['limit_number'] = $liked_setting_info['daily_limit_of_point'] / $liked_setting_info['point_per_action'];
            $liked_setting['current_number'] = $point_info['by_liked'] / $liked_setting_info['point_per_action'];
            $liked_setting['is_achieved'] = false;
            if ($liked_setting['limit_number'] <= $liked_setting['current_number']){
                $liked_setting['is_achieved'] = true;
            }

            $registry = getService('shop')->getRegistry();
            $avatar_feed_lounge_info = $registry->getArray('avatar_feed_lounge_info');
            $point_info['max_total'] = $avatar_feed_lounge_info['post_get_ap'];
            if ($like_setting['is_active']){
                $point_info['max_total'] += $like_setting_info['daily_limit_of_point'];
            }
            if ($liked_setting['is_active']){
                $point_info['max_total'] += $liked_setting_info['daily_limit_of_point'];
            }

            if ($this->input_values['second_whitelist'] == true) {
                $this->_second_manager = getService('shop')->getSecondManager('campaign', array('user_id' => $this->input_values['user_id']));
                $second_avatar_campaign_info = $this->_second_manager->getActiveMaster();
                if ($second_avatar_campaign_info !== false) {
                    $point_info['second_campaign'] = true;
                    $point_info['second_campaign_end_time'] = $second_avatar_campaign_info['end_time'];
                    $point_info['max_total'] += GREE_SERVICE_SHOP_SECOND_CAMPAIGN_POINT;
                }
            }

            $point_info['is_all_achieved'] = false;
            if ($point_info['total'] >= $point_info['max_total']){
                $point_info['is_all_achieved'] = true;
            }
        } catch (Exception $e) {
            $msg = 'failed get info of incentive.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_INCENTIVE_INFO_GET;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return false;
        }

        $point_info['like_setting'] = $like_setting;
        $point_info['liked_setting'] = $liked_setting;

        return $point_info;
    }
}
