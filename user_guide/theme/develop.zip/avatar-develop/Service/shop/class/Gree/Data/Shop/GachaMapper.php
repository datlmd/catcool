<?php
/**
 * GachaMapper.php
 */
class Gree_Service_Shop_Data_GachaMapper extends Gree_Service_Shop_Data_Mapper
{
    // ----[ Constants ]--------------------------------------------------------
    const DAO_NAME = 'LifeGachaMaster';

    // ----[ Properties ]-------------------------------------------------------
    /**
     * primary key filed
     */
    protected $primary_key = 'gacha_id';

    // ----[ Override Methods ]-------------------------------------------------
    /**
     * load accessor from gacha id
     *
     * @override
     * @param   int
     * @return  array
     */
    protected function load($gacha_id)
    {
        return $this->session->get(self::DAO_NAME, $gacha_id);
    }

    /**
     * mload accessors from gacha ids
     *
     * @override
     * @param   int
     * @return  array
     */
    protected function mload(array $gacha_ids)
    {
        return $this->session->toArray(
            self::DAO_NAME,
            'find_by_gacha_ids',
            array('gacha_ids' => $gacha_ids)
        );
    }

    // ----[ Methods ]----------------------------------------------------------
    /**
     * find by type id
     *
     * @param   int
     * @return  array
     */
    public function findByTypeId($type_id, $offset = null, $limit = null)
    {
        $params  = array('type_id' => $type_id);
        $masters = $this->session->toArray(
            self::DAO_NAME,
            'find_by_type_id',
            $params,
            $offset,
            $limit
        );

        return $this->minstantiate($masters);
    }
}
