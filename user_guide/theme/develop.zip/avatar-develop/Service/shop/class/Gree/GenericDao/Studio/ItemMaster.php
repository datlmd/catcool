<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/StudioItemFarmSelector.php';

class Gree_GenericDao_Studio_ItemMasterDao extends Gree_GenericDao
{
    var $_table_name = 'life_studio_item';

    var $_primary_key = 'item_id';

    var $_master_dsn = 'gree://master/life_item';

    var $_slave_dsn  = 'gree://slave/life_item';

    var $_auto_increment = false;

    var $_field_names = [
        'item_id',
        'origin_item_id',
        'status',
        'after_item_id',
        'type',
        'start_dt',
        'end_dt',
        'mtime',
        'ctime',
    ];

    var $_queries = [

        //Refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY item_id DESC'
        ],
        'find_by_status' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :status ORDER BY item_id'
        ],
        'find_by_type' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE type in (:type) ORDER BY item_id'
        ],
        'find_by_item_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = :item_id'
        ],
        'find_by_item_ids' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id in (:item_ids)'
        ],
        'find_by_item_id_equal_origin_item_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = origin_item_id order by ctime asc'
        ],

        //Update queries
        'update_all_attr' => [
            'sql' => "UPDATE __TABLE_NAME__ SET
            origin_item_id  = :origin_item_id,
            status          = :status,
            after_item_id   = :after_item_id,
            type            = :type,
            start_dt        = :start_dt,
            end_dt          = :end_dt
            WHERE item_id   = :item_id",
        ],
        'update_status' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE item_id in (:item_ids)'
        ],
        'update_after_item_id' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET after_item_id = :after_item_id WHERE item_id = :item_id'
        ],
        'update_start_dt' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET start_dt = :start_dt WHERE item_id in (:item_ids)'
        ],
        'update_end_dt' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET end_dt = :end_dt WHERE item_id in (:item_ids)'
        ],

        //Insert query
        'insert' => [
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    item_id,
                    origin_item_id,
                    status,
                    after_item_id,
                    type,
                    start_dt,
                    ctime
                )
                VALUES(
                    :item_id,
                    :origin_item_id,
                    :status,
                    :after_item_id,
                    :type,
                    :start_dt,
                    NOW()
                )
            ",
        ],

       //Create table query 
        'create' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `item_id` int(10) unsigned NOT NULL,
                `origin_item_id` int(11) unsigned NOT NULL,
                `status` tinyint(4) unsigned NOT NULL,
                `after_item_id` text NOT NULL,
                `type` tinyint(4) unsigned NOT NULL,
                `start_dt` timestamp NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_dt` timestamp NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`item_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
    ];

    function _init()
    {
        parent::_init();
        $this->_farm_selector = new Gree_GenericDao_Shop_StudioItemFarmSelector();
    }

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
