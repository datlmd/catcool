<?php
/**
 * @package     GREE Avatar
 * @since       2017-01-23
 */

class Gree_GenericDao_Pbox_AssignPresentTicketUserDao extends Gree_GenericDao {
    /** @var table name */
    var $_table_name = 'pbox_assign_present_ticket_user';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_present_box';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_present_box';

    /** @var field names */
    var $_field_names = array(
        'id',
        'assign_id',
        'user_id',
        'quantity',
        'status',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_assign_id'       => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE assign_id = :assign_id',
        ),
        'count_user_by_assign_id' => array(
            'sql' => 'SELECT count(*) as total_user FROM __TABLE_NAME__ WHERE assign_id = :assign_id',
        ),
        // {{{ update queries
        'entry'                   => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (assign_id, user_id, quantity, ctime) VALUES (:assign_id, :user_id, :quantity, NOW())',
            'return_last_insert_id' => true
        ),
        'update_status'           => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE id = :id',
        ),
        'create_table'            => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`            INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `assign_id`     INT(10) UNSIGNED NOT NULL,
                `user_id`       INT(10) UNSIGNED NOT NULL,
                `quantity`      TINYINT(3) UNSIGNED DEFAULT 1 NOT NULL,
                `status`        TINYINT(4) UNSIGNED DEFAULT 0 NOT NULL,
                `ctime`         DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime`         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                 PRIMARY KEY (`id`),
                 KEY `assign_id` (`assign_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );

}