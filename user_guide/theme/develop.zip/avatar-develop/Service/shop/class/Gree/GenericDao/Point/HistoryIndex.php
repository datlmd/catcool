<?php
/**
 * Gree_GenericDao_Point_HistoryIndex
 *
 * @author  Takahsi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/DateFarmSelector.php';

class Gree_GenericDao_Shop_Point_HistoryIndexDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'point_history_index';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_point';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_point';

    /** @var field names */
    var $_field_names       = array(
        'id',
        'user_id',
        'year',         // ǯ���ݻ�
        'month',        // ����ݻ�
        'date_array',   // �����ݻ��ʥҥ��ȥ꡼�ݻ��������������JSON��������Ρ�
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY year DESC, month DESC',
        ),
        'find_by_user_id_and_month' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND year = :year AND month = :month',
        ),
        // }}}

        // {{{ update queries
        'replace' => array(
            'sql' => 'REPLACE INTO __TABLE_NAME__ (id, user_id, year, month, date_array, ctime) VALUES (:id, :user_id, :year, :month, :date_array, :ctime)',
        ),
        'create_table'      => array(
            'sql'   => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id          INT(11)         UNSIGNED NOT NULL AUTO_INCREMENT,
                    user_id     INT(11)         UNSIGNED NOT NULL,
                    year        INT(4)          UNSIGNED NOT NULL,
                    month       TINYINT(2)      UNSIGNED NOT NULL,
                    date_array  TEXT,
                    ctime       DATETIME        NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime       TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (id),
                    UNIQUE KEY `user_id_and_ym` (`user_id`, `year`, `month`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'delete' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    /**
     * initialize farm selector
     *
     * @access  private
     */
    function _initFarmSelector()
    {
        // default table nums
        $table_nums     = 100;

        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            // for develop
            $table_nums = 2;
        }

        $this->_farm_selector   = new Gree_GenericDao_UserIdFarmSelector($table_nums);
    }
    // }}}
}
