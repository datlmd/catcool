<?php
/**
 * Service/shop/class/Gree/Data/Life/Item.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */

/**
 * Gree_Service_Shop_Data_Ticket
 *
 * @package GREE
 * @access  public
 */
class Gree_Service_Shop_Data_Life_Item
    extends Gree_Service_Shop_Data_Abstract
{
    // ----[ Methods ]----------------------------------------------------------
    /**
     * validate sex
     *
     * @param   int     $sex
     * @return  bool
     */
    public function validateSex($sex)
    {
        return in_array($this->sex, array($sex, LIFE_ITEM_SEX_UNISEX));
    }
}
