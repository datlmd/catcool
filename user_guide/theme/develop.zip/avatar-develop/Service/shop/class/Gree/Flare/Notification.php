<?php
/**
 * service/shop/class/Flare/Notification.php
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare.php';

class Gree_Service_Shop_Flare_Notification extends Gree_Service_Shop_Flare
{
    const NOTIFY_NAMESPACE = 'notification';
    const NOTIFY_EXPIRE_TIME = 2592000; // 30days
    // general
    const FLARE_ERROR_CODE_GENERAL_GET = 0000;
    const FLARE_ERROR_CODE_GENERAL_SET = 0100;

    var $_expire_time = null;

    public function __construct($time) {
        $this->_expire_time = $time;
    	return true;   
    }

     // Cache Life Time
    protected function getExpireTime() {
        if ($this->_expire_time) {
            return $this->_expire_time;
        }
        return self::NOTIFY_EXPIRE_TIME;
    }
    protected function getNameSpace() {
        return self::NOTIFY_NAMESPACE;
    }

    /**
     * set notification
     *
     * @param string $key
     * @param array  $val
     *
     * @return bool|array
     */
    public function setNotification($key, $val) {
        try {
            $ret = parent::set(self::NOTIFY_NAMESPACE . "_" . $key, $val);
        } catch (Exception $e) {
            // no action for exception
        }

        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }
 
    /**
     * get notification
     *
     * @param string $key
     *
     * @return bool|array
     */
    public function getNotification($key) {
        try {
            list($ret, $var) = parent::get(self::NOTIFY_NAMESPACE . "_" . $key);
        } catch (Exception $e) {
            if ($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                throw new Gree_Service_Shop_Exception("System Error(FLENT)", $code = parent::FLARE_EMERGENCY_ERROR);
            }
        }
        return $this->validateNotificationList($ret);
    }

    /**
     * customize notification list
     *
     * @param array  $notification_list
     *
     * @return bool|array
     */
    public function validateNotificationList($notification_list) {
    	if (empty($notification_list)) {
            return false;
        }
        $expire_time = $this->getExpireTime();
        foreach ($notification_list as $key => $notification){
            if(time() - $notification['created'] <= $expire_time){
                break;
            }
            unset($notification_list[$key]);
        }
    	return array_values($notification_list);
    }
}

?>