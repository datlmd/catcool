<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserInfo.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Raid_Marche_UserInfoDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'raid_marche_userinfo';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_raid';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_raid';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'group_id',
        'point',
        'status',
        'festival_status',
        'money',
        'quest_cnt',
        'festival_cnt',
        'login_cnt',
        'last_area_id',
        'last_shop_id',
        'last_minutes',
        'fever_time',
        'selected_friends',
        'wearable_items',
        'festival_wearable_items',
        'shop_select_items',
        'complete_time',
        'festival_next_date',
        'receive_reward_date',
        'last_login_date',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
        'count_all' => array(
            'sql' => 'SELECT count(user_id) as cnt FROM __TABLE_NAME__',
        ),
        'count_all_group_by_group_id' => array(
            'sql' => 'SELECT group_id, count(user_id) as cnt FROM __TABLE_NAME__ GROUP BY group_id',
        ),
        // {{{ �������������������
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, group_id, status, last_area_id, last_minutes, selected_friends, wearable_items, complete_time, last_login_date, ctime) VALUES(:user_id, :group_id, :status, :last_area_id, :last_minutes, :selected_friends, :wearable_items, :complete_time, :last_login_date, NOW())',
        ),
        'update_by_user_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status=:status, last_area_id=:last_area_id, last_minutes=:last_minutes, fever_time=:fever_time, selected_friends=:selected_friends, wearable_items=:wearable_items, complete_time=:complete_time WHERE user_id=:user_id',
        ),
        'update_by_for_quest_result' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status=:status, money=:money, quest_cnt=:quest_cnt, last_shop_id=:last_shop_id, fever_time=:fever_time, shop_select_items=:shop_select_items WHERE user_id=:user_id AND status=:current_status',
        ),
        'update_by_for_shop_result' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status=:status, money=:money WHERE user_id=:user_id AND status=:current_status',
        ),
        'update_only_status' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status=:status WHERE user_id=:user_id',
        ),
        'update_money_by_user_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET money=:money WHERE user_id=:user_id',
        ),
        // login
        'update_login_by_user_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET login_cnt=:login_cnt, last_login_date=:last_login_date WHERE user_id=:user_id',
        ),
        // daily group reward
        'update_money_for_daily_group_ranking' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET money=:money, receive_reward_date=:receive_reward_date WHERE user_id=:user_id',
        ),
        // festival
        'update_for_festival_commit' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET festival_status=:festival_status, festival_wearable_items=:festival_wearable_items, festival_next_date=:festival_next_date WHERE user_id=:user_id',
        ),
        'update_for_festival_result' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET festival_cnt=:festival_cnt, festival_status=:festival_status WHERE user_id=:user_id',
        ),

        // initilize
        'initialize_complete_time_by_user_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET complete_time = :date_time WHERE user_id=:user_id',
        ),
        'initialize_festival_next_date_by_user_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET festival_next_date = :date_time WHERE user_id=:user_id',
        ),
        
        // for support tool
        'update_for_simple_from_support_tool' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET complete_time=:complete_time, festival_next_date=:festival_next_date, receive_reward_date="0000-00-00 00\:00\:00" WHERE user_id=:user_id',
        ),
        'update_for_debug_from_support_tool' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET group_id=:group_id, status=:status, money=:money, quest_cnt=:quest_cnt, festival_cnt=:festival_cnt, login_cnt=:login_cnt, last_area_id=:last_area_id, last_shop_id=:last_shop_id, last_minutes=:last_minutes, selected_friends=:selected_friends, wearable_items=:wearable_items, festival_wearable_items=:festival_wearable_items, shop_select_items=:shop_select_items, complete_time=:complete_time, festival_next_date=:festival_next_date, receive_reward_date=:receive_reward_date, last_login_date=:last_login_date WHERE user_id=:user_id',
        ),
        // }}}
        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `user_id`               int(11) unsigned NOT NULL default '0',
                    `group_id`              int(11) unsigned NOT NULL default '0',
                    `point`                 int(11) unsigned NOT NULL default '0',
                    `status`                tinyint(4) unsigned NOT NULL default '0',
                    `festival_status`       tinyint(4) unsigned NOT NULL default '0',
                    `money`                 int(11) unsigned NOT NULL default '0',
                    `quest_cnt`             int(11) unsigned NOT NULL default '0',
                    `festival_cnt`          int(11) unsigned NOT NULL default '0',
                    `login_cnt`             int(11) unsigned NOT NULL default '1',
                    `last_area_id`          int(11) unsigned NOT NULL default '0',
                    `last_shop_id`          int(11) unsigned NOT NULL default '0',
                    `last_minutes`          int(11) unsigned NOT NULL default '0',
                    `fever_time`            int(11) unsigned NOT NULL default '0',
                    `selected_friends`          varchar(64) NOT NULL default '',
                    `wearable_items`            varchar(128) NOT NULL default '',
                    `festival_wearable_items`   varchar(128) NOT NULL default '',
                    `shop_select_items`         varchar(128) NOT NULL default '',
                    `complete_time`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `festival_next_date`        datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `receive_reward_date`       datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `last_login_date`           datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`user_id`),
                    KEY `user_id` (`user_id`, `status`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'truncate_table' => array(      // for batch
            'sql' => "TRUNCATE TABLE __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Raid_Marche_UserInfoSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserInfo.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Raid_Marche_UserInfoSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ TABLE_DIVIDE_NUM
    /* �ơ��֥�ʬ��� */
    const TABLE_DIVIDE_NUM = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%d";   // event_id, user_id
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['event_id']) || !isset($hint['user_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, $hint['event_id'], ($hint['user_id'] % self::TABLE_DIVIDE_NUM));

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
