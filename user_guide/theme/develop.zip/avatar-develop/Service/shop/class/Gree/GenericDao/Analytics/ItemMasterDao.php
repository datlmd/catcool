<?php
    require_once('AnalyticsDao.php');

    class Gree_GenericDao_Analytics_ItemMasterDao extends Gree_GenericDao_Analytics
    {
        /** #@+
         * @access private
         */

        /** @var テーブル名 */
        public $_table_name = 'item_master';
        /** @var 主キー。複合キーはarrayハッシュで指定する。 */
        public $_primary_key = 'gacha_id';
        /** @var 更新日カラム名 */
        public $_updated_at_column = null;
        /** @var 登録日カラム名 */
        public $_created_at_column = null;
        /** @var マスターデータベースの接続文字列 */
        public $_master_dsn = 'gree://master/avatar_analytics';
        /** @var 登録日カラム名 */
        public $_slave_dsn = 'gree://slave/avatar_analytics';
        /** @var オートインクリメント */
        public $_auto_increment = true;
        /** @var フィールド名 */
        public $_field_names = [
            'gahca_id',
            'item_id',
            'sex',
            'category',
            'rare_level',
            'attr',
            'name',
        ];
        /**
         * @var クエリ定義。
         */
        public $_queries = [
            // {{{ 更新系
            'create_table'     => [
                'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                      `gacha_id` int(10) unsigned NOT NULL,
                      `item_id` int(10) unsigned NOT NULL,
                      `sex` varchar(8) NOT NULL,
                      `category` int(8) unsigned NOT NULL,
                      `rare_level` tinyint(4) unsigned NOT NULL,
                      `attr` tinyint(4) NOT NULL,
                      `name` varchar(64) NOT NULL,
                      PRIMARY KEY (`gacha_id`),
                      UNIQUE KEY `unq_item_gacha_sex` (`gacha_id`,`item_id`,`sex`)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
            ],
            'all'              => [
                'sql' => 'SELECT * FROM __TABLE_NAME__',
            ],
            'find_by_gacha_id' => [
                'sql' => 'SELECT * FROM __TABLE_NAME__ where `gacha_id` = :gacha_id',
            ],
            'find_rare_id_by_gacha_id' => [
                'sql' => 'SELECT * FROM __TABLE_NAME__ where `gacha_id` = :gacha_id and `rare_level` > 0',
            ],
            'insert_master'    => [
                'sql' => 'INSERT INTO __TABLE_NAME__
                          (`gacha_id`, `item_id`, `sex`, `category`, `rare_level`, `attr`, `name`)
                          VALUES (:gacha_id, :item_id, :sex, :category, :rare_level, :attr, :name)
                          ON DUPLICATE KEY UPDATE 
                          `category` = VALUES (`category`),
                          `rare_level` = VALUES (`rare_level`), 
                          `attr` = VALUES (`attr`), 
                          `name` = VALUES (`name`)',
            ],
        ];
        /** #@- */
    }
