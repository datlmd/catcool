<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Quiz_InfoMasterDao extends Gree_GenericDao_Apc {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'quiz_info_master';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'quiz_id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_quiz';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_quiz';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
    var $_field_names = array(
                         'quiz_id',
                         'question',
                         'answer',
                         'answer_id',
                         'link_type',
                         'link1',
                         'link2',
                         'image_path',
                         'question_type',
                         'mtime',
                         'ctime'
                   );

	/** @var ������ */
	var $_queries = array(
        'all' => array(
            'sql' => "SELECT * from __TABLE_NAME__ ORDER BY quiz_id",
        ),
        'find_quiz_by_id' => array(
            'sql' => "SELECT * from __TABLE_NAME__ WHERE quiz_id = :quiz_id",
        ),
        'insert_quiz' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (question, answer, answer_id, link_type, link1, link2, image_path, question_type) VALUES (:question, :answer, :answer_id, :link_type, :link1, :link2, :image_path, :question_type)'
        ),
        'update_quiz' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET question = :question, answer = :answer, answer_id = :answer_id, link_type = :link_type, link1 = :link1, link2 = :link2, image_path = :image_path, question_type = :question_type WHERE quiz_id = :quiz_id'
        ),
        'delete_quiz' => array(
            'sql' => "DELETE from __TABLE_NAME__ WHERE quiz_id = :quiz_id",
        ),
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `quiz_id` int(10) unsigned NOT NULL auto_increment,
                    `question` varchar(255) NOT NULL default 'empty',
                    `answer` varchar(255) NOT NULL default 'empty',
                    `answer_id` tinyint(10) unsigned NOT NULL default '0',
                    `link_type` tinyint(10) unsigned NOT NULL default '0',
                    `link1` varchar(255) DEFAULT NULL,
                    `link2` varchar(255) DEFAULT NULL,
                    `image_path` varchar(255) DEFAULT NULL,
                    `question_type` tinyint(10) unsigned NOT NULL default '0',
                    `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY  (`quiz_id`)
                ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=ujis
            ",
        ),
	);

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
