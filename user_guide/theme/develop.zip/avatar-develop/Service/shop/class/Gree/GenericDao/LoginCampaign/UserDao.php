<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/LoginCampaign/User.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_LoginCampaign_UserDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'login_campaign_user';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'login_id',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'find_user_incentive_list_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` int(11) unsigned NOT NULL,
                `login_id` TINYINT(4) unsigned NOT NULL,
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                 UNIQUE KEY `user_id` (`user_id`, `login_id`)
             ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__
                         (user_id, login_id, ctime)
                      VALUES
                         (:user_id, :login_id, :ctime)
                     '
        ),
        'delete' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_LoginCampaign_UserFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Contest/UserFarmSelector.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: UserDao.php 142658 2011-12-21 05:21:25Z shingo-harada$
 */
class Gree_GenericDao_LoginCampaign_UserFarmSelector extends Gree_GenericDao_FarmSelector
{

    // {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%02d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['login_campaign_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        if (empty($hint['user_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $user_id = $hint['user_id'];
        $login_campaign_id = $hint['login_campaign_id'];
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }

        // �ơ��֥�̾�˥ե�������ɲ�
        $farm_no = (int)(((int)$user_id) % $this->_table_nums);
        if ($farm_no < 0) {
            return PEAR::raiseError("system error.");
        }

        $farm = sprintf($this->_table_suffix_format, $login_campaign_id, $farm_no);
        if (empty($farm)) {
            return PEAR::raiseError("farm is blank");
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}

}
