<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Battle/MasterAttrDao.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_Battle_MasterAttrDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'battle_master_attr';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_coorde_battle';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_coorde_battle';

    /** @var auto increment */
    var $_auto_increment = 'true';

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'battle_id',
        'name',
        'value',
        'mtime',
        'ctime',
    );

    /** @var ������ */
    var $_queries = array(
        'create_table' => array(
            'sql' => 
                "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `battle_id` int(10) unsigned NOT NULL default '0',
                    `name` varchar(255) NOT NULL,
                    `value` varchar(255) NOT NULL,
                    `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY  (`id`),
                    UNIQUE KEY `name` (`battle_id`,`name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis"
        ),
        'find_battle_master_attr_by_battle_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE battle_id = :battle_id'
        ),
        'find_battle_master_attr_by_battle_id_and_name' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE battle_id = :battle_id AND name = :name'
        ),
        'find_attr_value_by_battle_id_and_name' => array(
            'sql' => 'SELECT value FROM __TABLE_NAME__ WHERE battle_id = :battle_id AND name = :name'
        ),
        'insert_total_rank_count' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (battle_id, name, value) VALUES (:battle_id, :name, :value)'
        ),
        'delete_by_battle_id_and_name' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE battle_id = :battle_id AND name = :name'
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__"
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
