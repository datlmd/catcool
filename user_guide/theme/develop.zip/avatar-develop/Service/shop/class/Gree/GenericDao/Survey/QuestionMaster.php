<?php

class Gree_GenericDao_Survey_QuestionMasterDao extends Gree_GenericDao
{
    var $_table_name = 'customer_survey_questions';

    var $_primary_key = 'id';

    var $_master_dsn = 'gree://master/avatar_user';

    var $_slave_dsn  = 'gree://slave/avatar_user';

    var $_auto_increment = false;

    var $_field_names = [
        'id',
        'survey_id',
        'answer_type',
        'required',
        'section_id',
        'question_order',
        'question',
        'choices',
        'max_ans_num',
        'min_ans_num',
        'status',
        'mtime',
        'ctime',
    ];

    var $_queries = [

        //Refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE survey_id = :survey_id AND status = 1 ORDER BY section_id, question_order'
        ],
        'find_by_section' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE survey_id = :survey_id AND section_id = :section_id AND status = 1 ORDER BY question_order'
        ],
        'find_by_section_order' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE survey_id = :survey_id AND section_id = :section_id AND question_order = :question_order AND status = 1'
        ],
        'count_section' => [
            'sql' => 'SELECT max(section_id) FROM __TABLE_NAME__ WHERE survey_id = :survey_id'
        ],
        'count_order_by_section' => [
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE survey_id = :survey_id AND section_id = :section_id'
        ],

        //Update queries
        'update_status_order' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status, question_order = :after_order WHERE survey_id = :survey_id AND section_id = :section_id AND question_order = :question_order'
        ],
        'update_order' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET question_order = :new_question_order WHERE id = :id'
        ],

        'update_all' => [
            'sql' => '
            UPDATE __TABLE_NAME__ SET
                    answer_type    = :answer_type,
                    required       = :required,
                    section_id     = :section_id,
                    question_order = :question_order,
                    question       = :question,
                    choices        = :choices,
                    max_ans_num    = :max_ans_num,
                    min_ans_num    = :min_ans_num
                WHERE
                    survey_id = :survey_id AND section_id = :section_id AND question_order = :question_order
            ',
        ],

        //Insert query
        'insert' => [
            'sql' => "
            INSERT IGNORE INTO __TABLE_NAME__ (
                    survey_id,
                    answer_type,
                    required,
                    section_id,
                    question_order,
                    question,
                    choices,
                    max_ans_num,
                    min_ans_num,
                    ctime
                )
                VALUES(
                    :survey_id,
                    :answer_type,
                    :required,
                    :section_id,
                    :question_order,
                    :question,
                    :choices,
                    :max_ans_num,
                    :min_ans_num,
                    NOW()
                )
            ",
        ],

        //Create table query 
        'create' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `survey_id` int(10) UNSIGNED NOT NULL,
                `answer_type` tinyint(4) UNSIGNED NOT NULL,
                `required` tinyint(4) UNSIGNED NOT NULL,
                `section_id` int(10) UNSIGNED NOT NULL,
                `question_order` int(10) UNSIGNED NOT NULL,
                `question` varchar(255) NOT NULL,
                `choices` text NOT NULL,
                `max_ans_num` int(10) UNSIGNED NOT NULL,
                `min_ans_num` int(10) UNSIGNED NOT NULL,
                `status` tinyint(4) UNSIGNED NOT NULL DEFAULT 1,
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                KEY `survey_section_order_idx` (`survey_id`, `section_id`, `question_order`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
    ];

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
