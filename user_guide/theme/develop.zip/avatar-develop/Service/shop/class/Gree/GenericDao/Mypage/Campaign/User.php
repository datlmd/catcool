<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Gree_GenericDao_Shop_Mypage_Campaign_UserDao
 *
 * @author  Shingo Harada <shingo.harada@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Mypage_Campaign_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'avatar_mypage_campaign_user';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',
        'campaign_id', // �����ڡ���ID
        'check_count', // �����å���
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'get_check_count' => array(
            'sql' => 'SELECT check_count FROM __TABLE_NAME__ WHERE user_id = :user_id AND campaign_id = :campaign_id',
        ),
        'get_user_info' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND campaign_id = :campaign_id',
        ),
        // batch
        'get_user_count_by_check_count' => array(
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE check_count >= :check_count',
        ),
        // {{{ update queries
        'update_check_count' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__
                    (user_id, campaign_id, check_count, ctime)
                VALUES
                    (:user_id, :campaign_id, :check_count, NOW())
                ON DUPLICATE KEY UPDATE
                    check_count = check_count + :check_count
            ',
        ), 
        // {{{ update queries
        'create_user_record' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, campaign_id, check_count, redirect_flag, ctime)
                VALUES
                    (:user_id, :campaign_id, :check_count, :redirect_flag, NOW())
            ',
        ),
        'update_redirect_flag' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET redirect_flag = :redirect_flag, mtime = NOW() WHERE user_id = :user_id AND campaign_id = :campaign_id',
        ),
        // {{{ debug
        'reset_user_info' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id AND campaign_id = :campaign_id',
        ),
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` INT(11) unsigned NOT NULL,
                `campaign_id` TINYINT(4) unsigned NOT NULL,
                `check_count` INT(11) unsigned NOT NULL,
                `redirect_flag` TINYINT(4) unsigned NOT NULL,
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                 UNIQUE KEY `user_id` (`user_id`, `campaign_id`)
             ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ), 
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
