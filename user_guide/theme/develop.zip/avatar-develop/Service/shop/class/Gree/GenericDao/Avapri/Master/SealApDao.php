<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Avapri_Master_SealApDao extends Gree_GenericDao_Apc
{
	/** @var table name */
    var $_table_name = 'master_seal_ap';
	/** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = [
        'id',
        'name',
        'value_ap',
        'seal_number',
        'start_datetime',
        'end_datetime',
        'status',
        'ctime',
        'mtime'
    ];

    var $_queries = [
        'get_all_master' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ],
        'find_by_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        // update----------------------
        'update' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET name = :name, value_ap = :value_ap, seal_number = :seal_number, start_datetime = :start_datetime, end_datetime = :end_datetime, status = :status WHERE id = :id',
        ],
        // insert----------------------
        'insert' => [
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (name, value_ap, seal_number, start_datetime, end_datetime, status, ctime) VALUES (:name, :value_ap, :seal_number, :start_datetime, :end_datetime, :status, NOW())',
        ],
        // create table ----------------
        'create_table' => [
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int unsigned NOT NULL auto_increment,
                `name` varchar(255) NOT NULL default '',
                `value_ap` int unsigned NOT NULL default '0',
                `seal_number` int unsigned NOT NULL default '0',
                `start_datetime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `end_datetime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `status` TINYINT UNSIGNED NOT NULL DEFAULT '0',
                `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                PRIMARY KEY  (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
    ];
}

