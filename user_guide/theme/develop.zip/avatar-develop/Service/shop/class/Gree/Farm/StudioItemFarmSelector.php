<?php
/**
 *  @package GREE
 *	Gree_GenericDao_Shop_StudioItemFarmSelector
 *
 */
class Gree_GenericDao_Shop_StudioItemFarmSelector extends Gree_GenericDao_FarmSelector
{

	// {{{ _dsn_nums
	/** var int �ǡ����١���ʬ��� */
    var $_id_per_dsn = 10;  //2010/03/10 �ޥ���ʬ����б�
    var $_default_dsn = 1;  //default dsn number for support tool
    // }}}

    function getMasterDsn($dao, $type, $hint) {
        if (!empty($hint['farm_num'])) {
            $num = $hint['farm_num'];
        } else {
            return PEAR::raiseError('no number');
        }
		if (empty($num)) {
            return PEAR::raiseError('no number');
		}
		$dsn = $dao->_master_dsn . $num;
		return $dsn;
	}

    function getSlaveDsn($dao, $type, $hint) {
        $num = null;
        if (empty($hint['user_id'])) {
            $num = $this->_default_dsn;
        } else {
            $num = $this->_getDsnFarmNumber($hint);
        }
        if (empty($num)) {
            return PEAR::raiseError('no number');
		}
		$dsn = $dao->_slave_dsn . $num;
		return $dsn;
	}

	function _getDsnFarmNumber($hint) {
        $user_id = $hint['user_id'];
		$num = floor(($user_id % 100) / $this->_id_per_dsn) + 1;
		return $num;
	}
}
?>
