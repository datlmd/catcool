<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/PointDao.php
 *
 *  @author   Jun Tomioka <jun.tomioka@gree.net>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_PointDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var �ơ��֥�̾ */
    var $_table_name = 'point';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_analytics';

    /** @var ��Ͽ�������̾ */
    var $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'datetime',
        'service',
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'action',
        'increment',
        'decrement',
        'total',
        'is_tld_net',
        'is_app',
        'ctime',
    );

    /** @var namespace */
    var $_namespace = null;

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id              INT(10)         UNSIGNED NOT NULL AUTO_INCREMENT,
                    datetime        DATETIME        NOT NULL,
                    service         VARCHAR(16)     NOT NULL,
                    user_id         BIGINT(20)      UNSIGNED NOT NULL,
                    user_sex        TINYINT(4),
                    user_age        TINYINT(4),
                    phone_carrier   TINYINT(4),
                    action          VARCHAR(255),
                    increment       INT(11)         UNSIGNED NOT NULL,
                    decrement       INT(11)         UNSIGNED NOT NULL,
                    total           INT(11)         UNSIGNED NOT NULL,
                    is_tld_net      TINYINT(4)      UNSIGNED NOT NULL,
                    is_app          TINYINT(4)      UNSIGNED NOT NULL,
                    ctime           DATETIME        NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY  (id),
                    KEY (datetime),
                    KEY (service),
                    KEY (user_id),
                    KEY (user_sex),
                    KEY (user_age),
                    KEY (phone_carrier),
                    KEY (action),
                    KEY (increment),
                    KEY (decrement),
                    KEY (total),
                    KEY is_tld_net (is_tld_net),
                    KEY is_app (is_app)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        // }}}
        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ),
        'get_summary' => array(
            'sql' => '
                SELECT
                    user_id,
                    sum(increment) as increment_sum
                    sum(decrement) as decrement_sum
                FROM
                    __TABLE_NAME__
                GROUP BY
                    user_id
            '
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
    );
    /** #@- */
}
