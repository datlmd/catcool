<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Gree_GenericDao_AvapriMasterMaterialDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Master_MaterialDao extends Gree_GenericDao_Apc
{
	/** @var table name */
    var $_table_name = 'master_material';
	/** @var primary key */
    var $_primary_key = 'material_id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'material_id',
        'item_id',
        'type',
        'price',
        'state',
        'ctime',
        'mtime'
    );

    var $_queries = array(
        // select----------------------
        //'find_by_material_id' => array(
        //    'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE material_id = :material_id AND state=:state',
        //),
        'find_price_by_item_id' => array(
            'sql' => 'SELECT SUM(price) FROM __TABLE_NAME__ WHERE item_id IN (:item_ids) AND state IN (:state)',
            'disable_apc' => true,
        ),
        'find_by_type_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE type = :type AND state IN (:state) order by state desc, material_id desc',
        ),
        'find_by_type_and_state_free' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE type = :type AND state IN (:state) AND price = 0 order by state desc, material_id desc',
        ),
        'find_by_type_and_state_purchase' => array( // It does not use now. 
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE type = :type AND state = :state AND price > 0 order by material_id desc',
        ),
        'count_by_type_and_state_all' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE type = :type AND state IN (:state) AND price >= 0',
        ),
        'count_by_type_and_state_free' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE type = :type AND state IN (:state) AND price = 0',
        ),
        'count_by_type_and_state_purchase' => array( // It does not use now.
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE type = :type AND state = :state AND price >= 0',
        ),
        // support tool
        'get_all_master' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        // update----------------------
        'update_setting' => array( // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state, item_id = :item_id, type=:type, price = :price WHERE material_id =:material_id',
        ),
        // insert----------------------
        'insert_material' => array( // for support tool
                'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (item_id, type, price, state, ctime) VALUES (:item_id, :type, :price, :state, NOW())',
        ),  
        // create table ----------------
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
              `material_id` int(11) unsigned NOT NULL auto_increment,
              `item_id` int(11) unsigned NOT NULL,
              `type` tinyint(4) unsigned NOT NULL,
              `state` tinyint(4) unsigned NOT NULL default '0',
              `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
              `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
              `price` int(11) unsigned NOT NULL default '0',
              PRIMARY KEY  (`material_id`),
              UNIQUE KEY `item_id` (`item_id`),
              KEY `master_material_1` (`type`,`state`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );
}
?>
