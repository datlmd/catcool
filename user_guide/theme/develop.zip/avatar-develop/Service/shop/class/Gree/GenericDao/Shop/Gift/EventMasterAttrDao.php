<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Shop/Gift/EventMasterAttrDao.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Shop_Gift_EventMasterAttrDao extends Gree_GenericDao_Apc
{
    /** @var �ơ��֥�̾ */
    var $_table_name = 'gift_event_master_attr';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gift';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gift';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array('id', 'gift_shop_id', 'name', 'value', 'mtime', 'ctime',);

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(             // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_by_gift_shop_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `gift_shop_id` = :gift_shop_id ORDER BY `id` ASC',
        ),
        'find_by_gift_shop_id_and_name' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `gift_shop_id` = :gift_shop_id and `name` = :name',
        ),
        // }}}

        // {{{ �������������������
        'insert_on_update' => array(                // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (`gift_shop_id`, `name`, `value`, `ctime`) VALUES(:gift_shop_id, :name, :value, NOW()) ON DUPLICATE KEY UPDATE `value` = :value',
        ),
        'delete_by_gift_shop_id_and_name' => array( // for support tool
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE `gift_shop_id` = :gift_shop_id AND `name` = :name'
        ),
        // }}}

        // {{{ �ơ��֥����
        'create_table' => array(    // for batch
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(10) unsigned NOT NULL auto_increment,
                `gift_shop_id` INT(11) UNSIGNED NOT NULL default '0',
                `name` VARCHAR(255) NOT NULL DEFAULT '',
                `value` VARCHAR(255) NOT NULL DEFAULT '',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                UNIQUE KEY `gift_shop_id` (`gift_shop_id`,`name`)
            ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // {{{ show_table
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

}
