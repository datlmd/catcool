<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Event/Gacha/UserInfo.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Event_Gacha_UserInfoDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'event_gacha_user_info';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_event_count';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'event_gacha_id',
        'status',
        'life_user_item_id',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(

        // {{{ service
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
        'find_all_by_user_id_and_event_gacha_id_and_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND event_gacha_id = :event_gacha_id AND status=:status',
        ),
        'find_all_by_user_id_and_event_gacha_ids_and_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND event_gacha_id in (:event_gacha_id) AND status=:status',
        ),
        'count_all_by_user_id_and_event_gacha_id_and_status' => array(
            'sql' => 'SELECT event_gacha_id, count(user_id) as cnt FROM __TABLE_NAME__ WHERE user_id=:user_id AND event_gacha_id = :event_gacha_id AND status=:status',
        ),
        'count_all_by_user_id_and_event_gacha_ids_and_status' => array(
            'sql' => 'SELECT event_gacha_id, count(user_id) as cnt FROM __TABLE_NAME__ WHERE user_id=:user_id AND event_gacha_id in (:event_gacha_id) AND status=:status group by event_gacha_id',
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, event_gacha_id, status, ctime) VALUES(:user_id, :event_gacha_id, 0,  NOW())',
            
        ),
        'update_by_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status=:status, life_user_item_id=:life_user_item_id WHERE id=:id',
        ),
        // }}}
        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                int(11) unsigned NOT NULL auto_increment,
                    `user_id`           int(11) unsigned NOT NULL default '0',
                    `event_gacha_id`    int(11) unsigned NOT NULL default '0',
                    `status`            tinyint(4) unsigned NOT NULL default '0',
                    `life_user_item_id` int(11) unsigned NOT NULL default '0',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    KEY `user_id` (`user_id`, `event_gacha_id`, `status`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector() {
        $this->_farm_selector = new Gree_GenericDao_Event_Gacha_UserInfoSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Event/Gacha/UserInfo.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Event_Gacha_UserInfoSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ TABLE_DIVIDE_NUM
    /* �ơ��֥�ʬ��� */
    const TABLE_DIVIDE_NUM = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%02d";   // user_id
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || !isset($hint['user_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, ($hint['user_id'] % self::TABLE_DIVIDE_NUM));

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
