<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserLightFarmSelector.php';

/**
 * Gree_GenericDao_MaterialPoint_UserDao
 *
 * @package GREE
 */
class Gree_GenericDao_MaterialPoint_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'user_material_point';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_point';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_point';

    /** @var field names */
    var $_field_names       = array(
        'user_id',
        'value',
        'mtime',
        'ctime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        'get_point'               => array(
            'sql'   => 'SELECT value, mtime FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}
        // {{{ update queries
        'create'            => array(
            'sql'   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, value, ctime) VALUES (:user_id, :value, NOW())',
        ),
        'update'            => array(
            'sql'   => 'UPDATE __TABLE_NAME__ SET value = :value WHERE user_id = :user_id',
        ),
        'create_table'      => array(
            'sql'   => '
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                user_id     INT(11)     UNSIGNED NOT NULL,
                value       INT(11)     UNSIGNED NOT NULL,
                mtime       TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                ctime       DATETIME    NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                PRIMARY KEY (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table'        => array(
            'sql'   => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    /**
     * initialize farm selector
     */
    function _init()
    {
        parent::_init();
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
    // }}}
}
