<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Class Gree_GenericDao_Gacha_Fever_CountIncentiveDao
 */
class Gree_GenericDao_Gacha_Fever_CountIncentiveDao extends Gree_GenericDao_Apc
{

    /** @var �ơ��֥�̾ */
    public $_table_name = 'gacha_fever_count_incentive';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣 */
    public $_primary_key = 'id';

    /** @var �����������̾ */
    public $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    public $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    public $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    public $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �����ȥ��󥯥���� */
    public $_auto_increment = true;

    /** @var �ե������̾ */
    public $_field_names = [
        'id',
        'gacha_id',
        'count',
        'item_type',
        'item_id',
        'mtime',
        'ctime',
    ];

    /**
     * @var �����������
     */
    public $_queries = [
        // {{{ ������
        'create_table'     => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT NOT NULL AUTO_INCREMENT,
                `gacha_id` INT NOT NULL,
                `count` INT NOT NULL,
                `item_type` INT NOT NULL,
                `item_id` INT NOT NULL,
                `mtime` DATETIME NOT NULL default CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL default CURRENT_TIMESTAMP,
                PRIMARY KEY  (`id`),
                UNIQUE KEY `gacha_id_and_count` (`gacha_id`, `count`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ],
        'drop_table'       => [
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ],
        'insert'           => [
            'sql' => "INSERT INTO __TABLE_NAME__ (`gacha_id`, `count`, `item_type`, `item_id`) values (:gacha_id, :count, :item_type, :item_id)",
        ],
        'delete_incentive_count_by_gacha_id_and_count' => [
            'sql' => '
                DELETE FROM __TABLE_NAME__
                WHERE
                    `gacha_id` = :gacha_id
                    AND `count` = :count'
            ,
        ],
        'find_by_gacha_id' => [
            'sql' => 'SELECT * FROM `__TABLE_NAME__` WHERE `gacha_id` = :gacha_id ORDER BY `count`',
        ],


        'get_incentive_count_by_gacha_id_and_count' => [
            'sql' => '
                SELECT *
                FROM __TABLE_NAME__
                WHERE
                    `gacha_id` = :gacha_id
                    AND `count` = :count
            ',
        ],
    ];
}
