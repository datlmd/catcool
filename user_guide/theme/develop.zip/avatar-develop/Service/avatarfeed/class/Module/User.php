<?php

class Gree_Service_AvatarFeed_Module_User
    extends Gree_Service_AvatarFeed_Module_Base
{
    const DELETED_USER_NICKNAME = "該当するユーザーが見つかりません";
    const DELETED_USER_THUMB_SP = "http://img-mshop.gree.jp/img/common/041d17d905b80c58b275bc968102005d.jpg";
    const DELETED_USER_THUMB_FP = "http://img-mshop.gree.jp/img/common/4a82204efddc5378a47965575c905e7e.gif";

    private $_avatar_img_url_cache = array();

    public function appendUserInfo($entries, $all = false)
    {
        $stream_data = array();
        try {
            $user_ids = $this->_getUserIds($entries);
            $users_info = $this->_getUserInfo($user_ids, false);
            if ($all) {
                $stream_data = $this->_appendAll($entries, $users_info);
            } else {
                $stream_data = $this->_append($entries, $users_info);
            }
        } catch (Exception $e) {
            // failed to append user info
            // return $stream_data = array()
            // please check exception log
        }

        return $stream_data;
    }

    public function excludeHideScoreUser($score_list)
    {
        $srv_shop = getService('shop');
        $registry = $srv_shop->getRegistry();
        $exclude_score_user_lists = $registry->getArray('avatar_score_exclude_user_list');
        if (Config::get('state') == GREE_STATE_DEVELOPMENT) {
            $exclude_score_user_list = $exclude_score_user_lists['dev'];
        } else {
            $exclude_score_user_list = $exclude_score_user_lists['production'];
        }

        $excluded_score_list = array();
        unset($score_list['min']);
        foreach ($score_list as $user_id => $score) {
            $is_show_setting = $this->_isShowRecentCoordinateSetting($user_id);
            if (in_array($user_id, $exclude_score_user_list) || $is_show_setting == false) {
                continue;
            }

            $excluded_score_list[$user_id] = $score;
        }

        return $excluded_score_list;
    }

    public function appendScoreUserInfo($score_list, $is_check_following = true)
    {
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;
        $mod_avatar = self::getModule('Avatar');
        $mod_follow = self::getModule('Follow');

        $appended_score_list = array();
        $rank_number = 1;
        foreach ($score_list as $user_id => $score) {
            $user_info = $mod_user->selectByID($user_id);
            $second_image = Gree_Service_Shop_SecondUtil::getPreviewUrlIncludeSecond($user_id);
            if (!empty($second_image)) {
                $img_url = $second_image;
            } else {
                $img_url = $mod_avatar->getAvatarImgUrl($user_id, GREE_SERVICE_AVATARFEED_CHANGE_IMG_SIZE);
            }

            if ($is_check_following){
                $is_following = $mod_follow->getFollowingUser($user_id);
            } else {
                $is_following = false;
            }

            $is_top3 = false;
            if ($rank_number == 1 || $rank_number == 2 || $rank_number == 3){
                $is_top3 = true;
            }

            $appended_score_list[$rank_number] = array(
                'user_id'      => $user_id,
                'rank'         => $rank_number,
                'score'        => $score,
                'nick_name'    => $user_info['nick_name'],
                'img_url'      => $img_url,
                'is_following' => $is_following,
                'is_top3'      => $is_top3,
            );

            $rank_number++;
        }

        return $appended_score_list;
    }

    /*
     * return list = array(
     *      'rank',
     *      'user_id',
     *      'score',
     *      'nick_name',
     *      'img_url',
     *      'open_status',
     *      'is_exclude'
     * );
     *
     */
    public function appendScoreUserInfoAndSupportInfo($score_list)
    {
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;
        $mod_avatar = self::getModule('Avatar');

        $appended_score_list = array();
        $rank_number = 1;
        foreach ($score_list as $user_id => $score) {
            // get user info
            $user_info = $mod_user->selectByID($user_id);
            $second_image = Gree_Service_Shop_SecondUtil::getPreviewUrlIncludeSecond($user_id);
            if (!empty($second_image)) {
                $img_url = $second_image;
            } else {
                $img_url = $mod_avatar->getAvatarImgUrl($user_id, GREE_SERVICE_AVATARFEED_CHANGE_IMG_SIZE);
            }

            // check  exclude list
            $srv_shop = getService('shop');
            $registry = $srv_shop->getRegistry();
            $exclude_score_user_lists = $registry->getArray('avatar_score_exclude_user_list');
            if (Config::get('state') == GREE_STATE_DEVELOPMENT) {
                $exclude_score_user_list = $exclude_score_user_lists['dev'];
            } else {
                $exclude_score_user_list = $exclude_score_user_lists['production'];
            }

            $is_exclude_user  = false;
            if (in_array($user_id, $exclude_score_user_list)){
                $is_exclude_user  = true;
            }

            // check open status
            $is_show_setting = $this->_isShowRecentCoordinateSetting($user_id);

            $appended_score_list[$rank_number] = array(
                'user_id'         => $user_id,
                'rank'            => $rank_number,
                'score'           => $score,
                'nick_name'       => $user_info['nick_name'],
                'img_url'         => $img_url,
                'is_exclude'      => $is_exclude_user,
                'is_show_setting' => $is_show_setting
            );

            $rank_number++;
        }

        return $appended_score_list;
    }

    public function _getUserIds($entries)
    {
        $user_ids = array();

        foreach ($entries as $entry) {
            $sender_ids = array(
                $entry['content']['sender_id']
            );
            if (isset($entry['comment']['count']) && $entry['comment']['count'] > 0) {
                foreach ($entry['comment']['list'] as $comment) {
                    $sender_ids[] = $comment['content']['sender_id'];
                }
            }
            if (isset($entry['like']['count']) && $entry['like']['count'] > 0) {
                foreach ($entry['like']['sender_id'] as $like_sender_id) {
                    $sender_ids[] = $like_sender_id;
                }
            }
            if (isset($entry['content']['attr']['notification_user'])
                && !empty($entry['content']['attr']['notification_user'])
            ) {
                foreach ($entry['content']['attr']['notification_user'] as $notification_user) {
                    $sender_ids[] = $notification_user;
                }
            }
            if (isset($entry['content']['attr']['members'])) {
                $members = explode(',', $entry['content']['attr']['members']);
                foreach ($members as $member) {
                    $sender_ids[] = $member;
                }
            }

            $user_ids = array_merge($user_ids, $sender_ids);
        }
        $user_ids = array_unique($user_ids);

        return $user_ids;
    }

    public function _getUserInfo($user_ids, $with_thumbnail = true)
    {
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;

        $users_info = $mod_user->selectByIDs($user_ids, USER_STATUS_ALL);
        if ($users_info == false) {
            $users_info = array();
            foreach ($user_ids as $user_id) {
                $users_info[$user_id] = array(
                    'user_id' => $user_id,
                );
            }
        }

        if ($with_thumbnail == true) {
            // get thumbnail url
            $mod_avatar = self::getModule('Avatar');
            foreach ($users_info as $user_id => $user_info) {
                $thumbnail_url = $mod_avatar->getAvatarImgUrl($user_id, GREE_SERVICE_AVATARFEED_THUMBNAIL_SIZE);
                $users_info[$user_id]['thumbnail_url'] = $thumbnail_url;

            }
        }

        return $users_info;
    }

    private function _getAvatarImgUrl($user_id)
    {
        if (isset($this->_avatar_img_url_cache[$user_id])) {
            return $this->_avatar_img_url_cache[$user_id];
        }

        $mod_avatar = self::getModule('Avatar');
        $thumbnail_url = $mod_avatar->getAvatarImgUrl($user_id, GREE_SERVICE_AVATARFEED_THUMBNAIL_SIZE);

        $this->_avatar_img_url_cache[$user_id] = $thumbnail_url;

        return $thumbnail_url;
    }

    public function _append($entries, $users_info)
    {
        $append_entries = array();

        foreach ($entries as $index => $entry) {
            $is_exist_user = $this->_isExistUser($entry['content']['sender_id'], $users_info);
            if ($is_exist_user == false) {
                if (isset($entry['content']['text']) && $entry['content']['text'] == 'notification') {
                    $avatar_feed = Gree_Service_AvatarFeed::getInstance();
                    // 退会ユーザーからの通知は削除する
                    $notification_params = array(
                        'entry_id' => $entry['entry_id'],
                    );
                    $avatar_feed->process('notification_remove', $notification_params);
                    continue;
                } else if (isset($entry['content']['text']) && isset($entry['comment_id'])) {
                    // 退会ユーザーのコメントはダミーを入れる
                    $entry = $this->_replaceUserInfoWithDeletedInfo($entry);
                } else {
                    continue;
                }
            } else {
                $entry['content']['user_info']['nick_name'] = $users_info[$entry['content']['sender_id']]['nick_name'];
                $entry['content']['user_info']['thumbnail_url'] = $this->_getAvatarImgUrl($entry['content']['sender_id']);
            }

            $append_comment_list = array();
            // don't use recursive processing.
            if (isset($entry['comment']['count']) && $entry['comment']['count'] > 0) {
                foreach ($entry['comment']['list'] as $comment_index => $comment) {
                    $is_exist_user = $this->_isExistUser($comment['content']['sender_id'], $users_info);
                    if ($is_exist_user == false) {
                        // 退会ユーザーのコメントはダミーを入れる
                        $comment = $this->_replaceUserInfoWithDeletedInfo($comment);
                    } else {
                        $comment['content']['nick_name'] = $users_info[$comment['content']['sender_id']]['nick_name'];
                        $comment['content']['thumbnail_url'] = $this->_getAvatarImgUrl($comment['content']['sender_id']);
                    }

                    $append_comment_list[] = $comment;
                }
            }

            $entry['comment']['list'] = $append_comment_list;

            $append_like_list = array();
            if (isset($entry['like']['count']) && $entry['like']['count'] > 0) {
                foreach ($entry['like']['sender_id'] as $like_index => $like_sender_id) {
                    $is_exist_user = $this->_isExistUser($like_sender_id, $users_info);
                    if ($is_exist_user == false) {
                        continue;
                    }

                    $append_like_list[$like_index] = array(
                        'user_id'   => $like_sender_id,
                        'nick_name' => $users_info[$like_sender_id]['nick_name']
                    );

                    if (count($append_like_list) == 3) {
                        break;
                    }
                }
            }

            $entry['like']['list'] = $append_like_list;

            if (isset($entry['content']['attr']['notification_user'])
                && !empty($entry['content']['attr']['notification_user'])
            ) {
                $notification_user_id = array_shift($entry['content']['attr']['notification_user']);

                $is_exist_user = $this->_isExistUser($notification_user_id, $users_info);
                if ($is_exist_user == false) {
                    $avatar_feed = Gree_Service_AvatarFeed::getInstance();
                    // 退会ユーザーからの通知は削除する
                    $notification_params = array(
                        'entry_id' => $entry['entry_id'],
                    );
                    $avatar_feed->process('notification_remove', $notification_params);

                    continue;
                }

                $entry['content']['attr']['notification_user'] = $users_info[$notification_user_id]['nick_name'];
            }

            if (isset($entry['content']['attr']['members'])) {
                $avapri_member_list = array();
                $members = explode(',', $entry['content']['attr']['members']);
                foreach ($members as $member) {
                    $is_exist_user = $this->_isExistUser($member, $users_info);
                    if ($is_exist_user == false) {
                        continue;
                    }

                    $avapri_member_list[] = array(
                        'user_id' => $member,
                        'nick_name' => $users_info[$member]['nick_name'],
                    );
                }
                $entry['content']['attr']['members'] = $avapri_member_list;
            }

            $append_entries[] = $entry;
        }

        return $append_entries;
    }

    public function _appendAll($entries, $users_info)
    {
        $append_entries = array();

        foreach ($entries as $index => $entry) {
            $is_exist_user = $this->_isExistUser($entry['content']['sender_id'], $users_info);
            if ($is_exist_user == false) {
                $entry['content']['user_info']['nick_name'] = null;
                $entry['content']['user_info']['thumbnail_url'] = null;
            } else {
                $entry['content']['user_info']['nick_name'] = $users_info[$entry['content']['sender_id']]['nick_name'];
                $entry['content']['user_info']['thumbnail_url'] = $this->_getAvatarImgUrl($entry['content']['sender_id']);
            }

            $append_comment_list = array();
            // don't use recursive processing.
            if (isset($entry['comment']['count']) && $entry['comment']['count'] > 0) {
                foreach ($entry['comment']['list'] as $comment_index => $comment) {
                    $is_exist_user = $this->_isExistUser($comment['content']['sender_id'], $users_info);
                    if ($is_exist_user == false) {
                        $entry['content']['user_info']['nick_name'] = null;
                        $entry['content']['user_info']['thumbnail_url'] = null;
                    } else {
                        $entry['content']['user_info']['nick_name'] = $users_info[$entry['content']['sender_id']]['nick_name'];
                        $entry['content']['user_info']['thumbnail_url'] = $this->_getAvatarImgUrl($entry['content']['sender_id']);
                    }

                    $append_comment_list[] = $comment;
                }
            }

            $entry['comment']['list'] = $append_comment_list;

            $append_like_list = array();
            if (isset($entry['like']['count']) && $entry['like']['count'] > 0) {
                foreach ($entry['like']['sender_id'] as $like_index => $like_sender_id) {
                    $is_exist_user = $this->_isExistUser($like_sender_id, $users_info);
                    if ($is_exist_user == false) {
                        $append_like_list[$like_index] = array(
                            'user_id'   => null,
                            'nick_name' => $users_info[$like_sender_id]['nick_name']
                        );
                    } else {
                        $append_like_list[$like_index] = array(
                            'user_id'   => $like_sender_id,
                            'nick_name' => $users_info[$like_sender_id]['nick_name']
                        );
                    }

                    if (count($append_like_list) == 3) {
                        break;
                    }
                }
            }

            $entry['like']['list'] = $append_like_list;

            if (isset($entry['content']['attr']['notification_user'])
                && !empty($entry['content']['attr']['notification_user'])
            ) {
                $notification_user_id = array_shift($entry['content']['attr']['notification_user']);

                $is_exist_user = $this->_isExistUser($notification_user_id, $users_info);
                if ($is_exist_user == false) {
                    $entry['content']['attr']['notification_user'] = null;
                } else {
                    $entry['content']['attr']['notification_user'] = $users_info[$notification_user_id]['nick_name'];
                }
            }

            $append_entries[] = $entry;
        }

        return $append_entries;
    }


    public function _isExistUser($user_id, $user_info)
    {
        $is_exist = false;

        if (isset($user_info[$user_id]['nick_name']) && in_array($user_info[$user_id]['status'], array(USER_STATUS_ALIVE, USER_STATUS_STOP))) {
            $is_exist = true;
        }

        return $is_exist;
    }

    public function getCheckList($user_id)
    {
        $srv_shop = getService('shop');
        $mgr_mypage = $srv_shop->getMypageManager();

        $checks_info = $mgr_mypage->getWatchList($user_id);
        if (PEAR::isError($checks_info)) {
            return array();
        }
        if (empty($checks_info)) {
            return array();
        }

        $check_list = array();
        foreach ($checks_info as $check_info) {
            // if need check user_status, please check check_info['status'],
            $check_list[] = $check_info['watch_user_id'];
        }

        return $check_list;
    }

    public function getLinkList($user_id,
                                $offset = null,
                                $input_limit = 20)
    {
        $srv_sns = getService('sns');
        $mgr_friend = $srv_sns->getFriendManager();

        $has_more = false;
        $limit = $input_limit + 1;
        $links_info = $mgr_friend->getLinkHash($user_id, $offset, $limit);
        if (PEAR::isError($links_info)) {
            throw new Gree_Service_AvatarFeed_Exception(
                'Failed to get Link User',
                Gree_Service_AvatarFeed_Exception::E_DATA_NOT_FOUND,
                array(
                    $user_id,
                    $offset,
                    $limit
                )
            );
        }

        $has_more = $this->_getHasMore($limit, count($links_info));
        $link_list = $this->_getLinkList($links_info);

        /* if need more official info, use getMultiUserAttr
        $official_users_info = $srv_sns->getMultiUserAttr($link_list, 'official');
        if (is_array($official_users_info) && !empty($official_users_info)) {
            $link_list = $this->_deselectOfficialUser($link_list, $official_users_info);
        }
        */

        return array(
            $has_more,
            $link_list
        );
    }

    public function _getLinkList($links_info)
    {
        $link_list = array();
        foreach ($links_info as $link_info) {
            if ($link_info['t_user_type'] == 0) {
                $link_list[] = $link_info['t_user_id'];
            }
        }

        return $link_list;
    }

    public function _deselectOfficialUser($link_list, $official_users_info)
    {
        $link_list_unofficial = array();
        foreach ($link_list as $user_id) {
            if (array_key_exists($user_id, $official_users_info) == false) {
                $link_list_unofficial[] = $user_id;
            }
        }

        return $link_list_unofficial;
    }

    public function _getHasMore($limit, $result_count)
    {
        if ($limit == $result_count) {
            return true;
        } else {
            return false;
        }
    }

    public function _isShowRecentCoordinateSetting($user_id)
    {
        $srv_shop = getService('shop');
        $mgr_mypage = $srv_shop->getMypageManager();
        $mypage_data = $mgr_mypage->getUser($user_id);
        if ($mypage_data['open_status'] == GREE_SERVICE_SHOP_MYPAGE_OPEN_STATUS_TRUE) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * ユーザー情報を退会ユーザー用の情報に置き換えて返します
     *
     * @param $entry エントリー情報またはコメント情報
     *
     * @return array 退会ユーザー用の情報に置き換えた$entry
     */
    private function _replaceUserInfoWithDeletedInfo($entry)
    {
        $entry['content']['is_deleted_user'] = true;
        $entry['content']['text']            = '';
        $entry['content']['nick_name']       = defined('IS_MSHOP') ? mb_convert_encoding(self::DELETED_USER_NICKNAME, 'eucJP-win', 'UTF-8') : self::DELETED_USER_NICKNAME;
        $entry['content']['thumbnail_url']   = defined('IS_MSHOP') ? self::DELETED_USER_THUMB_FP : self::DELETED_USER_THUMB_SP;

        $entry['content']['user_info']['nick_name']     = $entry['content']['nick_name'];
        $entry['content']['user_info']['thumbnail_url'] = $entry['content']['thumbnail_url'];

        //余計な情報は削除する
        if (isset($entry['content']['attr'])) {
            unset($entry['content']['attr']);
        }

        return $entry;
    }

    /**
     * return user status for a user
     *
     *
     * @param $user_id
     * @return number user_status (0/7/8/9)
     */
    public function getUserStatus($user_id)
    {
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;

        $user_info = $mod_user->selectByID($user_id, USER_STATUS_ALL);
        if (!empty($user_info)) {
            return $user_info['status'];
        }

        return null;
    }
}
