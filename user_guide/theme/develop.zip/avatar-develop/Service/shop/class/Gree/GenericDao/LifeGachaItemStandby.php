<?php
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/LifeGachaItem.php';
class Gree_GenericDao_LifeGachaItemStandbyDao extends Gree_GenericDao_LifeGachaItemDao
{
    var $_slave_dsn = 'gree://standby/shop';
}
