<?php
/**
 * ItemMapper.php
 */
class Gree_Service_Shop_Data_Life_ItemMapper
    extends Gree_Service_Shop_Data_Mapper
{
    // ----[ Properties ]-------------------------------------------------------
    /**
     * @var primary key
     */
    protected $primary_key = 'id';

    // ----[ Override Methods ]-------------------------------------------------
    /**
     * load by primary key
     *
     * @override
     * @param   array
     * @return  array
     */
    protected function load($primary_key)
    {
        $life_service = getService('life');
        $item         = $life_service->getItem($primary_key);
        if (PEAR::isError($item)) {
            throw new Gree_Service_Shop_Exception($item->getMessage());
        }

        return $item;
    }

    /**
     * load by primary keys
     *
     * @override
     * @param   array
     * @return  array
     */
    protected function mload($primary_keys)
    {
        $life_service = getService('life');
        $items        = $life_service->findItemsByIds($primary_keys);
        if (PEAR::isError($items)) {
            throw new Gree_Service_Shop_Exception();
        }

        return $items;
    }
}
