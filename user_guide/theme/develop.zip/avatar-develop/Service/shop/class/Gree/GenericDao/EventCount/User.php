<?php
/**
 * Gree_GenericDao_EventCountUserDao
 * 
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

class Gree_GenericDao_EventCount_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'event_user_count';
    /** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
    /** @var updated at column */
    var $_updated_at_column = 'mtime';
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_event_count';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'event_id',
        'count',
        'ctime',
        'mtime'
    );

    var $_queries = array(
    // --select
        'find_by_user_id_and_event_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND event_id IN (:event_id)',
        ),
    // --insert & update
        'insert_user' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, event_id, count, ctime) VALUES (:user_id, :event_id, :count, NOW())',
        ),
        'insert_user_mtime' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, event_id, count, ctime, mtime) VALUES (:user_id, :event_id, :count, NOW(), :mtime)',
        ),

        'update_user_count_by_event_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET count = count + 1 WHERE user_id = :user_id AND event_id = :event_id',
        ),
        'update_user_count_and_mtime_by_event_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET count = count + 1, mtime = :mtime WHERE user_id = :user_id AND event_id = :event_id',
        ),
    // --delete for support tool
        'delete_user_by_user_id_and_event_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id AND event_id = :event_id',
        ),
    // --create table
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT(10) UNSIGNED NOT NULL,
                `event_id` INT(10) UNSIGNED NOT NULL,
                `count` INT(10) UNSIGNED NOT NULL DEFAULT '0',
                `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `user_and_event` (`user_id`, `event_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
    );


    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
