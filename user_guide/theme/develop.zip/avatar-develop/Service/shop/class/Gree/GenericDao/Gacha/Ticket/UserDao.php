<?php
// vim: foldmethod=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Ticket/User.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: UserDao.php 140764 2011-11-04 13:09:21Z ibuki $
 */
class Gree_GenericDao_Gacha_Ticket_UserDao extends Gree_GenericDao
{
	/** #@+
	 *  @access private
	 */ 

	/** @var �ơ��֥�̾ */
	var $_table_name = 'gacha_ticket_user';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �ե�����ɥ����̾ */
	var $_field_names = array(
		'id',
		'user_id',
		'type_id',
		'status',
		'ticket_master_id',
		'used_gacha_id',
		'life_user_item_id',
		'mtime',
		'ctime',
	);

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_gacha_ticket';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_gacha_ticket';

	/**
	 *	@var �����������
	 */
	var $_queries = array(
	    // {{{ ���ȷ�
		'find_by_user' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id ORDER BY id DESC',
        ),
		'find_by_user_type_status_master_id' => array(
		    'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND type_id=:type_id AND status=:status AND ticket_master_id=:ticket_master_id',
		),
        'find_by_user_type_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND type_id=:type_id AND status=:status',
        ),
		// }}}
        // {{{ support tool
        'count_user_id_by_used_gacha_id_and_mtime' => array(
            'sql' => 'SELECT user_id, count(id) as quantity FROM __TABLE_NAME__ WHERE used_gacha_id=:used_gacha_id AND mtime BETWEEN :from_date AND :to_date GROUP BY user_id',
        ),
        // }}
		// {{{ ������
		'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(11) unsigned NOT NULL auto_increment,
                `user_id` int(11) unsigned NOT NULL,
				`type_id` int(11) unsigned NOT NULL,
                `status` tinyint(2) NOT NULL default '0',
                `ticket_master_id` int(11) unsigned NOT NULL,
				`used_gacha_id` int(10) unsigned default NULL,
				`life_user_item_id` int(11) unsigned default NULL,
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                KEY `user_id_1` (`user_id`, `type_id`, `status`, `ticket_master_id`),
				KEY `user_id_2` (`user_id`, `used_gacha_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis"
        ),
        'insert_including_ctime' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__
                        (user_id, type_id, status, ticket_master_id, used_gacha_id, life_user_item_id, ctime)
                      VALUES
                        (:user_id, :type_id, :status, :ticket_master_id, :used_gacha_id, :life_user_item_id, :ctime)
                      ',
        ),
        'delete' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
	);

	/** #@- */

	// {{{ _initFarmSelector
	// �ե����ॻ�쥯���ν����
	//  @access private
	function _initFarmSelector()
	{
		$this->_farm_selector = new Gree_GenericDao_Gacha_Ticket_UserFarmSelector();
	}
	// }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Ticket/UserFarmSelector.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: UserDao.php 140764 2011-11-04 13:09:21Z ibuki $
 */
class Gree_GenericDao_Gacha_Ticket_UserFarmSelector extends Gree_GenericDao_FarmSelector
{

	// {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 100;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%02d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['user_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
		$user_id = $hint['user_id'];

        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is emptry. dao=" . get_class($dao) . "];");
        }

        // �ơ��֥�̾�˥ե�������ɲ�
		$farm_no = (int)(((int)$user_id) % $this->_table_nums);
        $farm = sprintf($this->_table_suffix_format, $farm_no);
        if (empty($farm)) {
            return PEAR::raiseError("farm is blank. user_id=" . $user_id);
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
