<?php
/**
 *  /home/gree/service/shop/class/GenericDao/GeneralCampaign/Entry.php
 *
 *  @author   Norie Matsuda <norie.matsuda@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_GeneralCampaign_EntryDao extends Gree_GenericDao {
    var $_table_name = 'general_campaign_entry';
    var $_primary_key = 'user_id';
    var $_updated_at_column = 'mtime';
    var $_created_at_column = 'ctime';
    var $_master_dsn = 'gree://master/shop';
    var $_slave_dsn = 'gree://slave/shop';
    var $_auto_increment = false;
    var $_field_names = array(
        'user_id',
        'mtime',
        'ctime'
    );
      
    /** @var Query */
    var $_queries = array(
        // {{{ select
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        // }}}
        // {{{ update / insert 
        'insert_master' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, ctime) VALUES (:user_id, now())'
        ),
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` int(10) UNSIGNED NOT NULL default 0,
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                PRIMARY KEY(`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis"
        ),
        // }}}
    );
    // {{{ _initFarmSelector()
    function _initFarmSelector() {
        $this->_farm_selector = new Gree_GenericDao_GeneralCampaign_EntrySelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/GeneralCampaign/Entry.php
 *
 *  @author   norie.matsuda
 *  @package  GREE
 */
class Gree_GenericDao_GeneralCampaign_EntrySelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%d";   // campaign_id

    // {{{ getTableName
    function getTableName($dao, $type, $hint)
    {
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['campaign_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, $hint['campaign_id']);
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
