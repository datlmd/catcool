<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/EventCount/FpApCampaignMaster.php
 *
 * @author      Thien Nguyen <z.thanhthien.nguyen@gree.net>
 * @package     GREE Avatar
 * @since       2015-08-27
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * FpApCampaignMaster form constructor
 * @access      public
 */
class Gree_GenericDao_EventCount_FpApCampaignMasterDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'fp_ap_campaign_master';

    /** @var primary key */
    var $_primary_key = 'ap_campaign_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_event_count';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var field names */
    var $_field_names = array(
        'ap_campaign_id',
        'start_datetime',
        'end_datetime',
        'announce_name',
        'point',
        'bonus_point',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY ap_campaign_id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE ap_campaign_id = :ap_campaign_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (start_datetime, end_datetime, announce_name, point, bonus_point, ctime) VALUES (:start_datetime, :end_datetime, :announce_name, :point, :bonus_point, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET start_datetime = :start_datetime, end_datetime = :end_datetime, announce_name = :announce_name, point = :point, bonus_point = :bonus_point WHERE ap_campaign_id = :ap_campaign_id',
        ),
        'create_table'           => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `ap_campaign_id`      INT(10)     UNSIGNED NOT NULL AUTO_INCREMENT,
                  `start_datetime`      DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `end_datetime`        DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `announce_name`       VARCHAR(50) NOT NULL,
                  `point`               SMALLINT(5) UNSIGNED NOT NULL DEFAULT "0",
                  `bonus_point`         SMALLINT(5) UNSIGNED NOT NULL DEFAULT "0",
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`ap_campaign_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis COLLATE=ujis_bin;'
        ),
        // }}}
    );
}
