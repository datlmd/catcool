<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/MarketFarmSelector.php';

/**
 * Gree_GenericDao_Market_Bid
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_BidDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'market_bid';

    /** @var primary key */
    var $_primary_key       = array('user_id', 'item_id');

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'user_id',
        'item_id',
        'point',
        'state',
        'counter',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        'find_by_user' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_user_item' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND item_id = :item_id',
        ),
        'find_by_item_point' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = :item_id AND point = :point',
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'get_summary' => array(     // for batch
            'sql' => 'SELECT item_id, point, COUNT(*) as counter FROM __TABLE_NAME__ GROUP BY item_id, point',
        ),
        'get_summary_by_item' => array(
            'sql' => 'SELECT point, count(*) as counter FROM __TABLE_NAME__ WHERE item_id = :item_id Group by point',
        ),
        'find_by_state' => array(   // for batch
            'sql' => 'SELECT user_id, item_id FROM __TABLE_NAME__ WHERE state = :state',
        ),
        'get_all_user_id_and_state' => array(   // for batch
            'sql' => 'SELECT user_id, state FROM __TABLE_NAME__ GROUP BY user_id, state',
        ),
        
        // {{{ refer queries
        'get_item_count' => array(  // for batch
            'sql' => 'SELECT item_id, count(item_id) as count FROM __TABLE_NAME__ Group by item_id',
        ),
        // }}}
        
        // }}}
        // {{{ summary (support tool only)
        'get_uu' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM (SELECT DISTINCT(user_id) FROM __TABLE_NAME__) AS t',
        ),
        'get_uu_by_state' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM (SELECT DISTINCT(user_id) FROM __TABLE_NAME__ WHERE state = :state) AS t',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, item_id, point, state, counter, ctime) VALUES (:user_id, :item_id, :point, :default_state, :counter, NOW())',
        ),
        'update_state' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state WHERE user_id = :user_id AND item_id = :item_id',
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET point = :point, counter = :counter WHERE user_id = :user_id AND item_id = :item_id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    user_id         INT(11)     UNSIGNED NOT NULL,
                    item_id         INT(11)     UNSIGNED NOT NULL,
                    point           INT(11)     UNSIGNED NOT NULL,
                    state           TINYINT(4)  UNSIGNED NOT NULL,
                    counter         TINYINT(4)  UNSIGNED NOT NULL,
                    ctime           DATETIME    NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime           TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, item_id),
                    KEY item_point (item_id, point),
                    KEY state (state)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_MarketFarmSelector();
    }
}
