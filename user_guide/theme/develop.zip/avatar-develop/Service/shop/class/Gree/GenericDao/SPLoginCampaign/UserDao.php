<?php
/**
 *  /home/gree/service/shop/class/GenericDao/SPLoginCampaign/User.php
 *
 *  @author   Masayoshi Yoshino <masayoshi.yoshino@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_SPLoginCampaign_UserDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'sp_logincampaign_user';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'first_login_date';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'login_count',
        'first_login_date',
        'last_update_date',
        'mtime',
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` int(11) unsigned NOT NULL,
                `login_count` TINYINT(4) unsigned DEFAULT 1,
                `first_login_date` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `last_update_date` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                 UNIQUE KEY `user_id` (`user_id`)
             ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, first_login_date, last_update_date) VALUES (:user_id, :first_login_date, :last_update_date)'
        ),
        'update_count' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET login_count = login_count + 1, last_update_date = :last_update_date WHERE user_id = :user_id'
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_SPLoginCampaign_UserFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_SPLoginCampaign_UserFarmSelector extends Gree_GenericDao_FarmSelector
{

    // {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%02d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['user_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $user_id = $hint['user_id'];
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }

        // �ơ��֥�̾�˥ե�������ɲ�
        $farm_no = (int)(((int)$user_id) % $this->_table_nums);
        if ($farm_no < 0) {
            return PEAR::raiseError("system error.");
        }

        $farm = sprintf($this->_table_suffix_format, $farm_no);
        if (empty($farm)) {
            return PEAR::raiseError("farm is blank");
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}

}
