<?php
/**
 * Service/shop/class/Gree/Data/User/Contest.php
 *
 * @author  Yuta Araki <yuta.araki@gree.net>
 * @package GREE
 */

require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Contest/CategoryDao.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Contest/SettingDao.php';

/**
 * Gree_Service_Shop_Data_User_Contest
 *
 * @package GREE
 * @access  public
 */
class Gree_Service_Shop_Data_Contest
    extends Gree_Service_Shop_Data_Abstract
{
    /** ---- [ Properties ] -------------------------------- */
    /**
     * @var $_format        defines default property
     * @var $_life_service  class wide reference to life service object
     * @var $_closet_state  holds current closet state
     * @var $_closet        closet array object, format defined in _createCloset()
     * @var $_logger        class wide reference to statistic logger object
     */
    protected $_format = array(
        'user_id',
        'user_sex',
        'nick_name',
        "contest_id",
        "status",
        "name",
        "open_datetime",
        "close_datetime",
        "vote_open_datetime",
        "vote_close_datetime",
        "vote_limit_change_count",
        "vote_limit_change_open_datetime",
        "vote_limit_change_close_datetime",
        "invite_limit_count",
        "invite_vote_increase_amount",
        "invite_open_datetime",
        "invite_close_datetime",
        "secret_open_datetime",
        "mtime",
        "ctime",
        "_dao_name"
    );

    protected $_session = null;
    // }}}
    // {{{ $_service
    protected $_life_service = null;
    protected $_shop_service = null;
    // }}}

    // {{{ $_dao_name_category
    private $_dao_name_category = "Contest_Category";
    // }}}
    private $_dao_name_info_master = "Contest_InfoMaster";

    // {{{ $_dao_name_setting
    private $_dao_name_setting = "Contest_Setting";
    // }}}

    protected $_logger = null;
    protected $_log = null;
    protected $_status = null;

    private $_contest_master_keys = array("contest_id", "status", "name",
                                          "open_datetime", "close_datetime",
                                          "vote_open_datetime", "vote_close_datetime",
                                          "vote_limit_change_count", "vote_limit_change_open_datetime",
                                          "vote_limit_change_close_datetime", "invite_limit_count",
                                          "invite_vote_increase_amount", "invite_open_datetime",
                                          "invite_close_datetime", "secret_open_datetime"
    );


    /**
     * Constructor for Gree_Service_Shop_Data_User_Closet
     * initialize accessor, life service and logger, retrieve contest master
     *
     * @param $accessor
     */
    public function __construct($accessor) {
        parent::__construct($accessor);
        $this->_life_service = getService('life');
        $this->_shop_service = getService('shop');
        $this->_logger       = $this->_life_service->getStatisticsLogger();
        $this->_log          = getService('shop')->_log;
        $this->_session      = Gree_GenericDao_SessionFactory::openSession();
    }



    /** ---- [ Public Methods ] -------------------------------- */
    /** ---- [ States ] ---------------------------------------- */

    /**
     * isContestReleased
     * Checks whether the contest master has been enabled
     * @return bool
     */
    public function isContestReleased() {
        if ($this->_status == GREE_SERVICE_SHOP_AVATAR_CONTEST_MASTER_STATUS_RELEASED) {
            return true;
        }

        return false;
    }

    /**
     * isContestOpen
     * Checks if contest is in open state
     * @return bool
     */
    public function isContestOpen() {
        if ($this->state != GREE_SERVICE_SHOP_CONTEST_STATE_CLOSED && $this->state != GREE_SERVICE_SHOP_CONTEST_STATE_DONE) {
            return true;
        }

        return false;
    }

    /**
     * isContestAcceptingEntry
     * Checks if contest is accepting entry.
     * Entry only period and vote period.
     * @return bool
     */
    public function isContestAcceptingEntry() {
        if ($this->state == GREE_SERVICE_SHOP_CONTEST_STATE_ENTRY_ONLY
            || $this->state == GREE_SERVICE_SHOP_CONTEST_STATE_ACTIVE_VOTE
        ) {
            return true;
        }

        return false;
    }

    /**
     * isContestAcceptingVote
     * Checks if contest is accepting vote
     * @return bool
     */
    public function isContestAcceptingVote() {
        if ($this->state == GREE_SERVICE_SHOP_CONTEST_STATE_ACTIVE_VOTE) {
            return true;
        }

        return false;
    }

    /**
     * isContestPresentRetrievable
     * Checks if user can get presents
     * @return bool
     */
    public function isContestPresentRetrievable() {
        return $this->isContestOpen();
    }

    /**
     * isContestPresentOnlyPeriod
     * Checks if contest is in present only period
     * @return bool
     */
    public function isContestPresentOnlyPeriod() {
        if ($this->state == GREE_SERVICE_SHOP_CONTEST_STATE_PRESENT_ONLY) {
            return true;
        }

        return false;
    }

    /**
     * isContestEntryOnlyPeriod
     * Checks if contest is in entry only period
     * @return bool
     */
    public function isContestEntryOnlyPeriod() {
        if ($this->state == GREE_SERVICE_SHOP_CONTEST_STATE_ENTRY_ONLY) {
            return true;
        }

        return false;
    }

    /**
     * isContestDone
     * Checks if contest is done.
     * True if all the contest related dates are time of past.
     * @return bool
     */
    public function isContestDone() {
        if ($this->state == GREE_SERVICE_SHOP_CONTEST_STATE_DONE) {
            return true;
        }

        return false;
    }

    /**
     * getCategoryIdBySex
     * 
     * Calculates category id based on given gender param
     * @param $user_sex
     *
     * @return int
     */
    public function getCategoryIdBySex($user_sex) {
        if (!in_array($user_sex, array(LIFE_ITEM_SEX_MALE, LIFE_ITEM_SEX_FEMALE))){
            throw new Gree_Service_Shop_Exception_DataException("Invalid gender specified");
        }
        return (int)$this->contest_id * 2 - abs(2 - (int)$user_sex);
    }

    /**
     * getOtherCategoryId
     * Calculates other category id based on given category id
     * @param $category_id
     *
     * @return mixed
     */
    public function getOtherCategoryId($category_id) {
        if (abs((int)$this->contest_id * 2 - $category_id)) {
            return $this->current_category_id + 1;
        } else {
            return $this->current_category_id - 1;
        }
    }

    /**
     * getSexFromCategoryId
     * Get user_sex from category id
     * @param $category_id
     *
     * @return int
     */
    public function getSexFromCategoryId($category_id) {
        $user_sex = $category_id % 2;

        return $user_sex;
    }


    /** ---- [ Protected Methods ] -------------------------------- */
    /**
     * _validateContestMaster
     * Checks to see all the required fields are filled.
     * 
     * @param $master contest master array
     *
     * @return bool
     */
    protected function _validateContestMaster($master) {
        foreach ($this->_contest_master_keys as $key) {
            if (array_key_exists($key, $master)) {
                if (strpos($key, "datetime") > -1) {
                    if (!strtotime($master[$key])) {
                        return false;
                    }
                    ;
                }
            } else {
                if (is_null($master[$key])) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * _getItemFromList
     * 
     * @param $ids
     * @param $item_info
     *
     * @return array
     */
    private function _getItemFromList($ids, $item_info) {
        $items = array();
        foreach ($ids as $id) {
            $items[] = $item_info[$id];
        }

        return $items;
    }

    /** ---- [ Getter Methods ] -------------------------------- */
    /**
     * contest_id           : Contest id
     * master           : Newest Contest Master
     * raw_attributes      : Contest attributes, as is.
     * attributes         : Contest attributes with other gender filtered out
     * state                : Current state of contest
     * current_time         : AVATAR_TIME
     * other_sex            : Other gender
     * current_category_id  : Current category_id
     * other_category_id    : Other category_id
     * categories           : Category data
     * current_category     : Current category data
     * other_category       : Other category data
     * incentive_ids        : List of incentive item ids
     * incentive_list       : Comprehensive structured array of incentive items
     * 
     */

    /**
     * __readContestId
     * Get contest id
     * @return int
     */
    protected function __readContestId() {
        return $this->master['contest_id'];
    }

    /**
     * __readMaster
     * Get contest master array
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function __readMaster() {
        $list = $this->_session->toArray($this->_dao_name_info_master, 'all', null);
        if (PEAR::isError($list)) {
            return $list;
        } elseif (empty($list)) {
            throw new Gree_Service_Shop_Exception_DataException('Invalid Data (Contest)', $code = "001");
        }
        $active_list = array();
        foreach ($list as $v) {
            if ($v['status'] == GREE_SERVICE_SHOP_AVATAR_CONTEST_MASTER_STATUS_RELEASED) {
                $active_list[] = $v;
            }
        }

        if ((Config::get('state') == "staging" || Config::get('state') == 'dev')) {
            if (count($list) === 0) {
                throw new Gree_Service_Shop_Exception_DataException('Invalid Data (Contest)', $code = "003");
            }
            $contest_mater         = $list[0];
            if (!$this->_validateContestMaster($contest_mater)) {
                throw new Gree_Service_Shop_Exception_DataException("Invalid contest master format.");
            }
            $this->_status = GREE_SERVICE_SHOP_AVATAR_CONTEST_MASTER_STATUS_RELEASED;
        } else if (!isset($active_list[0])) {
            throw new Gree_Service_Shop_Exception_DataException('Invalid Data (Contest)', $code = "002");
        } else if (isset($active_list[0])) {
            if (count($active_list) > 1) {
                throw new Gree_Service_Shop_Exception_DataException('Multiple active contest.');
            }
            $contest_mater         = $list[0];
            $this->_status = $list[0]['status'];
            if (!$this->_validateContestMaster($contest_mater)) {
                throw new Gree_Service_Shop_Exception_DataException("Invalid contest master format.");
            }
        }
        return $contest_mater;
    }

    /**
     * __readRawAttributes
     * Get raw contest attributes with all the keys
     * @return array
     */
    protected function __readRawAttributes() {
        $contest_attrs = $this->_shop_service->getContestAttrManager();

        return $contest_attrs->getContestMasterAttrAllAsArray($this->contest_id);
    }

    /**
     * __readAttributes
     * Get contest attributes with gender based keys with other gender key removed.
     * i.e. keys startswith 1_ or 2_
     * @return array
     */
    protected function __readAttributes() {
        function startsWith($haystack, $needle) {
            return strpos($haystack, $needle, 0) === 0;
        }

        $attributes           = $this->raw_attributes;
        $formatted_attributes = array();
        //Filter male/female attrs
        foreach ($attributes as $key => $value) {
            if (startsWith($key, "{$this->user_sex}_")) {
                $formatted_attributes[substr($key, 2)] = $value;
            } elseif (startsWith($key, "{$this->other_sex}_")) {
                continue;
            } else {
                $formatted_attributes[$key] = $value;

            }
        }

        return $formatted_attributes;
    }

    /**
     * __readState
     * check contest state
     *
     * @return int current state
     */
    protected function __readState() {
        if (isset($this->_status) === false) {
            return GREE_SERVICE_SHOP_CONTEST_STATE_CLOSED;
        }
        if ($this->_status == GREE_SERVICE_SHOP_AVATAR_CONTEST_MASTER_STATUS_CLOSED) {
            return GREE_SERVICE_SHOP_CONTEST_STATE_CLOSED;
        }
        //Current datetime is smaller than open_datetime or large than close_datetime, thus this contest is closed
        if ($this->current_time >= strtotime($this->master['close_datetime'])) {
            return GREE_SERVICE_SHOP_CONTEST_STATE_DONE;
        }

        //Current datetime is smaller than open_datetime or large than close_datetime, thus this contest is closed
        if ($this->current_time < strtotime($this->master['open_datetime'])
            || strtotime($this->master['close_datetime']) < $this->current_time
        ) {
            return GREE_SERVICE_SHOP_CONTEST_STATE_CLOSED;
        }

        //Current datetime is after vote close_date but before close_datetime, meaning it's open for present retrieval.
        if ($this->current_time >= strtotime($this->master['vote_close_datetime'])
            && $this->current_time < strtotime($this->master['close_datetime'])
        ) {
            return GREE_SERVICE_SHOP_CONTEST_STATE_PRESENT_ONLY;
        }
        //Current datetime is between vote_[open/close]_datetime, thus it's time for vote
        if ($this->current_time >= strtotime($this->master['vote_open_datetime'])
            && $this->current_time < strtotime($this->master['vote_close_datetime'])
        ) {
            return GREE_SERVICE_SHOP_CONTEST_STATE_ACTIVE_VOTE;
        }
        //Current datetime is between vote_open_datetime and open_datetime, which means it's in entry period.
        if ($this->current_time >= strtotime($this->master['open_datetime'])
            && $this->current_time < strtotime($this->master['vote_open_datetime'])
        ) {
            return GREE_SERVICE_SHOP_CONTEST_STATE_ENTRY_ONLY;
        }

        return GREE_SERVICE_SHOP_CONTEST_STATE_CLOSED;
    }

    /**
     * __readCurrentTime
     * proxy to AVATAR_TIME
     * pre strtotime'd.
     * @return int unix time (time since epoch)
     */
    protected function __readCurrentTime() {
        return strtotime($this->_shop_service->getDate());
    }

    /**
     * __readOtherSex
     * Gets opposite gender from current one
     * @return mixed
     */
    protected function __readOtherSex() {
        if ($this->user_sex == LIFE_ITEM_SEX_MALE) {
            return LIFE_ITEM_SEX_FEMALE;
        } else {
            return LIFE_ITEM_SEX_MALE;
        }
    }

    /**
     * __readCurrentCategoryId
     * Gets current category id
     * @return int category id
     */
    protected function __readCurrentCategoryId() {
        if (!in_array($this->user_sex, array(LIFE_ITEM_SEX_MALE, LIFE_ITEM_SEX_FEMALE))){
            return (int)$this->contest_id * 2 - (2 - LIFE_ITEM_SEX_MALE);
        }else {
            return (int)$this->contest_id * 2 - (2 - (int)$this->user_sex);
        }
    }

    /**
     * __readOtherCategoryId
     * Gets other category id
     * @return int category id
     */
    protected function __readOtherCategoryId() {
        if (abs((int)$this->contest_id * 2 - $this->current_category_id)) {
            return $this->current_category_id + 1;
        } else {
            return $this->current_category_id - 1;
        }
    }

    /**
     * __readCategories
     * Gets category info related to this contest
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function __readCategories() {
        $categories = $this->_session->toArray(
            $this->_dao_name_category,
            'find_by_contest_id',
            array('contest_id' => $this->contest_id)
        );
        if (PEAR::isError($categories) || empty($categories)) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [ContestCategory]", $code = "001");
        }
        $categories_keyed = array();
        foreach ($categories as $cat) {
            $categories_keyed[$cat['id']] = $cat;
        }
        if (count($categories_keyed) == 2) {
            $formatted_categories = $categories_keyed;
        } else {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [ContestCategory]", $code = "002");
        }

        return $formatted_categories;
    }

    /**
     * __readCurrentCategory
     * Gets category info for current category
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function __readCurrentCategory() {
        if (isset($this->categories[$this->current_category_id])) {
            return $this->categories[$this->current_category_id];
        };
        throw new Gree_Service_Shop_Exception_DataException("Category not defined");
    }

    /**
     * __readOtherCategory
     * Gets category info for other category
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     */
    protected function __readOtherCategory() {
        if (isset($this->categories[$this->other_category_id])) {
            return $this->categories[$this->other_category_id];
        };
        throw new Gree_Service_Shop_Exception_DataException("Category not defined");
    }

    /**
     * __readIncentiveIds
     * Gets array of item ids used for incentive
     * @return array
     */
    public function __readIncentiveIds() {
        $item_ids = array();
        foreach ($this->raw_attributes as $key => $value) {
            if (strpos($key, "_point_incentives") > 0) {
                $item_ids = array_merge($item_ids, explode(",", $value));
            }
        }
        $item_list = array_values(array_unique($item_ids));

        return $item_list;
    }

    /**
     * __readIncentiveList
     * Gets comprehensive structured data for incentive items with user's possession status
     * @return array
     * @throws Gree_Service_Shop_Exception_DataException
     */
    public function __readIncentiveList() {
        $item_ids = $this->incentive_ids;

        $incentive_nums = explode(',', $this->attributes['incentive_nums']);
        //        $other_sex      = 2-abs(1-(int)$this->user_sex);

        $secret_items = explode(',', $this->attributes['is_secret']);
        $is_secret    = false;
        if ($this->current_time <= strtotime($this->master['secret_open_datetime'])) {
            $is_secret = true;
        }
        // �����ƥ॰�롼�פμ���
        $group_list = $this->_life_service->findGroupsBySexAndBodyType($this->user_sex, LIFE_BODY_AVATAR);
        $groups     = array();
        foreach ($group_list as $row) {
            $groups[$row['code']] = $row['name'];
        }

        $item_list = $this->_life_service->findItemsByIds($item_ids);
        $item_info = array();
        foreach ($item_list as $value) {
            $item_info[$value['id']] = $value;
        }
        $obtained_items    = $this->_life_service->findAllUserItemsByUserAndItems($this->user_id, $item_ids);
        $obtained_items_id = array();
        foreach ($obtained_items as $item) {
            $obtained_items_id[] = $item['item_id'];
        }
        $incentive_list = array();
        foreach ($incentive_nums as $count_num) {

            $male_items   = explode(
                ',',
                $this->raw_attributes[sprintf("%s_point_incentives_%s",
                    LIFE_ITEM_SEX_MALE,
                    $count_num)]
            );
            $female_items = explode(
                ',',
                $this->raw_attributes[sprintf("%s_point_incentives_%s",
                    LIFE_ITEM_SEX_FEMALE,
                    $count_num)]
            );
            sort($male_items);
            sort($female_items);
            if (Config::get("state") == "dev"){
                $count_num = (int)$count_num/10;
            }

            //is present a unisex item?
            $incentive_list[$count_num]['property']['unisex_item'] = ($male_items == $female_items);

            //check for multi color
            if (count($male_items) > 1 && count($female_items) > 1) {
                $incentive_list[$count_num]['property']['multi_color'] = true;
            } elseif (count($male_items) > 1 || count($female_items) > 1) {
                throw new Gree_Service_Shop_Exception_DataException("Invalid Present data.");
            } else {
                $incentive_list[$count_num]['property']['multi_color'] = false;
            }


            $incentive_list[$count_num]['property']['secret'] = ($is_secret && in_array($male_items[0], $secret_items));

            //Group code correction...
            if ($item_info[$male_items[0]]['group_code'] == 1120) {
                if (defined('IS_GAVATAR')) {
                    $incentive_list[$count_num]['property']['group'] = mb_convert_encoding("�ط�", mb_internal_encoding(), mb_detect_encoding("�ط�"));
                } else {
                    $incentive_list[$count_num]['property']['group'] = "�ط�";
                }
            } else {
                $incentive_list[$count_num]['property']['group'] = $groups[$item_info[$male_items[0]]['group_code']];
            }


            $incentive_list[$count_num]['property']['obtained'][LIFE_ITEM_SEX_MALE]   = false;
            $incentive_list[$count_num]['property']['obtained'][LIFE_ITEM_SEX_FEMALE] = false;
            foreach ($male_items as $item) {
                if (in_array($item, $obtained_items_id)) {
                    $incentive_list[$count_num]['property']['obtained'][LIFE_ITEM_SEX_MALE] = true;
                    break;
                }
            }
            foreach ($female_items as $item) {
                if (in_array($item, $obtained_items_id)) {
                    $incentive_list[$count_num]['property']['obtained'][LIFE_ITEM_SEX_FEMALE] = true;
                    break;
                }
            }
            //�����������б�(��˥��å��������ƥ������
            if ($male_items[0] == "65363") {
                $incentive_list[$count_num]['property']['unisex_item'] = true;
            }

            $incentive_list[$count_num][LIFE_ITEM_SEX_MALE]   = $this->_getItemFromList($male_items, $item_info);
            $incentive_list[$count_num][LIFE_ITEM_SEX_FEMALE] = $this->_getItemFromList($female_items, $item_info);
        }

        return $incentive_list;
    }
}
