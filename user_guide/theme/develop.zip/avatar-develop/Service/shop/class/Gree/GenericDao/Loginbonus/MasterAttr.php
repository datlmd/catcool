<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Loginbonus/MasterAttr.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Loginbonus_MasterAttrDao extends Gree_GenericDao_Apc
{
    /** @var �ơ��֥�̾ */
    var $_table_name = 'loginbonus_master_attr';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array('id', 'login_id', 'name', 'value', 'mtime', 'ctime',);

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(             // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_by_login_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_id=:login_id',
        ),
        'find_by_login_id_and_name' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_id=:login_id and name=:name',
        ),
        // }}}

        // {{{ �������������������
        'insert' => array(                // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (login_id, name, value, ctime) VALUES(:login_id, :name, :value, NOW())',
        ),
        'update' => array(                // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET value=:value WHERE login_id=:login_id AND name=:name',
        ),
        'delete_by_login_id_and_name' => array( // for support tool
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE login_id=:login_id AND name=:name'
        ),
        // }}}

        // {{{ �ơ��֥����
        'create_table' => array(    // for batch
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`        int(11) unsigned NOT NULL auto_increment,
                `login_id`  int(11) unsigned NOT NULL default '0',
                `name`      varchar(255) NOT NULL DEFAULT '',
                `value`     varchar(255) NOT NULL DEFAULT '',
                `mtime`     timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime`     datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                UNIQUE KEY `login_id` (`login_id`,`name`)
            ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        // {{{ show_table
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
