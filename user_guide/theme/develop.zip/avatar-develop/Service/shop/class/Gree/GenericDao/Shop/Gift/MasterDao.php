<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

// vim: sts=4 sw=4 ts=4 fdm=marker
class Gree_GenericDao_Shop_Gift_MasterDao extends Gree_GenericDao_Apc {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'gift_master';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_gift';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_gift';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
    var $_field_names = array('id', 'item_id', 'state', 'start_time', 'end_time', 'mtime', 'ctime', 'gift_shop_id');
      
	/** @var ������ */
	var $_queries = array(
		// {{{ ���ȷ�
		'all' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC'
		),
        'find_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id:id BY id DESC'
        ),
		'find_by_item_id' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id=:item_id ORDER BY id DESC'
		),
		'find_by_state' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state=:state ORDER BY id DESC'
		),
        'find_by_shop_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gift_shop_id=:gift_shop_id ORDER BY id DESC'
        ),
		// }}}

        // {{{ ������
        'update_state_by_ids' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state=:state WHERE id in (:ids) AND gift_shop_id=:gift_shop_id'
        ),
		'create_table' => array(
			'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
				id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  				item_id INT(11) UNSIGNED NOT NULL DEFAULT 0,
  				state CHAR(1) NOT NULL DEFAULT '',
  				start_time DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
  				end_time DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                gift_shop_id SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  				mtime TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
  				ctime DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
  				PRIMARY KEY  (`id`),
  				KEY `item_id` (`item_id`),
                KEY `gift_shop_id` (`gift_shop_id`)
			) ENGINE=INNODB DEFAULT CHARSET=ujis"
		),
		// }}}
    );

}
