<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Item/SearchJobResultDao.php
 *
 * @package     GREE Avatar
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * SearchJobResult form constructor
 * @access      public
 */
class Gree_GenericDao_Item_SearchJobResultDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'search_job_result';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_item_tags';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_item_tags';

    /** @var field names */
    var $_field_names = array(
        'id',
        'search_job_id',
        'user_id',
        'item_id',
        'route',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'                    => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc'      => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_search_job_id'                  => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE search_job_id = :search_job_id',
        ),
        'count_user_by_search_job_id' => array(
            'sql' => 'SELECT count(*) as total_user FROM __TABLE_NAME__ WHERE search_job_id = :search_job_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                       => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (search_job_id, user_id, item_id, route, ctime) VALUES (:search_job_id, :user_id, :item_id, :route, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                      => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET search_job_id = :search_job_id, user_id = :user_id, item_id = :item_id, route = :route WHERE id = :id',
        ),
        'delete'                      => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'                => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `search_job_id` INT(10) UNSIGNED NOT NULL,
                    `user_id` INT(10) UNSIGNED NOT NULL,
                    `item_id` INT(10) UNSIGNED NOT NULL,
                    `route`  TINYINT(3) NOT NULL,
                    `ctime`  DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                    `mtime`  TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=ujis;',
        ),
        // }}}
    );
}
