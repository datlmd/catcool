<?php

class Gree_Service_AvatarFeed_Processor_Base
    extends Gree_Service_AvatarFeed_Processor
{
    protected function invoke()
    {
        // overridden by subclass
    }

    public function isEnableUser($user_id)
    {
        $is_enable_user = false;

        $registry          = getService('shop')->getRegistry();
        $enable_user_lists = $registry->getArray('avatar_feed_enable_user_list');

        if (Config::get('state') == 'dev') {
            $enable_user_list = $enable_user_lists['dev'];
        } else {
            $enable_user_list = $enable_user_lists['production'];
        }

        if (in_array($user_id, $enable_user_list)) {
            $is_enable_user = true;
        }

        return $is_enable_user;
    }
}
