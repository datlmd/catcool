<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Loginbonus/MasterItem.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Loginbonus_MasterItemDao extends Gree_GenericDao_Apc
{
    /** @var �ơ��֥�̾ */
    var $_table_name = 'loginbonus_master_item';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array('id', 'login_id', 'day_num', 'item_type', 'item_ids', 'mtime', 'ctime',);

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(             // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_by_login_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_id=:login_id order by day_num',
        ),
        'find_by_login_id_and_day_num' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_id=:login_id AND day_num=:day_num',
        ),
        // }}}

        // {{{ �������������������
        'insert' => array(                // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (login_id, day_num, item_type, item_ids, ctime) VALUES(:login_id, :day_num, :item_type, :item_ids, NOW())',
        ),
        'update' => array(                // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET item_type=:item_type, item_ids=:item_ids WHERE login_id=:login_id AND day_num=:day_num',
        ),
        'delete_by_login_id_and_day_num' => array( // for support tool
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE login_id=:login_id AND day_num=:day_num'
        ),
        // }}}

        // {{{ �ơ��֥����
        // item_ids �ˤĤ��Ƥ�csv�����Τߵ����פ��ޤ�("1234,5678")
        'create_table' => array(    // for batch
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`        int(11) unsigned NOT NULL auto_increment,
                `login_id`  int(11) unsigned NOT NULL default '0',
                `day_num`   int(11) unsigned NOT NULL default '0',
                `item_type` int(11) unsigned NOT NULL default '0',
                `item_ids`  varchar(255) NOT NULL DEFAULT '',
                `mtime`     timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime`     datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                UNIQUE KEY `login_id` (`login_id`,`day_num`)
            ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        // {{{ show_table
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );
}
