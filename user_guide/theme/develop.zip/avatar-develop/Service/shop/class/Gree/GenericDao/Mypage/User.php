<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Gree_GenericDao_Shop_Mypage_UserDao
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Mypage_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'avatar_mypage_user';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',
        'open_status',          // ���Х����������ơ�����
        'regist_status',        // ��Ͽ���ơ�����
        'fan_count',            // �ե���οͿ�
        'new_fan_count',        // ����ե���οͿ�(�������˥ꥻ�å�)
        'extend_watch_count',   // �����å���ĥ�ȿ�
        'last_change_time',     // �Ǹ���夻�ؤ��򤪤��ʤä�����
        'last_purchase_time',   // �Ǹ�˥��������Ѥ�������
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND regist_status >= :regist_status',
        ),
        'get_newer_users' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE regist_status = 1 ORDER BY user_id DESC LIMIT :limit',
        ),
        'get_change_users' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY last_change_time DESC LIMIT :limit',
        ),
        'get_check_user_list' => array(
            'sql' => 'SELECT user_id,last_change_time,fan_count FROM __TABLE_NAME__ WHERE open_status = :open_status ORDER BY user_id',
        ),
        'get_user_count' => array(
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__',
        ),
        // batch
        'get_user_count_by_fan_count' => array(
            'sql' => 'SELECT count(*) FROM __TABLE_NAME__ WHERE fan_count >= :fan_count',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, open_status, regist_status, last_change_time, last_purchase_time, ctime)
                VALUES
                    (:user_id, :open_status, :regist_status, :last_change_time, :last_purchase_time, NOW())
                ON DUPLICATE KEY UPDATE regist_status = :regist_status
            ',
        ),
        'unregist' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET regist_status = 0 WHERE user_id = :user_id AND regist_status = 1',
        ),
        'update_open_status' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET open_status = :open_status WHERE user_id = :user_id',
        ),
        'update_fan_count' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET fan_count = :fan_count, new_fan_count = new_fan_count + :new_fan_count WHERE user_id = :user_id',
        ),
        'reset_new_fan_count' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET new_fan_count = 0 WHERE user_id = :user_id',
        ),
        'increase_extend_watch_count' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET extend_watch_count = extend_watch_count + :increase_count WHERE user_id = :user_id',
        ),
        'update_change_time' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET last_change_time = :last_change_time WHERE user_id = :user_id',
        ),
        'update_purchase_time' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET last_purchase_time = :last_purchase_time WHERE user_id = :user_id',
        ),
        // debug
        'reset_user_info' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET fan_count = 0, new_fan_count = 0 WHERE user_id = :user_id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `open_status`         TINYINT(3)  UNSIGNED NOT NULL DEFAULT 1,
                  `regist_status`       TINYINT(3)  UNSIGNED NOT NULL DEFAULT 1,
                  `fan_count`           INT(10)     UNSIGNED NOT NULL,
                  `new_fan_count`       INT(10)     UNSIGNED NOT NULL,
                  `extend_watch_count`  INT(10)     UNSIGNED NOT NULL,
                  `last_change_time`    DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `last_purchase_time`  DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
