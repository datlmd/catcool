<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/PurchaseDao.php
 *
 *  @author   Jun Tomioka <jun.tomioka@gree.net>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_TryDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var �ơ��֥�̾ */
    var $_table_name = 'try';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_analytics';

    /** @var ��Ͽ�������̾ */
    var $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'datetime',
        'service',
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'action1',
        'shop',
        'action2',
        'item_id',
        'tenant_code',
        'category_code',
        'group_code',
        'price',
        'rare_level',
        'ctime',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id              INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    datetime        DATETIME NOT NULL,
                    service         VARCHAR(16) NOT NULL,
                    user_id         BIGINT(20) UNSIGNED NOT NULL,
                    user_sex        TINYINT(4) NOT NULL,
                    user_age        TINYINT(4) NOT NULL,
                    phone_carrier   TINYINT(4) NOT NULL,
                    action1         VARCHAR(255) NOT NULL,
                    shop            VARCHAR(16) NOT NULL,
                    action2         VARCHAR(255) NOT NULL,
                    item_id         INT(10) UNSIGNED,
                    tenant_code     INT(10) UNSIGNED,
                    category_code   INT(10) UNSIGNED,
                    group_code      INT(10) UNSIGNED,
                    price           INT(10) UNSIGNED,
                    rare_level      INT(10) UNSIGNED,
                    ctime           DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY  (id),
                    KEY datetime (datetime),
                    KEY service (service),
                    KEY user_id (user_id),
                    KEY user_sex (user_sex),
                    KEY user_age (user_age),
                    KEY phone_carrier (phone_carrier),
                    KEY action1 (action1),
                    KEY shop (shop),
                    KEY action2 (action2),
                    KEY item_id (item_id),
                    KEY enant_code (tenant_code),
                    KEY category_code (category_code),
                    KEY group_code (group_code),
                    KEY price (price),
                    KEY rare_level (rare_level)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        // }}}
        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ),
        'get_summary' => array(
            'sql' => '
                SELECT
                    user_id,
                    user_sex,
                    user_age,
                    phone_carrier,
                    COUNT(DISTINCT item_id) AS try_item_kind_count
                FROM __TABLE_NAME__
                GROUP BY user_id
            '
        ),
        'count_by_user_id' => array(
            'sql' => 'SELECT COUNT(item_id) AS cnt, SUM(price) AS sum FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'count_by_user_id_and_type' => array(
            'sql' => 'SELECT COUNT(item_id) AS cnt, SUM(price) AS sum FROM __TABLE_NAME__ WHERE user_id = :user_id AND purchase_type = :purchase_type',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
    );
    /** #@- */
}
