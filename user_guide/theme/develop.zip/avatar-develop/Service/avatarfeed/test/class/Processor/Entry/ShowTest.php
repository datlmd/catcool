<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_EntryShowTest
 *
 * this test is show entry process
 */
final class Gree_Service_Avatarfeed_Test_Processor_Entry_ShowTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);
    }

    /**
     * test1:
     * get Entry
     * is_exist_entry == true
     * entry_data     == array
     *
     * test2:
     * s_exist_entry == false
     * entry_data    == empty array
     */
    public function test_get_entry()
    {
        // test1
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_success_create_entry);
        sleep(2);

        $entry_params = array(
            'entry_id' => $entry_id,
        );
        list($is_exist_entry, $entry_data) = $this->avatar_feed->process('entry_show', $entry_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_exist_entry);
        $this->assertEquals($entry_id, $entry_data['entry_id']);
        $this->assertTrue(isset($entry_data['content']['user_info']['nick_name']));
        $this->assertTrue(isset($entry_data['content']['user_info']['thumbnail_url']));

        // test2
        list($is_success_delete_entry, $entry_id) = $this->module->deleteEntry($entry_params);

        sleep(2);

        list($is_exist_entry, $entry_data) = $this->avatar_feed->process('entry_show', $entry_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($is_exist_entry);
        $this->assertTrue(empty($entry_data));
    }


    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_entry_show',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}