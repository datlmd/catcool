<?php
/**
 * Gree_GenericDao_AvapriContestMasterAttrDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Contest_MasterAttrDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'master_contest_attr';
	/** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'id',
        'contest_id',
        'name',
        'value',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        // select----------------------
        'find_by_contest_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id',
        ),
        'find_by_contest_id_and_name' => array( // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND name = :name',
        ),
        // delete----------------------
        'delete_master_attr_by_contest_id_and_name' => array( // for support tool
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND name = :name',
        ),
        // insert----------------------
        'insert_master_attr' => array( // for support tool
            'sql' => 
                'INSERT INTO __TABLE_NAME__ 
                    (contest_id, name, value, ctime)
                VALUES 
                    (:contest_id, :name, :value, NOW()) 
                ON DUPLICATE KEY UPDATE value = :value',
        ),
        // update----------------------
        'update_master_attr' => array( // for batch execute (put on cron)
            'sql' => 'UPDATE __TABLE_NAME__ SET value = :value WHERE id = :id',
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` int(11) unsigned NOT NULL auto_increment,
                  `contest_id` int(11) unsigned NOT NULL default '0',
                  `name` varchar(255) NOT NULL,
                  `value` varchar(255) NOT NULL,
                  `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                  PRIMARY KEY  (`id`),
                  UNIQUE KEY `name` (`contest_id`,`name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );
    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
?>
