<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Gacha/Memories/MasterDao.php
 *
 * @package     GREE Avatar
 * @since       2018-06-08
 */

/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_Gacha_Memories_MasterDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'gacha_memories_master';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var field names */
    var $_field_names = array(
        'id',
        'title',
        'open_dt',
        'end_dt',
        'gacha_ids',
        'status',
        'mtime',
        'ctime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (title, open_dt, end_dt, gacha_ids, status, ctime) VALUES (:title, :open_dt, :end_dt, :gacha_ids, :status, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET title = :title, open_dt = :open_dt, end_dt = :end_dt, gacha_ids = :gacha_ids, status = :status WHERE id = :id',
        ),
        // }}}

        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `title` VARCHAR(255) NOT NULL,
                `open_dt` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_dt` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `gacha_ids` VARCHAR(255) NOT NULL,
                `status` TINYINT UNSIGNED NOT NULL DEFAULT '0',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}