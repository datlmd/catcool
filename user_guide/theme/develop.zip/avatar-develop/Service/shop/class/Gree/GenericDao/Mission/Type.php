<?php

/**
 * Class Gree_GenericDao_Mission_TypeDao
 *
 * @author     Masayoshi Yoshino <masayoshi.yoshino@gree.co.jp>
 * @package    GREE
 */
class Gree_GenericDao_Mission_TypeDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'mission_type';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_tutorial';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_tutorial';

    /** @var field names */
    var $_field_names = array(
        'user_id',              // UserID
        'mission_type',         // Mission Type
        'ctime',
    );

    /** @var query definitions */
    var $_queries = array(
        'find_by_userid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'entry' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, mission_type, ctime) VALUES (:user_id, :mission_type, NOW())',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `mission_type`        TINYINT(1)  UNSIGNED NOT NULL DEFAULT 0,
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  PRIMARY KEY (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );
}
