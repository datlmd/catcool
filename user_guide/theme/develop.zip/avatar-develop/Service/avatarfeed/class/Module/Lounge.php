<?php

/**
 * Module for Lounge.
 */
class Gree_Service_AvatarFeed_Module_Lounge
    extends Gree_Service_AvatarFeed_Module_Base
{
    /** 1日にラウンジに投稿できる回数 */
    const POST_LIMIT = 10;
    /** 連投制限の解除時間 */
    const LIMIT_RESET_HOUR = 3;
    /** 投稿回数を記録するFlareのキー */
    const LOUNGE_POST_LIMIT_FLARE_KEY = 'lounge_post_limit_';

    /**
     * 最大投稿回数を取得します。
     *
     * @retun int 最大投稿回数
     */
    public function getMaxPostLimit()
    {
        return self::POST_LIMIT;
    }

    /**
     * 残り投稿回数を取得します。
     *
     * @param int $user_id ユーザーID
     *
     * @return int 残り投稿回数
     */
    public function getRemainingPostCount($user_id)
    {
        $flare_event = $this->_getFlare();
        $remaining_post_count = $flare_event->getUserEvent($user_id);

        if (is_null($remaining_post_count)) {
            $flare_event->setUserEvent($user_id, self::POST_LIMIT);
            $remaining_post_count = self::POST_LIMIT;
        }

        return (int)$remaining_post_count;
    }

    /**
     * 投稿回数を1増やします。
     *
     * @param int $user_id ユーザーID
     *
     * @return int/bool 残り投稿回数
     */
    public function incrementPostCount($user_id)
    {
        $remaining_post_count = $this->getRemainingPostCount($user_id);
        $after_remaining_post_count = $remaining_post_count - 1;
        if ($after_remaining_post_count < 0) {
            $after_remaining_post_count = 0;
        }

        $flare_event = $this->_getFlare();
        $flare_event->setUserEvent($user_id, $after_remaining_post_count);

        return $after_remaining_post_count;
    }

    /**
     * 投稿回数制限がリセットされる日付を取得します。
     *
     * @return string リセットされる日付
     */
    public function getPostLimitResetDate()
    {
        $reset_time = self::LIMIT_RESET_HOUR * 3600;
        $current_date = date("Y-m-d H:i:s", strtotime(getService('shop')->getDate()) - $reset_time);
        $expire_date  = date("Y-m-d ".self::LIMIT_RESET_HOUR.":00:00", strtotime($current_date . " +1 day"));

        return $expire_date;
    }

    private function _getPostLimitExpireTime()
    {
        $current_date = getService('shop')->getDate();
        $expire_date  = $this->getPostLimitResetDate();
        $expire_time  = strtotime($expire_date) - strtotime($current_date);

        return $expire_time;
    }

    private function _getFlare()
    {
        $expire_time = $this->_getPostLimitExpireTime();
        $flare_event = getService('shop')->getFlareEvent($expire_time, self::LOUNGE_POST_LIMIT_FLARE_KEY);

        return $flare_event;
    }
}
