<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Stamp_Master_StampDao extends Gree_GenericDao_Apc
{
    var $_table_name = 'stamp_master';

    var $_primary_key = 'stamp_id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_stamp';

    var $_slave_dsn = 'gree://slave/avatar_stamp';

    var $_auto_increment = false;

    var $_field_names = array(
        'stamp_id',
        'stamp_set_id',
        'alt_text',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `stamp_id`          int(11) unsigned NOT NULL,
                    `stamp_set_id`      int(11) unsigned NOT NULL,
                    `alt_text`          varchar(255) NOT NULL,
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`stamp_id`),
                    KEY `stamp_set_id` (`stamp_set_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),

        'get_max_stamp_id_by_set_id' => array(
            'sql' => "SELECT max(stamp_id) FROM __TABLE_NAME__ WHERE stamp_set_id = :stamp_set_id",
            'disable_apc' => true,
        ),

        'insert' => array(
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    stamp_id,
                    stamp_set_id,
                    alt_text,
                    ctime
                )
                VALUES (
                    :stamp_id,
                    :stamp_set_id,
                    :alt_text,
                    NOW()
                )
            ",
        ),

        'update_alt_text_by_stamp_id' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET alt_text = :alt_text WHERE stamp_id = :stamp_id",
        ),

        'find_stamp' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE stamp_id = :stamp_id",
        ),

        'find_by_set_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE stamp_set_id = :stamp_set_id ORDER BY stamp_id",
        ),

        'find_set_id_by_stamp_id' => array(
            'sql' => "SELECT stamp_set_id FROM __TABLE_NAME__ WHERE stamp_id = :stamp_id",
        ),
    );

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
