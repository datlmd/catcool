<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Class Gree_GenericDao_Gacha_Fever_MasterDao
 */
class Gree_GenericDao_Gacha_Fever_MasterDao extends Gree_GenericDao_Apc
{

    /** @var �ơ��֥�̾ */
    public $_table_name = 'gacha_fever_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣 */
    public $_primary_key = 'id';

    /** @var �����������̾ */
    public $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    public $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    public $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    public $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �����ȥ��󥯥���� */
    public $_auto_increment = true;

    /** @var �ե������̾ */
    public $_field_names = [
        'id',
        'name',
        'start_date',
        'end_date',
        'ap_price',
        'coupon_gacha_male',
        'coupon_gacha_female',
        'mtime',
        'ctime',
    ];

    /**
     * @var �����������
     */
    public $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT NOT NULL AUTO_INCREMENT,
                `name` TEXT NOT NULL,
                `start_date` DATETIME NOT NULL,
                `end_date` DATETIME NOT NULL,
                `ap_price` INT NOT NULL,
                `coupon_gacha_male` INT,
                `coupon_gacha_female` INT,
                `mtime` DATETIME NOT NULL default CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL default CURRENT_TIMESTAMP,
                PRIMARY KEY  (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table'   => [
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ],
        'insert'       => [
            'sql'                   => "INSERT INTO __TABLE_NAME__ (name, start_date, end_date, ap_price, coupon_gacha_male, coupon_gacha_female) values (:name, :start_date, :end_date, :ap_price, :coupon_gacha_male, :coupon_gacha_female)",
            'return_last_insert_id' => true,
        ],

        'select_all' => [
            'sql' => "SELECT * FROM __TABLE_NAME__ ORDER BY `end_date` DESC",
        ],

    );


    function prepareI18n($row, $rw = 'r')
    {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
