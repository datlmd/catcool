<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Entry_Delete
 *
 * this test is delete entry process
 */
final class Gree_Service_Avatarfeed_Test_Processor_Entry_Delete
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);
    }

    /**
     * test1:
     * Delete Entry with owner
     * is_success     == true
     * entry_id     == string
     *
     * test2:
     * Delete Entry with other
     * is_success     == false
     * entry_id       == null
     */
    public function test_delete_entry()
    {
        // test1
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_success_create_entry);
        sleep(2);

        $entry_params = array(
            'entry_id' => $entry_id,
        );
        list($is_success_delete_entry, $delete_entry_id) = $this->avatar_feed->process('entry_delete', $entry_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_success_delete_entry);
        $this->assertEquals($entry_id, $delete_entry_id);

        // test2
        list($is_success_create_entry_2, $entry_id_2) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_success_create_entry_2);
        sleep(2);

        $entry_params_2 = array(
            'entry_id' => $entry_id_2,
        );
        list($is_success_delete_entry_2, $delete_entry_id_2) = $this->avatar_feed->process('entry_delete', $entry_params_2, UNIT_TEST_USER_ID_2);

        $this->assertFalse($is_success_delete_entry_2);
        $this->assertEquals(null, $delete_entry_id_2);
    }


    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_entry_show',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}