<?php

require_once("/home/gree/xgree/avatar/Service/avatarfeed/cli/Base.php");
require_once ("/home/gree/xgree/avatar/lib/gpdata-client/src/Gpdata/Autoloader.php");
Gpdata_Autoloader::register();


/**
 * Class Gree_Service_AvatarFeed_Cli_td_job_manager
 *
 * useage is
 */
class Gree_Service_AvatarFeed_Cli_TDJobManager
    extends Gree_Service_AvatarFeed_Cli_Base
{
    protected $gpdata_user = 'avatar-ro';
    protected $gpdata_token = 'ab322091f0b667d4199b121d301744bd8d343a41c3afea30';
    public $log_dir = '/home/gree/log/td/avatar/job/recommend_user';

    public function main()
    {
        $this->_initialize();

        $this->_print_header('td_job_manager');

        $this->short_opt      = "m:t:u:p:i:";
        $this->opt_names      = array(
            ''
        );
        $this->input_opt_list = $this->_get_parse_arg_list();

        try {
            $set_options = $this->_set_option_value();
            $this->_invoke($set_options);
        } catch (Exception $e) {
            printf("finish with error. \n");
        }

        $this->_print_footer();
    }

    public function _find_input_option($option)
    {
        $option_name  = null;
        $option_value = null;

        switch ($option[0]) {
            case 'm':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name  = 'mode';
                $option_value = $option[1];
                break;
            case 't':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name  = 'target_date';
                $option_value = $option[1];
                break;
            case 'u':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name  = 'user';
                $option_value = $option[1];
                break;
            case 'p':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name  = 'pass';
                $option_value = $option[1];
                break;
            case 'i':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name  = 'id';
                $option_value = $option[1];
                break;
            default:
                printf("please input mode \n");
                throw new Exception();
        }

        return array(
            $option_name,
            $option_value,
        );
    }

    public function _invoke($option)
    {
        switch ($option['mode']) {
            case 'create_table':
                $this->_create_table($option);
                break;
            case 'create_table_of_next_month':
                $this->_create_table_of_next_month($option);
                break;
            case 'drop_table':
                $this->_drop_table($option);
                break;
            case 'drop_table_of_last_month':
                $this->_drop_table_of_last_month($option);
                break;
            case 'check_table_of_next_month':
                $this->_check_table_of_next_month($option);
                break;
            case 'create_td_issue':
                $this->_create_td_issue($option);
                break;
            case 'insert_user_from_td':
                $this->_insert_user_from_td($option);
                break;
            case 'get_user_id':
                $this->_get_user_id_from_id($option);
                break;
            default:
                printf("please input exist mode\n");
                throw new Exception();
        }
    }

    public function _create_table($option)
    {
        $accessor = Cascade::getAccessor('avatar_feed#recommend_user');
        $params   = array();
        if (isset($option['target_date'])) {
            $params['date'] = $option['target_date'];
        }
        $accessor->execute('create_table', $params);
    }

    public function _create_table_of_next_month($option)
    {
        $accessor  = Cascade::getAccessor('avatar_feed#recommend_user');
        $next_date = date('Ym', strtotime('+1 month'));
        $lastday   = date('t', strtotime('+1 month'));

        $next_target_date_list = array();
        for ($i = 1; $i <= $lastday; $i++) {
            $next_target_date_list[] = $next_date . sprintf("%02d", $i);
        }

        $params = array();
        foreach ($next_target_date_list as $next_target_date) {
            $params['date'] = $next_target_date;
            $accessor->execute('create_table', $params);
        }
    }

    public function _drop_table($option)
    {
        $accessor = Cascade::getAccessor('avatar_feed#recommend_user');
        $params   = array();
        if (isset($option['target_date'])) {
            $params['date'] = $option['target_date'];
        }
        $accessor->execute('drop_table', $params);
    }

    public function _drop_table_of_last_month($option)
    {
        $accessor  = Cascade::getAccessor('avatar_feed#recommend_user');
        $last_date = date('Ym', strtotime('-1 month'));
        $lastday   = date('t', strtotime('-1 month'));

        $last_target_date_list = array();
        for ($i = 1; $i <= $lastday; $i++) {
            $last_target_date_list[] = $last_date . sprintf("%02d", $i);
        }

        $params = array();
        foreach ($last_target_date_list as $last_target_date) {
            $params['date'] = $last_target_date;
            $accessor->execute('drop_table', $params);
        }
    }

    public function _check_table_of_next_month($option)
    {
        $accessor  = Cascade::getAccessor('avatar_feed#recommend_user');
        $next_date = date('Ym', strtotime('+1 month'));
        $lastday   = date('t', strtotime('+1 month'));

        $next_target_date_list = array();
        for ($i = 1; $i <= $lastday; $i++) {
            $next_target_date_list[] = $next_date . sprintf("%02d", $i);
        }

        $not_exist_table_list = array();
        $params               = array();
        foreach ($next_target_date_list as $next_target_date) {
            $params['date'] = $next_target_date;
            $find_result    = $accessor->find('check_table', $params);
            if (empty($find_result)) {
                $not_exist_table_list[] = $next_target_date;
            }
        }

        if (empty($not_exist_table_list)) {
            printf("\033[32m[%s] Succeeded. %s\n\033[0m", 'avatar', "all table exist");
        } else {
            printf("\033[31m[%s] Failed. %s\n\033[0m", 'avatar', "table not exist");
            foreach ($not_exist_table_list as $not_exist_table) {
                printf("\033[31m[%s] Failed. %s\n\033[0m", 'avatar', "not exist table is recommend_user_" . $not_exist_table);
            }
        }
    }

    public function _create_td_issue($option)
    {
        if (file_exists($this->log_dir) == false) {
            mkdir($this->log_dir, 0777, true);
        }
        $log_file = $this->log_dir . "/" . date('Ymd') . '.log';
        if (file_exists($log_file)) {
            $msg = "recommend_user log file is already exist. log file name is " . $log_file;
            exit($msg);
        } else {
            $file_object = fopen($log_file, 'w');
        }

        $client        = new Gpdata_Api($this->gpdata_user, $this->gpdata_token);
        $database_name = 'avatar';
        $query         = "
          SELECT
            uid,
            COUNT(1) AS dayn
          FROM(
            SELECT
              uid,
              dt
            FROM
              access
            WHERE
              ACTION IN('api_mood_change')
              AND service IN('tshop')
              AND dt between query_dt(-6) and query_dt(-1)
            GROUP BY
              uid,
              dt
          ) access_days
          GROUP BY
            uid
          ORDER BY
            dayn DESC
          LIMIT
            10000
        ";

        $res = $client->issueHiveQuery($database_name, $query)->getResult();
        $job_id = $res->getJobId();

        if (!empty($job_id)) {
            fwrite($file_object, $job_id);
        }

        fclose($file_object);
    }

    public function _insert_user_from_td($option)
    {
        $log_file = $this->log_dir . "/" . date('Ymd') . '.log';
        if (file_exists($log_file)) {
            $file_object = fopen($log_file, 'r');
        } else {
            $msg = "recommend_user log file is not exist. log file name is " . $log_file;
            exit($msg);
        }

        $job_id = fgets($file_object);
        fclose($file_object);
        if ($job_id == false){
            $msg = "failed get job_id from recommend_user log ";
            exit($msg);
        }

        $client  = new Gpdata_Api($this->gpdata_user, $this->gpdata_token);
        $status = $client->getJobStatus($job_id)->getResult();

        if (!$status->isSuccess()){
            $msg = "job status is not success";
            exit($msg);
        }

        $ret      = $client->getJobResult($job_id)->getResult();
        if (is_array($ret) == false){
            $msg = "failed get job result. job_id is " . $job_id;
            exit($msg);
        }

        $accessor = Cascade::getAccessor('avatar_feed#recommend_user');

        foreach ($ret as $index => $user) {
            $params = array(
                'date'    => date('Ymd', strtotime('+1 day')),
                'user_id' => $user[0],
            );
            $accessor->execute('insert_user_id', $params);

            if ($index % 100 == 0) {
                printf("finish index " . $index . "\n");
                sleep(1);
            }
        }
    }

    public function _get_user_id_from_id($option)
    {
        $module_recommend_user = Gree_Service_AvatarFeed_Module::singleton('RecommendUser');
        $user_id               = $module_recommend_user->getUserIdFromId($option['id']);

        if (is_null($user_id)) {
            printf("not exist user" . "\n");
        } else {
            printf("user_id: " . $user_id . "\n");
        }
    }
}

$class = new Gree_Service_AvatarFeed_Cli_TDJobManager();
$class->main();
