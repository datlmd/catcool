<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Comment_List_Get
 */
class Gree_Service_AvatarFeed_Processor_Comment_List_Get
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return has_more, comment_list(appended user info)
     * if failed get then
     *   has_more     == false
     *   comment_list == empty array
     */
    protected function invoke()
    {
        $comment_list = array();
        $has_more     = false;
        $mod_appfeed  = self::getModule('AppFeed');

        try {
            list($has_more, $comments) = $mod_appfeed->getCommentList(
                $this->input_values['entry_id'],
                $this->input_values['limit'],
                $this->input_values['start_id']
            );
        } catch (Exception $e) {
            $msg     = 'failed get comment list.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_COMMENT_LIST_GET;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return  array(
                $has_more,
                $comment_list
            );
        }

        if (count($comments) == 0){
            return  array(
                $has_more,
                $comment_list
            );
        }

        $mod_user     = self::getModule('User');
        $comment_list = $mod_user->appendUserInfo($comments);

        return array(
            $has_more,
            $comment_list
        );
    }
}
