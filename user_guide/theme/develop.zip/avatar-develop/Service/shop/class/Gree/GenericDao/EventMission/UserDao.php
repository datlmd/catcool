<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/EventMission/UserDao.php
 * @package     GREE Avatar
 * @since       2018-10-19
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * User form constructor
 * @access      public
 */
class Gree_GenericDao_EventMission_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'mission_event_user';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'user_id',
        'master_id',
        'frequency_detail_id',
        'mission_info_master_id',
        'date',
        'clear_count',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // --select
        'find_by_user_id_and_frequency_and_master_and_date' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `user_id` = :user_id AND `frequency_detail_id` = :frequency_detail_id AND `date` = :date',
        ],
        'find_by_user_id_and_master_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `user_id` = :user_id AND `master_id` = :master_id',
        ],
        // --insert & update
        'insert_user' => [
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ 
                          (user_id, frequency_detail_id, master_id, mission_info_master_id, date, clear_count, ctime) 
                      VALUES
                          (:user_id, :frequency_detail_id, :master_id, :mission_info_master_id, :date, :clear_count, NOW())',
        ],
        // --create table
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id` INT UNSIGNED NOT NULL,
                    `master_id` INT UNSIGNED NOT NULL,
                    `frequency_detail_id` INT UNSIGNED NOT NULL,
                    `mission_info_master_id` INT UNSIGNED NOT NULL,
                    `date` DATE NOT NULL,
                    `clear_count` INT UNSIGNED NOT NULL,
                    `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `user_id` (`user_id`,`frequency_detail_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;
            ",
        ],
        // --delete for support tool - only debug
        'delete_by_user_id_and_master_id' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id AND master_id = :master_id',
        ),
    ];
    /** #@- */

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
