<?php
/**
 * Gree_GenericDao_Point_HistoryStandby
 *
 *  Standby����³����Τǡ���������
 *
 * @author  Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/DateFarmSelector.php';

class Gree_GenericDao_Shop_Point_HistoryStandbyDao extends Gree_GenericDao_Shop_Point_HistoryDao
{
    /** @var slave dsn */
    var $_slave_dsn         = 'gree://standby/avatar_point';

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'get_count_by_user_id' => array(
            'sql' => 'SELECT user_id, COUNT(*) AS cnt FROM __TABLE_NAME__ GROUP BY user_id',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    /**
     * initialize farm selector
     *
     * @access  private
     */
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Shop_DateFarmSelector();
    }
    // }}}
}
