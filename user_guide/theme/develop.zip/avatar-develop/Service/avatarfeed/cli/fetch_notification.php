<?php
require "/home/gree/src/Gree_Bootstrap.php";
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once "/home/gree/xgree/avatar/Service/avatarfeed/service.php";

if ($argc != 2) {
    echo '引数にユーザーIDを指定して下さい' . PHP_EOL;
    exit();
}

$user_id = $argv[1];

if (is_null($user_id) || !is_numeric($user_id)) {
    echo '引数にユーザーIDを指定して下さい' . PHP_EOL;
    exit();
}

try {
    $module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
    $module->setUserIDtoCtfy($user_id);

    list($has_more, $entries) = $module->getEntriesByFeedKey(
        $user_id,
        GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION,
        101,
        null
    );

    echo "エントリー数: " . count($entries) . PHP_EOL;

    foreach ($entries as $index => $entry) {
        echo PHP_EOL . "エントリー: " .  $index . PHP_EOL;

        var_export($entry);
    }

} catch (Exception $e) {
    echo $e->getMessage() . PHP_EOL;
    exit();
}
