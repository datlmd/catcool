<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Block
    extends Cascade_DB_SQL_DataFormat
{
    // dsn setting
    protected $master_dsn        = 'gree://master/avatar_block';
    protected $slave_dsn         = 'gree://slave/avatar_block';
    protected $extra_dsn         = array();

    // cascade setting
    protected $primary_key       = array(
        'user_id',
        'block_user_id',
    );
    protected $fetch_mode        = self::FETCH_MODE_ASSOC;
    // use primary_key
    protected $fetch_key         = NULL;
    protected $auto_increment    = false;

    // table and column setting
    protected $created_at_column = 'ctime';
    protected $table_name        = 'block';
    protected $field_names       = array(
        'user_id',
        'block_user_id',
        'ctime',
    );

    protected $queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`           bigint(20) UNSIGNED  NOT NULL,
                  `block_user_id`     bigint(20) UNSIGNED  NOT NULL,
                  `ctime`             datetime             NOT NULL,
                  PRIMARY KEY (`user_id`, `block_user_id`),
                          KEY `sort_ctime` (`user_id`, `ctime`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ",
        ),
        'find_user_by_user_id_and_block_user_id' => array(
            'sql' => 'SELECT block_user_id FROM __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   block_user_id = :block_user_id
            ',
        ),
        'find_date_by_user_id_and_block_user_id' => array(
            'sql' => 'SELECT ctime FROM __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   block_user_id = :block_user_id
            ',
        ),
        // offset = int
        'find_list_by_user_id_sort_ctime' => array(
            'sql' => 'SELECT block_user_id FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY ctime DESC',
        ),
        // offset = int
        'find_list_by_user_id_sort_block_user_id' => array(
            'sql' => 'SELECT block_user_id FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY block_user_id',
        ),
        // offset = block_user_id
        'find_list_by_user_id_and_block_user_id' => array(
            'sql' => 'SELECT block_user_id FROM __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   block_user_id > :block_user_id
                        ORDER BY block_user_id',
        ),
        'add_block' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, block_user_id, ctime) VALUES(:user_id, :block_user_id, NOW())'
        ),
        'remove_block' => array(
            'sql' => 'DELETE FROM  __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   block_user_id = :block_user_id
            '
        ),
        // get the total number of block users
        'get_count' => array(
            'sql' => 'SELECT COUNT(*) from __TABLE_NAME__ where user_id = :user_id'
        ),
    );
}
