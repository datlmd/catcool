<?php
/**
 * Gacha.php
 */
class Gree_Service_Shop_Data_Gacha
    extends Gree_Service_Shop_Data_Abstract
{
    // ----[ Constants ]--------------------------------------------------------
    const DAO_NAME_ATTR = 'LifeGachaMasterAttr';

    // ----[ Properties ]-------------------------------------------------------
    /**
     * @var array   format
     */
    protected $_format = array(
        'gacha_id',
        'type_id',
        'name',
        'tpl_type',
        'gold',
        'first_free_flag',
        'rare_ratio',
        'image_url',
        'shoulder_text',
        'user_sex',
        'gacha_method',
        'start_time',
        'end_time',
    );

    // ----[ Methods ]----------------------------------------------------------
    /**
     * is active gacha
     *
     * @return  bool
     */
    public function isActive()
    {
        $start_time   = strtotime($this->start_time);
        $end_time     = strtotime($this->end_time);
        $current_time = strtotime($this->_date);

        return ($start_time <= $current_time && $current_time < $end_time);
    }

    /**
     * is vlaid sex
     *
     * @param   int     user sex
     * @return  bool
     */
    public function isValidSex($user_sex)
    {
        if ($this->user_sex == LIFE_ITEM_SEX_UNISEX) {
            return true;
        } elseif ($this->user_sex == $user_sex) {
            return true;
        }

        return false;
    }

    // ---[ Read Functions ]----------------------------------------------------
    /**
     * read attrs
     *
     * @return  array
     */
    protected function __readAttrs()
    {
        $params = array('gacha_id' => $this->gacha_id);
        $attrs  = getService('shop')->getSessionWrapper()->toArray(
            self::DAO_NAME_ATTR,
            'find_by_gacha_id',
            $params
        );

        // format
        $formatted_attrs = array();
        foreach ($attrs as $attr) {
            $formatted_attrs[$attr['name']] = $attr['value'];
        }

        return $formatted_attrs;
    }
}
