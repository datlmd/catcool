<?php
require_once '/home/gree/xgree/avatar/Service/shop/class/Gree/Apc.php';

/**
 * GenericDaのクエリ結果を自動的にAPCキャッシュにのせるためのクラスです。
 * このクラスを継承して実装されたGenericDaoは自動的にキャッシュされるため、
 * マスターデータのGenericDaoのみに使用してください。
 *
 * キャッシュさせる秒数を変更したい場合、
 *     $_cache_lifetime
 * をオーバーライドしてください。
 * デフォルトの秒数はGREE_SERVICE_SHOP_APC_LIFETIME_MASTERで定義されます。
 *
 * Gree_GenericDao_Apcを継承したままAPCを無効にするには
 *     $_use_apc_get
 * をオーバーライドしてfalseにしてください。
 * サポツではデフォルトでfalseとなります。
 *
 * 使用途中で一時的にAPCを無効にしたい場合
 *     setUseApcCache(false)
 * を実行し、再度APCを有効にしたい場合は引数にtrueを指定してください。
 *
 * 特定のクエリのみAPCを無効にしたい場合、クエリ名の配列の中で
 *     'disable_apc' => true
 * を指定してください。
 * example)
 *    'find_by_id' => array(
 *        'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
 *        'disable_apc' => true,
 *     )
 */
class Gree_GenericDao_Apc extends Gree_GenericDao
{
    private $_apc = null;

    /** @var int キャッシュする秒数 */
    protected $_cache_lifetime = GREE_SERVICE_SHOP_APC_LIFETIME_MASTER;
    /** @var bool キャッシュからデータを取得するかどうか */
    protected $_use_apc_get = true;

    public function __construct($auto_commit = true)
    {
        parent::__construct($auto_commit);

        $servicename = Gree_Service_Shop_Util::getAvatarServiceName();
        $namespace   = $servicename . '/' . $this->_db_name . '/' . $this->_table_name;
        $this->_apc = Gree_Service_Shop_Apc::getInstance($namespace);

        // サポツまたはHTTPアクセスでない場合ははデフォルトでオフ
        $is_support      = Gree_Service_Shop_Util::isSupport();
        $is_no_http_host = !isset($_SERVER['HTTP_HOST']);
        if ($is_support || $is_no_http_host) {
            $this->_use_apc_get = false;
        }
    }

    /**
     * GenericDaoがAPCキャッシュを使用する場合はtrueを返します。
     *
     * @return bool APCキャッシュを使用するかどうか
     */
    public function isUseApcCache()
    {
        return $this->_use_apc_get;
    }

    /**
     * APCキャッシュを使用するかどうかを設定します。
     *
     * @param bool APCキャッシュを使用する場合はtrueを指定してください
     */
    public function setUseApcCache($use)
    {
        $this->_use_apc_get = $use;
    }

    /**
     * GenericDaoのgetメソッドをオーバーライドして、
     * Gree_Service_Shop_Apcを用いてキャッシュさせるようにしたものです。
     *
     * @see Gree_GenericDao
     */
    public function get($id, $hint = null)
    {
        if ($this->_canUseApc() == false) {
            return parent::get($id, $hint);
        }

        $apc_params = array(
            'query_type' => 'get',
            'id'         => $id,
            'hint'       => $hint,
        );
        $cache_data = $this->_apc->get($apc_params, $this->_cache_lifetime);
        if (!PEAR::isError($cache_data)) {
            return $cache_data;
        }

        $raw_data = parent::get($id, $hint);
        if (PEAR::isError($raw_data)) {
            return $raw_data;
        }

        $this->_apc->set($apc_params, $raw_data);

        return $raw_data;
    }

    /**
     * GenericDaoのtoValueメソッドをオーバーライドして、
     * Gree_Service_Shop_Apcを用いてキャッシュさせるようにしたものです。
     *
     * @see Gree_GenericDao
     */
    public function toValue($query_name, $params = null, $hint = null)
    {
        if ($this->_canUseApc($query_name) == false) {
            return parent::toValue($query_name, $params, $hint);
        }

        $apc_params = array(
            'query_type' => 'toValue',
            'query_name' => $query_name,
            'params'     => $params,
            'hint'       => $hint,
        );
        $cache_data = $this->_apc->get($apc_params, $this->_cache_lifetime);
        if (!PEAR::isError($cache_data)) {
            return $cache_data;
        }

        $raw_data = parent::toValue($query_name, $params, $hint);
        if (PEAR::isError($raw_data)) {
            return $raw_data;
        }

        $this->_apc->set($apc_params, $raw_data);

        return $raw_data;
    }

    /**
     * GenericDaoのtoArrayメソッドをオーバーライドして、
     * Gree_Service_Shop_Apcを用いてキャッシュさせるようにしたものです。
     *
     * @see Gree_GenericDao
     */
    public function toArray($query_name, $params = null, $offset = null, $limit = null, $hint = null)
    {
        if ($this->_canUseApc($query_name) == false) {
            return parent::toArray($query_name, $params, $offset, $limit, $hint);
        }

        $apc_params = array(
            'query_type' => 'toArray',
            'query_name' => $query_name,
            'params'     => $params,
            'offset'     => $offset,
            'limit'      => $limit,
            'hint'       => $hint,
        );
        $cache_data = $this->_apc->get($apc_params, $this->_cache_lifetime);
        if (!PEAR::isError($cache_data)) {
            return $cache_data;
        }

        $raw_data = parent::toArray($query_name, $params, $offset, $limit, $hint);
        if (PEAR::isError($raw_data)) {
            return $raw_data;
        }

        $this->_apc->set($apc_params, $raw_data);

        return $raw_data;
    }

    /**
     * GenericDaoのfindFirstメソッドをオーバーライドして、
     * Gree_Service_Shop_Apcを用いてキャッシュさせるようにしたものです。
     *
     * @see Gree_GenericDao
     */
    public function findFirst($query_name, $params = null, $hint = null)
    {
        if ($this->_canUseApc($query_name) == false) {
            return parent::findFirst($query_name, $params, $hint);
        }

        $apc_params = array(
            'query_type' => 'findFirst',
            'query_name' => $query_name,
            'params'     => $params,
            'hint'       => $hint,
        );
        $cache_data = $this->_apc->get($apc_params, $this->_cache_lifetime);
        if (!PEAR::isError($cache_data)) {
            return $cache_data;
        }

        $raw_data = parent::findFirst($query_name, $params, $hint);
        if (PEAR::isError($raw_data)) {
            return $raw_data;
        }

        $this->_apc->set($apc_params, $raw_data);

        return $raw_data;
    }

    /**
     * APCを使用できるならtrueを返します。
     *
     * @param string $query_name クエリ名 クエリ名が指定された場合、クエリ毎にAPCが有効かチェックします
     *
     * @return boolean APCが使用できるならtrue、そうでないならfalse
     */
    private function _canUseApc($query_name = null)
    {
        $enabled_apc           = $this->_use_apc_get;
        $not_master_connection = !$this->_session->isUseMasterConnection();
        $enabled_query_apc     = $this->_enabledQueryApc($query_name);

        return ($enabled_apc && $not_master_connection && $enabled_query_apc);
    }

    /**
     * クエリのAPC設定を確認します。
     *
     * @param string $query_name クエリ名
     *
     * @return boolean クエリのAPCが有効ならtrue、無効ならfalse
     */
    private function _enabledQueryApc($query_name = null)
    {
        if ($query_name == null) {
            return true;
        }

        if (!isset($this->_queries[$query_name])) {
            return false;
        }

        $query = $this->_queries[$query_name];
        if (isset($query['disable_apc']) && $query['disable_apc'] == true) {
            return false;
        }

        return true;
    }
}

