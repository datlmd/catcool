<?php
/**
 * Abstract.php
 */

/**
 * Gree_Service_Shop_Data_Abstract
 *
 * @package GREE
 * @access  public
 */
abstract class Gree_Service_Shop_Data_Abstract
{
    // ----[ Constants ]--------------------------------------------------------
    const COMMON_KEY = '__common__';

    // ----[ Properties ]-------------------------------------------------------

    // {{{ $_format
    protected $_format          = array();
    // }}}
    // {{{ $__accessor
    public $__accessor         = array();
    private $__extras           = array();
    // }}}
    // {{{ $_date
    protected $_date            = null;
    // }}}

    // ----[ Methods ]----------------------------------------------------------

    // {{{ __construct
    /**
     * Gree_Service_Shop_Data_Abstract
     *
     * @access  private
     * @param   mixed   $params
     */
    public function __construct($accessor)
    {
        $shop_service = getService('shop');
        $this->_date  = $shop_service->getDate();

        $this->_validateAccessor($accessor);
        $accessor = $this->_filterAccessor($accessor);
        $this->__accessor = $accessor;
    }
    // }}}
    // {{{ _filterAccessor
    /**
     * filter accessor
     *
     * @access  protected
     * @param   array   $accessor
     * @return  array   the filtered accessor
     */
    protected function _filterAccessor($accessor)
    {
        // override me
        return $accessor;
    }
    // }}}
    // {{{ _validateAccessor
    /**
     * check format of accessor
     *
     * @access  protected
     * @param   array   $accessor
     */
    protected function _validateAccessor(array $accessor)
    {
        $accessor_keys  = array_keys($accessor);
        $undefined_keys = array_diff($this->_format, $accessor_keys);
//        d($undefined_keys);
        if (!empty($undefined_keys)) {
            $ex_msg = 'invalid accessor to instantiate (class=%s)';
            $ex_msg = sprintf($ex_msg, get_class($this));
            throw new Gree_Service_Shop_Exception_DataException($ex_msg);
        }

        return;
    }
    // }}}
    // {{{ __get
    /**
     * __get
     * $instance->name で $__accessor['name'] を読み込む
     * $__accessor['name'] が無い場合, キャメルケースで__readXXX メソッドを探しにいく。
     * ex)
     * $instance->type_info => $instance->__readTypeInfo()
     *
     * @access  public
     * @return  mixed   the value
     */
    public function __get($name)
    {
        if (array_key_exists($name, $this->__accessor)) {
            return $this->__accessor[$name];
        } else if (array_key_exists($name, $this->__extras)) {
            return $this->__extras[$name];
        }

        $upper_case_name    = implode(array_map('ucfirst', explode('_', $name)));
        $read_function_name = sprintf('__read%s', $upper_case_name);
        if (method_exists($this, $read_function_name)) {
            $this->__extras[$name] = $this->$read_function_name();
            return $this->__extras[$name];
        }

        return null;
    }
    // }}}
    // {{{ __set
    /**
     * __set
     *
     * @access  public
     * @param   string  $name
     * @param   mixed   $value
     * @return  void
     */
    public function __set($name, $value)
    {
        $ex_msg = 'you cannot overwrite the property "%s" (%s)';
        $ex_msg = sprintf($ex_msg, $name, get_class($this));
        throw new Gree_Service_Shop_Exception($ex_msg);
    }
    // }}}
    // {{{ __clone
    /**
     * __clone
     *
     * @access  public
     */
    public final function __clone()
    {
        $ex_msg = 'you cannot clone this object (%s)';
        $ex_msg = sprintf($ex_msg, get_class($this));
        throw new Gree_Service_Shop_Exception($ex_msg);
    }
    // }}}
    // {{{ _set
    /**
     * set new value to info
     *
     * @access  protected
     * @param   array   $params
     */
    protected function _set(array $params)
    {
        $new_keys = array_diff(array_keys($params), array_keys($this->__accessor));
        if (!empty($new_keys)) {
            $ex_msg = 'you cannot set new key';
            throw new Gree_Service_Shop_Exception_DataException($ex_msg);
        }

        $this->__accessor = array_merge($this->__accessor, $params);
    }
    // }}}
    // {{{ toArray
    /**
     * to array
     *
     * @access  public
     * @return  mixed   the value
     */
    public function toArray()
    {
        return $this->__accessor;
    }
    // }}}

    // {{{ reset
    /**
     * reset
     * $__accessor['name'] をリセットする。
     * 再取得が必要な際明示的に呼ぶことで再度__readXXXを実行出来るようにする。
     * $nameを指定しないと全てをリセットする。
     * ex)
     * $instance->type_info => $instance->__readTypeInfo()
     * changeTypeInfo()
     * $instance->reset()
     * $instance->type_info => $instance->__readTypeInfo()
     *
     * @access  public
     * @return  mixed   the value
     */
    public function reset($name = null)
    {
        if (is_null($name)){
            $reset_array = array();
            foreach($this->_format as $property_name){
                $reset_array[$property_name] = $this->__accessor[$property_name];
            }
            $this->__accessor = $reset_array;
            $this->__extras   = array();
            return true;
        } else {
            if (array_key_exists($name, $this->__accessor)) {
                unset($this->__accessor[$name]);
                return true;
            } else if (array_key_exists($name, $this->__extras)) {
                unset($this->__extras[$name]);
                return true;
            }
        }
        return false;
    }
    // }}}
}
