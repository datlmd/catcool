<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Comment_DeleteTest
 *
 * this test is delete comment
 */
final class Gree_Service_Avatarfeed_Test_Processor_Comment_DeleteTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
    }

    /**
     * test1: success delete comment
     * expect: is_delete == true, comment_id == string
     *
     * text2: failed delete, comment_id is not specified
     * expect: is_delete == false, comment_id == null
     *
     * test3: failed delete, comment is already deleted
     * expect: is_delete == false, comment_id == null
     *
     * text4: failed delete, entry_id is not specified
     * expect: is_delete == false, comment_id == null
     *
     * test5: failed delete, not own comment, not own entry
     * expect: is_delete == false, comment_id == null
     *
     * test6: success delete, not own comment, own entry
     * expect: is_delete == false, comment_id == null
     */
    public function test_delete_comment()
    {
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_success_create_entry);

        // test1
        $text_1 = 'delete comment';
        list($is_create_comment_1, $comment_id_1) = $this->_createComment($text_1, $entry_id);
        $this->assertTrue($is_create_comment_1);
        $this->assertFalse(is_null($comment_id_1));

        $delete_params = array(
            'comment_id'        => $comment_id_1,
            'parent_entry_id'   => $entry_id,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_delete_success_1, $delete_comment_id_1) = $this->avatar_feed->process('comment_delete', $delete_params);

        $this->assertTrue($is_delete_success_1);
        $this->assertFalse(is_null($delete_comment_id_1));


        $text_2 = 'delete comment2';
        list($is_create_comment_2, $comment_id_2) = $this->_createComment($text_2, $entry_id);
        $this->assertTrue($is_create_comment_2);
        $this->assertFalse(is_null($comment_id_2));

        // test2
        $delete_params_2 = array(
            'parent_entry_id'   => $entry_id,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_delete_success_2, $delete_comment_id_2) = $this->avatar_feed->process('comment_delete', $delete_params_2);

        $this->assertFalse($is_delete_success_2);
        $this->assertTrue(is_null($delete_comment_id_2));

        // test3
        list($is_delete_success_3, $delete_comment_id_3) = $this->avatar_feed->process('comment_delete', $delete_params);

        $this->assertFalse($is_delete_success_3);
        $this->assertTrue(is_null($delete_comment_id_3));

        // test4
        $delete_params_3 = array(
            'comment_id'        => $comment_id_2,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_delete_success_4, $delete_comment_id_4) = $this->avatar_feed->process('comment_delete', $delete_params_3);

        $this->assertFalse($is_delete_success_4);
        $this->assertTrue(is_null($delete_comment_id_4));

        // test5
        $delete_params_4 = array(
            'comment_id'        => $comment_id_2,
            'parent_entry_id'   => $entry_id,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_delete_success_5, $delete_comment_id_5) = $this->avatar_feed->process('comment_delete', $delete_params, UNIT_TEST_USER_ID_2);

        $this->assertFalse($is_delete_success_5);
        $this->assertTrue(is_null($delete_comment_id_5));

        // test6
        $text_6 = 'delete comment test 6';
        list($is_create_comment_6, $comment_id_6) = $this->_createComment($text_6, $entry_id, UNIT_TEST_USER_ID_2);
        $this->assertTrue($is_create_comment_6);
        $this->assertFalse(is_null($comment_id_6));

        $delete_params = array(
            'comment_id'        => $comment_id_6,
            'parent_entry_id'   => $entry_id,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_delete_success_6, $delete_comment_id_6) = $this->avatar_feed->process('comment_delete', $delete_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_delete_success_6);
        $this->assertFalse(is_null($delete_comment_id_6));
    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_comment_delete',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }

    public function _createComment($text, $entry_id, $create_user = UNIT_TEST_USER_ID_1)
    {
        $this->module->setUserIDtoCtfy($create_user);
        $create_params = array(
            'text'              => $text,
            'entry_id'          => $entry_id,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_create_success, $comment_id) = $this->module->createComment($create_params);

        return array(
            $is_create_success,
            $comment_id
        );
    }
}


