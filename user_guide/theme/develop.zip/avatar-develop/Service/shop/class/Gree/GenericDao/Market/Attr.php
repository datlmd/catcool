<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Gree_GenericDao_Market_Attr
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_AttrDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name        = 'market_attr';

    /** @var primary key */
    var $_primary_key       = array('market_id', 'attr_key');

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'market_id',
        'attr_key',
        'value',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        'find_by_market' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE market_id = :market_id',
        ),
        // {{{ find value
        'find_value_by_market_id_and_attr_key' => array(
            'sql' => 'SELECT value FROM __TABLE_NAME__ WHERE market_id = :market_id AND attr_key= :attr_key',
        ),
        // }}}

        // {{{ update queries
        'create_or_update' => array(
            'sql' => '
                INSERT INTO
                    __TABLE_NAME__
                    (market_id, attr_key, value, ctime)
                VALUES
                    (:market_id, :attr_key, :value, NOW())
                ON DUPLICATE KEY UPDATE
                    value = :value
            ',
        ),
        'delete_by_market_key' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE market_id = :market_id AND attr_key = :attr_key',
        ),
        'delete_group_items_by_market' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE market_id = :market_id AND attr_key like \'group_code_%\'',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    market_id   INT(11)         UNSIGNED NOT NULL,
                    attr_key    VARCHAR(255)    NOT NULL,
                    value       TEXT            NOT NULL,
                    ctime       DATETIME        NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime       TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (market_id, attr_key)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
