<?php
/**
 * Service/shop/class/Gree/Data/User/Tutorial.php
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */

require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Tutorial/Entry.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Tutorial/InviteMaster.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Tutorial/InviteSuccess.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Tutorial/InviteIncentive.php';

/**
 * Gree_Service_Shop_Data_User_Tutorial
 *
 * @package GREE
 * @access  public
 */
class Gree_Service_Shop_Data_User_Tutorial extends Gree_Service_Shop_Data_Abstract
{
    private $_session   = null;

    // {{{ dao name
    private $_dao_name_tutorial_entry   = "Shop_Tutorial_Entry";
    private $_dao_name_invite_master    = "Shop_Tutorial_InviteMaster";
    private $_dao_name_invite_success   = "Shop_Tutorial_InviteSuccess";
    private $_dao_name_invite_incentive = "Shop_Tutorial_InviteIncentive";
    // }}}

    // {{{ __construct
    /**
     * Gree_Service_Shop_Data_User_Tutorial
     *
     * @access public
     */
    public function __construct()
    {
        $this->_session = Gree_GenericDao_SessionFactory::openSession();
    }
    // }}}

    //--------------------------------------------------------------------------
    // entry dao
    //--------------------------------------------------------------------------

    // {{{ getEntry
    /**
     * @access  public
     * @param   int     $user_id
     * @return  array   entry data
     */
    public function getEntry($user_id)
    {
        $entry_data = $this->_session->toArray($this->_dao_name_tutorial_entry, 'find_by_user', array('user_id' => $user_id));
        if (isset($entry_data[0])) {
            return $entry_data[0];
        }
        return false;
    }
    // }}}

    // {{{ setEntry
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $from_user_id
     * @param   string  $from_tag
     * @return  int     affected row count
     */
    public function setEntry($user_id, $from_user_id, $from_tag)
    {
        $hint = array(
            'user_id'       => $user_id,
            'from_user_id'  => $from_user_id,
            'from_tag'      => $from_tag,
            'tutorial_step' => 1,
            'status'        => GREE_SERVICE_SHOP_TUTORIAL_STATUS_UNCOMPLETE,
        );

        // �Х륯��Ͽ�ʵ���塼�ȥꥢ��򥯥ꥢ���Ƥ����
        if ($from_tag == 'bulk') {
            $hint['tutorial_step']  = 0;
            $hint['status']         = GREE_SERVICE_SHOP_TUTORIAL_STATUS_COMPLETE;
        }

        return $this->_session->execute($this->_dao_name_tutorial_entry, 'entry', $hint);
    }
    // }}}

    // {{{ stepUp
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $step
     * @return  int     affected row count
     */
    public function stepUp($user_id, $step, $force=false)
    {
        $hint = array(
            'user_id'       => $user_id,
            'tutorial_step' => $step,
        );
        if ($force) {
            return $this->_session->execute($this->_dao_name_tutorial_entry, 'force_step_up', $hint);
        } else {
            return $this->_session->execute($this->_dao_name_tutorial_entry, 'step_up', $hint);
        }
    }
    // }}}

    // {{{ complete
    /**
     * @access  public
     * @param   int     $user_id
     * @return  int     affected row count
     */
    public function complete($user_id)
    {
        return $this->_session->execute($this->_dao_name_tutorial_entry, 'complete', array('user_id' => $user_id));
    }
    // }}}

    // {{{ force_complete
    /**
     * @access  public
     * @param   int     $user_id
     * @return  int     affected row count
     */
    public function force_complete($user_id)
    {
        return $this->_session->execute($this->_dao_name_tutorial_entry, 'force_complete', array('user_id' => $user_id));
    }
    // }}}

    // {{{ update
    /**
     * @access  public
     * @param   int     $user_id(target_user_id)
     * @return  int     affected row count
     */
    public function updateFromUserId($user_id, $add_user_id)
    {
        $hint = array(
            'user_id'   => $user_id,
            'from_user_id'  => $add_user_id,
        );
        return $this->_session->execute($this->_dao_name_tutorial_entry, 'update_from_user_id', $hint);
    }
    // }}}

    //--------------------------------------------------------------------------
    // invite master dao
    //--------------------------------------------------------------------------

    // {{{ getAllMaster
    /**
     * @access  public
     * @return  array   all master data
     */
    public function getAllMaster()
    {
        return $this->_session->toArray($this->_dao_name_invite_master, 'get_all', array());
    }
    // }}}

    // {{{ getMaster
    /**
     * @access  public
     * @param   int     $master_id
     * @return  array   master data
     */
    public function getMaster($master_id)
    {
        $master = $this->_session->toArray($this->_dao_name_invite_master, 'find_by_user', array('master_id' => $master_id));
        if (isset($master[0])) {
            return $master[0];
        }
        return false;
    }
    // }}}

    // {{{ createMaster
    /**
     * @access  public
     * @param   datetime    $open_time
     * @param   datetime    $close_time
     * @param   string      $incentives
     * @return  int         affected row count
     */
    public function createMaster($open_time, $close_time, $incentives)
    {
        $hint = array(
            'open_time'     => $open_time,
            'close_time'    => $close_time,
            'incentives'    => $incentives,
        );
        return $this->_session->execute($this->_dao_name_invite_master, 'create', $hint);
    }
    // }}}

    // {{{ updateMaster
    /**
     * @access  public
     * @param   int         $master_id
     * @param   datetime    $open_time
     * @param   datetime    $close_time
     * @param   string      $incentive
     * @return  int         affected row count
     */
    public function updateMaster($master_id, $open_time, $close_time, $incentive)
    {
        $hint = array(
            'id'            => $master_id,
            'open_time'     => $open_time,
            'close_time'    => $close_time,
            'incentives'    => $incentives,
        );
        return $this->_session->execute($this->_dao_name_invite_master, 'update', $hint);
    }
    // }}}

    //--------------------------------------------------------------------------
    // invite success dao
    //--------------------------------------------------------------------------

    // {{{ getSuccess
    /**
     * @access  public
     * @param   int     $user_id
     * @return  array   invite success data
     */
    public function getSuccess($user_id)
    {
        return $this->_session->toArray($this->_dao_name_invite_success, 'find_by_user_id', array('user_id' => $user_id));
    }
    // }}}

    // {{{ getSuccessCount
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $campaign_id
     * @return  int     invite success count
     */
    public function getSuccessCount($user_id, $campaign_id)
    {
        $hint = array(
            'user_id'       => $user_id,
            'campaign_id'   => $campaign_id,
        );
        $count = $this->_session->toValue($this->_dao_name_invite_success, 'get_count_by_user_and_campaign', $hint);

        return $count;
    }
    // }}}

    // {{{ setSuccess
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $entry_user_id
     * @param   int     $campaign_id
     * @return  int     affected row count
     */
    public function setSuccess($user_id, $entry_user_id, $campaign_id)
    {
        $hint = array(
            'user_id'       => $user_id,
            'entry_user_id' => $entry_user_id,
            'campaign_id'   => $campaign_id,
        );
        return $this->_session->execute($this->_dao_name_invite_success, 'create', $hint);
    }
    // }}}

    //--------------------------------------------------------------------------
    // invite incentive dao
    //--------------------------------------------------------------------------

    // {{{ getReceivedIncentive
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $campaign_id
     * @param   int     $invite_count
     * @return  array   incentive receive data
     */
    public function getReceivedIncentive($user_id, $campaign_id, $invite_count = 0)
    {
        $hint = array(
            'user_id'       => $user_id,
            'campaign_id'   => $campaign_id,
            'invite_count'  => $invite_count,
        );
        if (empty($invite_count)) {
            $received_data = $this->_session->toArray($this->_dao_name_invite_incentive, 'find_by_user_and_campaign', $hint);
        } else {
            $received_data = $this->_session->toArray($this->_dao_name_invite_incentive, 'find_by_incentive', $hint);
        }
        return $received_data;
    }
    // }}}

    // {{{ setReceivedIncentive
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $campaign_id
     * @param   int     $invite_count
     * @return  int     affected row count
     */
    public function setReceivedIncentive($user_id, $campaign_id, $invite_count)
    {
        $hint = array(
            'user_id'       => $user_id,
            'campaign_id'   => $campaign_id,
            'invite_count'  => $invite_count,
        );
        return $this->_session->execute($this->_dao_name_invite_incentive, 'create', $hint);
    }
    // }}}
}
