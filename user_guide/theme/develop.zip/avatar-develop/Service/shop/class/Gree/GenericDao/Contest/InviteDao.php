<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/InviteDao.php
 *
 *  @author   Adib Gholaminezhad <adib.gholaminezhad@gree.co.jp>
 *  @package  GREE
 *  @version  $Id$
 */
class Gree_GenericDao_Contest_InviteDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'contest_invite';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_contest';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_contest';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array('id', 'user_id', 'accepted' ,'target_id', 'mtime', 'ctime');
      
	/** @var ������ */
	var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                    int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id`               int(11) unsigned NOT NULL default '0',
                    `target_id`             int(10) unsigned NOT NULL default '0',
                    `accepted`              int(10) unsigned NOT NULL default '0',
                    `mtime`                 timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`                 datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    KEY (`target_id`),
                    UNIQUE KEY `user_id` (`user_id`,`target_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE IF EXISTS __TABLE_NAME__',
        ),
        'replace' => array(
            'sql' => 'REPLACE INTO __TABLE_NAME__ (user_id, target_id, mtime, ctime) VALUES (:user_id, :target_id, :modify_time, :ctime)'
        ),
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ IGNORE INDEX(PRIMARY) WHERE user_id = :user_id ORDER BY id DESC'
        ),
        'find_by_target_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ IGNORE INDEX(PRIMARY) WHERE target_id = :target_id ORDER BY id DESC'
        ),
        'count_by_user_id' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'find_by_target_id_and_accepted' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE target_id = :user_id and accepted <> 0'
        ),
        'count_by_user_id_and_accepted' => array(
            'sql' => 'SELECT COUNT(*) as cnt FROM __TABLE_NAME__ WHERE user_id = :user_id and accepted <> 0'
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
	    'update_accepted_all' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET accepted=:accepted where target_id=:target_id'
        ),
	    'update_accepted_final' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET accepted=:accepted where accepted=:old_accepted and target_id=:target_id'
        ),
        'delete_user_for_debug' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE user_id=:user_id",
        ),
        'delete_target_user_for_debug' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE target_id=:target_id",
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Contest_InviteFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Contest/InviteDao.php
 *
 *  @package  GREE
 *  @version  $Id$
 */
class Gree_GenericDao_Contest_InviteFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        if (empty($hint)) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾�˥ե�������ɲ�
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['contest_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
