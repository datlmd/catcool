<?php
/**
 * Class Gree_Service_AvatarFeed_Processor_Block_Get
 *
 * @author  katsumi.zeniya
 */
class Gree_Service_AvatarFeed_Processor_Block_Get
    extends Gree_Service_AvatarFeed_Processor_Base
{
    // {{{ invoke
    /**
     * get block data
     *
     * @return boolean
     */
    protected function invoke()
    {
        $is_block = false;

        if ($this->input_values['block_user_id'] == $this->input_values['user_id']) {
            return $is_block;
        }
        $mod_block = self::getModule('Block');
        $is_block  = $mod_block->getBlockUser($this->input_values['block_user_id'], $this->input_values['user_id']);

        return $is_block;
    }
    // }}}
}
