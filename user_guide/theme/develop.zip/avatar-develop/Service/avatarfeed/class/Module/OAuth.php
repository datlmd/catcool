<?php

require_once GREE_SERVICE_AVATAR_ROOT . '/lib/OAuth.php';

class Gree_Service_AvatarFeed_Module_OAuth
    extends Gree_Service_AvatarFeed_Module_Base
{
    // request params
    var $body   = null;
    var $method = null;
    var $type   = null;
    var $url    = null;

    var $accessor_oauth;

    public function generateAuthorizationHeader()
    {
        $oauth_consumer    = new OAuthConsumer(GREE_SERVICE_AVATARFEED_CONSUMER_KEY, GREE_SERVICE_AVATARFEED_CONSUMER_SECRET);
        $oauth_token       = $this->_getOAuthToken();
        $adding_parameters = array('oauth_body_hash' => base64_encode(sha1($this->body, true)));

        $oauth_request = OAuthRequest::from_consumer_and_token(
            $oauth_consumer,
            $oauth_token,
            $this->method,
            $this->url,
            $adding_parameters
        );
        $oauth_request->sign_request(
            new OAuthSignatureMethod_HMAC_SHA1(),
            $oauth_consumer,
            $oauth_token
        );
        $authorization_header = substr($oauth_request->to_header(), strlen('Authorization: '));

        return $authorization_header;
    }

    public function _getOAuthToken()
    {
        $oauth_token = null;
        if ($this->type == "request") {
            $access_token = $this->getAccessToken();
            $oauth_token  = new OAuthToken(
                $access_token['access_key'],
                $access_token['access_secret']
            );
        }

        return $oauth_token;
    }

    public function getAccessToken()
    {
        $this->accessor_oauth = Cascade::getAccessor('avatar_feed#oauth');
        $find_values = array(
            'user_id' => $this->_certified_user->my['user_id'],
        );
        $find_result = $this->accessor_oauth->findFirst('find_by_user_id', $find_values);

        if (is_null($find_result)) {
            $access_token = $this->createAccessToken();
            $this->saveAccessToken($access_token);
        }else{
            $access_token = array(
                'access_key'    => $find_result['access_key'],
                'access_secret' => $find_result['access_secret']
            );
        }

        return $access_token;
    }

    public function createAccessToken()
    {
        $access_token = array(
            'access_key'    => '',
            'access_secret' => ''
        );

        $srv_oauth = getService('oauth');
        $consumer  = $srv_oauth->getConsumer(GREE_SERVICE_AVATARFEED_APP_ID);
        if (PEAR::isError($consumer)) {
            // application with $application_id is not found.
            throw new Gree_Service_AvatarFeed_Exception(
                'failed to get OAuth consumer',
                Gree_Service_AvatarFeed_Exception::E_OAuth_UNKNOWN
            );
        }

        $oauth_user = $consumer->getUser($this->_certified_user->my['user_id']);
        if (empty($oauth_user)) {
            $add_result = $consumer->addUser($this->_certified_user->my['user_id']);
            if (PEAR::isError($add_result)) {
                throw new Gree_Service_AvatarFeed_Exception(
                    'failed to create acceess token',
                    Gree_Service_AvatarFeed_Exception::E_OAuth_UNKNOWN
                );
            }
            $oauth_user = $consumer->getUser($this->_certified_user->my['user_id']);
        }
        if (PEAR::isError($oauth_user)) {
            throw new Gree_Service_AvatarFeed_Exception(
                'failed to get acceess token',
                Gree_Service_AvatarFeed_Exception::E_OAuth_UNKNOWN
            );
        }

        $access_token['access_key']    = $oauth_user['access_key'];
        $access_token['access_secret'] = $oauth_user['access_secret'];
        return $access_token;

    }

    public function saveAccessToken($access_token)
    {
        $save_value = array(
            'user_id'       => $this->_certified_user->my['user_id'],
            'access_key'    => $access_token['access_key'],
            'access_secret' => $access_token['access_secret'],
        );
        $this->accessor_oauth->execute('save', $save_value);
    }
}
