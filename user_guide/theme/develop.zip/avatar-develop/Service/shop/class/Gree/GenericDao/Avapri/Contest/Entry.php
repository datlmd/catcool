<?php
/**
 * Gree_GenericDao_AvapriContestEntryDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Contest_EntryDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'contest_entry';
	/** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'seal_id',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        // select----------------------
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id order by id desc',
        ),
        'find_by_user_id_and_seal_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND seal_id = :seal_id',
        ),
        'find_new_entry_seal' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ order by id desc',
        ),
        'count_all_entry_seal' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__',
        ),
        // insert----------------------
        'insert_entry_seal' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, seal_id, ctime) VALUES (:user_id, :seal_id, NOW())',
            'return_last_insert_id' => true,
        ),  
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                     `id`        INT(11)     UNSIGNED NOT NULL AUTO_INCREMENT,
                     `user_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                     `seal_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                     `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                     `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                 PRIMARY KEY  (`id`),
                 UNIQUE KEY `ids` (`user_id`,`seal_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE  IF EXISTS __TABLE_NAME__',
        ),
    );

    // {{{ _initFarmSelector
    function _initFarmSelector() {
        $this->_farm_selector = new Gree_GenericDao_Avapri_Contest_EntryFarmSelector();
    }
    // }}}
}
/**
 *  /home/gree/service/shop/class/GenericDao/Avapri/Contest/EntryFarmSelector.php
 *
 *  @author   Norie Matsuda <norie.matsuda@gree.net>
 *  @package  GREE
 */
class Gree_GenericDao_Avapri_Contest_EntryFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ getTableName
    /**
    *  get table name
    *
    *  @param      $dao        Dao class
    *  @param      $type       type
    *  @param      $hint       select table hint
    *  @return     string      table name
    */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['contest_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $contest_id = $hint['contest_id'];

        // get table name.
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is emptry. dao=" . get_class($dao) . "];");
        }
        $farm = $contest_id;
        $table_name = $original_table_name .'_'. $farm;
        return $table_name;
    }
    // }}}
}