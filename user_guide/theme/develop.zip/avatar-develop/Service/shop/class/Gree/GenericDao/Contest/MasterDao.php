<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Contest/Master.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: MasterDao.php 142132 2011-12-12 00:10:48Z ibuki $
 */

class Gree_GenericDao_Contest_MasterDao extends Gree_GenericDao_Apc {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'contest_master';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'contest_id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_contest';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_contest';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
	                          'contest_id',
							  'status',
							  'name',
							  'entry_open_datetime',
							  'entry_close_datetime',
							  'open_datetime',
							  'close_datetime',
							  'mtime',
							  'ctime'
							 );
      
	/** @var ������ */
	var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY contest_id DESC'
        ),
        'find_by_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id IN (:ids) ORDER BY contest_id desc'
        ),
        'find_by_contest_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id'
        ),
        // }}}
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `contest_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `status` TINYINT(2) NOT NULL DEFAULT '0',
                `name` VARCHAR(255) NOT NULL DEFAULT '',
                `entry_open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `entry_close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `open_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `close_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`contest_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__"
        ),
        // }}}
    ); 
}
