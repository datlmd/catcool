<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/MonthlyFarmSelector.php');
/**
 * Gree_GenericDao_Avapri_User_SealSendHistoryDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_User_SealSendHistoryDao extends Gree_GenericDao
{
	/** @var table name */
    var $_table_name = 'user_seal_send_history';
	/** @var primary key */
    var $_primary_key = 'send_history_id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'send_history_id',
        'seal_id',
        'user_id',
        'receive_user_id',
        'ctime',
        'mtime'
    );

    var $_queries = array( // ʣ�祭�� 
        // select----------------------
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY send_history_id DESC',
        ),
        // update----------------------
        
        // insert----------------------
        'insert_send_history' => array(
            'sql' =>  'INSERT INTO __TABLE_NAME__ (seal_id, user_id, receive_user_id, ctime) VALUES(:seal_id, :user_id, :receive_user_id, NOW())'
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `send_history_id` int(11) unsigned NOT NULL auto_increment,
                  `seal_id` int(11) unsigned NOT NULL,
                  `user_id` int(11) unsigned NOT NULL,
                  `receive_user_id` int(11) unsigned NOT NULL,
                  `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                  `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  PRIMARY KEY  (`send_history_id`),
                  KEY `user_seal_send_history_1` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'delete_table' => array(
                'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
    );
    
    function _init()
    {
        parent::_init();
        //require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/MonthlyFarmSelector.php');
    
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_MonthlyFarmSelector();
    }
}
?>
