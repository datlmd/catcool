<?php
/**
 * Service/shop/class/Gree/Data/Gacha/Coupon.php
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */

// {{{ status defined
define('GREE_SERVICE_SHOP_DATA_COUPON_STATUS_VALID',        0); // �����ݥ�ͭ��
define('GREE_SERVICE_SHOP_DATA_COUPON_STATUS_INVALID',      1); // �����ݥ���ѺѤ�
define('GREE_SERVICE_SHOP_DATA_COUPON_STATUS_EXPIRED',      2); // �����ݥ�����ڤ�

define('GREE_SERVICE_SHOP_DATA_COUPON_HISTORY_STATUS_GET',  0); // �����ݥ��������
define('GREE_SERVICE_SHOP_DATA_COUPON_HISTORY_STATUS_USE',  1); // �����ݥ���������
// }}}

require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Gacha/Coupon/User.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Gacha/Coupon/History.php';
require_once PATH_ROOT . '/service/shop/class/Gree/Data/Lib/Abstract.php';

/**
 * Gree_Service_Shop_Data_Gacha_Coupon
 *
 * @package GREE
 * @access  public
 */
class Gree_Service_Shop_Data_Gacha_Coupon extends Gree_Service_Shop_Data_Abstract
{
    protected $_shop_service            = null;
    protected $_session                 = null;
    protected $_format                  = array();

    // {{{ dao name
    private $_dao_name_coupon_user      = "Shop_Gacha_Coupon_User";
    private $_dao_name_coupon_history   = "Shop_Gacha_Coupon_History";
    // }}}

    // {{{ __construct
    /**
     * Gree_Service_Shop_Data_Gacha_Coupon
     *
     * @access  public
     */
    public function __construct()
    {
        $this->_shop_service    = getService('shop');
        $this->_session         = Gree_GenericDao_SessionFactory::openSession();
    }
    // }}}

    //--------------------------------------------------------------------------
    // �����ݥ����
    //--------------------------------------------------------------------------

    // {{{ getUserCoupon
    /**
     * @access  public
     * @param   int     $user_id
     * @return  array
     */
    public function getUserCoupon($user_id, $include_disabled = false)
    {
        if (empty($user_id)) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [CouponData]", $code="001");
        }

        $params = array(
            'user_id'   => abs($user_id),
        );
        $user_data = null;
        if ($include_disabled) {    // for support tool
            $user_data = $this->_session->toArray($this->_dao_name_coupon_user, 'find_by_user', $params);
        } else {
            $user_data = $this->_session->toArray($this->_dao_name_coupon_user, 'find_valid_coupon_by_user', $params);
        }
        if (isset($user_data[0])) {
            return $user_data[0];
        } else {
            return array();
        }
    }
    // }}}

    // {{{ createUserCoupon
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $gacha_id
     * @param   int     $price
     * @param   int     $expire_minutes
     * @return  bool
     */
    public function createUserCoupon($user_id, $gacha_id, $price, $expire_minutes)
    {
        if (empty($user_id) || empty($gacha_id) || empty($price) || empty($expire_minutes)) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [CouponData]", $code="002");
        }
        // calc expire_time
        $now_unixtime   = strtotime($this->_shop_service->getDate());
        $expire_time    = date("Y-m-d H:i:s", strtotime("+ $expire_minutes minute", $now_unixtime));

        $params = array(
            'user_id'       => abs($user_id),
            'gacha_id'      => abs($gacha_id),
            'price'         => abs($price),
            'expire_time'   => $expire_time,
        );
        return $this->_session->execute($this->_dao_name_coupon_user, 'validate', $params);
    }
    // }}}

    // {{{ deleteUserCoupon
    /**
     * @access  public
     * @param   int     $user_id
     * @return  bool
     */
    public function deleteUserCoupon($user_id, $status)
    {
        $status_list = array(
            GREE_SERVICE_SHOP_DATA_COUPON_STATUS_INVALID,       // used
            GREE_SERVICE_SHOP_DATA_COUPON_STATUS_EXPIRED,       // expired
        );
        if (empty($user_id) || in_array($status, $status_list) === false) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [CouponData]", $code="003");
        }
        $params = array(
            'user_id'   => abs($user_id),
            'status'    => abs($status),
        );
        return $this->_session->execute($this->_dao_name_coupon_user, 'invalidate', $params);
    }
    // }}}

    //--------------------------------------------------------------------------
    // �ҥ��ȥ꡼����
    //--------------------------------------------------------------------------

    // {{{ getHistory
    /**
     * @access  public
     * @param   int     $user_id
     * @return  array
     */
    public function getHistory($user_id)
    {
        if (empty($user_id)) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [CouponData]", $code="004");
        }
        return $this->_session->toArray($this->_dao_name_coupon_history, 'find_by_user', array('user_id' => $user_id));
    }
    // }}}

    // {{{ setHistory
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $gacha_id
     * @param   int     $price
     * @param   varchar $action_name
     * @param   int     $status
     * @return  bool
     */
    public function setHistory($user_id, $gacha_id, $price, $action_name, $status)
    {
        $status_list = array(
            GREE_SERVICE_SHOP_DATA_COUPON_HISTORY_STATUS_GET,   // get coupon
            GREE_SERVICE_SHOP_DATA_COUPON_HISTORY_STATUS_USE,   // use coupon
        );
        if (empty($user_id) || empty($gacha_id) || empty($price) || empty($action_name) || !in_array($status, $status_list)) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [CouponData]", $code="005");
        }
        $params = array(
            'user_id'       => abs($user_id),
            'gacha_id'      => abs($gacha_id),
            'price'         => abs($price),
            'action_name'   => $action_name,
            'status'        => abs($status),
        );
        return $this->_session->execute($this->_dao_name_coupon_history, 'create', $params);
    }
    // }}}
}
