<?php

final class Gree_Service_Avatarfeed_Test_Processor_Score_Increment
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $score_category = 'test';
    var $score_cycle    = 'daily';
    var $score_date;

    var $module_score;

    public function setUp()
    {
        $this->score_date = date('Ymd');

        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();
        $this->module_score = Gree_Service_AvatarFeed_Module::singleton('Score');

        $this->initialize_flare_data();
    }

    /**
     * story1 is increment of first
     * failed first incremented because not exist key
     * success add key
     * success add top score list of first
     */
    public function test_story_1()
    {
        $increment_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => $this->score_category,
            'date'     => $this->score_date,
            'cycle'    => $this->score_cycle,
        );

        $is_score_incremented = $this->avatar_feed->process('score_increment', $increment_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_score_incremented);

        // check score
        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        list($value, $token) = $this->module_score->get($this->score_cycle, $score_key);

        $this->assertEquals(1, $value);

        // check top score list
        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $this->assertTrue(array_key_exists(UNIT_TEST_USER_ID_1, $top_score_list));
        $this->assertEquals(1, $top_score_list[UNIT_TEST_USER_ID_1]);
    }

    /**
     * story1_1 is increment of first
     * failed first incremented because not exist key
     * success add key
     * failed add top score list
     */
    public function test_story_1_1()
    {
        // prepare
        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $top_score_list = 'incorrect data';
        $is_added_list = $this->module_score->add($this->score_cycle, $top_score_list_key, $top_score_list);
        $this->assertTrue($is_added_list);

        $increment_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => $this->score_category,
            'date'     => $this->score_date,
            'cycle'    => $this->score_cycle,
        );

        $is_score_incremented = $this->avatar_feed->process('score_increment', $increment_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($is_score_incremented);

        // check score
        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        list($value, $token) = $this->module_score->get($this->score_cycle, $score_key);

        $this->assertEquals(1, $value);

        // check top score list
        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $this->assertEquals('incorrect data', $top_score_list);
    }

    /**
     * story2 is increment of not first
     * success increment key
     * success insert score to top score list(exist target && incremented value is upper than before )
     */
    public function test_story_2()
    {
        //prepare
        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        $is_added_score = $this->module_score->add($this->score_cycle, $score_key);
        $this->assertTrue($is_added_score);

        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $top_score_list = array(
            'min'               => 1,
            UNIT_TEST_USER_ID_1 => 1
        );
        $is_added_list = $this->module_score->add($this->score_cycle, $top_score_list_key, $top_score_list);
        $this->assertTrue($is_added_list);

        // do processor
        $increment_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => $this->score_category,
            'date'     => $this->score_date,
            'cycle'    => $this->score_cycle,
        );

        $is_score_incremented = $this->avatar_feed->process('score_increment', $increment_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_score_incremented);

        // check score
        list($value, $token) = $this->module_score->get($this->score_cycle, $score_key);

        $this->assertEquals(2, $value);

        // check top score list
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $this->assertTrue(array_key_exists(UNIT_TEST_USER_ID_1, $top_score_list));
        $this->assertEquals(2, $top_score_list[UNIT_TEST_USER_ID_1]);
    }

    /**
     * story2_1 is increment of not first
     * success increment key
     * success insert score to top score list(exist target && incremented value is lower than before )
     */
    public function test_story_2_1()
    {
        //prepare
        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        $is_added_score = $this->module_score->add($this->score_cycle, $score_key, 10);
        $this->assertTrue($is_added_score);

        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $top_score_list = array(
            'min'               => 10,
            UNIT_TEST_USER_ID_1 => 10
        );
        $is_added_list = $this->module_score->add($this->score_cycle, $top_score_list_key, $top_score_list);
        $this->assertTrue($is_added_list);

        // do processor
        $increment_params = array(
            'user_id'           => UNIT_TEST_USER_ID_1,
            'category'          => $this->score_category,
            'date'              => $this->score_date,
            'cycle'             => $this->score_cycle,
            'is_retry'          => true,
            'incremented_value' => 1,
        );

        $is_score_incremented = $this->avatar_feed->process('score_increment', $increment_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($is_score_incremented);

        // check score
        list($value, $token) = $this->module_score->get($this->score_cycle, $score_key);

        $this->assertEquals(10, $value);

        // check top score list
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $this->assertTrue(array_key_exists(UNIT_TEST_USER_ID_1, $top_score_list));
        $this->assertEquals(10, $top_score_list[UNIT_TEST_USER_ID_1]);
    }

    /**
     * story2_2 is increment of not first
     * success increment key
     * success insert score to top score list(not exist target && within list limit && incremented value is upper than before )
     */
    public function test_story_2_2()
    {
        //prepare
        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        $is_added_score = $this->module_score->add($this->score_cycle, $score_key);
        $this->assertTrue($is_added_score);

        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $top_score_list = array(
            'min'               => 1,
            UNIT_TEST_USER_ID_1 => 1
        );
        $is_added_list = $this->module_score->add($this->score_cycle, $top_score_list_key, $top_score_list);
        $this->assertTrue($is_added_list);

        // do processor
        $increment_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
            'category' => $this->score_category,
            'date'     => $this->score_date,
            'cycle'    => $this->score_cycle,
        );

        $is_score_incremented = $this->avatar_feed->process('score_increment', $increment_params, UNIT_TEST_USER_ID_2);

        $this->assertTrue($is_score_incremented);

        // check score
        list($value, $token) = $this->module_score->get($this->score_cycle, $score_key);

        $this->assertEquals(1, $value);

        // check top score list
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $this->assertTrue(array_key_exists(UNIT_TEST_USER_ID_1, $top_score_list));
        $this->assertTrue(array_key_exists(UNIT_TEST_USER_ID_2, $top_score_list));
        $this->assertEquals(1, $top_score_list[UNIT_TEST_USER_ID_1]);
        $this->assertEquals(1, $top_score_list[UNIT_TEST_USER_ID_2]);
    }

    /**
     * story2_3 is increment of not first
     * success increment key
     * success insert score to top score list(not exist target && outside list limit && incremented value is upper than before && over threshold)
     */
    public function test_story_2_3()
    {
        //prepare
        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        $is_added_score = $this->module_score->add($this->score_cycle, $score_key, 101);
        $this->assertTrue($is_added_score);

        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $top_score_list = $this->_create_dummy_top_score_list();
        $is_added_list = $this->module_score->add($this->score_cycle, $top_score_list_key, $top_score_list);
        $this->assertTrue($is_added_list);

        // do processor
        $increment_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => $this->score_category,
            'date'     => $this->score_date,
            'cycle'    => $this->score_cycle,
        );

        $is_score_incremented = $this->avatar_feed->process('score_increment', $increment_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_score_incremented);

        // check score
        list($value, $token) = $this->module_score->get($this->score_cycle, $score_key);

        $this->assertEquals(102, $value);

        // check top score list
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $this->assertTrue(array_key_exists(UNIT_TEST_USER_ID_1, $top_score_list));
        $this->assertEquals(102, $top_score_list[UNIT_TEST_USER_ID_1]);

        $min = $top_score_list['min'];
        arsort($top_score_list);
        $this->assertEquals($min, array_pop($top_score_list));
    }

    /**
     * story2_4 is increment of not first
     * success increment key
     * success insert score to top score list(not exist target && outside list limit && incremented value is upper than before && lower threshold)
     */
    public function test_story_2_4()
    {
        //prepare
        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        $is_added_score = $this->module_score->add($this->score_cycle, $score_key, 1);
        $this->assertTrue($is_added_score);

        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $top_score_list = $this->_create_dummy_top_score_list();
        $is_added_list = $this->module_score->add($this->score_cycle, $top_score_list_key, $top_score_list);
        $this->assertTrue($is_added_list);

        // do processor
        $increment_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => $this->score_category,
            'date'     => $this->score_date,
            'cycle'    => $this->score_cycle,
        );

        $is_score_incremented = $this->avatar_feed->process('score_increment', $increment_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($is_score_incremented);

        // check score
        list($value, $token) = $this->module_score->get($this->score_cycle, $score_key);

        $this->assertEquals(2, $value);

        // check top score list
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $this->assertFalse(array_key_exists(UNIT_TEST_USER_ID_1, $top_score_list));

        $min = $top_score_list['min'];
        arsort($top_score_list);
        $this->assertEquals($min, array_pop($top_score_list));
    }

    /**
     *

    public function test_story_3()
    {
        //prepare

        $score_key = $this->module_score->_getScoreKey($this->score_category, UNIT_TEST_USER_ID_1, $this->score_date);
        $is_added_score = $this->module_score->add($this->score_cycle, $score_key, 100);
        $this->assertTrue($is_added_score);

        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $top_score_list = $this->_create_dummy_top_score_list();
        $is_added_list = $this->module_score->add($this->score_cycle, $top_score_list_key, $top_score_list);
        $this->assertTrue($is_added_list);

        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);

        $async_params = array(
            'is_retry'          => true,
            'user_id'           => UNIT_TEST_USER_ID_1,
            'category'          => $this->score_category,
            'date'              => $this->score_date,
            'cycle'             => $this->score_cycle,
            'incremented_value' => '200',
        );
        Gree_Async::add('shop::avatarfeed', 'incrementScore', null, $async_params);
        $async_params = array(
            'is_retry'          => true,
            'user_id'           => UNIT_TEST_USER_ID_1,
            'category'          => $this->score_category,
            'date'              => $this->score_date,
            'cycle'             => $this->score_cycle,
            'incremented_value' => '300',
        );
        Gree_Async::add('shop::avatarfeed', 'incrementScore', null, $async_params);

        // check top score list
        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);
        //error_log(print_r($top_score_list[UNIT_TEST_USER_ID_1],true));

        sleep(10);

        list($top_score_list, $token) = $this->module_score->get($this->score_cycle, $top_score_list_key);
        //error_log(print_r($top_score_list[UNIT_TEST_USER_ID_1],true));

    }
     * */

    public function initialize_flare_data()
    {
        $used_test_user_list = array(
            UNIT_TEST_USER_ID_1,
            UNIT_TEST_USER_ID_2,
        );

        foreach ($used_test_user_list as $user_id) {
            $score_key = $this->module_score->_getScoreKey($this->score_category, $user_id, $this->score_date);
            $is_success = $this->module_score->delete($this->score_cycle, $score_key);

            if ($is_success == false) {
                printf('failed initialized. score_key is ' . $score_key . "\n");
            }
        }

        $top_score_list_key = $this->module_score->_getTopScoreListKey($this->score_category, $this->score_date);
        $is_success = $this->module_score->delete($this->score_cycle, $top_score_list_key);
        if ($is_success == false) {
            printf('failed initialized. top_score_list_key is ' . $top_score_list_key . "\n");
        }
    }

    public function _create_dummy_top_score_list($user_count = 100)
    {
        $top_score_list = array();

        while (count($top_score_list) < $user_count) {
            $dummy_user_id = mt_rand(1, 500000);
            $dummy_score = mt_rand(10, 100);
            $top_score_list[$dummy_user_id] = $dummy_score;
        }

        arsort($top_score_list);
        $sorted_top_score_list = $top_score_list;
        $top_score_list['min'] = array_pop($sorted_top_score_list);

        return $top_score_list;
    }
}