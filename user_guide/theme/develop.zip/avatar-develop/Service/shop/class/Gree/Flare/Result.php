<?php
/**
 * service/shop/class/Flare/Reesult.php
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare.php';

class Gree_Service_Shop_Flare_Result extends Gree_Service_Shop_Flare
{
    public function __construct() {}

    // Cache Life Time
    protected function getExpireTime() {
        return 600;
    }
    protected function getNameSpace() {
        return 'result';
    }

    // try count
    const CAS_LOOP = 16;

    // {{{ getResult
    /**
     * check token is valid
     *
     * @access  public
     * @return  boolean
     */
    public function getResult($user_id, $key, $token) {
        if (empty($user_id) || empty($key) || empty($token)) {
            throw new Gree_Service_Shop_Exception('system error(FLRLT)', $code = '1000');
        }
        for ($i = 0 ; $i < self::CAS_LOOP ; $i++) {
            try {
                $ret = parent::get(self::getNameSpace() . '_' . $key . '_' . $user_id);

                if (!$ret) {
                    usleep(mt_rand(1, 100));
                    continue;
                }
            } catch (Exception $e) {
                if($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                    return false;
                }
            }

            list($val, $ver) = $ret;
            if (!empty($val['value']) && !empty($val['token']) && $val['token'] === $token) {
                return $val['value'];
            }

            if ($i < self::CAS_LOOP) {
                usleep(mt_rand(1, 100));
                continue;
            }
        }
        return false;
    }
    // }}}
    // {{{ setResult
    /**
     * check token is valid
     *
     * @access  public
     * @return  boolean
     */
    public function setResult($user_id, $key, $val, $token) {
        if (empty($user_id) || empty($key) || empty($val) || empty($token)) {
            throw new Gree_Service_Shop_Exception('system error(FLRLT)', $code = '2000');
        }
        $hint = array(
            'value' => $val,
            'token' => $token,
        );
        try {
            $ret = parent::set(self::getNameSpace() . '_' . $key . '_' . $user_id, $hint);
        } catch (Exception $e) {
            // no action for exception
        }

        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }
    // }}}

    // public =>  private
    public function set($key, $val) { throw new Exception(); }
    public function get($key) { throw new Exception(); }
    public function cas($key, $val, $version) { throw new Exception(); }
}
