<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Entry_Create_RecentCoordinate
 */
class Gree_Service_AvatarFeed_Processor_Entry_Create_RecentCoordinate
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;
    var $mod_follow;
    var $followed_count;

    /**
     * @return array|void
     *
     * return array has is_success and etnry_id
     *
     * flow is
     *     - set create prams
     *     - create Entry
     */
    protected function invoke()
    {
        try {
            $this->mod_follow = self::getModule('Follow');
            $is_following     = $this->mod_follow->getFollowingUser(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);

            if ($is_following == false) {
                return false;
            }

            $this->mod_appfeed = self::getModule('AppFeed');

            $add_params = array(
                'entry_id'     => $this->input_values['entry_id'],
                'destinations' => array(
                    array(
                        'type'  => 'feed_key',
                        'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID
                    )
                ),
            );
            $this->mod_appfeed->addDestination($add_params);
        } catch (Exception $e) {
            $msg     = 'failed create feed entry on recent coordinate.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_CREATE_RECENT_COORDINATE;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return false;
        }

        return true;
    }

    /**
     * @return array|bool
     *
     * set create params
     */
    public function _getCreateParams()
    {
        if (isset($this->input_values['avatar_key'])) {
            // continue
        } else {
            return false;
        }

        $create_params = array(
            'content'      => array(
                'sender_id'  => $this->_certified_user->my['user_id'],
                'entry_type' => 'activity',
                'text'       => GREE_SERVICE_AVATARFEED_DEFAULT_CHANGE_TEXT,
                'attr'       => array(
                    'entry_category' => 'change',
                    'avatar_key'     => $this->input_values['avatar_key']
                ),
            ),
            'destinations' => array(
                array(
                    'type'  => 'feed_key',
                    'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID
                )
            ),
        );

        return $create_params;
    }
}
