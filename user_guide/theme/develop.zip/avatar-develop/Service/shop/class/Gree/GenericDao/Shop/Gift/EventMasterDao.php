<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Shop/Gift/EventMasterDao.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Shop_Gift_EventMasterDao extends Gree_GenericDao_Apc
{
    /** @var �ơ��֥�̾ */
    var $_table_name = 'gift_event_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'gift_shop_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gift';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gift';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array('gift_shop_id', 'name', 'status', 'start_date', 'end_date', 'mtime', 'ctime',);

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(             // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY gift_shop_id DESC',
        ),
        'find_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gift_shop_id=:gift_shop_id',
        ),
        // }}}

        // {{{ ��������������
        'insert' => array(          // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (gift_shop_id, name, start_date, end_date, ctime) VALUES(:gift_shop_id, :name, :start_date, :end_date, NOW())',
        ),
        'update_by_gift_shop_id' => array(  // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET name=:name, status=:status, start_date=:start_date, end_date=:end_date WHERE gift_shop_id=:gift_shop_id',
        ),
        // }}}

        // {{{ �ơ��֥����
        'create_table' => array(    // for batch
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                gift_shop_id INT(11) UNSIGNED NOT NULL,
                name VARCHAR(255) NOT NULL DEFAULT '',
                status TINYINT(4) NOT NULL default '0',
                start_date DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                end_date DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                mtime TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                ctime DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`gift_shop_id`)
            ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

}
