<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Daily/HistoryDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: HistoryDao.php 142694 2011-12-22 00:40:19Z takashi-taniguchi $
 */
class Gree_GenericDao_Gacha_Daily_HistoryDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */ 

    /** @var �ơ��֥�̾ */
    var $_table_name = 'gacha_daily_history';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �ե�����ɥ����̾ */
    var $_field_names = array(
        'user_id',
        'gacha_type',
        'gacha_id',
        'item_type',
        'item_id',
        'use_time',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`     int(11) UNSIGNED NOT NULL,
                  `gacha_type`  int(11) UNSIGNED NOT NULL,
                  `gacha_id`    int(11) UNSIGNED NOT NULL,
                  `item_type`   int(11) UNSIGNED NOT NULL,
                  `item_id`     int(11) UNSIGNED NOT NULL,
                  `use_time`    DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00'
                ) ENGINE=ARCHIVE DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        // }}}

        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );
    /** #@- */

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Gacha_Daily_HistoryFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/Daily/HistoryFarmSelector.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: HistoryDao.php 142694 2011-12-22 00:40:19Z takashi-taniguchi $
 */
class Gree_GenericDao_Gacha_Daily_HistoryFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%s";
    // }}}

    // {{{ getTableName($dao, $type, $hint)
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ����������
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        // ���Ȥ���ơ��֥�����
        if (isset($hint['use_time']) === TRUE) {
            $postfix = date('Ymd', strtotime($hint['use_time']));
        } else if (isset($hint['date']) === TRUE) {
            $postfix = date('Ymd', strtotime($hint['date']));
        } else {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾����
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
