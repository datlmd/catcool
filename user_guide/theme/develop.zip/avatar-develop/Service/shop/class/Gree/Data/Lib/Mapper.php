<?php
/**
 * Mapper.php
 */
require_once sprintf('%s/Abstract.php', dirname(__FILE__));

/**
 * Gree_Service_Shop_Data_Mapper
 *
 * Dataクラスの生成を担当するクラス
 *
 * 一度取得したDataクラスは、$_primary_keyをキーとして、キャッシュされる。
 * キャッシュされたものはget / mgetを使った場合に有効。
 *
 * get / mget でキャッシュが無い場合は、load / mloadが呼ばれる。
 * load / mloadの処理は子クラスで拡張する。
 *
 * 子クラスで適当なレコードを取得し、instantiate, minstantiateを呼ぶと
 * Dataクラスを作成し、キャッシュに乗る。
 */
class Gree_Service_Shop_Data_Mapper
{
    // ----[ Constants ]--------------------------------------------------------
    /**
     * Default primary key name
     */
    const DEFAULT_KEY = '__common__';

    // ----[ Properties ]-------------------------------------------------------
    /**
     * @var string  class name
     */
    private $class = null;

    /**
     * @var array   data map
     */
    private $instances = array();

    /**
     * @var object  session
     */
    protected $session = null;

    /**
     * @var mixed   primary key field(s)
     */
    protected $primary_key = null;

    // ----[ Methods ]----------------------------------------------------------
    /**
     * constructor
     *
     * @param   string
     */
    public function __construct($class)
    {
        // set class name
        $this->class = $class;

        // set session
        $this->session = getService('shop')->getSessionWrapper();
    }

    // ----[ Methods ]----------------------------------------------------------
    /**
     * get
     *
     * @param   mixed
     * @param   mixed
     */
    public function get($primary_key, $hint = null)
    {
        $key = $this->createKey($primary_key);
        if (array_key_exists($key, $this->instances)) {
            return $this->instances[$key];
        }

        $accessor = $this->load($primary_key, $hint);
        return $this->instantiate($accessor);
    }

    /**
     * mget
     *
     * @param   array
     * @param   mixed
     */
    public function mget(array $primary_keys)
    {
        // get keys to load
        $load_keys = array_filter($primary_keys, array($this, 'isUnloadKey'));

        // load data_list
        if (!empty($load_keys)) {
            $accessors = $this->mload($load_keys);
            $this->minstantiate($accessors);
        }

        // get data list
        $keys      = array_map(array($this, 'createKey'), $primary_keys);
        $data_list = array();
        foreach ($keys as $key) {
            $data_list[$key] = $this->instances[$key];
        }

        return $data_list;
    }

    /**
     * instantiate Data from a accessor
     *
     * @param   array
     * @return  Gree_Service_Shop_Data
     */
    public function instantiate(array $accessor)
    {
        $data = new $this->class($accessor);
        $key  = $this->getPrimaryKey($data);
        if ($this->isUnloadKey($key)) {
            $this->instances[$key] = $data;
        }

        return $this->instances[$key];
    }

    /**
     * multi instantiate Data from accessors
     *
     * @param   array
     * @return  array
     */
    public function minstantiate(array $accessors)
    {
        $data_list = array();
        foreach ($accessors as $accessor) {
            $data = $this->instantiate($accessor);
            $key  = $this->getPrimaryKey($data);
            $data_list[$key] = $data;
        }

        return $data_list;
    }

    /**
     * load from primary key
     *
     * @param   mixed
     * @return  array
     */
    protected function load($primary_key, $hint = null)
    {
        // override me
        $msg = 'could not load accessor by key (class=%s)';
        $msg = sprintf($msg, $this->class);
        throw new Gree_Service_Shop_Exception($msg);
    }

    /**
     * load from primary key list
     *
     * @param   array
     * @return  array
     */
    protected function mload($primary_keys)
    {
        // override me
        $msg = 'could not mload accessor by keys (class=%s)';
        $msg = sprintf($msg, $this->class);
        throw new Gree_Service_Shop_Exception($msg);
    }

    /**
     * get key from data class
     *
     * @param   object
     * @return  string
     */
    protected function getPrimaryKey(Gree_Service_Shop_Data_Abstract $data)
    {
        if (is_null($this->primary_key)) {
            return self::DEFAULT_KEY;
        } elseif (is_array($this->primary_key)) {
            $keys = array();
            foreach ($this->primary_key as $key) {
                $keys[] = $data->$key;
            }
            return $this->createKey($keys);
        } else {
            $key = $this->primary_key;
            return $this->createKey($data->$key);
        }

    }

    /**
     * create string key from primary key(s)
     *
     * @param   mixed
     * @return  string
     */
    private function createKey($primary_key)
    {
        if (!is_array($primary_key)) {
            return $primary_key;
        }

        return serialize($primary_key);
    }

    /**
     * is unload key
     *
     * @param   mixed
     * @return  bool
     */
    private function isUnloadKey($key)
    {
        return !array_key_exists($this->createKey($key), $this->instances);
    }
}
