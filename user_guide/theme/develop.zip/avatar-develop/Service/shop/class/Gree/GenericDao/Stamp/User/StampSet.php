<?php
require_once PATH_SRC_CLASS . 'Gree/GenericDao/UserIdFarmSelector.php';

class Gree_GenericDao_Stamp_User_StampSetDao extends Gree_GenericDao
{
    var $_table_name = 'stamp_set_user';

    var $_primary_key = array('user_id', 'stamp_set_id');

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_stamp';

    var $_slave_dsn = 'gree://slave/avatar_stamp';

    var $_auto_increment = false;

    var $_field_names = array(
        'user_id',
        'stamp_set_id',
        'hidden',
        'state',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `user_id`      int(11) unsigned NOT NULL,
                    `stamp_set_id` int(11) unsigned NOT NULL,
                    `hidden`       boolean NOT NULL DEFAULT '0',
                    `state`        int(2) unsigned NOT NULL DEFAULT '1',
                    `mtime`        timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`        datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`user_id`, `stamp_set_id`),
                    KEY `user_ctime` (`user_id`, `ctime`),
                    KEY `user_mtime` (`user_id`, `mtime`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),

        'insert' => array(
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    user_id,
                    stamp_set_id,
                    ctime
                )
                VALUES (
                    :user_id,
                    :stamp_set_id,
                    NOW()
                )
            ",
        ),

        'update_hidden_by_user_id_and_stamp_set_id' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET hidden = :hidden WHERE user_id = :user_id and stamp_set_id = :stamp_set_id"
        ),

        'find_by_user_id_and_stamp_set_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id and stamp_set_id = :stamp_set_id",
        ),

        'find_active_stamp_set_by_user_id_order_ctime' => array(
            'sql' => "SELECT stamp_set_id FROM __TABLE_NAME__ WHERE user_id = :user_id and hidden = 0 and state = 1 order by ctime DESC"
        ),

        'find_all_stamp_set_by_user_id_order_ctime' => array(
            'sql' => "SELECT stamp_set_id, hidden FROM __TABLE_NAME__ WHERE user_id = :user_id and state = 1 order by ctime DESC"
        ),

    );

    public function _initFarmSelector()
    {
        $table_nums = 10;

        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = 2;
        }

        $this->_farm_selector = new Gree_GenericDao_UserIdFarmSelector($table_nums);
    }

}
