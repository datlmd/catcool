<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/LoginMonthly/MasterDao.php
 * @package     GREE Avatar
 * @since       2018-09-10
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_LoginMonthly_MasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'loginmonthly_master';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'status',
        'start_date',
        'end_date',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all_and_sort_desc' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ],
        'find_by_id'             => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'find_by_status'         => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :status ORDER BY id DESC',
        ],
        // }}}

        // {{{ update queries
        'entry'                  => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (status, start_date, end_date, ctime) VALUES (:status, :start_date, :end_date, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'                 => [
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status, start_date = :start_date, end_date = :end_date WHERE id = :id',
        ],
        // }}}

        // {{{ create table
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `status` INT NOT NULL DEFAULT 0,
                  `start_date` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `end_date` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`id`),
                  INDEX (`status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
    ];
}
