<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Notification_Add
 */
class Gree_Service_AvatarFeed_Processor_Notification_Add
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;

    /**
     * @return bool|void
     *
     * flow is
     *   make argument for notification create
     *   check _hasSameNotification()
     *   if has_notification
     *     _mergeEntry()
     *     create Entry
     *     delete old Entry
     *   then
     *     create Entry
     *     check entries count
     *     if limit over
     *       get save Entries
     *       get delete Entries
     *       delete Entries
     */
    protected function invoke()
    {
        $add_result = true;

        $this->mod_appfeed = self::getModule('AppFeed');

        $entry_category = $this->input_values['entry_category'];
        $create_params = array(
            'content'      => array(
                'sender_id'  => $this->input_values['user_id'],
                'entry_type' => 'activity',
                'text'       => 'notification',
                'attr'       => array(
                    'entry_category'        => $entry_category,
                    'notification_entry_id' => $this->input_values['notification_entry_id'],
                    'notification_user'     => serialize(array()),
                    'notification_count'    => 0,
                ),
            ),
            'destinations' => array(
                array(
                    'type'  => 'feed_key',
                    'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION . ':' . $this->input_values['destination_user']
                )
            )
        );

        if ($entry_category == 'notification_incentive') {
            $create_params['content']['attr']['incentive'] = $this->input_values['sum_point_value'];

        } elseif ($entry_category == 'notification_comment_relation' || $entry_category == 'lounge_notification_comment_relation') {
            //$create_params['content']['attr']['parent_entry_nick_name'] = mb_convert_encoding($this->input_values['parent_entry_nick_name'], 'UTF-8', mb_internal_encoding());
            //$create_params['content']['attr']['parent_thumbnail'] = $this->input_values['parent_thumbnail'];
        }
        if ($entry_category == 'lounge_notification_comment' || $entry_category == 'lounge_notification_comment_relation') {
            $create_params['content']['attr']['theme_id'] = $this->input_values['theme_id'];
        }
        if (isset($this->input_values['parent_entry_user_id'])) {
            $create_params['content']['attr']['parent_entry_user_id'] = $this->input_values['parent_entry_user_id'];
        }

        try {
            list($has_notification, $delete_entry, $is_full, $last_entry_id, $entries) = $this->_hasSameNotification();
            $created_notification_id = null;

            if ($has_notification) {
                // ポイント取得通知はエントリーを更新しない
                if ($entry_category != 'notification_incentive') {
                    list($notification_user, $notification_count) = $this->_mergeEntry($delete_entry);
                    $create_params['content']['attr']['notification_user'] = $notification_user;
                    // if fix appfeed delete this cast process
                    $notification_count                                     = (string)$notification_count;
                    $create_params['content']['attr']['notification_count'] = $notification_count;

                    list($is_create_success, $entry_id) = $this->mod_appfeed->createEntry($create_params);
                    $created_notification_id = $entry_id;

                    $delete_params = array(
                        'entry_id' => $delete_entry['entry_id']
                    );
                    list($is_delete_success, $entry_id) = $this->mod_appfeed->deleteEntry($delete_params);
                }
            } else {
                // if fix appfeed delete this cast process
                $create_params['content']['attr']['notification_count'] = (string)$create_params['content']['attr']['notification_count'];
                list($is_create_success, $entry_id) = $this->mod_appfeed->createEntry($create_params);
                $created_notification_id = $entry_id;

                if ($is_full) {
                    $delete_params = array(
                        'entry_id' => $last_entry_id
                    );
                    list($is_delete_success, $entry_id) = $this->mod_appfeed->deleteEntry($delete_params);

                    if (!$is_delete_success) {
                        $msg                        = 'failed delete limit over notification.';
                        $code                       = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_NOTIFICATION_ADD;
                        $context                    = $this->input_values;
                        $context['failed entry_id'] = $last_entry_id;
                        new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
                    }
                }
            }

            // send push notification
            $notification_manager = getService('shop')->getPushNotificationNotificationManager();

            $badge_count = null;
            if (!$has_notification && !$is_full) {
                $badge_count = $this->_countNotification($entries, $has_notification, $is_full);
            }

            if ($entry_category == 'notification_comment' || $entry_category == 'notification_comment_relation') {
                // comment notification
                $from_user_id   = $this->input_values['user_id'];
                $to_user_id     = $this->input_values['destination_user'];
                $is_parent_user = isset($this->input_values['parent_entry_user_id']) ? false : true;
                $entry_id       = $this->input_values['notification_entry_id'];

                $notification_manager->pushNotificationAvameeComment($from_user_id, $to_user_id, $is_parent_user, $entry_id, $created_notification_id, $badge_count);
            } else if ($entry_category == 'notification_follow') {
                // follow notification
                $from_user_id   = $this->input_values['user_id'];
                $to_user_id     = $this->input_values['destination_user'];

                $notification_manager->asyncNotificationFollow($from_user_id, $to_user_id, $created_notification_id, $badge_count);

            } else if ($entry_category == 'notification_like') {
                // like notification
                $from_user_id   = $this->input_values['user_id'];
                $to_user_id     = $this->input_values['destination_user'];
                $entry_id       = $this->input_values['notification_entry_id'];

                $notification_manager->asyncNotificationLike($from_user_id, $to_user_id, $entry_id, $created_notification_id, $badge_count);
            
            } else if ($entry_category == 'notification_avapri') {
                // avapri notification
                $from_user_id   = $this->input_values['user_id'];
                $to_user_id     = $this->input_values['destination_user'];
                $entry_id       = $this->input_values['notification_entry_id'];

                $notification_manager->asyncNotificationAvapriEntry($from_user_id, $to_user_id, $entry_id, $created_notification_id, $badge_count);

            } else if ($badge_count) {
                // badge count notification
                $notification_manager->asyncBadgeUpdate($this->input_values['destination_user'], $badge_count);
            }

        } catch (Exception $e) {
            $msg     = 'failed add notification.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_NOTIFICATION_ADD;
            $context = $this->input_values;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            $add_result = false;
        }

        return $add_result;
    }

    /**
     * @return array
     *
     * return has_notification, delete_entry
     *
     * flow is
     *   get Entries
     *   check entry_category && notification_entry_id
     */
    public function _hasSameNotification()
    {
        $has_notification     = false;
        $delete_entry         = null;
        $is_full_notification = false;
        $last_entry_id        = null;

        // get timeline
        list($has_more, $entries) = $this->mod_appfeed->getEntriesByFeedKey(
            $this->input_values['destination_user'],
            GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION,
            GREE_SERVICE_AVATARFEED_NOTIFICATION_LIMIT_COUNT,
            null,
            'batch'
        );

        if (empty($entries)) {
            return array(
                $has_notification,
                $delete_entry,
                $is_full_notification,
                $last_entry_id,
                $entries,
            );
        }

        foreach ($entries as $entry) {
            if (!isset($entry['content']['attr'])) {
                continue;
            }
            if ($entry['content']['attr']['entry_category'] == $this->input_values['entry_category']
                && $entry['content']['attr']['notification_entry_id'] == $this->input_values['notification_entry_id']
            ) {
                $has_notification = true;
                $delete_entry     = $entry;

                return array(
                    $has_notification,
                    $delete_entry,
                    $is_full_notification,
                    $last_entry_id,
                    $entries,
                );
            }
        }

        if (count($entries) >= GREE_SERVICE_AVATARFEED_NOTIFICATION_LIMIT_COUNT) {
            $is_full_notification = true;
            $last_entry           = $entries[count($entries)-1];
            $last_entry_id        = $last_entry['entry_id'];
        }

        return array(
            $has_notification,
            $delete_entry,
            $is_full_notification,
            $last_entry_id,
            $entries,
        );
    }

    /**
     * @param $delete_entry
     * @return array
     *
     * merge delete_entry_user_ids
     */
    public function _mergeEntry($delete_entry)
    {
        $notification_count = $delete_entry['content']['attr']['notification_count'];
        $notification_user  = array(
            $delete_entry['content']['sender_id']
        );

        $delete_entry_user_ids = unserialize($delete_entry['content']['attr']['notification_user']);
        if (!empty($delete_entry_user_ids)) {
            $notification_count++;
        }

        return array(
            serialize($notification_user),
            $notification_count
        );
    }

    private function _countNotification($entries, $has_same_notification, $is_full)
    {
        $today = getService('shop')->getDate('Y-m-d');

        foreach ($entries as $index => $entry) {
            if (!isset($entry['content']['attr'])) {
                unset($entries[$index]);
                continue;
            }
            if ($entry['content']['attr']['entry_category'] == 'notification_incentive' && $entry['content']['attr']['notification_entry_id'] == $today) {
                unset($entries[$index]);
            }
        }

        $cnt = count($entries);
        if (!$has_same_notification && !$is_full) {
            $cnt++;
        }

        return $cnt;
    }
}
