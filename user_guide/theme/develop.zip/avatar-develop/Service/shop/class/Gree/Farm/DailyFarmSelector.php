<?php
/**
 * Gree_GenericDao_Shop_DailyFarmSelector
 *
 * @author  Keisuke Kagiya <keisuke.kagiya@gree.co.jp>
 * @package GREE
 */
class Gree_GenericDao_Shop_DailyFarmSelector extends Gree_GenericDao_FarmSelector
{
    /** @var string table suffix format */
    var $_table_suffix_format = "_%s";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        // check $hint[date]
        if (isset($hint['date'])) {
            $date = strtotime($hint['date']);
        // check $hint[ctime]
        }else if (isset($hint['ctime'])) {
            $date = strtotime($hint['ctime']);
        } else {
            $error_msg  = sprintf('hint is empty. dao = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
        
        $postfix = date('Ymd', $date);

        // create table name
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
    // }}}
}
