<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Item/MixerHistoryDao.php
 *
 * @package     GREE Avatar
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * ItemMixerHistory form constructor
 * @access      public
 */
class Gree_GenericDao_Item_MixerHistoryDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'item_mixer_history';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/shop';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/shop';

    /** @var field names */
    var $_field_names = array(
        'id',
        'mixer_id',
        'user_id',
        'life_item_id',
        'id_a',
        'id_b',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user_id_and_sort_desc'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id DESC',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (mixer_id, user_id, life_item_id, id_a, id_b, ctime) VALUES (:mixer_id, :user_id, :life_item_id, :id_a, :id_b, NOW())',
            'return_last_insert_id' => true
        ),
        'create_table'           => array(
            'sql' => '
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`           INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `mixer_id`     INT(10) UNSIGNED NOT NULL,
                `user_id`      INT(10) UNSIGNED NOT NULL,
                `life_item_id` INT(10) UNSIGNED NOT NULL,
                `id_a`         INT(10) UNSIGNED NOT NULL,
                `id_b`         INT(10) UNSIGNED NOT NULL,
                `ctime`        DATETIME NOT NULL DEFAULT "00-00-00 00\:00\:00",
                `mtime`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis;'
        )
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}