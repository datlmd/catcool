<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserLightFarmSelector.php');
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Beginner/PlanUser.php
 * Gree_GenericDao_Beginner_PlanUserDao
 *
 * @author      ikuko.tamura <z.ikuko.tamura@gree.net>
 * @package     GREE
 */
class Gree_GenericDao_Beginner_PlanUserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'plan_user';
    /** @var primary key */
    var $_primary_key = ['user_id', 'grade'];
    /** @var auto increment */
    var $_auto_increment = false;
    /** @var updated at column */
    var $_updated_at_column = 'mtime';
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'user_id',
        'grade',
        'pack_id',
        'plan_id',
        'expired',
        'ctime',
        'mtime'
    ];

    var $_queries = [ // ʣ�祭��
        // select----------------------
        'find_by_user_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        'find_by_user_id_and_grade_desc' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY grade DESC',
        ],
        // insert----------------------
        'insert' => [
            'sql' =>  'INSERT INTO __TABLE_NAME__ (user_id, grade, pack_id, plan_id, expired, ctime) VALUES (:user_id, :grade, :pack_id, :plan_id, :expired, NOW())'
        ],
        // create table ----------------
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id` INT unsigned NOT NULL,
                  `grade` INT unsigned NOT NULL,
                  `pack_id` INT unsigned NOT NULL,
                  `plan_id` INT unsigned NOT NULL,
                  `expired` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `ctime` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                  PRIMARY KEY (`user_id`,`grade`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],
        // debug ----------------
        'delete_by_user_id_and_plan_id' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id and plan_id = :plan_id',
        ],
    ];

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
}
