<?php

/**
 *  JudgeHistoryDao
 *  ����ƥ��ȤΥ�����ɾ���������Ͽ����Dao��
 *
 *  @author   Daisuke Yamasaki
 *  @package  GREE
 */
class Gree_GenericDao_Contest_JudgeHistoryDao extends Gree_GenericDao
{
    var $_table_name        = 'contest_judge_history';
    var $_primary_key       = 'id';
    var $_updated_at_column = 'mtime';
    var $_created_at_column = 'ctime';
    var $_master_dsn        = 'gree://master/avatar_contest';
    var $_slave_dsn         = 'gree://slave/avatar_contest';
    var $_auto_increment    = true;

    var $_field_names = array(
        'id',
        'user_id',
        'target_id',
        'user_sex',
        'judge_id',
        'day_count',
        'mtime',
        'ctime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`          int(10) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id`     int(10) unsigned NOT NULL default '0',
                    `target_id`   int(10) unsigned NOT NULL default '0',
                    `user_sex` int(4)  unsigned NOT NULL default '1',
                    `judge_id`    tinyint(2)  unsigned NOT NULL default '0',
                    `day_count`   tinyint(2)  unsigned NOT NULL default '0',
                    `mtime`       timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`       datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `judge_not_duplicate` (`user_id`, `day_count`, `target_id`, `user_sex`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),

        'drop_table' => array(
            'sql' => 'DROP TABLE IF EXISTS __TABLE_NAME__',
        ),

        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),

        'insert' => array(
            'sql' => "INSERT IGNORE INTO __TABLE_NAME__ (user_id, target_id, user_sex, judge_id, day_count, ctime) values (:user_id, :target_id, :user_sex, :judge_id, :day_count, NOW())",
        ),

        'find_judge_history_by_day' => array(
            'sql' => 'select * from __TABLE_NAME__ where user_id=:user_id and day_count=:day_count',
        ),
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Contest_JudgeHistoryFarmSelector();
    }
}

/**
 * JudgeHistoryFarmSelector
 *
 * ����ƥ���ID��˥ơ��֥��������桼����ID�ǥ��㡼�ǥ��󥰤��롣
 *
 */
class Gree_GenericDao_Contest_JudgeHistoryFarmSelector extends Gree_GenericDao_FarmSelector
{
    // �桼����ID��100ʬ��
    var $_table_nums = 100;

    // ����ƥ���ID_�桼����ID
    var $_table_suffix_format = "_%d_%02d";

    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        if (empty($hint) || !isset($hint['contest_id']) || !isset($hint['user_id'])) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }

        $table_number = (int)$hint['user_id'] % $this->_table_nums;
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['contest_id'], $table_number);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
}
