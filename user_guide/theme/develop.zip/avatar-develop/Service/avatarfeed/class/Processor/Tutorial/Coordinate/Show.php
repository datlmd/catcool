<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Tutorial_Coordinate_Show
 */
class Gree_Service_AvatarFeed_Processor_Tutorial_Coordinate_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array()
     *
     * get Stream data
     *
     * if failed to find feed then create feed.
     *
     * return has_more and stream data
     */
    protected function invoke()
    {
        $stream_data = array();
        $has_more    = false;
        $mod_appfeed = self::getModule('AppFeed');
        $mod_user    = self::getModule('User');

        try {
            $start_id = $this->input_values['start_id'];
            $service_shop = getService('shop');
            $unsupported_items = $service_shop->getUnsupportedItems();
            if (!empty($unsupported_items)) {
                list($has_more, $entries) = $this->_getUnsupportedEntry();
            } else {
                list($has_more, $entries) = $mod_appfeed->getEntriesByFeedKey(
                        $this->input_values['user_id'],
                        $this->input_values['category'],
                        $this->input_values['limit'],
                        $start_id
                );
            }
        } catch (Exception $e) {
            $msg     = 'failed get feed.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_STREAM;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array(
                $has_more,
                $stream_data
            );
        }

        if (count($entries) == 0) {
            return array(
                $has_more,
                $stream_data
            );
        }

        $entries     = $mod_appfeed->appendCommentInfo($entries);
        $entries     = $mod_appfeed->appendEntryInfo($entries);
        $stream_data = $mod_user->appendUserInfo($entries);

        foreach ($stream_data as $key => $val) {
            if ($stream_data[$key]['comment']['count'] > 1) {
                $stream_data[$key]['comment']['list'] = array_reverse($stream_data[$key]['comment']['list']);
                $stream_data[$key]['comment_window'] = true;
            }
            if (!empty($is_like_effect) && !empty($val['content']['attr']['item_ids']) && !empty($val['content']['attr']['effect_id'])) {
                $stream_data[$key]['content']['attr']['item_ids'] .= (',' . $val['content']['attr']['effect_id']);
            }
        }

        return array(
            $has_more,
            $stream_data
        );
    }

    // {{{ _getUnsupportedEntry()
    private function _getUnsupportedEntry() {
        $start_id = $this->input_values['start_id'];
        $roop_limit = 2;//�������ˤ������
        $roop_count = 0;
        $entries_tmp = array();
        $mod_appfeed = self::getModule('AppFeed');

        while (true) {
            $roop_count++;
            list($has_more, $entries) = $mod_appfeed->getEntriesByFeedKey(
                    $this->input_values['user_id'],
                    $this->input_values['category'],
                    $this->input_values['limit'],
                    $start_id
            );
            $entries_tmp = array_merge($entries_tmp, $entries);

            foreach ($entries_tmp as $key => $val) {
                switch($val['content']['attr']['entry_category']) {
                    // unsupported avatar key
                    case 'unsupported_change':
                    case 'unsupported_avapri':
                    case 'unsupported_change_mood':
                        unset($entries_tmp[$key]);
                        break;
                    default:
                        break;
                }
            }
            if (!$has_more || count($entries_tmp) >= $this->input_values['limit'] || $roop_count >= $roop_limit ) {
                $entries = array_slice($entries_tmp, 0, $this->input_values['limit']);
                break;
            } else {
                $start_id = $val['entry_id'];
            }
        }
        return array($has_more, $entries);
    }
    // }}}
}
