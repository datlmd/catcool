<?php
/**
 * Purchase.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */

require_once dirname(dirname(__FILE__)) . '/Statistics.php';
require_once PATH_SRC_CLASS . '/Gree/Statistics/Logger/Service/Purchase.php';

/**
 * logger class of shop service
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @access  public
 * @package GREE
 */
class Gree_Service_Shop_Logger_Statistics_Purchase
    extends Gree_Service_Shop_Logger_Statistics
{
    const SERVICE_NAME = 'shop';

    /* -------- [ public methods ] -------- */

    // {{{ __construct
    /**
     * constructor
     */
    public function __construct()
    {
        // do nothing
    }
    // }}}

    // ------------------------------------------------------------------
    // Gacha Log
    // ------------------------------------------------------------------

    // {{{ purchaseGacha
    /**
     * @access  public
     * @param   int     $item_id
     * @param   int     $price
     * @param   int     $having_point
     * @param   object  $gacha
     * @param   string  $code
     */
    public function purchaseGacha($item_id, $price, $having_point, $gacha, $code)
    {
        $data = array(
            'gacha_type'    => $gacha->type_id,
            'gacha_id'      => $gacha->gacha_id,
            'code'          => $code,
        );
        $this->_log(
            'shop/gacha_purchase',
            'gacha_purchase',
            $item_id,
            $price,
            $having_point,
            $data
        );
    }
    // }}}

    // ------------------------------------------------------------------
    // Market Log
    // ------------------------------------------------------------------

    // {{{ payMarketCharge
    /**
     * pay market charge log
     *
     * @access  public
     * @param   int     $charge         the charge to buy market item
     * @param   string  $action         the action name
     * @param   int     $item_id        the item id
     * @param   int     $having_point   the having point
     * @param   int     $market_id      the market id
     * @param   int     $avatar_point   the avatar point to bid / sell the item
     */
    public function payMarketCharge($charge, $action, $item_id, $having_point, $market_id, $avatar_point)
    {
        $data = array(
            'market_id' => $market_id,
            'point'     => $avatar_point,
        );
        $this->_log(
            'shop/market_charge',
            $action,
            $item_id,
            $charge,
            $having_point,
            $data
        );
    }
    // }}}

    // ------------------------------------------------------------------
    // Avapri Log
    // ------------------------------------------------------------------
    
    // {{{ payAvapriCharge
    /**
     * pay avapri charge log
     *
     * @access  public
     * @param   int     $charge         the charge to buy avapri item
     * @param   string  $action         the action name
     * @param   int     $item_id        the item id
     * @param   int     $having_point   the having point
     */
    public function payAvapriCharge($charge, $action, $item_id, $having_point)
    {
        $data = array(
            'item_id' => $item_id,
        );
        $this->_log(
             'shop/avapri_purchase',
             $action,
             $item_id,
             $charge,
             $having_point,
             $data
         );
     }
     // }}}
    
    
    /* -------- [ protected methods ] -------- */

    // {{{ _log
    /**
     * log method
     *
     * @access  protected
     * @param   string  $log_name       the log dir name
     * @param   string  $action         the action name
     * @param   int     $item_id        the item id
     * @param   int     $price          the item price
     * @param   int     $having_point   the total point before buy the item
     * @param   array   $data           the data
     */
    protected function _log($log_name, $action, $item_id, $price, $having_point, $data = array())
    {
        // get logger
        $logger = Gree_Statistics_Logger_Service_Purchase::getInstance();
        $logger->setLogName($log_name);

        // get action
        $action = $this->_getLogActionName($action);

        // log
        $logger->log(
            self::SERVICE_NAME,
            $action,
            $item_id,
            $price,
            $having_point,
            $this->_appendNetLog($data)
        );
        unset($logger);
    }
    // }}}

    // {{{ _getLogActionName
    /**
     * get action name for log
     *
     * @access  protected
     * @param   string      $action the action name
     * @return  string              the action name
     */
    protected function _getLogActionName($action)
    {
        $action = parent::_getLogActionName($action);
        $action .= '_coin';

        return $action;
    }
    // }}}
}
