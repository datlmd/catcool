<?php
/**
 * Gree_GenericDao_PointDao
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */

require_once PATH_SRC_CLASS . 'Gree/GenericDao/UserIdFarmSelector.php';

class Gree_GenericDao_Shop_PointDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'point';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_point';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_point';

    /** @var field names */
    var $_field_names       = array(
        'user_id',
        'value',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        // }}}
        // {{{ update queries
        'create'            => array(
            'sql'   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, value, ctime) VALUES (:user_id, :value, NOW())',
        ),
        'update'            => array(
            'sql'   => 'UPDATE __TABLE_NAME__ SET value = :value WHERE user_id = :user_id',
        ),
        // {{{ refer queries
        'get_all_info' => array(  // for batch
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'create_table'      => array(
            'sql'   => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    user_id     INT(11)     UNSIGNED NOT NULL,
                    value       INT(11)     UNSIGNED NOT NULL,
                    ctime       DATETIME    NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime       TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table'        => array(
            'sql'   => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    /**
     * initialize farm selector
     *
     * @access  private
     */
    function _initFarmSelector()
    {
        // default table nums
        $table_nums     = 100;

        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            // for develop
            $table_nums = 2;
        }

        $this->_farm_selector   = new Gree_GenericDao_UserIdFarmSelector($table_nums);
    }
    // }}}
}
