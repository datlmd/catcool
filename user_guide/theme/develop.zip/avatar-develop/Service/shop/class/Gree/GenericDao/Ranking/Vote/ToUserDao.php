<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Ranking/Vote/ToUserDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: ToUserDao.php 144123 2012-02-22 11:19:30Z takashi-taniguchi $
 */
class Gree_GenericDao_Ranking_Vote_ToUserDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */ 

    /** @var �ơ��֥�̾ */
    var $_table_name = 'vote_to_user';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_ranking_vote';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_ranking_vote';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'user_sex',
        'target_id',
        'point',
        'mtime',
        'ctime',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id`                  INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                  `user_id`             INT(10) UNSIGNED NOT NULL DEFAULT '0',
                  `user_sex`            INT(10) UNSIGNED NOT NULL DEFAULT '1',
                  `target_id`           INT(10) UNSIGNED NOT NULL DEFAULT '0',
                  `point`               INT(10) UNSIGNED NOT NULL DEFAULT '0',
                  `mtime`               TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `ctime`               DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY  (`id`),
                  UNIQUE KEY `user_id` (`user_id`,`user_sex`,`target_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE IF EXISTS __TABLE_NAME__',
        ),
        'replace' => array(
            'sql' => 'REPLACE INTO __TABLE_NAME__ (user_id, user_sex, target_id, point, mtime, ctime) VALUES (:user_id, :user_sex, :target_id, :point, NOW(), NOW())'
        ),
        // }}}
        // {{{ ���ȷ�
        'find_by_unique_key' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND user_sex = :user_sex AND target_id = :target_id LIMIT 1'
        ),
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ IGNORE INDEX(PRIMARY) WHERE user_id = :user_id ORDER BY id DESC LIMIT :limit'
        ),
        'find_ids_by_target_id' => array(
            'sql' => 'SELECT id FROM __TABLE_NAME__ WHERE target_id = :target_id'
        ),
        'find_by_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id in (:ids)'
        ),
        'find_target_id_order_by_id_and_user_sex_desc' => array(
            'sql' => 'SELECT target_id, user_sex FROM __TABLE_NAME__ where user_sex = :user_sex ORDER BY id DESC',
        ),
        'max_primary_id' => array(
            'sql' => 'SELECT COUNT(*) AS max FROM __TABLE_NAME__'
        ),
        'count_by_user_id' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'count_by_target_id_and_user_sex' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM __TABLE_NAME__ WHERE target_id = :target_id AND user_sex = :user_sex'
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        'delete_by_user_id' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE user_id=:user_id",
        ),
        'delete_by_target_id' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE target_id=:target_id",
        ),
        // }}}
    );

    /** #@- */

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Ranking_Vote_ToUserFarmSelector();
    }
    // }}}
}

/**
 *  vote_to_user�ơ��֥��Farm Selector���
 *  
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @access   public
 *  @package  GREE
 */
class Gree_GenericDao_Ranking_Vote_ToUserFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%s_%02d";
    // }}}

    // {{{ _dateline
    /** var integer ����ɼ�����ն������� */
    var $_dateline = 11;
    // }}}

    // {{{ getTableName($dao, $type, $hint)
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ����������
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        // user_id��ɬ��
        if (empty($hint['user_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        // ���Ȥ���ơ��֥�����
        if (isset($hint['ctime']) === TRUE) {
            $postfix = date('Y-m-d H:i:s', strtotime($hint['ctime']));
        } else if (isset($hint['date']) === TRUE) {
            $postfix = date('Y-m-d H:i:s', strtotime($hint['date']));
        } else {
            $postfix = date('Y-m-d H:i:s');
        }
        // ���ն����򤺤餹
        $postfix = date('Ymd', strtotime($postfix) - 3600 * $this->_dateline);
        //����ƥ���ID��8�ʲ��ξ���100ʬ��
        if ($postfix < '20130731') {
            $this->_table_nums = 100;
        }

        // �ơ��֥�̾����
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix, $hint['user_id'] % $this->_table_nums);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
