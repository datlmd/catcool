<?php

class Gree_Service_AvatarFeed_Processor_Followed_List_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $followed_list = array();
        $has_more      = false;
        $show_all      = false;

        $mod_follow = self::getModule('Follow');
        
        if (!empty($this->input_values['show_all'])) {
            $show_all = $this->input_values['show_all'];
        }

        $followed_user_ids = null;
        try {
            if(!empty($this->input_values['followed_user_id'])){
                $mod_block = self::getModule('Block');
                $is_block = $mod_block->getBlockUser($this->input_values['followed_user_id']);
                if(!$is_block){
                    $followed_user_ids[] = array(
                        'content' => array(
                            'sender_id' => $this->input_values['followed_user_id']
                        )
                    );
                }
            }else{
                list($has_more, $followed_user_ids) = $mod_follow->getFollowedListOrderInTime(
                    $this->input_values['user_id'],
                    $this->input_values['limit'],
                    $this->input_values['offset']
                );
            }
        } catch (Exception $e) {
            $msg     = 'failed get follow status.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        if (is_null($followed_user_ids)) {
            return array(
                $has_more,
                $followed_list
            );
        }

        $mod_user      = self::getModule('User');
        $followed_list = $mod_user->appendUserInfo($followed_user_ids, $show_all);

        return array(
            $has_more,
            $followed_list
        );
    }
}
