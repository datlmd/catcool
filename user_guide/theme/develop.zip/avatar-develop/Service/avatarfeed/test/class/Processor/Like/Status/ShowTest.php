<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Like_Status_ShowTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Like_Status_ShowTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;
    var $module_setting;
    var $point_manager = null;

    public function setUp()
    {
        $this->avatar_feed    = Gree_Service_AvatarFeed::getInstance();
        $this->module         = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module_setting = Gree_Service_AvatarFeed_Module::singleton('Setting');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        $this->initialize_like_status();
        $this->initialize_setting_info_of_like();
        $this->initialize_point_and_history(UNIT_TEST_USER_ID_1);
    }

    /**
     * case  : no exist like data. empty($like_data) && $has_more == false && $is_exception == false
     * expect: $is_first_like == true, $is_max_count == false, $today_like_count == 0
     */
    public function test_case_is_until_like_add()
    {
        $like_setting_info  = $this->module_setting->getSettingInfoOfIncentive(array('action_type' => 'like'));
        $limit_count = (int)($like_setting_info['daily_limit_of_point'] / $like_setting_info['point_per_action']);

        list($is_first, $is_max_count, $today_like_count, $get_limit_count) = $this->avatar_feed->process('like_status_show');

        $this->assertTrue($is_first);
        $this->assertFalse($is_max_count);
        $this->assertEquals(0, $today_like_count);
        $this->assertEquals($limit_count, $get_limit_count);
    }

    /**
     * case  : range out setting time && not empty($like_data)
     * expect: $is_first_like == false, $is_max_count == true, $today_like_count == 0
     */
    public function test_case_is_no_active_setting_info()
    {
        $start_date_time = date("Y-m-d H:i:s", mktime(date('H') +1));
        $end_date_time   = date("Y-m-d H:i:s", mktime(date('H') +2));

        $like_save_params     = array(
            'action_type'                 => 'like',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 10,
            'daily_limit_of_point'        => 50,
            'limit_of_point_to_same_user' => 3,
        );
        $this->module_setting->saveSettingInfoOfIncentive($like_save_params);

        list($is_created_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        $like_params = array(
            'entry_id' => $entry_id,
            'user_id'  => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, // for td
            'liked_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 // for td
        );

        list($is_added_like, $added_entry_id) = $this->module->addLike($like_params);

        $this->assertTrue($is_added_like);
        $this->assertEquals($entry_id, $added_entry_id);

        list($is_first, $is_max_count, $today_like_count, $limit_count) = $this->avatar_feed->process('like_status_show', UNIT_TEST_USER_ID_1);

        $this->assertFalse($is_first);
        $this->assertTrue($is_max_count);
        $this->assertEquals(0, $today_like_count);
        $this->assertEquals(0, $limit_count);
    }

    /**
     * case  : exist $like_data and range in setting time
     * expect: $is_first_like == false
     *         variable: $is_max_count, $today_like_count
     */
    public function test_case_is_full_added_like()
    {
        $like_setting_info  = $this->module_setting->getSettingInfoOfIncentive(array('action_type' => 'like'));
        $limit_count = (int)($like_setting_info['daily_limit_of_point'] / $like_setting_info['point_per_action']);

        $entry_ids = array();
        foreach ($this->enable_user_list as $user_id) {
            list($is_created_entry, $entry_id) = $this->_createEntry($user_id, $user_id);

            $this->assertTrue($is_created_entry);
            $entry_ids[] = $entry_id;
        }

        $like_params = array(
            'entry_id' => $entry_ids[0],
            'user_id'  => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, // for td
            'liked_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 // for td
        );
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        list($is_added_like, $added_entry_id) = $this->module->addLike($like_params);

        $this->assertTrue($is_added_like);

        // $today_like_point['like'] == 0:
        list($is_first, $is_max_count, $today_like_count, $get_limit_count) = $this->avatar_feed->process('like_status_show');

        $this->assertFalse($is_first);
        $this->assertFalse($is_max_count);
        $this->assertEquals(0, $today_like_count);
        $this->assertEquals($limit_count, $get_limit_count);

        for ($i=1; $i < $limit_count; $i++) {
            $target_date = date("Y-m-d H:i:s");
            $incentive_params = array(
                'incentive_category' => 'point',
                'target_action'      => 'like',
                'user_id'            => UNIT_TEST_USER_ID_1,
                'target_entry_id'    => $entry_ids[$i],
                'target_date'        => $target_date,
                'liked_user_id'      => $this->enable_user_list[$i]
            );
            $result_code = $this->avatar_feed->process('incentive_add', $incentive_params);
            $this->assertEquals(2, $result_code);
        }

        sleep(2);

        // $today_like_point['like'] < $setting_info['daily_limit_of_point']:
        list($is_first, $is_max_count, $today_like_count, $get_limit_count) = $this->avatar_feed->process('like_status_show');

        $this->assertFalse($is_first);
        $this->assertFalse($is_max_count);
        $this->assertEquals($limit_count - 1, $today_like_count);
        $this->assertEquals($limit_count, $get_limit_count);

        $target_date = date("Y-m-d H:i:s");
        $incentive_params = array(
            'incentive_category' => 'point',
            'target_action'      => 'like',
            'user_id'            => UNIT_TEST_USER_ID_1,
            'target_entry_id'    => $entry_ids[0],
            'target_date'        => $target_date,
            'liked_user_id'      => $this->enable_user_list[0]
        );
        $result_code_2 = $this->avatar_feed->process('incentive_add', $incentive_params);
        $this->assertEquals(2, $result_code_2);

        sleep(2);

        // $today_like_point['like'] >= $setting_info['daily_limit_of_point']:
        list($is_first, $is_max_count, $today_like_count, $get_limit_count) = $this->avatar_feed->process('like_status_show');

        $this->assertFalse($is_first);
        $this->assertTrue($is_max_count);
        $this->assertEquals($limit_count, $today_like_count);
        $this->assertEquals($limit_count, $get_limit_count);
    }
}