<?php

class Gree_Service_AvatarFeed_Module_Follow
    extends Gree_Service_AvatarFeed_Module_Base
{
    var $accessor_follow_count;
    var $accessor_following;
    var $accessor_followed;

    public function getFollowCount($user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_follow_count = Cascade::getAccessor('avatar_feed#follow_count');
        $find_values                 = array(
            'user_id' => $user_id,
        );
        $find_result                 = $this->accessor_follow_count->findFirst('find_by_user_id', $find_values);

        if (is_null($find_result)) {
            $following_count = 0;
            $followed_count  = 0;
        } else {
            $following_count = $find_result['following'];
            $followed_count  = $find_result['followed'];
        }

        return array(
            $following_count,
            $followed_count
        );
    }

    public function updateFollowCount($user_id = null,
                                      $following_number = 0,
                                      $followed_number = 0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_follow_count = Cascade::getAccessor('avatar_feed#follow_count');
        $update_values               = array(
            'user_id'          => $user_id,
            'following_number' => $following_number,
            'followed_number'  => $followed_number,
        );
        $update_result               = $this->accessor_follow_count->execute('update_count', $update_values);

        return $update_result;
    }

    public function incrementFollowCount($increment_column,
                                         $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $query = null;
        if ($increment_column == 'following') {
            $query = 'increment_following';
        } else if ($increment_column == 'followed') {
            $query = 'increment_followed';
        } else {
            return false;
        }

        $this->accessor_follow_count = Cascade::getAccessor('avatar_feed#follow_count');
        $increment_values            = array(
            'user_id' => $user_id,
        );
        $increment_result            = $this->accessor_follow_count->execute($query, $increment_values);

        return $increment_result;
    }

    public function decrementFollowCount($decrement_column,
                                         $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $query = null;
        if ($decrement_column == 'following') {
            $query = 'decrement_following';
        } else if ($decrement_column == 'followed') {
            $query = 'decrement_followed';
        } else {
            return false;
        }

        $this->accessor_follow_count = Cascade::getAccessor('avatar_feed#follow_count');
        $decrement_values            = array(
            'user_id' => $user_id,
        );
        $decrement_result            = $this->accessor_follow_count->execute($query, $decrement_values);

        return $decrement_result;
    }

    public function decrementFollowCountByInput($decrement_column,
                                         $decrement_num,
                                         $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $query = null;
        if ($decrement_column == 'following') {
            $query = 'decrement_following_by_input';
        } else if ($decrement_column == 'followed') {
            $query = 'decrement_followed_by_input';
        } else {
            return false;
        }

        $this->accessor_follow_count = Cascade::getAccessor('avatar_feed#follow_count');
        $decrement_values            = array(
            'user_id'       => $user_id,
            'decrement_num' => $decrement_num,
        );
        $decrement_result            = $this->accessor_follow_count->execute($query, $decrement_values);

        return $decrement_result;
    }

    public function getFollowingUser($following_user_id,
                                     $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $find_values              = array(
            'user_id'           => $user_id,
            'following_user_id' => $following_user_id,
        );
        $find_result              = $this->accessor_following->findFirst('find_user_by_user_id_and_following_user_id', $find_values);

        $is_following = true;
        if (is_null($find_result)) {
            $is_following = false;
        }

        return $is_following;
    }

    public function getFollowingListUser($following_user_ids,
                                         $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $find_values              = array(
            'user_id'           => $user_id,
            'following_user_ids' => $following_user_ids,
        );
        $find_result              = $this->accessor_following->find('find_user_by_user_id_and_following_user_id_bulk', $find_values);

        return $find_result;
    }

    public function getFollowingListOrderInTime($user_id = null,
                                                $input_limit = 10,
                                                $offset = 0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $limit = $input_limit + 1;

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $find_values              = array(
            'user_id' => $user_id,
        );
        $find_result              = $this->accessor_following->find('find_list_by_user_id_sort_ctime', $find_values, $offset, $limit);
        if (is_null($find_result)) {
            return null;
        }

        $has_more = $this->_getHasMore($limit, count($find_result));
        if ($has_more) {
            array_pop($find_result);
        }
        $following_list = $this->_alignFormatOfEntry($find_result, 'following_user_id');

        return array(
            $has_more,
            $following_list
        );
    }

    public function getFollowingListOrderInFollowingUser($user_id = null,
                                                         $limit = 10,
                                                         $offset = 0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $find_values              = array(
            'user_id' => $user_id,
        );
        $find_result              = $this->accessor_following->find('find_list_by_user_id_sort_following_user_id', $find_values, $offset, $limit);

        return $find_result;
    }

    // offset is following_user_id
    public function getFollowingListByFollowingUser($following_user_id,
                                                    $user_id = null,
                                                    $limit = 10)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $find_values              = array(
            'following_user_id' => $following_user_id,
            'user_id'           => $user_id,
        );
        $find_result              = $this->accessor_following->find('find_list_by_user_id_and_following_user_id', $find_values, 0, $limit);

        return $find_result;
    }

    public function addFollowingUser($following_user_id,
                                     $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $add_values               = array(
            'following_user_id' => $following_user_id,
            'user_id'           => $user_id,
        );
        $add_result               = $this->accessor_following->execute('add_following', $add_values);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $user_id;
        $mod_tdlog->state = $mod_tdlog->getInsertState();
        $mod_tdlog->following_user_id = $following_user_id;
        $mod_tdlog->result = $add_result;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedFollowingTableName());

        return $add_result;
    }

    public function removeFollowingUser($following_user_id,
                                        $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $remove_values            = array(
            'following_user_id' => $following_user_id,
            'user_id'           => $user_id,
        );
        $remove_result            = $this->accessor_following->execute('remove_following', $remove_values);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $user_id;
        $mod_tdlog->state = $mod_tdlog->getDeleteState();
        $mod_tdlog->following_user_id = $following_user_id;
        $mod_tdlog->result = $remove_result;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedFollowingTableName());

        return $remove_result;
    }

    public function getFollowedUser($followed_user_id,
                                    $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $find_values             = array(
            'user_id'          => $user_id,
            'followed_user_id' => $followed_user_id,
        );
        $find_result             = $this->accessor_followed->findFirst('find_user_by_user_id_and_followed_user_id', $find_values);

        $is_followed = true;
        if (is_null($find_result)) {
            $is_followed = false;
        }

        return $is_followed;
    }

    public function getFollowedListOrderInTime($user_id = null,
                                               $input_limit = 10,
                                               $offset = 0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }
        $limit = $input_limit + 1;

        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $find_values             = array(
            'user_id' => $user_id,
        );
        $find_result             = $this->accessor_followed->find(
            'find_list_by_user_id_sort_ctime',
            $find_values,
            $offset,
            $limit
        );

        if (is_null($find_result)) {
            return null;
        }

        $has_more = $this->_getHasMore($limit, count($find_result));
        if ($has_more) {
            array_pop($find_result);
        }
        $followed_list = $this->_alignFormatOfEntry($find_result, 'followed_user_id');

        return array(
            $has_more,
            $followed_list
        );
    }

    public function getFollowedListOrderInFollowedUser($user_id = null,
                                                       $limit = 20,
                                                       $offset = 0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $find_values             = array(
            'user_id' => $user_id,
        );
        $find_result             = $this->accessor_followed->find('find_list_by_user_id_sort_followed_user_id', $find_values, $offset, $limit);

        if (is_null($find_result)) {
            return array();
        }

        $destinations = $this->_alignFormatOfDestination($find_result);

        return $destinations;
    }

    // offset is followed_user_id
    public function getFollowedListByFollowedUser($followed_user_id,
                                                  $user_id = null,
                                                  $input_limit = 10)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $limit = $input_limit + 1;

        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $find_values             = array(
            'followed_user_id' => $followed_user_id,
            'user_id'          => $user_id,
        );
        $find_result             = $this->accessor_followed->find('find_list_by_user_id_and_followed_user_id', $find_values, 0, $limit);

        if (is_null($find_result)) {
            return array(
                false,
                array()
            );
        }

        $has_more = $this->_getHasMore($limit, count($find_result));
        if ($has_more) {
            array_pop($find_result);
        }

        $destinations = $this->_alignFormatOfDestination($find_result);

        return array(
            $has_more,
            $destinations
        );
    }

    public function addFollowedUser($followed_user_id,
                                    $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $add_values              = array(
            'followed_user_id' => $followed_user_id,
            'user_id'          => $user_id,
        );
        $add_result              = $this->accessor_followed->execute('add_followed', $add_values);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $user_id;
        $mod_tdlog->state = $mod_tdlog->getInsertState();
        $mod_tdlog->followed_user_id = $followed_user_id;
        $mod_tdlog->result = $add_result;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedFollowedTableName());

        return $add_result;
    }

    public function removeFollowedUser($followed_user_id,
                                       $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $remove_values           = array(
            'followed_user_id' => $followed_user_id,
            'user_id'          => $user_id,
        );
        $remove_result           = $this->accessor_followed->execute('remove_followed', $remove_values);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $user_id;
        $mod_tdlog->state = $mod_tdlog->getDeleteState();
        $mod_tdlog->followed_user_id = $followed_user_id;
        $mod_tdlog->result = $remove_result;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedFollowedTableName());

        return $remove_result;
    }

    // for appendUserInfo()
    public function _alignFormatOfEntry($find_results, $column_name)
    {
        $aligned_format_list = array();

        foreach ($find_results as $result) {
            $aligned_format_list[] = array(
                'content' => array(
                    'sender_id' => $result[$column_name]
                )
            );
        }

        return $aligned_format_list;
    }

    public function _alignFormatOfDestination($find_results)
    {
        $aligned_format_list = array();

        foreach ($find_results as $result) {
            $aligned_format_list[] = $result['followed_user_id'];
        }

        return $aligned_format_list;
    }

    public function _getHasMore($limit, $result_count)
    {
        if ($limit == $result_count) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Get mutual check (following and followed)
     *
     * @param null $user_id
     * @param int  $limit
     * @param int  $offset
     *
     * @return array
     * @author Thien Nguyen <z.thanhthien.nguyen@gree.co.jp>
     */
    public function getFollowMutualListByUserId($user_id = null, $limit = 10, $offset=0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }
        $find_values = array('user_id' => $user_id);

        // Step 1: Get all users who user A following
        $following_list = $this->_getFollowingList($find_values);
        if (empty($following_list)) {
            return array(false, false, array());
        }

        // Step 2:  Get all users who followed user A
        $followed_list = $this->_getFollowedList($find_values);
        if (empty($followed_list)) {
            return array(false, false, array());
        }

        // Step 3: Merge to get mutual check
        $_mutual   = array_intersect($following_list, $followed_list);
        $mutual = array();
        foreach ($_mutual as $result) {
            $mutual[] = array(
                'content' => array(
                    'sender_id' => $result
                )
            );
        }

        $total    = count($mutual);
        $has_more = $this->_getHasMore($limit, $total);
        $mutual = array_slice($mutual, $offset, $limit);

        return array(
            $has_more,
            $total,
            $mutual
        );
    }

    /**
     * @param $find_values
     *
     * @return array
     * @author Thien Nguyen <z.thanhthien.nguyen@gree.co.jp>
     */
    private function _getFollowingList($find_values)
    {
        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $find_result              = $this->accessor_following->find('find_list_by_user_id_sort_ctime', $find_values);
        if (is_null($find_result)) {
            return array();
        }

        $aligned_format_list = array();
        foreach ($find_result as $result) {
            $aligned_format_list[] = $result['following_user_id'];
        }
        return $aligned_format_list;
    }

    /**
     * @param $find_values
     *
     * @return array
     * @author Thien Nguyen <z.thanhthien.nguyen@gree.co.jp>
     */
    private function _getFollowedList($find_values)
    {
        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $find_result             = $this->accessor_followed->find('find_list_by_user_id_sort_ctime', $find_values);
        if (is_null($find_result)) {
            return array();
        }

        $aligned_format_list = array();
        foreach ($find_result as $result) {
            $aligned_format_list[] = $result['followed_user_id'];
        }
        return $aligned_format_list;
    }

    /**
     * get count the followed users by user id
     *
     * @param $user_id
     * @return int
     */
    public function getFollowedCount($user_id)
    {
        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $get_values = array(
            'user_id' => $user_id,
        );
        // get the total number of followed users
        $get_result = $this->accessor_followed->toValue('count_list_by_user_id', $get_values);

        return $get_result;
    }

    /**
     * get count the following users by user id
     *
     * @param $user_id
     * @return int
     */
    public function getFollowingCount($user_id)
    {
        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $get_values = array(
            'user_id' => $user_id,
        );
        // get the total number of following users
        $get_result = $this->accessor_following->toValue('count_list_by_user_id', $get_values);

        return $get_result;
    }

    /**
     * get followed date of 2 users
     *
     * @param $followed_user_id
     * @param null $user_id
     * @return null
     */
    public function getFollowedDate($followed_user_id, $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_followed = Cascade::getAccessor('avatar_feed#followed');
        $find_values             = array(
            'user_id'          => $user_id,
            'followed_user_id' => $followed_user_id,
        );
        $find_result             = $this->accessor_followed->findFirst('find_date_by_user_id_and_followed_user_id', $find_values);
        if (!empty($find_result) && $find_result['ctime']) {
            return $find_result['ctime'];
        }

        return null;
    }

    /**
     * get following date of 2 users
     *
     * @param $following_user_id
     * @param null $user_id
     * @return null
     */
    public function getFollowingDate($following_user_id, $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_following = Cascade::getAccessor('avatar_feed#following');
        $find_values             = array(
            'user_id'           => $user_id,
            'following_user_id' => $following_user_id,
        );
        $find_result             = $this->accessor_following->findFirst('find_date_by_user_id_and_following_user_id', $find_values);
        if (!empty($find_result) && $find_result['ctime']) {
            return $find_result['ctime'];
        }

        return null;
    }

    /**
     * get block date of 2 users
     *
     * @param $block_user_id
     * @param null $user_id
     * @return null
     */
    public function getBlockDate($block_user_id, $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $find_values          = array(
            'user_id'       => $user_id,
            'block_user_id' => $block_user_id,
        );
        $find_result             = $this->accessor_block->findFirst('find_date_by_user_id_and_block_user_id', $find_values);
        if (!empty($find_result) && $find_result['ctime']) {
            return $find_result['ctime'];
        }

        return null;
    }
}
