<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Gree_GenericDao_Greeting_TotalDao
 */
class Gree_GenericDao_Greeting_TotalDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'avatar_greeting_total';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',          // UserID
        'poke_count',
        'poked_count',
        'mutual_count',
        'notice_count',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_userid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}

        // {{{ update queries
        'entry' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, poke_count, poked_count, mutual_count, notice_count, ctime) VALUES (:user_id, 0, 0, 0, 0, NOW())',
        ),
        'entry_add_poked' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, poke_count, poked_count, mutual_count, notice_count, ctime) VALUES (:user_id, 0, 1, 0, 1, NOW()) ON DUPLICATE KEY UPDATE poked_count=poked_count+1,notice_count=notice_count+1',
        ),
        'entry_add_mutual' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, poke_count, poked_count, mutual_count, notice_count, ctime) VALUES (:user_id, 0, 0, 1, 0, NOW()) ON DUPLICATE KEY UPDATE mutual_count=mutual_count+1',
        ),
        'entry_add_poke' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, poke_count, poked_count, mutual_count, notice_count, ctime) VALUES (:user_id, 1, 0, 0, 0, NOW()) ON DUPLICATE KEY UPDATE poke_count=poke_count+1',
        ),
        'entry_add_poke_and_mutual' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, poke_count, poked_count, mutual_count, notice_count, ctime) VALUES (:user_id, 1, 0, 1, 0, NOW()) ON DUPLICATE KEY UPDATE poke_count=poke_count+1,mutual_count=mutual_count+1',
        ),
        'add_poked' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET poked_count=poked_count+1 WHERE user_id=:user_id',
        ),
        'add_poke' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET poke_count=poke_count+1 WHERE user_id=:user_id',
        ),
        'notice_clear' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET notice_count=0 WHERE user_id=:user_id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `poke_count`          INT(10)     UNSIGNED NOT NULL DEFAULT 0,
                  `poked_count`         INT(10)     UNSIGNED NOT NULL DEFAULT 0,
                  `mutual_count`        INT(10)     UNSIGNED NOT NULL DEFAULT 0,
                  `notice_count`        INT(10)     UNSIGNED NOT NULL DEFAULT 0,
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {   
        $this->_farm_selector = new Gree_GenericDao_Greeting_TotalFarmSelector();
    }   
    // }}}
}

class Gree_GenericDao_Greeting_TotalFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    // var string �ơ��֥�ե������ֹ�ե����ޥå�
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /** 
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {   
        // �ơ��֥�̾�μ���
        if (empty($hint)) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }   
        // �ơ��֥�̾�˥ե�������ɲ�
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['event_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }   
    // }}}
}
