<?php

final class Gree_Service_Avatarfeed_Test_Processor_Follow_Import_RecommendTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $accessor;
    var $module_follow;
    var $module_appfeed;
    var $module;

    public function setUp()
    {
        $this->avatar_feed    = Gree_Service_AvatarFeed::getInstance();
        $this->module         = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->accessor       = Cascade::getAccessor('avatar_feed#recommend_user');
        $this->module_follow  = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_appfeed = Gree_Service_AvatarFeed_Module::singleton('AppFeed');

        // initalize recommend_user table
        $params = array();
        $this->accessor->execute('drop_table', $params);
        $this->accessor->execute('create_table', $params);

        // initialize follow status
        $this->initialize_all_test_user_follow_status();
    }

    public function test_not_exist_table()
    {
        $this->accessor->execute('drop_table', array());

        sleep(2);

        $result = $this->avatar_feed->process('follow_import_recommend', array(), UNIT_TEST_USER_ID_1);
        $this->assertFalse($result);
    }

    public function test_not_exist_import_user()
    {
        sleep(2);

        $result = $this->avatar_feed->process('follow_import_recommend', array(), UNIT_TEST_USER_ID_1);
        $this->assertTrue($result);

    }

    public function test_failed_following_user()
    {
        // can not test
    }

    public function test_failed_get_first_entry_of_import_user()
    {
        sleep(2);

        $this->_add_test_import_test_user_to_db();
        $this->initialize_feed_all_test_user();

        sleep(2);

        $result = $this->avatar_feed->process('follow_import_recommend', array('user_id' => UNIT_TEST_USER_ID_1));
        $this->assertTrue($result);

        sleep(2);

        //check follow number
        $follow_count = $this->module_follow->getFollowCount(UNIT_TEST_USER_ID_1);
        $this->assertEquals(GREE_SERVICE_AVATARFEED_IMPORT_RECOMMEND_NUMBER, $follow_count[0]);
    }

    public function test_success()
    {
        sleep(2);

        $this->_add_test_import_test_user_to_db();
        $this->initialize_feed_all_test_user();

        sleep(2);

        $this->_add_test_entry_for_test_user_feed();

        sleep(5);

        $result = $this->avatar_feed->process('follow_import_recommend', array('user_id' => UNIT_TEST_USER_ID_1));
        $this->assertTrue($result);

        sleep(2);

        //check follow number
        $follow_count = $this->module_follow->getFollowCount(UNIT_TEST_USER_ID_1);
        $this->assertEquals(GREE_SERVICE_AVATARFEED_IMPORT_RECOMMEND_NUMBER, $follow_count[0]);
    }

    public function _add_test_import_test_user_to_db()
    {
        foreach ($this->test_user_list as $test_user_id) {
            $params = array(
                'user_id' => $test_user_id
            );
            $this->accessor->execute('insert_user_id', $params);
        }
    }

    public function _add_test_entry_for_test_user_feed()
    {
        foreach ($this->test_user_list as $test_user_id) {
            $this->_createEntry(UNIT_TEST_USER_ID_1, $test_user_id, 'user');
        }
    }
}