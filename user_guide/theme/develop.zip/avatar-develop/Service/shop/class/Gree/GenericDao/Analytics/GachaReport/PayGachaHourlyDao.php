<?php

class Gree_GenericDao_Analytics_GachaReport_PayGachaHourlyDao extends Gree_GenericDao
{
    var $_table_name = 'pay_gacha_hourly';

    var $_primary_key = 'id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_analytics';

    var $_slave_dsn = 'gree://slave/avatar_analytics';

    var $_auto_increment = true;

    var $_field_names = array(
        'id',
        'date',
        'hour',
        'is_release_day',
        'gacha_id',
        'type_id',
        'sex',
        'pay',
        'pay_uu',
        'login_uu',
        'gacha_page_uu',
        'mtime',
        'ctime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `date` DATE NOT NULL,
                    `hour` TINYINT UNSIGNED NOT NULL,
                    `is_release_day` BOOLEAN NOT NULL DEFAULT 0,
                    `gacha_id` INT NOT NULL,
                    `type_id` INT NOT NULL,
                    `sex` TINYINT UNSIGNED NOT NULL,
                    `pay` INT UNSIGNED NOT NULL DEFAULT 0,
                    `pay_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `login_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `gacha_page_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    UNIQUE (date, hour, gacha_id, type_id, sex),
                    INDEX gacha_id (gacha_id),
                    INDEX type_id (type_id)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
         'insert_or_update_pay' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ (date, hour, gacha_id, type_id, sex, pay, pay_uu, is_release_day, ctime)
                      VALUES (:date, :hour, :gacha_id, :type_id, :sex, :pay, :pay_uu, :is_release_day, NOW())
                      ON DUPLICATE KEY UPDATE pay = VALUES(pay), pay_uu = VALUES(pay_uu), is_release_day = VALUES(is_release_day)",
        ),
        'insert_or_update_login_uu' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ (date, hour, gacha_id, type_id, sex, login_uu, gacha_page_uu, ctime)
                      VALUES (:date, :hour, :gacha_id, :type_id, :sex, :login_uu, :gacha_page_uu, NOW())
                      ON DUPLICATE KEY UPDATE login_uu = VALUES(login_uu), gacha_page_uu = VALUES(gacha_page_uu)",
        ),
        'delete_old_record' => array(
            'sql' => "DELETE FROM __TABLE_NAME__ WHERE date < :date and is_release_day = 0",
        ),
        'find_by_date' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE date = :date order by date, hour, sex",
        ),
        'find_enable_days' => array(
            'sql' => "SELECT distinct date FROM __TABLE_NAME__ WHERE is_release_day = 0 order by date",
        ),
        'find_hourly_range' => array(
            'sql' => "SELECT date, hour, sum(pay) as pay FROM __TABLE_NAME__ WHERE date >= :sdate and date <= :edate group by date, hour order by date, hour",
        ),
        'find_release_hourly_by_gacha_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE gacha_id = :gacha_id and is_release_day = 1 order by hour, sex",
        ),
   );
}
