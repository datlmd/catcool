<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/LoginCampaign/MasterDao.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_LoginCampaign_MasterDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'login_campaign_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'login_campaign_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var ��Ͽ�������̾ */
    var $_auto_increment = 'true';

    /** @var �ե������̾ */
    var $_field_names = array(
        'login_campaign_id',
        'status',
        'name',
        'open_datetime',
        'close_datetime',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'get_all_master' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY login_campaign_id DESC'
        ),
        'find_by_login_campaign_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE login_campaign_id = :login_campaign_id'
        ),
        // }}}
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `login_campaign_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `status` tinyint(2) unsigned NOT NULL DEFAULT '0',
                `name` varchar(255) NOT NULL DEFAULT '',
                `open_datetime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `close_datetime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`login_campaign_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=ujis"
        ),
        'update_master' => array(
            'sql' => 'UPDATE __TABLE_NAME__ 
                      SET status = :status, 
                          name = :name, 
                          open_datetime  = :open_datetime, 
                          close_datetime = :close_datetime, 
                      WHERE 
                          login_campaign_id = :login_campaign_id'
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
