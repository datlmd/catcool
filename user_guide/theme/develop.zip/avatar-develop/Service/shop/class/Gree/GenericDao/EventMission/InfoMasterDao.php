<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/EventMission/InfoMasterDao.php
 * @package     GREE Avatar
 * @since       2018-10-16
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * InfoMaster form constructor
 * @access      public
 */
class Gree_GenericDao_EventMission_InfoMasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'mission_info_master';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'mission_type',
        'mission_content',
        'mission_value',
        'incentive',
        'is_deleted',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all_available' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE is_deleted = 0',
        ],
        'find_by_id'         => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'find_active_by_id'         => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id AND is_deleted = 0',
        ],
        'find_detail_by_type_and_content' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE mission_type = :mission_type AND mission_content = :mission_content AND is_deleted = 0',
        ],
        // }}}

        // {{{ update queries
        'entry'              => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (mission_type, mission_content, mission_value, incentive, ctime) VALUES (:mission_type, :mission_content, :mission_value, :incentive, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'             => [
            'sql' => 'UPDATE __TABLE_NAME__ SET mission_type = :mission_type, mission_content = :mission_content, mission_value = :mission_value, incentive = :incentive WHERE id = :id',
        ],
        'soft_delete'        => [
            'sql' => 'UPDATE __TABLE_NAME__ SET is_deleted = :is_deleted WHERE id = :id',
        ],
        // }}}

        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `mission_type` INT UNSIGNED NOT NULL,
                    `mission_content` INT UNSIGNED NOT NULL,
                    `mission_value` INT UNSIGNED NOT NULL,
                    `incentive` VARCHAR(255) NOT NULL,
                    `is_deleted` INT UNSIGNED NOT NULL DEFAULT '0',
                    `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
    ];
}
