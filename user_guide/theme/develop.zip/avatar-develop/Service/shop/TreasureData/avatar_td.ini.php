<?php
return [
	'db_list' => [
		'dev' => 'avatar_test',
		'staging' => 'avatar',
		'production' => 'avatar',
    ],
    'db_list_xpf' => [
		'dev' => 'avatar_xpf_test',
		'staging' => 'avatar_xpf',
		'production' => 'avatar_xpf',
	],
	'recovery_dir' => '',
	'socket_name' => 'unix:///var/run/td-agent/td-agent.sock',
	'enable_td' => '/home/gree/xgree/avatar/Service/shop/TreasureData/enable-td',
];
