<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Quiz/Master.php
 *
 *  @author   Masayoshi Yoshino <masayoshi.yoshino@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_Quiz_MasterDao extends Gree_GenericDao_Apc {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'quiz_master';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'event_id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_quiz';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_quiz';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
	                          'event_id',
							  'status',
                              'max_mission',
							  'start_datetime',
							  'end_datetime',
							  'mtime',
							  'ctime'
							 );
      
	/** @var ������ */
	var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY event_id DESC'
        ),
        'find_by_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id IN (:event_ids) ORDER BY event_id desc'
        ),
        'find_by_event_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id = :event_id'
        ),
        'find_active' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE :time BETWEEN start_datetime AND end_datetime AND status = 1',
            // TODO : ������˸��ߤλ��郎���ꤵ��Ƥ���Τ�APC�ǥ���å���Ǥ��ʤ����������ľ��
            'disable_apc' => true,
        ),
        // }}}
        // {{{ ������
        'insert_master' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (status, max_mission, start_datetime, end_datetime, ctime) VALUES (:status, :max_mission, :start_datetime, :end_datetime, now())',
            'return_last_insert_id' => true,
        ),
        'update_master' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status, max_mission = :max_mission, start_datetime = :start_datetime, end_datetime = :end_datetime WHERE event_id = :event_id'
        ),
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `event_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `status` TINYINT(2) NOT NULL DEFAULT '0',
                `max_mission` TINYINT(2) NOT NULL DEFAULT '0',
                `start_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`event_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__"
        ),
        // }}}
    ); 
}
