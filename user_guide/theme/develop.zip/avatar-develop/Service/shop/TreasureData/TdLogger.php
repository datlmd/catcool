<?php
/**
 * TdLogger.php
 *
 * @author  Norie Matsuda <norie.matsuda@gree.net>
 * @package GREE
 */

/**
 * logger class of avatar service
 *
 * @author  Norie Matsuda <norie.matsuda@gree.net>
 * @access  public
 * @package GREE
 */
class Gree_Service_Shop_TreasureData_TdLogger
{
    /* debug_flg  true -> output log : false-> skip log */
    private static $_debug_log_flg = false;

    /* server */
    const SERVICE_FP = 'mshop';
    const SERVICE_SP = 'tshop';
    const SERVICE_PC = 'avatar';

    /* device */
    const DEVICE_UNKNOWN = 'unknown';
    const DEVICE_FP      = 'fp';
    const DEVICE_IPHONE  = 'iphone';
    const DEVICE_ANDROID = 'android';
    const APP_TYPE_WEB    = '-web';
    const APP_TYPE_NATIVE = '-native';
    const DEVICE_WINDOWS_PHONE = 'windows-phone';
    const DEVICE_PC      = 'pc';

    /* region */
    const REGION_JP = 'JP';

    /* instance */
    private static $_instance = null;

    /* setting */
    private static $_avatar_td_info = [];

    /* default pay count */
    private static $_pay_count = 1 ;

    // {{{ __construct
    public function __construct() {
    }
    // }}}
    // {{{ getInstance
    public function getInstance() {
        if (self::$_instance !== null ) {
            return self::$_instance;
        }
        self::$_instance = new self();
        self::$_avatar_td_info = require dirname(__FILE__) . '/avatar_td.ini.php';

        return self::$_instance;
    }
    // }}}
    // {{{ writeTdLoggerLog
    public function writeTdLoggerLog($table_name, $log_record, $user_id = null){
        // check treasure data flg
        if ($this->isEnableTdLoggerLogging() === false) {
            return true;
        }
        if(!file_exists(self::$_avatar_td_info['enable_td'])) {
            // emergency stop
            return true;
        }

        // get User Info
        $log_record				= $this->_createUserInfoRecord($log_record);
        $log_record['region'] 	= $this->_getRegion();
        $log_record['service'] 	= $this->_getService();
        if (!isset($log_record['device'])) { $log_record['device'] 	= $this->_getDevice();}
        if ($user_id) { $log_record['uid'] = $user_id; }

        $db_name = $this->_getDbName($log_record['uid']);
        $log_recovery_dir = $this->_getLogRecoveryDir();
        $socket_name = $this->_getSocketName();
        // get TreasureDataLogger Instance
        require_once PATH_ROOT . '/xgree/avatar/lib/td_toolkit/Td/Logger.php';
        $logger = Td_Logger::getInstance($db_name, $log_recovery_dir, $socket_name);
        
        if ($logger->write($table_name, $log_record) === false) {
                return false;
        }
    }
    // }}}
    // {{{ writeTdLoggerLogForBatch
    /**
     * �Хå�/Async�ѤΥ��������ؿ��Ǥ���
     * writeTdLoggerLog�Ȱ㤤���桼���������ưŪ����Ϳ���ޤ���
     */
    public function writeTdLoggerLogForBatch($table_name, $log_record){
        // check treasure data flg
        if ($this->isEnableTdLoggerLoggingForBatch() === false) {
            return true;
        }
        if(!file_exists(self::$_avatar_td_info['enable_td'])) {
            // emergency stop
            return true;
        }

        $db_name          = $this->_getDbName();
        $log_recovery_dir = $this->_getLogRecoveryDir();
        $socket_name      = $this->_getSocketName();
        // get TreasureDataLogger Instance
        require_once PATH_ROOT . '/xgree/avatar/lib/td_toolkit/Td/Logger.php';
        $logger = Td_Logger::getInstance($db_name, $log_recovery_dir, $socket_name);

        if ($logger->write($table_name, $log_record) === false) {
                return false;
        }
    }
    // }}}
    // {{{
    private function _getInputTag() {
        $http_vars = array_merge($_POST, $_GET);
        if (!empty($http_vars['from_shop'])) {
            return $http_vars['from_shop'];
        }
    }
    // }}}
    // {{{ writeTdLoggerAccessLog
    public function writeTdLoggerAccessLog($action_name, $response_time=0) {
        if (isset($_SERVER['HTTP_USER_AGENT'])) {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
        } else {
            $user_agent = '';
        }
        $log_record['user_agent'] = $user_agent;
        $log_record['action'] = $action_name;

        if (Gree_Service_Shop_Util::isAvatarApp()) {
            $log_record['sdk_version']    = $this->_getSDKVersion();
            $log_record['device_version'] = $this->_getAppVersion();
        }

        $log_record['request'] = $this->createRequestLog();
        $log_record['response_time'] = $response_time;
        $log_record['from_shop'] = $this->_getInputTag();

        if (array_key_exists('HTTP_REFERER', $_SERVER) === true) {
            $log_record['referer'] = $_SERVER['HTTP_REFERER'];
        } else {
            $log_record['referer'] = '';
        }

        $log_record['memory_peak_usage'] = memory_get_peak_usage(true);

        return $this->writeTdLoggerLog('access', $log_record);
    }
    // }}}
    // {{{ createRequestLog
    private function createRequestLog() {
        $param = $_REQUEST;
        $ret = '';
        if(count($param) > 0) {
            foreach ($param as $key => $val) {
                if (is_array($val)) {
                    $val = implode(',', $val);
                }
                $ret .= $key .'='.$val.'&';
            }
        }
        return $ret;
    }
    // }}}
    // {{{ writeLogRecord
    public function writeLogRecord($result_info, $type, $route = LIFE_ROUTE_AVATAR_NORMAL) {
        // write pay record
        $this->writeItemGainLog($result_info , $type, $route);
        // write item_gain record
        $this->writePayLog($result_info , $type, $route);
    }
    // }}}
    // {{{ writePayLog
    public function writePayLog($result_info, $type) {
        if ($result_info['price'] <= 0) {
            return;
        }
        $pay_log_record = $this->_createPayRecord($result_info,$type);
        $this->writeTdLoggerLog('pay',$pay_log_record);
    }
    // }}}
    // {{{ writeItemGainLog
    public function writeItemGainLog($result_info, $type, $route = LIFE_ROUTE_AVATAR_NORMAL) {
        if ($result_info['id'] <= 0) {
            return; // skip log
        }
        $user_id = null;
        if (isset($result_info['user_id'])) {
            $user_id = $result_info['user_id'];
        }
        $gain_log_record = $this->_createItemGainRecord($result_info,$type,$route);
        $this->writeTdLoggerLog('item_gain', $gain_log_record, $user_id);
    }
    // }}}
    // {{{ writeGiftItemGainLog
    public function writeGiftItemGainLog($result_info, $type, $route, $user_id) {
        $gain_log_record = $this->_createItemGainRecord($result_info,$type,$route);
        $this->writeTdLoggerLog('item_gain', $gain_log_record, $user_id);
    }
    // }}}
    // {{{ writeSPLoginCampaignLog
    public function writeSPLoginCampaignLog($result_info) {
        $log_record = [
                'item_id'               => $result_info['item_id'],
                'first_receive_date'    => $result_info['first_receive_date'],
                'last_receive_date'     => $result_info['last_receive_date'],
                'day_count'             => $result_info['day_count'],
        ];
        $this->writeTdLoggerLog('sp_login_campaign', $log_record);
    }
    // }}}
    // {{{ writeStarGachaLog
    public function writeStarGachaLog($user_id, $gacha_id, $point, $count, $type) {
        $log_record = [
            'gacha_id'  => $gacha_id,
            'point'     => $point,
            'count'     => $count,
            'type'      => $type,
        ];
        $this->writeTdLoggerLog('star_gacha_point', $log_record, $user_id);
    }
    /// }}}
    // {{{ _createItemGainRecord
    private function _createItemGainRecord($result_info, $item_type, $route_type) {
        $log_record = [
                'item_id' 		=> $result_info['item_id'], // item_id is gacha_id in treasure data
                'price' 		=> $result_info['price'],
                'id' 			=> $result_info['id'],
                'code' 			=> $result_info['code'],
                'route_type' 	=> $route_type,
                'item_type' 	=> $item_type,
        ];
        return $log_record;
    }
    // }}}
    // {{{ _createPayRecord
    private function _createPayRecord($result_info, $item_type) {
        $result_info['gender'] = isset($result_info['gender']) ? $result_info['gender'] : 0;
        $log_record = [
                'item_id' 		=> $result_info['item_id'], // item_id is gacha_id in treasure data
                'price' 		=> $result_info['price'],
                'base_price' 	=> $result_info['base_price'],
                'code' 			=> $result_info['code'],
                'gender' 		=> $result_info['gender'],
                'count' 		=> self::$_pay_count, // default count 1
                'item_type' 	=> $item_type,
                'device'    => $this->_getPaymentDevice(),
                'sub_device' => $this->_getDevice(),
        ];
        return $log_record;
    }
    // }}}
    // {{{ _createUserInfoRecord
    private function _createUserInfoRecord($log_record) {
        $user_info = $this->_getUserInfo();

        $log_record['uid']              = !empty($user_info['user_id']) ? $user_info['user_id'] : 0;
        $log_record['user_link_num']    = !empty($user_info['user_link_num']) ? $user_info['user_link_num'] : 0;
        $log_record['user_sex']         = !empty($user_info['user_sex']) ? $user_info['user_sex'] : 0;
        $log_record['user_birth']       = !empty($user_info['user_birth']) ? $user_info['user_birth'] : 0;
        $log_record['user_pref']        = !empty($user_info['user_pref']) ? $user_info['user_pref'] : 0;
        $log_record['user_regist_datetime'] =  !empty($user_info['user_regist_datetime']) ? $user_info['user_regist_datetime'] : 0;

        return $log_record;
    }
    // }}}

    // {{{ _getPaymentDevice
    private function _getPaymentDevice() {

        if (isset($_COOKIE['uatype']) === true && $_COOKIE['uatype'] === 'iphone-app' &&  isset($_COOKIE['URLScheme']) === true && 
            $_COOKIE['URLScheme'] === 'greeapp' . Gree_Service_Shop_Util::getAppId()) {
            // iphone native (this log doesn't exist in avatar service.)
            return self::DEVICE_IPHONE. self::APP_TYPE_NATIVE;
        } else if (isset($_COOKIE['uatype']) === true && $_COOKIE['uatype'] === 'android-app' && isset($_COOKIE['URLScheme']) === true && 
            $_COOKIE['URLScheme'] === 'greeapp' . Gree_Service_Shop_Util::getAppId()) {
            // android native
            return self::DEVICE_ANDROID. self::APP_TYPE_NATIVE;
        } else if (Gree_Service_Shop_Util::isHostTshop() ||  defined('IS_AVATAR_TOUCH') || Gree_Ggp_Domain::isTLDNet()) {
            // host tshop and avatarnet

            if (isset($_SERVER['HTTP_USER_AGENT'])) {
                $user_agent = $_SERVER['HTTP_USER_AGENT'];
            } else {
                $user_agent = '';
            }

            // agent check.
            $cc_ua = new Gree_Service_Cc_Foundation_UserAgent($user_agent, $_COOKIE);
            if ($cc_ua->isIOS() === true) {
                // iphone web
               return self::DEVICE_IPHONE.self::APP_TYPE_WEB;
            } elseif ($cc_ua->isAndroid() === true) {
                // android web
                return self::DEVICE_ANDROID.self::APP_TYPE_WEB;
            } elseif ($cc_ua->isWindowsPhone()) {
                // windows phone
                return self::DEVICE_WINDOWS_PHONE;
            }
        } else if (defined('IS_AVATAR_PC')) {
            // pc
            return self::DEVICE_PC;
        } else {
            // fp
            return self::DEVICE_FP;
        }
        return self::DEVICE_UNKNOWN;
    }
    // }}}
    // {{{ _getDevice
    private function _getDevice() {
        if (Gree_Util::isFeaturePhone() === true) {
            //featurePhone
            return self::DEVICE_FP;
        }

        if (isset($_SERVER['HTTP_USER_AGENT'])) {
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
        } else {
            $user_agent = '';
        }
        //Use Control-Center.
        $srv_cc = getService('cc');
        $cc_ua = new Gree_Service_Cc_Foundation_UserAgent($user_agent, $_COOKIE);
        if ($cc_ua->isIOS() === true) {
            //ios
            $device = self::DEVICE_IPHONE;
        } elseif ($cc_ua->isAndroid() === true) {
            //android
            $device = self::DEVICE_ANDROID;
        } else {
            $smart_phone_user_agent = new SmartPhone_UserAgent($user_agent);
            if ($smart_phone_user_agent->isWindowsPhone()) {
                //windows Phone
                return self::DEVICE_WINDOWS_PHONE;
            } elseif (! isset($user_agent) || ! $smart_phone_user_agent->isSmartPhone()) {
                //pc
                return self::DEVICE_PC;
            }
            //unknown
            return self::DEVICE_UNKNOWN;
        }

        if ($cc_ua->isApp() === true) {
            if ($_COOKIE['URLScheme'] === 'greeapp' . Gree_Service_Shop_Util::getAppId()) {
                //avatar(sns) native application
                $device .= self::APP_TYPE_NATIVE;
            } else {
                //other native application
                 $device .= self::APP_TYPE_WEB;
            }
        } else {
            // web
            $device .= self::APP_TYPE_WEB;
        }
        return $device;
    }
    // }}}
    // {{{ _getUserInfo
    private function _getUserInfo() {
        $id = getService('id');
        $ctfy = $id->getCertify();
        $user_info = $ctfy->my;

        if (isset($ctfy->my['user_id']) === false) {
            $user_info['user_id'] = 0;
        }
         return $user_info;
    }
    // }}}
    // {{{ isEnableTdLoggerLogging
    public function isEnableTdLoggerLogging() {
        if (!GREE_SERVICE_SHOP_USER_LEVEL_BEGINNER) {
            // ��ǽ�ե饰��ǧ
            return false;
        }
        $state = Config::get('state');
        if ($state === 'dev' || $state === 'staging') {
            //��ȯ�Ķ��ȥ��ơ����󥰤ν��Ϥʤ�
            if (! self::$_debug_log_flg) { return false; }
        }
        if ((isset($_SERVER['HTTP_HOST']) === true) &&
            ($_SERVER['HTTP_HOST'] === HOST_MSHOP ||
             $_SERVER['HTTP_HOST'] === HOST_TSHOP ||
             $_SERVER['HTTP_HOST'] === HOST_TAVATAR ||
             $_SERVER['HTTP_HOST'] === HOST_AVATAR ||
             $_SERVER['HTTP_HOST'] === HOST_GAVATAR )) {
                //http request�ǳ��pirate�ؤΥ����������enable�ե����뤬����Ȥ��˥�����
                return true;
        }
        return false;
    }
    // }}}
    // {{{ isEnableTdLoggerLoggingForBatch
    /**
     * �Хå�/Async��ǥ����󥰤���Ȥ���ͭ����ǧ�ؿ��Ǥ���
     * isEnableTdLoggerLogging�Ȥϰ㤤��HTTP_HOST���ǧ���ޤ���
     */
    public function isEnableTdLoggerLoggingForBatch() {
        $state = Config::get('state');
        if ($state === 'dev' || $state === 'staging') {
            //��ȯ�Ķ��ȥ��ơ����󥰤ν��Ϥʤ�
            if (! self::$_debug_log_flg) { return false; }
        }

        return true;
    }
    // }}}
    // {{{ _getDbName
    private function _getDbName($user_id = null) {
        $db_list_index = 'db_list';
        if ($user_id) {
            if(!getService('user')->profile->isGREEUser($user_id)) {
                $db_list_index = $db_list_index . '_xpf';
            }
        }
        $name = self::$_avatar_td_info[$db_list_index][Config::get('state')];
        if (empty($name)) {
            return null;
        }
        return $name;
    }
    // }}}
    //{{{ _getLogRecoveryDir
     private function _getLogRecoveryDir() {
         $dir = self::$_avatar_td_info['recovery_dir'];
            if (empty($dir)) {
             return null;
         }
        return $dir;
    }
    //}}}
    //{{{ _getService
    private function _getService() {
        if ($_SERVER['HTTP_HOST'] === HOST_GAVATAR || $_SERVER['HTTP_HOST'] === HOST_TSHOP || $_SERVER['HTTP_HOST'] === HOST_TAVATAR ) {
            return self::SERVICE_SP;
        } elseif($_SERVER['HTTP_HOST'] === HOST_AVATAR) {
            return self::SERVICE_PC;
        } else {
            return self::SERVICE_FP;
        }
    }
    // }}}
    //{{{ _getSocketName
    private function _getSocketName() {
        $name = self::$_avatar_td_info['socket_name'];
            if (empty($name)) {
             return null;
         }
        return $name;
    }
    // }}}
    //{{{ _getRegion
    private function _getRegion() {
        return self::REGION_JP;
    }
    // }}}
    //{{{ _getSDKVersion
    private function _getSDKVersion() {
        $sdk_ver = null;
        if(isset($_COOKIE['iosSDKVersion'])) {
            $sdk_ver = $_COOKIE['iosSDKVersion'];
        } elseif (isset($_COOKIE['androidSDKVersion'])) {
            $sdk_ver = $_COOKIE['androidSDKVersion'];
        }
        return $sdk_ver;
    }
    // }}}
    //{{{ _getAppVersion
    private function _getAppVersion() {
        $app_ver = null;
        if(isset($_COOKIE['appVersion'])) {
            $app_ver = $_COOKIE['appVersion'];
        }
        return $app_ver;
    }
    // }}}
}
