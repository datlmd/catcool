<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	CampaignConditionDao.php
 *
 *	@author		Tomoaki Sawa <sawa@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: ConditionDao.php 30044 2008-03-17 10:25:16Z  $
 */
class Gree_GenericDao_Shop_Campaign_ConditionDao extends Gree_GenericDao {
	var $_table_name = 'shop_campaign_condition';
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';
	var $_primary_key = 'id';
	var $_auto_increment = true;
	var $_queries = array(
			'find_by_campaign_id' => array(
					'sql' => 'SELECT * FROM shop_campaign_condition WHERE campaign_id=:campaign_id'
			),
			'find_by_campaign_id_and_sex' => array(
					'sql' => 'SELECT * FROM shop_campaign_condition WHERE campaign_id=:campaign_id AND
						condition_sex=:condition_sex'
			),
			'find_by_campaign_id_and_sex_and_type' => array(
					'sql' => 'SELECT * FROM shop_campaign_condition WHERE campaign_id=:campaign_id 
						AND condition_sex=:condition_sex AND condition_type=:condition_type'
			),
			'find_all' => array(
					'sql' => 'SELECT * FROM shop_campaign_condition'
			),
			'delete_by_campaign_id_and_sex_and_type' => array(
					'sql' => 'DELETE FROM shop_campaign_condition WHERE campaign_id=:campaign_id AND
						 condition_sex=:condition_sex AND condition_type=:condition_type'
			),
            'find_by_campaign_ids_and_type' => array(
                'sql' => 'SELECT * FROM shop_campaign_condition WHERE campaign_id in (:campaign_ids) AND condition_type = :condition_type'
            ),
	);
}
?>
