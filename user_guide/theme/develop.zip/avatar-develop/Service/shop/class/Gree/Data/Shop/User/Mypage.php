<?php
/**
 * Service/shop/class/Gree/Data/User/Mypage.php
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */

require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Mypage/User.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Mypage/Watch.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Mypage/Fan.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Mypage/IgnoreMail.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Mypage/WatchScore.php';
require_once PATH_ROOT . '/service/shop/class/Gree/GenericDao/Mypage/Campaign/User.php';

/**
 * Gree_Service_Shop_Data_User_Mypage
 *
 * @package GREE
 * @access  public
 */
class Gree_Service_Shop_Data_User_Mypage extends Gree_Service_Shop_Data_Abstract
{
    protected $_shop_service            = null;
    protected $_session                 = null;
    protected $_format                  = array();

    // {{{ �ޥ��ڡ����������ơ�����
    protected $_open_status_list        = array(
        GREE_SERVICE_SHOP_MYPAGE_OPEN_STATUS_FALSE,     // ̵��
        GREE_SERVICE_SHOP_MYPAGE_OPEN_STATUS_TRUE,      // ͭ��
    );
    // }}}

    // {{{ �᡼��������ݥ��ơ�����
    protected $_ignore_status_list        = array(
        GREE_SERVICE_SHOP_IGNORE_MAIL_STATUS_FALSE,     // ���¤ʤ�
        GREE_SERVICE_SHOP_IGNORE_MAIL_STATUS_TRUE,      // ����
    );
    // }}}

    // {{{ dao name
    private $_dao_name_mypage_user      = "Shop_Mypage_User";
    private $_dao_name_mypage_watch     = "Shop_Mypage_Watch";
    private $_dao_name_mypage_fan       = "Shop_Mypage_Fan";
    private $_dao_name_mypage_ignore_ml = "Shop_Mypage_IgnoreMail";
    private $_dao_name_mypage_wscore    = "Shop_Mypage_WatchScore";
    private $_dao_name_mypage_campaign_user = "Shop_Mypage_Campaign_User";
    // }}}

    // {{{ APC cache
    private $_apc_cache_class           = null;
    private $_apc_namespace             = 'avatar#mypage_preview';

    // avatar recommend user cache
    private $_apc_recommend_key = 'avatar_recommand_user';
    private $_apc_recommend_sec = 30;
    // }}}

    // {{{ __construct
    /**
     * Gree_Service_Shop_Data_User_Mypage
     *
     * @access  public
     */
    public function __construct()
    {
        $this->_shop_service    = getService('shop');
        $this->_session         = Gree_GenericDao_SessionFactory::openSession();

        // APC cache
        if (Gree_Ggp_Domain::isTLDNet()) {
            $this->_apc_namespace   = 'avatar#mypage_preview_tld_net';
        }
        $this->_apc_cache_class = Gree_Cache::getInstance('local', $this->_apc_namespace);
    }
    // }}}


    //--------------------------------------------------------------------------
    // �ޥ��ڡ�������
    //--------------------------------------------------------------------------

    // {{{ getUser
    /**
     * @access  public
     * @param   int     $user_id
     * @return  array
     */
    public function getUser($user_id, $regist_status = GREE_SERVICE_SHOP_MYPAGE_REGISTER_STATUS_TRUE)
    {
        $params = array(
            'user_id'       => $user_id,
            'regist_status' => $regist_status,
        );
        $user_data = $this->_session->toArray($this->_dao_name_mypage_user, 'find_by_user', $params);
        if (isset($user_data[0])) {
            return $user_data[0];
        }
    }
    // }}}

    // {{{ getNewerUsers
    /**
     * @access  public
     * @param   int     $farm_id
     * @param   int     $limit
     * @return  array
     * for apc cache recovery
     */
    public function getNewerUsers($farm_id, $limit = GREE_SERVICE_SHOP_MYPAGE_PREVIEW_CACHE_COUNT)
    {
        $params = array(
            'user_id'   => $farm_id,
            'limit'     => $limit,
        );
        return $this->_session->toArray($this->_dao_name_mypage_user, 'get_newer_users', $params);
    }
    // }}}

    // {{{ getUserList
    /**
     * @access  public
     * @param   int     $limit
     * @return  array
     * for user list
     */
    public function getCheckUserList($farm_id, $offset, $limit)
    {
        $params = array(
            'user_id'    => $farm_id,
            'open_status' => GREE_SERVICE_SHOP_MYPAGE_OPEN_STATUS_TRUE,
        );
        // user_id, last_change_time�����
        return $user_list = $this->_session->toArray($this->_dao_name_mypage_user, 'get_check_user_list', $params, $offset, $limit);
    }
    // }}}

    // {{{ getUserCount
    /**
     * @access  public
     * @return  array
     * for user list
     */
    public function getUserCount($farm_id)
    {
        $params = array(
            'user_id'    => $farm_id,
        );
        return $this->_session->toValue($this->_dao_name_mypage_user, 'get_user_count', $params);
    }
    // }}}

    //--------------------------------------------------------------------------

    // {{{ createUser
    /**
     * @access  public
     * @param   int         $user_id
     * @param   datetime    $last_change_time
     * @param   datetime    $last_purchase_time
     * @return  bool
     */
    public function createUser($user_id, $last_change_time = null, $last_purchase_time = null)
    {
        $params = array(
            'user_id'               => $user_id,
            'open_status'           => GREE_SERVICE_SHOP_MYPAGE_OPEN_STATUS_TRUE,
            'regist_status'         => GREE_SERVICE_SHOP_MYPAGE_REGISTER_STATUS_TRUE,
            'last_change_time'      => $last_change_time,
            'last_purchase_time'    => $last_purchase_time,
        );
        return $this->_session->execute($this->_dao_name_mypage_user, 'create', $params);
    }
    // }}}

    // {{{ deleteUser
    /**
     * @access  public
     * @param   int     $user_id
     * @return  bool
     */
    public function deleteUser($user_id)
    {
        return $this->_session->execute($this->_dao_name_mypage_user, 'unregist', array('user_id' => $user_id));
    }
    // }}}

    // {{{ updateOpenStatus
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $open_status
     * @return  bool
     */
    public function updateOpenStatus($user_id, $open_status)
    {
        if (!in_array($open_status, $this->_open_status_list)) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]", $code="001");
        }
        $params = array(
            'user_id'       => $user_id,
            'open_status'   => $open_status,
        );
        return $this->_session->execute($this->_dao_name_mypage_user, 'update_open_status', $params);
    }
    // }}}

    // {{{ updateFanCount
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $fan_count
     * @param   int     $new_fan_count(0 or 1)
     * @return  bool
     */
    public function updateFanCount($user_id, $fan_count = 0, $new_fan_count = 0)
    {
        if ($fan_count < 0) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]", $code="002");
        }
        $params = array(
            'user_id'       => $user_id,
            'fan_count'     => $fan_count,
            'new_fan_count' => $new_fan_count,
        );
        return $this->_session->execute($this->_dao_name_mypage_user, 'update_fan_count', $params);
    }
    // }}}

    // {{{ resetNewFanCount
    /**
     * @access  public
     * @param   int     $user_id
     * @return  bool
     */
    public function resetNewFanCount($user_id)
    {
        return $this->_session->execute($this->_dao_name_mypage_user, 'reset_new_fan_count', array('user_id' => $user_id));
    }
    // }}}

    // {{{ updateLastChangeTime
    /**
     * @access  public
     * @param   int         $user_id
     * @param   datetime    $purchase_time
     * @return  bool
     */
    public function updateLastChangeTime($user_id, $change_time = null)
    {
        if (is_null($change_time)) {
            $change_time = $this->_shop_service->getDate();
        }
        $params = array(
            'user_id'           => $user_id,
            'last_change_time'  => $change_time,
        );
        return $this->_session->execute($this->_dao_name_mypage_user, 'update_change_time', $params);
    }
    // }}}

    // {{{ updateLastPurchaseTime
    /**
     * @access  public
     * @param   int         $user_id
     * @param   datetime    $purchase_time
     * @return  bool
     */
    public function updateLastPurchaseTime($user_id, $purchase_time = null)
    {
        if (is_null($purchase_time)) {
            $purchase_time = $this->_shop_service->getDate();
        }
        $params = array(
            'user_id'               => $user_id,
            'last_purchase_time'    => $purchase_time,
        );
        return $this->_session->execute($this->_dao_name_mypage_user, 'update_purchase_time', $params);
    }
    // }}}

    //--------------------------------------------------------------------------
    // �᡼������������
    //--------------------------------------------------------------------------

    // {{{ getIgnoreMailStatus
    /**
     * @access  public
     * @param   int     $user_id
     * @return  bool
     */
    public function getIgnoreMailStatus($user_id)
    {
        $ignore_data = $this->_session->toArray($this->_dao_name_mypage_ignore_ml, 'get_status', array('user_id' => $user_id));
        if (isset($ignore_data[0])) {
            return $ignore_data[0];
        }
    }
    // }}}

    // {{{ updateIgnoreMailStatus
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $ignore_status
     * @return  bool
     */
    public function updateIgnoreMailStatus($user_id, $ignore_status)
    {
        if ($ignore_status == GREE_SERVICE_SHOP_IGNORE_MAIL_STATUS_TRUE) {
            $ret = $this->_session->execute($this->_dao_name_mypage_ignore_ml, 'on_status', array('user_id' => $user_id));
        } elseif ($ignore_status == GREE_SERVICE_SHOP_IGNORE_MAIL_STATUS_FALSE) {
            $ret = $this->_session->execute($this->_dao_name_mypage_ignore_ml, 'off_status', array('user_id' => $user_id));
        }
        throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]", $code="003");
    }
    // }}}

    //--------------------------------------------------------------------------
    // �����å������mypage_watch/mypage_fan��
    //--------------------------------------------------------------------------

    // {{{ getWatch
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $watch_user_id
     * @return  array
     */
    public function getWatch($user_id, $watch_user_id)
    {
        $params = array(
            'user_id'       => $user_id,
            'watch_user_id' => $watch_user_id,
        );
        $watch_data = $this->_session->toArray($this->_dao_name_mypage_watch, 'find_watch', $params);
        if (isset($watch_data[0])) {
            return $watch_data[0];
        }
    }
    // }}}

    // {{{ getWatchList
    /**
     * @access  public
     * @param   int     $user_id
     * @return  array
     */
    public function getWatchList($user_id)
    {
        $params = array(
            'user_id'   => $user_id,
            'status'    => GREE_SERVICE_SHOP_MYPAGE_WATCH_STATUS_ENABLE,
        );
        return $this->_session->toArray($this->_dao_name_mypage_watch, 'find_by_user', $params);
    }
    // }}}

    // {{{ getWatchListByUserIDs
    /**
     * @access  public
     * @param   array $user_ids
     * @return  array
     */
    public function getWatchListByUserIDs($user_id, $watch_user_ids)
    {
        $params = array(
            'user_id'   => $user_id,
            'watch_user_id' => $watch_user_ids,
            'status'    => GREE_SERVICE_SHOP_MYPAGE_WATCH_STATUS_ENABLE,
        );
        return $this->_session->toArray($this->_dao_name_mypage_watch, 'find_by_user_ids', $params);
    }
    // }}}

    // {{{ getWatchCount
    /**
     * @access  public
     * @param   int     $user_id
     * @return  int
     */
    public function getWatchCount($user_id)
    {
        $params = array(
            'user_id'   => $user_id,
            'status'    => GREE_SERVICE_SHOP_MYPAGE_WATCH_STATUS_ENABLE,
        );
        $cnt_data = $this->_session->toArray($this->_dao_name_mypage_watch, 'get_watch_count', $params);
        if (isset($cnt_data[0]['cnt'])) {
            return $cnt_data[0]['cnt'];
        }
        throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]", $code="004");
    }
    // }}}

    // {{{ getWatchCountByCtime
    /**
     * @access  public
     * @param   int     $user_id
     * @param   datetime $ctime
     * @return  int
     */
    public function getWatchCountByCtime($user_id, $ctime)
    {
        if (empty($ctime)) {
            // ctime�����ꤵ��Ƥ��ʤ����
            throw new Gree_Service_Shop_Exception_DataException('�����ƥ२�顼�Ǥ�');
        }
        $params = array(
            'user_id' => $user_id,
            'ctime'   => $ctime,
        );
        $cnt_data = $this->_session->toArray($this->_dao_name_mypage_watch, 'get_watch_count_by_ctime', $params);
        if (PEAR::isError($cnt_data)) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]");
        }
        if (isset($cnt_data[0]['cnt'])) {
            return $cnt_data[0]['cnt'];
        }
        throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]", $code="004");
    }
    // }}}

    // {{{ getFanListLimited
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $offset
     * @param   int     $limit
     * @return  array
     */
    public function getFanListLimited($user_id)
    {
        $params = array(
            'user_id'   => $user_id,
            'status'    => GREE_SERVICE_SHOP_MYPAGE_WATCH_STATUS_ENABLE,
            'limit'     => GREE_SERVICE_SHOP_MYPAGE_FAN_SEEK_MAX,
        );
        return $this->_session->toArray($this->_dao_name_mypage_fan, 'find_by_user_limited', $params);
    }
    // }}}

    // {{{ getFanCount
    /**
     * @access  public
     * @param   int     $user_id
     * @return  int
     */
    public function getFanCount($user_id)
    {
        $params = array(
            'user_id'   => $user_id,
            'status'    => GREE_SERVICE_SHOP_MYPAGE_WATCH_STATUS_ENABLE,
        );
        $cnt_data = $this->_session->toArray($this->_dao_name_mypage_fan, 'get_fan_count', $params);
        if (isset($cnt_data[0]['cnt'])) {
            return $cnt_data[0]['cnt'];
        }
        throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]", $code="005");
    }
    // }}}

    //--------------------------------------------------------------------------

    // {{{ updateWatch
    /**
     * @access  public
     * @param   int     $user_id
     * @param   int     $target_id
     * @param   int     $status
     * @return  bool
     */
    public function updateWatch($user_id, $target_id, $status)
    {
        if ($user_id == $target_id) {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Data [MypageData]", $code="006");
        }
        $watch_params = array(
            'user_id'       => $user_id,
            'watch_user_id' => $target_id,
            'status'        => $status,
        );
        $fan_params = array(
            'user_id'       => $target_id,
            'fan_user_id'   => $user_id,
            'status'        => $status,
        );
        if ($status == GREE_SERVICE_SHOP_MYPAGE_WATCH_STATUS_ENABLE) {
            // watch
            $ret = $this->_session->execute($this->_dao_name_mypage_watch, 'create', $watch_params);
            if ($ret) {
                return $this->_session->execute($this->_dao_name_mypage_fan, 'create', $fan_params);
            }
        } elseif ($status == GREE_SERVICE_SHOP_MYPAGE_WATCH_STATUS_DISABLE) {
            // unwatch
            $ret = $this->_session->execute($this->_dao_name_mypage_watch, 'update_status', $watch_params);
            if ($ret) {
                return $this->_session->execute($this->_dao_name_mypage_fan, 'update_status', $fan_params);
            }
        }
        return false;
    }
    // }}}

    //--------------------------------------------------------------------------
    // Recommend User
    //--------------------------------------------------------------------------
    // {{{ getRecommendUser
    /**
     * ��������桼����������������
     */
    public function getRecommendUser($user_id, $limit) {

        // cache�������
        if ($data = $this->getApcCache($this->_apc_recommend_key, $this->_apc_recommend_sec)) {
            if (!PEAR::isError($data) && count($data) > 0) {
                //print 'from cache!';
                return $data;
            }
        }

        $params = array(
            'user_id' => $user_id,
            'limit' => $limit,
        );
        $data = $this->_session->toArray($this->_dao_name_mypage_user, 'get_change_users', $params);

        // cache���ݻ�
        $this->setApcCache($this->_apc_recommend_key, $data);

        //print 'set cache!';

        return $data;
    }
    // }}}
    //--------------------------------------------------------------------------
    // APC
    //--------------------------------------------------------------------------

    // {{{ getApcCache
    /**
     * APC����å�������
     */
    public function getApcCache($key, $expire = GREE_SERVICE_SHOP_MYPAGE_PREVIEW_CACHE_TIME)
    {
        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $expire = null; // ��ȯ�ϤΤߥ���å���̵����
        }
        $cache_data = $this->_apc_cache_class->get($key, $expire, $this->_apc_namespace);
        if (PEAR::isError($cache_data) || empty($cache_data)) {
            return array();
        }
        return $cache_data;
    }
    // }}}

    // {{{ setApcCache
    /**
     * APC����å������¸
     */
    public function setApcCache($key, $data)
    {
        $ret = $this->_apc_cache_class->set($key, $data, time(), $this->_apc_namespace);
        if (PEAR::isError($ret) || empty($ret)) {
            return false;
        }
        return true;
    }
    // }}}

    //--------------------------------------------------------------------------
    // �����ڡ���桼��������
    //--------------------------------------------------------------------------

    // {{{ getCampaignUserCount
    /**
     * @access  public
     * @return  array
     * for user list
     */
    public function getCampaignUserCount($user_id, $campaign_id)
    {
        if (empty($campaign_id)) {
            // �����ڡ���ID�����ꤵ��Ƥ��ޤ���
            throw new Gree_Service_Shop_Exception_DataException('�����ڡ���ID�����ꤵ��Ƥ��ޤ���');
        }
        $params = array(
            'user_id'    => $user_id,
            'campaign_id' => $campaign_id,
        );
        return $this->_session->toValue($this->_dao_name_mypage_campaign_user, 'get_check_count', $params);
    }
    // }}}

    // {{{ getCampaignInfo
    /**
     * @access  public
     * @return  array
     * for user list
     */
    public function getCampaignUserInfo($user_id, $campaign_id)
    {
        if (empty($campaign_id)) {
            // �����ڡ���ID�����ꤵ��Ƥ��ޤ���
            throw new Gree_Service_Shop_Exception_DataException('�����ڡ���ID�����ꤵ��Ƥ��ޤ���');
        }
        $params = array(
            'user_id'    => $user_id,
            'campaign_id' => $campaign_id,
        );
        return $this->_session->toArray($this->_dao_name_mypage_campaign_user, 'get_user_info', $params);
    }
    // }}}

    // {{{ UpdateCampaignCheckCount
    /**
     * @access  public
     * @return  array
     * for user list
     */
    public function UpdateUserCheckCount($user_id, $campaign_id, $check_count)
    {
        if (empty($campaign_id)) {
            // �����ڡ���ID�����ꤵ��Ƥ��ʤ����
            throw new Gree_Service_Shop_Exception_DataException('�����ڡ���ID�����ꤵ��Ƥ��ޤ���');
        }
        $params = array(
            'user_id'    => $user_id,
            'campaign_id' => $campaign_id,
            'check_count' => $check_count,
        );
        return $this->_session->execute($this->_dao_name_mypage_campaign_user, 'update_check_count', $params);
    }
    // }}}

    // {{{ createUserRecord 
    /**
     * @access  public
     * @return  array
     * for user list
     */
    public function createUserRecord($user_id, $campaign_id, $check_count, $redirect_flag = 1)
    {
        if (empty($campaign_id)) {
            // �����ڡ���ID�����ꤵ��Ƥ��ʤ����
            throw new Gree_Service_Shop_Exception_DataException('�����ڡ���ID�����ꤵ��Ƥ��ޤ���');
        }
        $params = array(
            'user_id'    => $user_id,
            'campaign_id' => $campaign_id,
            'check_count' => $check_count,
            'redirect_flag' => $redirect_flag,
        );
        return $this->_session->execute($this->_dao_name_mypage_campaign_user, 'create_user_record', $params);
    }
    // }}}

    // {{{ UpdateCampaignRedirectFlag
    /**
     * @access  public
     * @return  array
     * for user list
     */
    public function UpdateRedirectFlag($user_id, $campaign_id, $redirect_flag)
    {
        if (empty($campaign_id)) {
            // �����ڡ���ID�����ꤵ��Ƥ��ʤ����
            throw new Gree_Service_Shop_Exception_DataException('�����ڡ���ID�����ꤵ��Ƥ��ޤ���');
        }
        $params = array(
            'user_id'    => $user_id,
            'campaign_id' => $campaign_id,
            'redirect_flag' => $redirect_flag,
        );
        return $this->_session->execute($this->_dao_name_mypage_campaign_user, 'update_redirect_flag', $params);
    }
    // }}}
}
