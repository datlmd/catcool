<?php

class Gree_Service_AvatarFeed_Logger
{
    const ERROR_PROCESSOR_STREAM                         = 1;
    const ERROR_PROCESSOR_FOLLOW                         = 2;
    const ERROR_PROCESSOR_FOLLOWING_ADD                  = 3;
    const ERROR_PROCESSOR_FOLLOWING_DELETE               = 4;
    const ERROR_PROCESSOR_ENTRY_CREATE                   = 5;
    const ERROR_PROCESSOR_ENTRY_DESTINATION_ADD          = 6;
    const ERROR_PROCESSOR_FOLLOW_IMPORT_LINK             = 7;
    const ERROR_PROCESSOR_FOLLOW_IMPORT_CHECK            = 8;
    const ERROR_PROCESSOR_BLOCK_ADD                      = 9;
    const ERROR_PROCESSOR_BLOCK_DELETE                   = 10;
    const ERROR_PROCESSOR_BLOCK_LIST_SHOW                = 11;
    const ERROR_PROCESSOR_LIKE_ADD                       = 12;
    const ERROR_PROCESSOR_LIKE_DELETE                    = 13;
    const ERROR_PROCESSOR_LIKE_LIST                      = 14;
    const ERROR_PROCESSOR_LIKE_STATUS_SHOW               = 15;
    const ERROR_PROCESSOR_NOTIFICATION_ADD               = 16;
    const ERROR_PROCESSOR_NOTIFICATION_REMOVE            = 17;
    const ERROR_PROCESSOR_INCENTIVE_ADD                  = 18;
    const ERROR_PROCESSOR_ENTRY_SHOW                     = 19;
    const ERROR_PROCESSOR_ENTRY_DELETE                   = 20;
    const ERROR_PROCESSOR_ENTRY_CREATE_RECENT_COORDINATE = 21;
    const ERROR_PROCESSOR_COMMENT_LIST_GET               = 22;
    const ERROR_PROCESSOR_COMMENT_CREATE                 = 23;
    const ERROR_PROCESSOR_COMMENT_DELETE                 = 24;
    const ERROR_PROCESSOR_FOLLOW_IMPORT_RANDOM           = 25;
    const ERROR_PROCESSOR_SUPPORT_ENTRY_CREATE           = 26;
    const ERROR_PROCESSOR_OFFICIAL_ENTRY_CREATE          = 27;
    const ERROR_PROCESSOR_OFFICIAL_ENTRY_SHOW            = 28;
    const ERROR_PROCESSOR_OFFICIAL_STREAM_SHOW           = 29;
    const ERROR_PROCESSOR_COMMENT_RELATION_CREATE        = 30;
    const ERROR_PROCESSOR_FOLLOW_IMPORT_RECOMMEND        = 31;
    const ERROR_PROCESSOR_INCENTIVE_INFO_GET             = 32;
    const ERROR_PROCESSOR_SCORE_INCREMENT                = 33;
    const ERROR_PROCESSOR_SCORE_LIST_SHOW                = 34;
    const ERROR_PROCESSOR_FOLLOWED_DELETE                = 35;


    const RETURN_PROCESSOR_INCENTIVE_ADD_OVER_SAME_USER_LIMIT = 1;
    const RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS              = 2;
    const RETURN_PROCESSOR_INCENTIVE_ADD_FAILED               = 3;
    const RETURN_PROCESSOR_INCENTIVE_ADD_DISABLED             = 4;
    const RETURN_PROCESSOR_INCENTIVE_ADD_NO_ACTIVE            = 5;


    public function __construct($message,
                                $code,
                                $context = array())
    {
        $log_name = GREE_SERVICE_AVATARFEED_LOG_PATH . 'error';
        $log_data = array(
            'msg'  => $message,
            'code' => $code
        );

        if (is_array($context)) {
            foreach ($context as $key => $value) {
                $log_data[$key] = $value;
            };
        } else {
            $log_data = array($context);
        }

        $srv_life = getService('shop');
        $logger   = $srv_life->getServiceLogger();
        $logger->avatarFeedLog($log_name, $log_data);
    }
}
