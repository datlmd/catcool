<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Shop/Campaign/UserDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id$
 */
class Gree_GenericDao_Shop_Campaign_UserDao extends Gree_GenericDao
{
    /** #@+
     *  @access private
     */

    /** @var �ơ��֥�̾ */
    var $_table_name = 'shop_campaign_user';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/shop';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/shop';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'state',
        'ctime',
    );

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',
                  `state`   TINYINT(3) UNSIGNED NOT NULL DEFAULT '0',
                  `ctime`   DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY  (`user_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'update_state' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state WHERE user_id = :user_id',
        ),
        // }}}
        // {{{ ���ȷ�
        'find' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
    );

    /** #@- */

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Shop_Campaign_UserSelector();
    }
    // }}}
}

/**
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id$
 */
class Gree_GenericDao_Shop_Campaign_UserSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ getTableName
    /**
     *    �ơ��֥�̾��������롣
     *
     *    @param        $dao        DAO���饹
     *    @param        $type       ���������ס�
     *    @param        $hint       �ơ��֥�����ҥ��
     *    @return       string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        if (empty($hint['campaign_name'])) {
            $type = !isset($hint['campaign_name']) ? 'missing' : 'empty';
            return PEAR::raiseError("farm hint campaign_name is $type. hint=[" . var_export($hint, true) . "];");
        }
        $campaign_name = $hint['campaign_name'];

        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is emptry. dao=" . get_class($dao) . "];");
        }
        $table_name = sprintf("%s_%s", $original_table_name, $campaign_name);
        return $table_name;
    }
    // }}}
}
