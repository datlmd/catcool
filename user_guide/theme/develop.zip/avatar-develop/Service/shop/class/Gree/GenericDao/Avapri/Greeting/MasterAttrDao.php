<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Avapri/Greeting/MasterAttrDao.php
 *
 * @package     GREE Avatar
 * @since       2018-06-04
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_Avapri_Greeting_MasterAttrDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'greeting_master_attr';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';

    /** @var field names */
    var $_field_names = [
        'id',
        'book_id',
        'name',
        'value',
        'end_date',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_book_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE book_id = :book_id',
        ],
        // }}}

        // {{{ update queries
        'entry' => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (book_id, name, value, ctime) VALUES (:book_id, :name, :value, NOW())',
            'return_last_insert_id' => true
        ],
        'delete_by_book_id_and_name' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE book_id = :book_id AND name = :name',
        ],
        // }}}

        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `book_id` INT UNSIGNED NOT NULL,
                    `name` VARCHAR(255) NOT NULL,
                    `value` VARCHAR(255) NOT NULL,
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                    `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                UNIQUE KEY `name` (`book_id`,`name`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ],
        // }}}
    ];
}
