<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Setting_Incentive_Point
    extends Cascade_DB_SQL_DataFormat
{
    protected $master_dsn = 'gree://master/avatar_feed_setting';
    // @var string  slave DSN
    protected $slave_dsn = 'gree://slave/avatar_feed_setting';
    // @var array   list of extra DSN
    protected $extra_dsn = array();
    // @var mixed   PRIMARY-KEY   (if multi-column-index, use array)
    protected $primary_key = 'action_type';
    // @var mixed   fetch mode (assoc/num)
    protected $fetch_mode = self::FETCH_MODE_ASSOC;
    // @var mixed   fetch KEY (if null, primary key is used)
    protected $fetch_key = NULL;
    // @var boolean flag representing whether use auto increment or not
    protected $auto_increment = false;
    // @var string  create date column name
    protected $created_at_column = 'ctime';
    // @var string  table name
    protected $table_name = 'incentive_point';
    // @var array   list of field names
    protected $field_names = array(
        'action_type',
        'start_date_time',
        'end_date_time',
        'point_per_action',
        'daily_limit_of_point',
        'ctime'
    );
    // @var array   queries
    protected $queries = array(
        'create_table'    => array(
            'sql' => '
              CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `action_type`                 varchar(100)      NOT NULL,
                `start_date_time`             datetime          NOT NULL,
                `end_date_time`               datetime          NOT NULL,
                `point_per_action`            int(11)  UNSIGNED NOT NULL,
                `daily_limit_of_point`        int(11)  UNSIGNED NOT NULL,
                `limit_of_point_to_same_user` int(11)  UNSIGNED NOT NULL,
                `ctime`                datetime          NOT NULL,
                PRIMARY KEY (`action_type`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ',
        ),
        'find_by_action_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE action_type = :action_type ORDER BY ctime DESC',
        ),
        'save'            => array(
            'sql' => 'INSERT INTO __TABLE_NAME__  (action_type,  start_date_time,  end_date_time,  point_per_action,  daily_limit_of_point,  limit_of_point_to_same_user, ctime)
                                          VALUES (:action_type, :start_date_time, :end_date_time, :point_per_action, :daily_limit_of_point, :limit_of_point_to_same_user, NOW())
                                          ON DUPLICATE KEY UPDATE start_date_time             = :start_date_time,
                                                                  end_date_time               = :end_date_time,
                                                                  point_per_action            = :point_per_action,
                                                                  daily_limit_of_point        = :daily_limit_of_point,
                                                                  limit_of_point_to_same_user = :limit_of_point_to_same_user'
        )
    );
}
