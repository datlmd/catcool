<?php
/**
 * Service/shop/class/Gree/Flare/Life/Item.php
 * Using cache life item
 *
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Flare.php';

class Gree_Service_Shop_Flare_Life_Item extends Gree_Service_Shop_Flare
{
    /**
     * Expire time default is 60s
     * @var int
     */
    var $_expire_time = null;

    public function __construct($expire_time = null)
    {
        if (empty($expire_time) || !is_numeric($expire_time)) {
            throw new Gree_Service_Shop_Exception("empty cache expire time(FLENT)");
        }
        $this->_expire_time = $expire_time;
    }

    protected function getExpireTime()
    {
        return $this->_expire_time;
    }

    protected function getNameSpace()
    {
        return 'result';
    }

    /**
     * getLifeItem
     *
     * @param $key
     *
     * @return mixed
     * @throws Gree_Service_Shop_Exception
     */
    public function getLifeItem($key)
    {
        try {
            list($ret, $var) = parent::get($this->getNameSpace() . $key);
        } catch (Exception $e) {
            if ($e->getCode() === parent::FLARE_EMERGENCY_ERROR) {
                throw new Gree_Service_Shop_Exception("System Error(FLENT)", $code = parent::FLARE_EMERGENCY_ERROR);
            }
        }

        return $ret;
    }

    /**
     * setLifeItem
     *
     * @param $key
     * @param $data
     *
     * @return bool
     */
    public function setLifeItem($key, $data)
    {
        try {
            $ret = parent::set($this->getNameSpace() . $key, $data);
        } catch (Exception $e) {
            // no action for exception
        }
        if (empty($ret) || $ret !== true) {
            return false;
        }

        return $ret;
    }

    public function set($key, $val)
    {
        throw new Exception();
    }

    public function get($key)
    {
        throw new Exception();
    }

    public function cas($key, $val, $version)
    {
        throw new Exception();
    }
}