<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Admin/NotificationDao.php
 *
 * @package     GREE Avatar
 */

/**
 * Notification form constructor
 *
 * @access      public
 */
class Gree_GenericDao_Admin_NotificationDao extends Gree_GenericDao
{
    /** @var table name */
    public $_table_name = 'notification';
    /** @var primary key */
    public $_primary_key = 'id';
    /** @var auto increment */
    public $_auto_increment = true;
    /** @var created at column */
    public $_created_at_column = 'ctime';
    /** @var updated at column */
    public $_updated_at_column = 'mtime';
    /** @var master dsn */
    public $_master_dsn = 'gree://master/avatar_user';
    /** @var slave dsn */
    public $_slave_dsn = 'gree://slave/avatar_user';
    /** @var field names */
    public $_field_names = [
        'id',
        'device',
        'state',
        'type',
        'opentime',
        'closetime',
        'title',
        'content',
        'ctime',
        'mtime',
    ];
    /** @var query definitions */
    public $_queries = [
        // {{{ refer queries
        'find_all_and_sort_id_desc'              => [
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY id DESC',
        ],
        'find_all_and_sort_device_asc'           => [
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY device ASC',
        ],
        'find_all_and_sort_device_desc'          => [
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY device DESC',
        ],
        'find_all_and_sort_state_asc'            => [
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY state ASC',
        ],
        'find_all_and_sort_state_desc'           => [
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY state DESC',
        ],
        'find_all_and_sort_type_asc'             => [
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY type ASC',
        ],
        'find_all_and_sort_type_desc'            => [
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY type DESC',
        ],
        'find_for_frontend'                      => [
            'sql' => 'SELECT id, title FROM __TABLE_NAME__ WHERE device IN (:device) AND state = :state AND (opentime <= :opentime AND :closetime <= closetime) ORDER BY type DESC',
        ],
        'find_for_frontend_with_type'            => [
            'sql' => 'SELECT id, title FROM __TABLE_NAME__ WHERE device IN (:device) AND state IN (:state) AND (opentime <= :opentime AND :closetime <= closetime) AND type IN (:type) ORDER BY id desc',
        ],
        'find_for_frontend_with_type_and_paging' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `device` IN (:device) AND `state` IN (:state) AND `opentime` <= :opentime AND `type` IN (:type) ORDER BY id DESC LIMIT :limit OFFSET :offset',
        ],
        'find_for_list_with_type'                => [
            'sql' => 'SELECT id, title FROM __TABLE_NAME__ WHERE device IN (:device) AND state = :state AND opentime <= :opentime AND type IN (:type) ORDER BY id desc',
        ],
        'find_by_id'                             => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'find_by_id_state'                       => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id AND state = :state ORDER BY id desc',
        ],
        'count_for_frontend_with_type'           => [
            'sql' => 'SELECT count(id) as total FROM __TABLE_NAME__ WHERE device IN (:device) AND state IN (:state) AND opentime <= :opentime AND type IN (:type)',
        ],
        // }}}

        // {{{ update queries
        'entry'                                  => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (device, state, `type`, modal_type, opentime, closetime, title, content, ctime) VALUES (:device, :state, :type, :modal_type, :opentime, :closetime, :title, :content, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'                                 => [
            'sql' => 'UPDATE __TABLE_NAME__ SET device = :device, state = :state, `type` = :type, modal_type = :modal_type, opentime = :opentime, closetime = :closetime, title = :title, content = :content WHERE id = :id',
        ],
        'delete'                                 => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'create_table'                           => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    device TINYINT(4) UNSIGNED NOT NULL DEFAULT '0',
                    state TINYINT(4) UNSIGNED NOT NULL DEFAULT '0',
                    type VARCHAR(255) NOT NULL,
                    modal_type TINYINT(4) UNSIGNED NOT NULL DEFAULT '0',
                    opentime DATETIME NOT NULL,
                    closetime DATETIME NOT NULL,
                    title text NOT NULL,
                    content text NOT NULL,
                    ctime             DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    mtime             TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                INDEX (device),
                INDEX (state),
                INDEX (type)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        'edit_column'                            => [
            'sql' => 'ALTER TABLE __TABLE_NAME__ CHANGE COLUMN `type` `type` smallint(6) UNSIGNED NOT NULL',
        ],
        'add_index'                              => [
            'sql' => 'ALTER TABLE __TABLE_NAME__ ADD INDEX (device), ADD INDEX (state), ADD INDEX (type)',
        ],
        // }}}
    ];
}
