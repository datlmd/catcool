<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Effect/User.php
 *
 *  @author   Masayoshi Yoshino <masayoshi.yoshino@gree.co.jp>
 *  @package  GREE
 */

class Gree_GenericDao_Effect_UserDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'user_effect';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_effect';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_effect';

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'item_id',
        'state',
        'type',
        'ctime',
        'mtime',
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_user_id_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = :state ORDER BY id DESC',
        ),
        'find_by_user_id_and_state_and_itemids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = :state AND item_id in (:item_ids)',
        ),
        'count_by_user_id_and_item_id_and_state' => array(
            'sql' => 'SELECT count(id) as cnt FROM __TABLE_NAME__ WHERE user_id = :user_id AND item_id = :item_id AND state = :state',
        ),
        'count_by_user_id_and_state' => array(
            'sql' => 'SELECT count(id) as cnt FROM __TABLE_NAME__ WHERE user_id = :user_id AND state = :state',
        ),
        // }}}
        // {{{ ������
        'insert' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (
                        user_id, 
                        item_id,
                        state,
                        type,
                        ctime
                    ) VALUES (
                        :user_id, 
                        :item_id,
                        :state,
                        :type,
                        :ctime
                    )',
            'return_last_insert_id' => true
        ),
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`            INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`       INT(10) UNSIGNED NOT NULL,
                    `item_id`       INT(10) UNSIGNED NOT NULL,
                    `state`         TINYINT(1) UNSIGNED DEFAULT 1,
                    `type`          TINYINT(1) UNSIGNED DEFAULT 1,
                    `ctime`         DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime`         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    KEY `user_id` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Effect_UserFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Effect_UserFarmSelector extends Gree_GenericDao_FarmSelector
{

    /** @var string table suffix format */
    var $_table_suffix_format = "_%02d";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        /** var �ơ��֥�ʬ��� */
        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = 2;
        } else {
            $table_nums = 100;
        }

        // check $hint[user_id]
        if (empty($hint['user_id']) || is_numeric($hint['user_id']) == false || $hint['user_id'] <= 0) {
            $error_msg  = sprintf('hint is empty. dao = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
        $user_id = $hint['user_id'];
        $postfix = (int)($user_id % $table_nums);

        // create table name
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
    // }}}
}
