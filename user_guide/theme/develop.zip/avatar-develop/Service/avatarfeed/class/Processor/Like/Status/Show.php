<?php

class Gree_Service_AvatarFeed_Processor_Like_Status_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $is_first_like     = false;
        $today_like_count  = 0;
        $is_max_count      = false;
        $has_more          = false;
        $like_data         = array();
        $is_exception      = false;
        $like_setting_info = array();

        $mod_appfeed = self::getModule('AppFeed');

        try {
            $like_setting_info = $this->_getSettingInfo();

            if ($like_setting_info['is_active'] == false) {
                $is_max_count = true;

                return array(
                    $is_first_like,
                    $is_max_count,
                    $today_like_count,
                    $like_setting_info['limit_count']
                );
            }

            $get_params = array(
                'limit' => $like_setting_info['limit_count']
            );
            list($has_more, $like_data) = $mod_appfeed->getLikeTimeLine($get_params);
        } catch (Exception $e) {
            $msg     = 'failed get like status.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_LIKE_STATUS_SHOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            $is_exception = true;
        }

        if (empty($like_data) && $has_more == false && $is_exception == false) {
            $is_first_like = true;
        } else {
            list($is_max_count, $today_like_count) = $this->_countTodayLike($like_data, $like_setting_info);
        }

        return array(
            $is_first_like,
            $is_max_count,
            $today_like_count,
            $like_setting_info['limit_count']
        );
    }

    public function _countTodayLike($like_data, $setting_info)
    {
        $count        = 0;
        $is_max_count = false;

        $today_like_point = $this->_getTargetPointRow();

        switch (true) {
            case $today_like_point['like'] == 0:
                break;
            case $today_like_point['like'] >= $setting_info['daily_limit_of_point']:
                $count        = $setting_info['limit_count'];
                $is_max_count = true;
            default:
                $count = $today_like_point['like'] / $setting_info['point_per_action'];
        }

        return array(
            $is_max_count,
            (int)$count
        );
    }

    public function _getLastData($original_data)
    {
        $data = $original_data;

        return array_pop($data);
    }

    public function _getDate($datetime)
    {
        $date = new DateTime($datetime);

        return $date->format('Y-m-d');
    }

    public function _getDateTimeNow()
    {
        $date = new DateTime();

        return $date->format('Y-m-d H:i:s');
    }

    public function _getSettingInfo()
    {
        $mod_setting = self::getModule('Setting');

        $setting_info = array(
            'is_active'   => false,
            'limit_count' => 0
        );

        $setting_params   = array(
            'action_type' => 'like',
        );
        $get_setting_info = $mod_setting->getSettingInfoOfIncentive($setting_params);

        if (is_null($get_setting_info)) {
            return $setting_info;
        } else {
            $setting_info = $get_setting_info;
        }

        if (isset($setting_info['start_date_time'])) {
            //$target_date               = getService('shop')->getDate('Y-m-d H:i:s');
            $target_date               = $this->_getDateTimeNow();
            $is_active                 = $mod_setting->isActiveSettingOfIncentive($target_date, $setting_info['start_date_time']);
            $setting_info['is_active'] = $is_active;
        }

        $limit_count = 0;
        if ($setting_info['is_active']) {
            $limit_count                 = ($setting_info['daily_limit_of_point'] / $setting_info['point_per_action']);
            $setting_info['limit_count'] = (int)$limit_count;
        } else {
            $setting_info['limit_count'] = 0;
        }

        return $setting_info;
    }

    public function _getTargetPointRow()
    {
        $srv_shop      = getService('shop');
        $point_manager = $srv_shop->getPointManager();
        $target_date   = $srv_shop->getDate('Y-m-d H:i:s');
        $user_id       = $this->_certified_user->my['user_id'];
        $target_points = $point_manager->getLikePointHistory($user_id, $target_date);

        return $target_points;
    }
}
