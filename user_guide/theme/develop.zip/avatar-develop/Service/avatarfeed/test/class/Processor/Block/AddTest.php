<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Block_AddTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Block_AddTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module_block;
    var $module_follow;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module_block  = Gree_Service_AvatarFeed_Module::singleton('Block');
        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_block->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        $this->initialize_following_status();
        $this->initialize_followed_status();
        $this->initialize_block_status();

        list($has_more, $empty_following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_following_user_ids));

        list($has_more, $empty_followed_user_ids) = $this->module_follow->getFollowedListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_followed_user_ids));

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($block_user_ids));
    }

    public function test_add_not_followed_user()
    {
        $block_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
        );

        $add_result = $this->avatar_feed->process('block_add', $block_params);

        $this->assertTrue($add_result);

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertFalse($has_more);
        $this->assertEquals(1, count($block_user_ids));
        $block_user = array_shift($block_user_ids);
        $this->assertEquals($block_params['user_id'], $block_user['content']['sender_id']);
    }

    public function test_add_followed_user()
    {
        $this->module_follow->addFollowedUser(UNIT_TEST_USER_ID_2);
        $this->module_follow->addFollowedUser(UNIT_TEST_USER_ID_3);
        $this->module_follow->addFollowedUser(UNIT_TEST_USER_ID_4);
        $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1, 0, 3);

        $block_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
        );
        $add_result = $this->avatar_feed->process('block_add', $block_params);

        $this->assertTrue($add_result);

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertFalse($has_more);
        $this->assertEquals(1, count($block_user_ids));
        $block_user = array_shift($block_user_ids);
        $this->assertEquals($block_params['user_id'], $block_user['content']['sender_id']);

        list($has_more_followed, $followed_users) = $this->module_follow->getFollowedListOrderInTime(
            UNIT_TEST_USER_ID_1,
            2,
            0
        );

        $this->assertFalse($has_more_followed);
        $this->assertEquals(2, count($followed_users));
        $followed_user_ids = array();
        foreach ($followed_users as $user) {
            $followed_user_ids[] = $user['content']['sender_id'];
        }
        $this->assertFalse(in_array($block_params['user_id'], $followed_user_ids));

        list($following_count, $followed_count) = $this->module_follow->getFollowCount();
        $this->assertEquals(2, $followed_count);
    }

    public function test_failed_add_user()
    {
        $block_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
        );

        $add_result = $this->avatar_feed->process('block_add', $block_params);

        $this->assertTrue($add_result);

        $add_result_2 = $this->avatar_feed->process('block_add', $block_params);

        $this->assertFalse($add_result_2);

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertFalse($has_more);
        $this->assertEquals(1, count($block_user_ids));
        $block_user = array_shift($block_user_ids);
        $this->assertEquals($block_params['user_id'], $block_user['content']['sender_id']);
    }

    public function test_over_limit_count()
    {
        for ($i = 0; $i < GREE_SERVICE_AVATARFEED_BLOCK_LIMIT_COUNT; $i++) {
            $block_params = array(
                'user_id'  => $i,
            );

            $add_result = $this->avatar_feed->process('block_add', $block_params, UNIT_TEST_USER_ID_1);

            $this->assertTrue($add_result);
        }

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(GREE_SERVICE_AVATARFEED_BLOCK_LIMIT_COUNT, count($block_user_ids));

        $block_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
        );

        $add_result = $this->avatar_feed->process('block_add', $block_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($add_result);
    }
}