<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Medal/ItemDao.php
 *
 * @package     GREE Avatar
 * @since       2016-08-29
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Item form constructor
 * @access      public
 */
class Gree_GenericDao_Medal_ItemDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'medal_item';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_coordell';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_coordell';

    /** @var field names */
    var $_field_names = array(
        'id',
        'item_id',
        'state',
        'need_medal',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all_by_state'      => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (item_id, state, need_medal, ctime) VALUES (:item_id, :state, :need_medal, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET item_id = :item_id, state = :state, need_medal = :need_medal WHERE id = :id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `item_id` INT(10) UNSIGNED NOT NULL,
                    `state` TINYINT(1) UNSIGNED NOT NULL,
                    `need_medal` SMALLINT(5) UNSIGNED NOT NULL,
                    ctime             DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    mtime             TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `state` (`state`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        'modify_table'           => array(
            'sql' => "ALTER TABLE __TABLE_NAME__ DROP COLUMN `close_datetime`, CHANGE COLUMN `open_datetime` `state` tinyint(1) UNSIGNED NOT NULL;"
        ),
        'index_state'            => array(
            'sql' => "ALTER TABLE __TABLE_NAME__ ADD INDEX (state);"
        )
        // }}}
    );
}
