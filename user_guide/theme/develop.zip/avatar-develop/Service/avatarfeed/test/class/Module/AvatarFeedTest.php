<?php

final class Gree_Service_Avatarfeed_Test_Module_AvatarFeedTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $module;

    public function setUp() {
        /*
        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(548662);
        */
    }

    public function test_createFeed_success()
    {
        /*
        list($is_success, $feed_id) = $this->module->createFeed();
        $this->assertTrue($is_success);
        $this->assertFalse(empty($feed_id));
        */
    }
}