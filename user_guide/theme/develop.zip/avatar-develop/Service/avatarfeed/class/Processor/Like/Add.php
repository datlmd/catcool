<?php

class Gree_Service_AvatarFeed_Processor_Like_Add
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $add_result = true;

        $mod_appfeed = self::getModule('AppFeed');

        try {
            list($add_result, $entry_id) = $mod_appfeed->addLike($this->input_values);
        } catch (Exception $e) {
            $msg = 'failed add like.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_LIKE_ADD;
            $context = $this->input_values;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            $add_result = false;
        }

        return $add_result;
    }
}
