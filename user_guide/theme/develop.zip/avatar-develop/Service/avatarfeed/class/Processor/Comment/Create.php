<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Comment_Create
 */
class Gree_Service_AvatarFeed_Processor_Comment_Create
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return is_create, comment_id
     * if failed create then
     *  is_create  == false,
     *  comment_id == null
     */
    protected function invoke()
    {
        $is_create_success = false;
        $comment_id        = null;

        $mod_appfeed = self::getModule('AppFeed');
        try {
            list($is_create_success, $comment_id) = $mod_appfeed->createComment($this->input_values);
        } catch(Exception $e) {
            $msg     = 'failed create comment.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_COMMENT_CREATE;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $is_create_success,
            $comment_id
        );
    }
}
