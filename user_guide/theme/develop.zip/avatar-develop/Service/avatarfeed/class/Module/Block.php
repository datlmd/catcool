<?php

class Gree_Service_AvatarFeed_Module_Block
    extends Gree_Service_AvatarFeed_Module_Base
{
    var $accessor_block;

    public function getBlockUser($block_user_id,
                                 $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $find_values          = array(
            'user_id'       => $user_id,
            'block_user_id' => $block_user_id,
        );
        $find_result          = $this->accessor_block->findFirst('find_user_by_user_id_and_block_user_id', $find_values);

        $is_block = true;
        if (is_null($find_result)) {
            $is_block = false;
        }

        return $is_block;
    }

    public function getBlockListOrderInTime($user_id = null,
                                            $input_limit = 10,
                                            $offset = 0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $limit = $input_limit + 1;

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $find_values          = array(
            'user_id' => $user_id,
        );
        $find_result          = $this->accessor_block->find('find_list_by_user_id_sort_ctime', $find_values, $offset, $limit);
        if (is_null($find_result)) {
            return null;
        }

        $has_more = $this->_getHasMore($limit, count($find_result));
        if ($has_more) {
            array_pop($find_result);
        }
        $block_list = $this->_alignFormatOfEntry($find_result, 'block_user_id');

        return array(
            $has_more,
            $block_list
        );
    }

    public function getBlockListOrderInBlockUser($user_id = null,
                                                 $limit = 10,
                                                 $offset = 0)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $find_values          = array(
            'user_id' => $user_id,
        );
        $find_result          = $this->accessor_block->find('find_list_by_user_id_sort_block_user_id', $find_values, $offset, $limit);

        return $find_result;
    }

    // offset is block_user_id
    public function getBlockListByBlockUser($block_user_id,
                                            $user_id = null,
                                            $limit = 10)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $find_values          = array(
            'block_user_id' => $block_user_id,
            'user_id'       => $user_id,
        );
        $find_result          = $this->accessor_block->find('find_list_by_user_id_and_block_user_id', $find_values, 0, $limit);

        return $find_result;
    }

    public function addBlockUser($block_user_id,
                                 $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $add_values           = array(
            'block_user_id' => $block_user_id,
            'user_id'       => $user_id,
        );
        $add_result           = $this->accessor_block->execute('add_block', $add_values);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $user_id;
        $mod_tdlog->state = $mod_tdlog->getInsertState();
        $mod_tdlog->block_user_id = $block_user_id;
        $mod_tdlog->result = $add_result;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedBlockTableName());

        return $add_result;
    }

    public function removeBlockUser($block_user_id,
                                    $user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $remove_values        = array(
            'block_user_id' => $block_user_id,
            'user_id'       => $user_id,
        );
        $remove_result        = $this->accessor_block->execute('remove_block', $remove_values);

        $mod_tdlog = self::getModule('Tdlog');
        $mod_tdlog->uid = $user_id;
        $mod_tdlog->state = $mod_tdlog->getDeleteState();
        $mod_tdlog->block_user_id = $block_user_id;
        $mod_tdlog->result = $remove_result;
        $mod_tdlog->createFeedTdLog($mod_tdlog->getAvatarFeedBlockTableName());

        return $remove_result;
    }

    public function getCount($user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = $this->_certified_user->my['user_id'];
        }

        $this->accessor_block = Cascade::getAccessor('avatar_feed#block');
        $get_values          = array(
            'user_id' => $user_id,
        );
        // get the total number of block users
        $get_result          = $this->accessor_block->toValue('get_count', $get_values);

        return $get_result;
    }

    // for appendUserInfo()
    public function _alignFormatOfEntry($find_results, $column_name)
    {
        $aligned_format_list = array();

        foreach ($find_results as $result) {
            $aligned_format_list[] = array(
                'content' => array(
                    'sender_id' => $result[$column_name]
                )
            );
        }

        return $aligned_format_list;
    }

    public function _getHasMore($limit, $result_count)
    {
        if ($limit == $result_count) {
            return true;
        } else {
            return false;
        }
    }
}