<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Incentive_Add
 */
class Gree_Service_AvatarFeed_Processor_Incentive_Add
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $point_manager;

    /**
     * switch incentive category && target_action
     */
    protected function invoke()
    {
        $return_code = null;

        switch ($this->input_values['incentive_category']) {
            case 'point':
                if ($this->input_values['target_action'] = 'like') {
                    $return_code = $this->_addPointOnLike();
                }
                break;
            default:
        }

        return $return_code;
    }

    /**
     * flow is
     *   get Setting Info of Incentive
     *   get same user count
     *   get target point row
     *   check is enable add point
     *   add point and notification
     */
    public function _addPointOnLike()
    {
        $like_setting_info  = $this->_getSettingInfoOfIncentive('like');
        $liked_setting_info = $this->_getSettingInfoOfIncentive('liked');

        $srv_shop            = getService('shop');
        $this->point_manager = $srv_shop->getPointManager();

        $like_user_target_points  = $this->_getTargetPointRow($this->input_values['user_id']);
        $liked_user_target_points = $this->_getTargetPointRow($this->input_values['liked_user_id']);

        // 同じユーザーにいいねしているか確認する前に、一度設定でいいねが有効になっているか、両者がいいね上限まで達していないか
        // を確認して、両者ともAPをもらえない状態であればそこで終了する。
        $is_add_to_like_user  = $this->_isEnableAddPoint('like', $like_setting_info, 0, $like_user_target_points);
        $is_add_to_liked_user = $this->_isEnableAddPoint('liked', $liked_setting_info, 0, $liked_user_target_points);

        if ($is_add_to_like_user == false && $is_add_to_liked_user == false) {
            return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_DISABLED;
        }

        list($is_get_success, $same_user_count) = $this->_getSameUserCount($like_setting_info, $liked_setting_info);
        if (!$is_get_success) {
            return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_FAILED;
        }

        $is_add_to_like_user  = $this->_isEnableAddPoint('like', $like_setting_info, $same_user_count, $like_user_target_points);
        $is_add_to_liked_user = $this->_isEnableAddPoint('liked', $liked_setting_info, $same_user_count, $liked_user_target_points);

        // AP取得通知の追加を試行する上限ポイント
        //   AP取得通知は1つのみ作成されるが、毎回通知が既にあるか確認している。
        //   その確認コストを削減するために、本日取得したAP数が(いいねAP + 被いいね)*2 を超えると通知があるかの確認も行わないようにする
        $notification_try_limit_points = ($like_setting_info['point_per_action'] + $liked_setting_info['point_per_action']) * 2;

        if ($is_add_to_like_user) {
            $add_result_like_user = $this->_addPointAndNotification(
                $this->input_values['user_id'],
                $like_setting_info['point_per_action'],
                GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADD,
                $like_user_target_points,
                $notification_try_limit_points
            );

            if ($add_result_like_user == false) {
                $msg     = 'failed add point to like user.';
                $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_INCENTIVE_ADD;
                $context = $this->input_values;

                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            }
        }

        if ($is_add_to_liked_user) {
            $add_result_liked_user = $this->_addPointAndNotification(
                $this->input_values['liked_user_id'],
                $liked_setting_info['point_per_action'],
                GREE_SERVICE_SHOP_POINT_RECENT_TYPE_LIKE_ADDED,
                $liked_user_target_points,
                $notification_try_limit_points
            );

            if ($add_result_liked_user == false) {
                $msg     = 'failed add point to liked user.';
                $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_INCENTIVE_ADD;
                $context = $this->input_values;

                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            }
        }

        if ($is_add_to_like_user) {
            return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_SUCCESS;
        } else {
            return Gree_Service_AvatarFeed_Logger::RETURN_PROCESSOR_INCENTIVE_ADD_DISABLED;
        }
    }

    public function _getDate($datetime)
    {
        $date = new DateTime($datetime);

        return $date->format('Y-m-d');
    }

    public function _addNotification($notification_user_id, $sum_point_value)
    {
        $avatar_feed                 = Gree_Service_AvatarFeed::getInstance();
        $notification_params         = array(
            'user_id'               => $this->input_values['user_id'],
            'entry_category'        => 'notification_incentive',
            'notification_entry_id' => $this->_getDate($this->input_values['target_date']),
            'destination_user'      => $notification_user_id,
            'sum_point_value'       => $sum_point_value
        );
        $is_success_add_notification = $avatar_feed->process('notification_add', $notification_params);

    }

    /**
     * @param $action
     * @return array
     */
    public function _getSettingInfoOfIncentive($action)
    {
        $setting_info = array(
            'is_active' => false
        );

        $mod_setting = self::getModule('Setting');

        $get_params = array(
            'action_type' => $action,
        );
        try {
            $get_setting_info = $mod_setting->getSettingInfoOfIncentive($get_params);
        } catch (Exception $e) {
            $msg     = 'failed get setting info of incentive.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_INCENTIVE_ADD;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return $setting_info;
        }

        if (is_null($get_setting_info)) {
            return $setting_info;
        } else {
            $setting_info = $get_setting_info;
        }

        if (isset($setting_info['start_date_time'])) {
            $is_active                 = $mod_setting->isActiveSettingOfIncentive($this->input_values['target_date'], $setting_info['start_date_time']);
            $setting_info['is_active'] = $is_active;
        }

        return $setting_info;
    }

    public function _getSameUserCount($like_setting_info, $liked_setting_info)
    {
        $mod_appfeed     = self::getModule('AppFeed');
        $same_user_count = 1;
        $is_success      = true;

        $like_limit_count = 0;
        if ($like_setting_info['is_active']) {
            $like_limit_count = (int)($like_setting_info['daily_limit_of_point'] / $like_setting_info['point_per_action']);
        }

        $liked_limit_count = 0;
        if ($liked_setting_info['is_active']) {
            $liked_limit_count = (int)($liked_setting_info['daily_limit_of_point'] / $liked_setting_info['point_per_action']);
        }

        if ($like_limit_count <= $liked_limit_count) {
            $limit = $liked_limit_count + 1;
        } else {
            $limit = $like_limit_count + 1;
        }
        $get_params = array(
            'user_id'  => $this->input_values['user_id'],
            'limit'    => $limit,
            'start_id' => $this->input_values['target_entry_id']
        );

        try {
            list($has_more, $like_data) = $mod_appfeed->getLikeTimeLine($get_params);

            foreach ($like_data as $index => $entry) {
                if ($this->_getDate($this->input_values['target_date']) == $this->_getDate($entry['created_time'])
                    && $this->input_values['liked_user_id'] == $entry['parent']['body']['content']['sender_id']
                ) {
                    $same_user_count++;
                }
            }
        } catch (Exception $e) {
            $msg     = 'failed get like timeline.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_INCENTIVE_ADD;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            $is_success = false;
        }

        return array(
            $is_success,
            $same_user_count
        );
    }

    public function _isEnableAddPoint($type, $setting_info, $same_user_count, $target_points)
    {
        if ($setting_info['is_active'] == false) {
            return false;
        }

        if ($same_user_count > $setting_info['limit_of_point_to_same_user']) {
            return false;
        }

        if ($target_points[$type] >= $setting_info['daily_limit_of_point']
        ) {
            return false;
        }

        return true;
    }

    public function _getTargetPointRow($user_id)
    {
        $date = $this->input_values['target_date'];
        $target_points = $this->point_manager->getLikePointHistory($user_id, $date);

        return $target_points;
    }


    public function _addPointAndNotification($user_id, $point, $recent_type, $target_points, $notification_try_limit_points)
    {
        $ret = $this->point_manager->changePointAndRecent(
            $user_id,
            $point,
            $recent_type,
            0
        );

        $sum_point_value = $target_points['like'] + $target_points['liked'] + $point;

        if ($ret['succeeded']) {
            if($sum_point_value <= $notification_try_limit_points) {
                $this->_addNotification($user_id, $sum_point_value);
            }

            return true;
        } else {
            return false;
        }
    }
}
