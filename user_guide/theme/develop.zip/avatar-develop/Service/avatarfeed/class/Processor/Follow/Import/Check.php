<?php

class Gree_Service_AvatarFeed_Processor_Follow_Import_Check
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $mod_user = self::getModule('User');

        try{
            $check_list = $mod_user->getCheckList($this->input_values['user_id']);
            if (empty($check_list)){
                $msg  = 'Import check user is empty.';
                $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_CHECK;
                new Gree_Service_AvatarFeed_Logger($msg, $code, $this->input_values);

                return false;
            }

            foreach ($check_list as $user_id){
                $add_params = array(
                    'user_id'        => $user_id,
                    'certified_user' => $this->input_values['user_id'],
                    'is_async'       => true
                );
                Gree_Service_AvatarFeed_Processor::execute(
                    'following_add',
                    $add_params
                );

                // ignore result processor of following add
                // result == false is already following
            }
        }catch (Exception $e){
            $msg  = 'failed Import check user.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_CHECK;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $this->input_values);

            return false;
        }

        return true;
    }
}