<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/MonthlyFarmSelector.php';

class Gree_GenericDao_Community_CommentImageDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'comment_image';

    /** @var primary key */
    var $_primary_key       = 'comment_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_community';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_community';

    /** @var field names */
    var $_field_names       = [
        'comment_id',
        'user_id',
        'img_url',
        'type',
        'ctime',
        'mtime',
    ];

    var $_queries = [
        'find_by_comment_ids' => [
            'sql' => 'SELECT comment_id, user_id, img_url, type, status, mtime, ctime
            FROM 
                __TABLE_NAME__ 
            WHERE 
                comment_id in (:comment_ids)
                and topic_id = :topic_id
                and status = :status
            '
        ],
        'make_status_off' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET status = 0
                WHERE
                    comment_id = :comment_id
                    and topic_id = :topic_id
            '
        ],
        'insert' => [
            'sql' => 'INSERT INTO __TABLE_NAME__ (
                comment_id,
                topic_id,
                user_id,
                img_url,
                type
            ) 
            VALUES 
            (
                :comment_id,
                :topic_id,
                :user_id,
                :img_url,
                :type
            )',
        ],

        'create_table'      => [
            'sql'   => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `comment_id`      INT      UNSIGNED NOT NULL,
                    `topic_id`        INT      UNSIGNED NOT NULL,
                    `user_id`         INT      UNSIGNED NOT NULL,
                    `img_url`         TEXT     NOT NULL,
                    `type`            TINYINT  UNSIGNED NOT NULL,
                    `status`          TINYINT  UNSIGNED DEFAULT 1,
                    `mtime`           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    `ctime`           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`comment_id`, `topic_id`),
                    KEY `user_id` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ],
        // }}}
    ];

    public function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Shop_MonthlyFarmSelector();
    }
}
