<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Followed
 */
class Gree_Service_AvatarFeed_Processor_Followed_Status
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return
     *   is_following
     */
    protected function invoke()
    {

        $mod_follow = self::getModule('Follow');

        $followed_date = null;
        try {
            $followed_date = $mod_follow->getFollowedDate($this->input_values['target_user_id'], $this->input_values['user_id']);
        } catch (Exception $e) {
            $msg     = 'failed get follow status.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return $followed_date;
    }
}
