<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Gree_GenericDao_Shop_Market_Border_SummaryDao
 *
 * @author  katsumi.zeniya
 * @package GREE
 */
class Gree_GenericDao_Market_Border_SummaryDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name        = 'market_border_summary';

    /** @var primary key */
    var $_primary_key       = 'item_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'item_id',
        'group_code',
        'sex',
        'market_id',
        'sell_border_ap',
        'bid_border_ap',
        'sell_avg_ap',
        'sell_min_ap',
        'sell_max_ap',
        'bid_min_ap',
        'bid_max_ap',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ select queries
        'find_by_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = :item_id',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__ 
                    (item_id, group_code, sex, market_id, sell_border_ap, bid_border_ap, sell_avg_ap, sell_min_ap, sell_max_ap, bid_min_ap, bid_max_ap, ctime)
                VALUE
                    (:item_id, :group_code, :sex, :market_id, :sell_border_ap, :bid_border_ap, :sell_avg_ap, :sell_min_ap, :sell_max_ap, :bid_min_ap, :bid_max_ap, NOW())
                ON DUPLICATE KEY UPDATE
                    market_id = :market_id, sell_border_ap = :sell_border_ap, bid_border_ap = :bid_border_ap, sell_avg_ap = :sell_avg_ap, sell_min_ap = :sell_min_ap, sell_max_ap = :sell_max_ap, bid_min_ap = :bid_min_ap, bid_max_ap = :bid_max_ap
            ',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    item_id                 INT(11)     UNSIGNED NOT NULL,
                    market_id               INT(11)     UNSIGNED NOT NULL,
                    group_code              INT(11)     UNSIGNED NOT NULL,
                    sex                     TINYINT(4)  UNSIGNED NOT NULL,
                    sell_border_ap          INT(11)     UNSIGNED,
                    bid_border_ap           INT(11)     UNSIGNED,
                    sell_avg_ap             INT(11)     UNSIGNED,
                    sell_min_ap             INT(11)     UNSIGNED,
                    sell_max_ap             INT(11)     UNSIGNED,
                    bid_min_ap              INT(11)     UNSIGNED,
                    bid_max_ap              INT(11)     UNSIGNED,
                    ctime                   DATETIME    NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime                   TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (item_id),
                    KEY (group_code, sex)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );
}
