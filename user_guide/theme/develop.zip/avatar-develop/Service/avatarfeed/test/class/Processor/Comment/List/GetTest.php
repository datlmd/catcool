<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Comment_List_GetTest
 *
 * this test is get comment list
 */
final class Gree_Service_Avatarfeed_Test_Processor_Comment_List_GetTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }
    }

    /**
     * test1: comment is empty
     * expect: has_more == false, comment_list == empty array
     *
     * test2: entry has 1 comment
     * expect: has_more == false, comment_list == array(append user info)
     *
     * test3: entry has some comment(number > GREE_SERVICE_AVATARFEED_DEFAULT_GET_COMMENTS_LIMIT)
     * expect: has_more == true, comment_list == array(append user info)
     * expect: comment list count is limit number
     *
     * test4: specific start_id
     * expect: entry_id of array_shift(comment_list) is next entry_id
     */
    public function test_get_comment_list()
    {
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_success_create_entry);

        // test1
        $comment_params = array(
            'entry_id' => $entry_id,
            'limit'    => GREE_SERVICE_AVATARFEED_DEFAULT_GET_COMMENTS_LIMIT,
            'start_id' => null,
        );
        list($has_more, $comment_data) = $this->avatar_feed->process('comment_list_get', $comment_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more);
        $this->assertTrue(empty($comment_data));

        // test2
        $text_1 = 'test2 get comment list';
        list($is_success_create_comment_1, $comment_id_1) = $this->_createComment($text_1, $entry_id);

        list($has_more_2, $comment_data_2) = $this->avatar_feed->process('comment_list_get', $comment_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more_2);
        $this->assertEquals(1, count($comment_data_2));

        $comment = array_shift($comment_data_2);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $comment['content']['sender_id']);
        $this->assertEquals($text_1, $comment['content']['text']);
        $this->assertTrue(isset($comment['content']['user_info']));
        $this->assertTrue(isset($comment['content']['user_info']['nick_name']));
        $this->assertTrue(isset($comment['content']['user_info']['thumbnail_url']));
        $this->assertEquals($comment_id_1, $comment['comment_id']);
        $this->assertEquals($entry_id, $comment['parent_entry_id']);

        // test3
        $comment_id_list = array();
        for ($i = 0; $i < GREE_SERVICE_AVATARFEED_DEFAULT_GET_COMMENTS_LIMIT; $i++) {
            $text_2 = 'test3 get comment list_' . $i;
            list($is_success_create_comment_2, $comment_id_2) = $this->_createComment($text_2, $entry_id);

            $this->assertTrue($is_success_create_comment_2);
            $comment_id_list[$i] = $comment_id_2;
        }

        list($has_more_3, $comment_data_3) = $this->avatar_feed->process('comment_list_get', $comment_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($has_more_3);

        // test4
        $comment_params_2 = array(
            'entry_id' => $entry_id,
            'limit'    => GREE_SERVICE_AVATARFEED_DEFAULT_GET_COMMENTS_LIMIT,
            'start_id' => $comment_id_2,
        );
        list($has_more_4, $comment_data_4) = $this->avatar_feed->process('comment_list_get', $comment_params_2, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more_4);
        $this->assertEquals(GREE_SERVICE_AVATARFEED_DEFAULT_GET_COMMENTS_LIMIT, count($comment_data_4));

        array_pop($comment_id_list);
        $expect_comment_id = array_pop($comment_id_list);
        $comment_2         = array_shift($comment_data_4);
        $this->assertEquals($expect_comment_id, $comment_2['comment_id']);
    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_stream_show',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }

    public function _createComment($text, $entry_id)
    {
        $create_params = array(
            'text'              => $text,
            'entry_id'          => $entry_id,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_create_success, $comment_id) = $this->module->createComment($create_params);

        return array(
            $is_create_success,
            $comment_id
        );
    }
}