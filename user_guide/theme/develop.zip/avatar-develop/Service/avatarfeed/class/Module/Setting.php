<?php

class Gree_Service_AvatarFeed_Module_Setting
    extends Gree_Service_AvatarFeed_Module_Base
{
    public function getSettingInfoOfIncentive($find_params)
    {
        $accessor = Cascade::getAccessor('avatar_feed#setting_incentive_point');

        $find_result = $accessor->findFirst('find_by_action_type', $find_params);

        return $find_result;
    }

    public function saveSettingInfoOfIncentive($save_params)
    {
        $accessor = Cascade::getAccessor('avatar_feed#setting_incentive_point');

        $save_result = $accessor->execute('save', $save_params);

        return $save_result;
    }

    public function isActiveSettingOfIncentive($target_date, $start_date_time)
    {
        $is_active = false;

        if (strtotime($start_date_time) < strtotime($target_date)) {
            $is_active = true;
        }

        return $is_active;
    }

}