<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Battle/VoteDao.php
 *
 *  @author   Adib Gholaminezhad <adib.gholaminezhad@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_Battle_VoteDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'battle_vote';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_coorde_battle';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_coorde_battle';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'target_id',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_user_id_and_target_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND target_id = :target_id LIMIT 1'
        ),

        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'max_id' => array(
            'sql' => 'SELECT MAX(id) FROM __TABLE_NAME__'
        ),
        'count_by_user_id' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}

        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`        INT(11)     UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id`   INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                `target_id` INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                `mtime`     TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime`     DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY `ids` (`user_id`, `target_id`)
            ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        'replace' => array(
            'sql' => 'REPLACE INTO __TABLE_NAME__ (user_id, target_id, ctime) VALUES (:user_id, :target_id, NOW())'
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__"
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Battle_VoteFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Battle/VoteFarmSelector.php
 *
 *  @package  GREE
 */
class Gree_GenericDao_Battle_VoteFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%s";
    // }}}

    // {{{ _dateline
    /** var integer ����ɼ�����ն������� */
    var $_dateline = 3;
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) 
    {
        if (empty($hint['battle_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $battle_id = $hint['battle_id'];
        if (isset($hint['date']) === TRUE) {
            $postfix = date('Y-m-d H:i:s', strtotime($hint['date']));
        } else {
            $postfix = date('Y-m-d H:i:s');
        }
        // ���ն����򤺤餹
        $postfix = date('Ymd', strtotime($postfix) - 3600 * $this->_dateline);

        // �ơ��֥�̾����
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix, $hint['battle_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
    // }}}
}
