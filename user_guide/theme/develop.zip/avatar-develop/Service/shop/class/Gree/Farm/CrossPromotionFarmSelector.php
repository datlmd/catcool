<?php
/**
 * Gree_GenericDao_CrossPromotionFarmSelector
 *
 * @author  Yuta Araki <yuta.araki@gree.net>
 * @package GREE
 */
class Gree_GenericDao_ShopCrossPromotionFarmSelector
    extends Gree_GenericDao_FarmSelector
{
    /** @var string table suffix format */
    var $_table_suffix_format   = "_%d";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        // check $hint[promotion_id]
        if (isset($hint['promotion_id'])){
            // create table name
            $farm       = sprintf($this->_table_suffix_format, $hint['promotion_id']);
            $table_name = sprintf('%s%s', $dao->_getTableName(), $farm);
            return $table_name;
        } else {
            $error_msg  = sprintf('Invalid promotion id. DAO = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
    }
    // }}}
}
