<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/RankPointDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-19
 */

/**
 * RankPoint form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_RankPointDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'rank_point';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'point',
        'summary_id',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'                         => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_point_desc'           => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY point DESC, id ASC',
        ),
        'find_by_id'                       => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'find_by_user_id'                  => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
        'count_user_ranking_by_summary_id' => array(
            'sql' => 'SELECT COUNT(id) + 1 AS rank FROM __TABLE_NAME__ WHERE point > :point AND summary_id = :summary_id',
        ),
        //@todo will remove
        'find_user_below_point_by_summary_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE point < :point AND summary_id = :summary_id ORDER BY point DESC, ctime ASC LIMIT :limit',
        ),
        //@todo will remove
        'find_user_above_point_by_summary_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE point >= :point AND summary_id = :summary_id ORDER BY point ASC, ctime ASC LIMIT :limit',
        ),
        'find_user_below_point' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE point < :point ORDER BY point DESC',
        ),
        'find_user_below_and_equal_point' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE point <= :point ORDER BY point DESC',
        ),
        'find_user_above_point' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE point >= :point ORDER BY point ASC',
        ),
        // }}}

        // {{{ update queries
        'insert_or_update'                 => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, point, summary_id, ctime) VALUES(:user_id, :point, :summary_id, NOW()) ON DUPLICATE KEY UPDATE point=:point, summary_id=:summary_id',
        ),
        'entry'                            => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, point, summary_id, ctime) VALUES (:user_id, :point, :summary_id, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                           => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET user_id = :user_id, point = :point, summary_id = :summary_id WHERE id = :id',
        ),
        'delete'                           => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'                     => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id` INT(11) UNSIGNED NOT NULL,
                    `point` INT(11) UNSIGNED NOT NULL,
                    `summary_id` INT(11) UNSIGNED NOT NULL,
                    `mtime`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`         DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    UNIQUE `user_id` (`user_id`),
                    KEY `point` (`point`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"

        ),
        // }}}
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Osacolo_RankPointFarmSelector();
    }
}

class Gree_GenericDao_Osacolo_RankPointFarmSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%02d"; //[osacolo_id]

    function getTableName($dao, $type, $hint)
    {
        if (empty($hint) || !isset($hint['osacolo_id'])) {
            return PEAR::raiseError("hint is empty osacolo_id, dao=" . get_class($dao) . "];");
        }

        $table_suffix = sprintf($this->_table_suffix_format, $hint['osacolo_id']);
        $table_name   = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
}
