<?php
/**
 *  SimulationResultItemsDao.php
 *
 *  @author     Kanro Kikuchi
 *  @package    GREE
 *  @version    $Id: 
 */
class Gree_GenericDao_Shop_Simulation_ResultItemsDao extends Gree_GenericDao {
    var $_table_name = 'gacha_simulation_result_items';
    var $_master_dsn = 'gree://master/avatar_gacha';
    var $_slave_dsn = 'gree://slave/avatar_gacha';
    var $_primary_key = ['setting_id', 'item_id', 'no'];
    var $_auto_increment = false;
    var $_created_at_column = null;
    var $_updated_at_column = null;
    var $_field_names = [
        'setting_id',
        'item_id',
        'no',
        'run_time',
    ];

    var $_queries = [
        'find_by_setting_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE setting_id=:setting_id ORDER BY `no`'
        ],
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `setting_id`    INT UNSIGNED NOT NULL,
                    `item_id`       INT UNSIGNED NOT NULL,
                    `no`            INT UNSIGNED NOT NULL,
                    `run_time`      DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`setting_id`,`item_id`,`no`),
                    KEY `setting_id` (`setting_id`),
                    KEY `run_time` (`run_time`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            "
        ],
        'insert' => [
            'sql' => "
                INSERT INTO __TABLE_NAME__ (
                    `setting_id`, `item_id`, `no`, `run_time`
                ) values (
                    :setting_id, :item_id, :no, :run_time
                )
            "
        ],
        'delete_by_run_time' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE DATE_ADD(run_time, INTERVAL 1 MONTH) <= NOW()'
        ],
    ];
}
?>
