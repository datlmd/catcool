<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/GeneralCampaign/CrossMissionUser.php
 *
 * @package     GREE Avatar
 * @since       2020-10-06
 */

require_once(GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php');

/**
 * Master form constructor
 *
 * @access      public
 */
class Gree_GenericDao_GeneralCampaign_CrossMissionUserDao extends Gree_GenericDao
{
    /** @var テーブル名 */
    var $_table_name = 'cross_mission_user';
    /** @var 主キー。複合キーはarrayハッシュで指定する。 */
    var $_primary_key = 'id';
    /** @var 更新日カラム名 */
    var $_updated_at_column = 'mtime';
    /** @var 登録日カラム名 */
    var $_created_at_column = 'ctime';
    /** @var マスターデータベースの接続文字列 */
    var $_master_dsn = 'gree://master/shop';
    /** @var スレーブデータベースの接続文字列 */
    var $_slave_dsn = 'gree://slave/shop';
    /** @var オートインクリメント */
    var $_auto_increment = true;
    /** @var フィールド名 */
    var $_field_names = [
        'id',
        'campaign_id',
        'mission_id',
        'user_id',
        'progress',
        'mtime',
        'ctime'
    ];
    /** @var クエリ */
    var $_queries = [
        'find_by_mission_id_and_user_id'   => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE mission_id= :mission_id AND user_id = :user_id AND campaign_id = :campaign_id'
        ],
        'insert_by_mission_id_and_user_id' => [
            'sql' => 'INSERT INTO __TABLE_NAME__ (campaign_id, mission_id, user_id, progress, ctime) VALUES (:campaign_id, :mission_id, :user_id, :progress, now())'
        ],
        'update_by_mission_id_and_user_id' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET progress = :progress WHERE mission_id = :mission_id AND user_id = :user_id AND campaign_id = :campaign_id'
        ],
        'delete_by_mission_id_and_user_id' => [ // for dev support tool
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE mission_id = :mission_id AND user_id = :user_id AND campaign_id = :campaign_id'
        ],
        'create_table'                     => [
            'sql' => '
                 CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                     id             INT(11)     UNSIGNED NOT NULL auto_increment,
                     campaign_id    INT(11)     UNSIGNED NOT NULL,
                     mission_id     INT(11)     UNSIGNED NOT NULL,
                     user_id        INT(11)     UNSIGNED NOT NULL,
                     progress       INT(11)     UNSIGNED NOT NULL,
                     mtime          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                     ctime          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
                     UNIQUE (`campaign_id` ,`mission_id` ,`user_id`),
                     PRIMARY KEY (id )
                 ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ],
    ];

    public function _init()
    {
        parent::_init();
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}