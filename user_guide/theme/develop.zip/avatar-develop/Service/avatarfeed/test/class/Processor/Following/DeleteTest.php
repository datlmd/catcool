<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Following_DeleteTest
 *
 * this test is follow status
 */
final class Gree_Service_Avatarfeed_Test_Processor_Following_DeleteTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;
    var $module_block;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        // initialize follow status
        try {
            $this->module->updateFollowCount(UNIT_TEST_USER_ID_1);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_1);

            $this->module->updateFollowCount(UNIT_TEST_USER_ID_2);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_2);


        } catch (Exception $e) {
        }

        $this->module_block = Gree_Service_AvatarFeed_Module::singleton('Block');
        $this->module_block->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        try {
            $this->module_block->removeBlockUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->module_block->removeBlockUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
        } catch (Exception $e) {

        }
    }

    /**
     * test1: UNIT_TEST_USER_ID_1 try to remove following UNIT_TEST_USER_ID_2
     * expect: delete_result == true
     *
     * test2: UNIT_TEST_USER_ID_1 already remove following UNIT_TEST_USER_ID_2
     * expect: delete_result == false
     *
     */
    public function test_delete_following()
    {
        // prepare
        $follow_params = array(
            'user_id' => UNIT_TEST_USER_ID_2,
        );
        $add_result    = $this->avatar_feed->process('following_add', $follow_params);

        $this->assertTrue($add_result);

        // test1
        $delete_result    = $this->avatar_feed->process('following_delete', $follow_params);

        $this->assertTrue($delete_result);

        list($owner_following_count_test_1, $owner_followed_count_test_1) = $this->module->getFollowCount(UNIT_TEST_USER_ID_1);
        list($target_following_count_test_1, $target_followed_count_test_1) = $this->module->getFollowCount(UNIT_TEST_USER_ID_2);
        $is_following_test_1 = $this->module->getFollowingUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
        $is_followed_test_1  = $this->module->getFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);

        $this->assertEquals(0, $owner_following_count_test_1);
        $this->assertEquals(0, $owner_followed_count_test_1);
        $this->assertEquals(0, $target_following_count_test_1);
        $this->assertEquals(0, $target_followed_count_test_1);
        $this->assertFalse($is_following_test_1);
        $this->assertFalse($is_followed_test_1);

        // test2
        $delete_result_2 = $this->avatar_feed->process('following_delete', $follow_params);

        $this->assertFalse($delete_result_2);

        list($owner_following_count_test_2, $owner_followed_count_test_2) = $this->module->getFollowCount(UNIT_TEST_USER_ID_1);
        list($target_following_count_test_2, $target_followed_count_test_2) = $this->module->getFollowCount(UNIT_TEST_USER_ID_2);
        $is_following_test_2 = $this->module->getFollowingUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
        $is_followed_test_2  = $this->module->getFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);

        $this->assertEquals(0, $owner_following_count_test_2);
        $this->assertEquals(0, $owner_followed_count_test_2);
        $this->assertEquals(0, $target_following_count_test_2);
        $this->assertEquals(0, $target_followed_count_test_2);
        $this->assertFalse($is_following_test_2);
        $this->assertFalse($is_followed_test_2);
    }
}