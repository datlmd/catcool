<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Entry_Delete
 */
class Gree_Service_AvatarFeed_Processor_Entry_Delete
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return array has is_success, entry_id
     *
     * get Entry before delete Entry
     *
     * check is user_id
     * Only entry owner can delete entry
     *
     */
    protected function invoke()
    {
        $is_delete_success = false;
        $entry_id          = null;

        $mod_appfeed = self::getModule('AppFeed');
        try {
            list($is_exist, $entry) = $mod_appfeed->getEntry($this->input_values['entry_id']);


            if ($is_exist
                && $this->_certified_user->my['user_id'] == $entry[0]['content']['sender_id']
            ) {
                list($is_delete_success, $entry_id) = $mod_appfeed->deleteEntry($this->input_values);
            }
        } catch (Exception $e) {
            $msg     = 'failed get entry.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_DELETE;
            $context = $this->input_values;
            $is_delete_success = false;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $is_delete_success,
            $entry_id
        );
    }
}
