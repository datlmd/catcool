<?php
// vim: foldmethod=marker tabstop=4 shiftwidth=4 autoindent
/**
 * @file
 *          This class expands user data and provide necessary function related
 *          to user data.
 *          Service/shop/class/Gree/Data/User.php
 *
 * @author  Yuta Araki <yuta.araki@gree.net>
 * @package GREE
 */

/**
 * Gree_Service_Shop_Data_User
 *
 * @package GREE
 * @property int $user_id
 * @property
 *
 */
class Gree_Service_Shop_Data_User
    extends Gree_Service_Shop_Data_Abstract
{
    protected $_format          = array(
        'user_id',
        'user_sex',
    );

    /** instances of data class based on user id */
    protected $_data_instances  = array();

    protected $_life_service    = null;
    protected $_shop_service    = null;
    protected $register_date    = null;
    protected $offical_user     = null;

    // {{{
    private $is_app = null;
    private $is_ggp = null;
    private $is_ios = null;
    private $is_android = null;
    private $is_tld_net = null;
    private $_timezone = null;
    private $is_new_user = null;
    private $_vendor_prefix = null;
    static  $image_keys = array(
        'bust'     =>
        array(
            'small'  => array(true => 48,   false => 'st48'),
            'medium' => array(true => 80,   false => 'st80'),
            'large'  => array(true => 160,  false => 'st160'),
        ),
        'preview'  =>
        array('x-small' => array(true => '9676',    false => 'st9676'),
              'small'   => array(true => '12095',   false => ''),
              'medium'  => array(true => '240190',  false => ''),
              'large'   => array(true => '360285',  false => ''),
        ),
        'portrait' =>
        array('small'  => array(true => '4876',     false => 'st4876'),
              'medium' => array(true => '80126',    false => 'st80127'),
              'large'  => array(true => '',         false => 'st160254'),
        ),
    );

//        ̤����Key
//        //��Ĺ�ʼ��FP�ѡ�
//        //48x114 anim
//        '48114',
//        //Square
//        //150x150 anim
//        150,
//        //120x120 anim
//        120,
//        //100x100 anim
//        100,
//        //60x60 anim
//        60,
//        //��Ĺ
//        //230x190 anim
//        230,
//        //120x190 anim
//        190,
//        // for avatar coordinate
//        //9767 noanim
//        'st9676',
//        // PC�Ǥ������ᥳ���ǥ��͡���
//        // 180x142 anim
//        '180142',
//        //120x95 anim
//        // touch�Ǥ������ᥳ���ǥ��͡���
//        '12095',
//        //240190
//        '240190',
    // }}}

    // {{{ __construct
    public function __construct($accessor)
    {
        parent::__construct($accessor);
        $this->_shop_service    = getService('shop');
        $this->_life_service    = getService('life');
    }
    // }}}
    // {{{ _filterAccessor
    /**
     * @override
     */
    protected function _filterAccessor($record)
    {
        // ����ƥ��Ȥ�ͧã����ɽ�����ǡ����������桼�������������˲��������桼�����Ȥߤʤ�
        if (!in_array($record['user_sex'], array(LIFE_ITEM_SEX_MALE, LIFE_ITEM_SEX_FEMALE))) {
            $record['user_sex'] = LIFE_ITEM_SEX_MALE;
        }

        return $record;
    }
    // }}}
    // {{{ __readOfficialUser
    /**
     * read official user
     *
     * @access  protected
     * @return  array
     */
    protected function __readOfficialUser()
    {
        $shop_service       = getService('shop');
        $profile_manager    = $shop_service->getManager('profile');
        $official_user      = $profile_manager->getOfficialUserInfo($this->user_id);

        return $official_user;
    }
    // }}}

    // {{ setUserAgent
    /**
     *  Sets UA related data
     *
     * @return void
     */
    private function setUserAgent()
    {
        if (Gree_Ggp_Domain::isTLDNet()) {
            $this->is_tld_net    = true;
        }
        getService('cc');
        $ua                  = new Gree_Service_Cc_Foundation_UserAgent($_SERVER['HTTP_USER_AGENT']);
        $this->is_android     = $ua->isAndroid();
        $this->is_ios         = $ua->isIOS();
        $this->_vendor_prefix = "webkit";
        if ($ua->isTrident()) {
            $this->_vendor_prefix = "ms";
        }
    }

    // }}}
    // {{{ isIOS
    /**
     * Check if user is using iOS device
     *
     * @return Bool
     */
    public function isIOS()
    {
        if (is_null($this->is_ios)) {
            $this->setUserAgent();
        }
        return $this->is_ios;
    }

    // }}}
    // {{{ isAndroid
    /**
     * Check if user is using android device
     *
     * @return Bool
     */
    public function isAndroid()
    {
        if (is_null($this->is_android)) {
            $this->setUserAgent();
        }
        return $this->is_android;
    }

    // }}}
    // {{{ isGGP
    /**
     * Check if user is accessing via GGP version
     *
     * @return Bool
     */
    public function isGGP()
    {
        if (is_null($this->is_ggp)) {
            $this->setUserAgent();
        }
        return $this->is_ggp;
    }

    // }}}
    // {{{ isApp
    /**
     * Check if user is using SNS app
     *
     * @return Bool
     */
    public function isApp()
    {
        if (is_null($this->is_app)) {
            $this->setUserAgent();
        }
        return $this->is_app;
    }

    // }}}
    // {{{ isNewUser
    /**
     * Check if the user is new user
     * True if user's today - register_date is less than 30 days
     *
     * @return Bool
     */
    public function isNewUser()
    {
        if (is_null($this->is_new_user)) {
            $new_user_border = strtotime($this->register_date) + (30 * 24 * 60 * 60);
            if (strtotime($this->_shop_service->getDate()) <= $new_user_border) {
                $this->is_new_user = true;
                return $this->is_new_user;
            } else {
                $this->is_new_user = false;
                return $this->is_new_user;
            }
        } else {
            return $this->is_new_user;
        }
    }

    // }}}
    // {{ getImage
    /**
     *  Get image with specified size/type/animation/format
     *
     * @param string        $size
     *  size specifier (small/medium/large)
     * @param bool          $animation
     *  animated = true, nonanimated = false
     * @param string        $type
     *  type of out put (preview/portrait/bust)
     * @param string        $format
     *  output format (gif/png/jpg/swf)
     * @param bool          $force
     *  force fetch latest image
     *
     * @throws Gree_Service_Shop_Exception_DataException
     * @return string url of image
     */
    public function getImage($size = 'small', $animation = false, $type = 'preview', $format = "gif", $force = false)
    {
        if (isset(self::$image_keys[$type][$size][$animation])) {
            $image_size = self::$image_keys[$type][$size][$animation];
        } else {
            throw new Gree_Service_Shop_Exception_DataException("Invalid arguments.");
        }
        if (!isset($this->$image_size) || $force == true) {
            $this->$image_size = $this->_life_service->getProfileImageUrl($this->user_id, $format, $image_size);
        }

        return $this->$image_size;
    }

    // }}}
    // {{ getImageByKey
    /**
     * Get image with specified key
     *
     * @param string    $key
     *  raw key specifier
     * @param string    $format
     *  output format (gif/png/jpg/swf)
     * @param bool      $force
     *  force fetch latest image
     *
     * @return string url of image
     */
    public function getImageByKey($key = '12095', $format = "gif", $force = false)
    {
        if (!isset($this->$key) || $force == true) {
            $this->$key = $this->_life_service->getProfileImageUrl($this->user_id, $format, $key);
        }
        return $this->$key;
    }

    // }}}
    // {{ getSafeData
    /**
     * Get data that can be transmitted to javascript (client) side
     *
     * @return Array array containing safe data
     */
    public function getSafeData()
    {
        $user_data              = array();
        $user_data['nick_name'] = $this->nick_name;
        $user_data['user_id']   = $this->user_id;
        $user_data['user_sex']  = $this->user_sex;
        $user_data['language']  = $this->language;
        return $user_data;
    }

    // }}}

    // {{{
    /**
     * Generate image from item id list
     *
     * @param string $size
     *  Size of image (small, medium,large)
     * @param bool   $animation
     *  Enable animation on image
     * @param string $type
     *  Type of image (preview, portrait, bust)
     * @param string $format
     *  Format of image (gif, png, swf, jpg)
     * @param array  $idl
     *  List of item ids
     * @param int    $version
     *
     * @throws Gree_Service_Shop_Exception_DataException
     *        Exception is thrown if argument includes invalid value
     * @return string url of image from image id list
     */
    static public function getImageByIdl($size = 'small', $animation = false, $type = 'preview', $format = "gif", $idl, $version = 4)
    {
        $_life_service = getService('life');
        if (isset(self::$image_keys[$type][$size][$animation])) {
            $image_size = self::$image_keys[$type][$size][$animation];
        } else {
            throw new Gree_Service_Shop_Exception_DataException("Invalid Arguments");
        }
        $url = $_life_service->getEasyGenerateURL($idl, $format, $animation, $image_size, $version);
        return $url;
    }

    public function getFriendList($offset, $limit = 5, $with_offical_user = false) {
        $friend_manager  = getFriendManager();
        if (!empty($this->offical_user)) {
            throw new Gree_Service_Shop_Exception_DataException("official user cannot not use this function.");
        }
        $list = $friend_manager->getLinkHashSortLastLogin($this->user_id, $offset, $limit+1);
        if (PEAR::isError($list)) {
            throw new Gree_Service_Shop_Exception_DataException($list->getMessage());
        }
        $id_list = array();
        foreach ($list as $value) {
            $id_list[] = $value['t_user_id'];
        }
        
        return $id_list;
    }
    public function getProperty($property_name){
        if (property_exists($this, $property_name)){
            return $this->$property_name;
        }
        return null;
    }
    // {{{ selectItemsInPossession
    /**
     * select items the user have currently
     *
     * @access  public
     * @param   array   $items  the item data list
     * @return  array   the list of item data the user have
     */
    public function selectItemsInPossession($items)
    {
        $item_ids       = array_keys($items);
        $user_items     = $this->_life_service->findUserItemsByUserAndItems(
            $this->user_id,
            $item_ids
        );
        if (PEAR::isError($user_items)) {
            throw new Gree_Service_Shop_Exception();
        }
        $user_item_ids  = array();
        foreach ($user_items as $user_item) {
            $user_item_ids[] = $user_item['item_id'];
        }

        foreach ($items as $key => $item) {
            if (!in_array($item->id, $user_item_ids)) {
                unset($items[$key]);
            }
        }

        return $items;
    }
    // }}}
    // {{{ gacha
    /**
     * get user gacha hub
     *
     * @param   int     $gacha_id
     * @return  object  the instance
     */
    public function gacha($gacha_id)
    {
        if (!isset($this->_data_instances['gacha'][$gacha_id])) {
            $params = array(
                'user'  => $this,
                'gacha' => Gree_Service_Shop_Data_Factory::getData('Gacha_Master', $gacha_id),
            );
            $instance = Gree_Service_Shop_Data_Factory::instantiate('User_Gacha', $params);
            $this->_data_instances['gacha'][$gacha_id] = $instance;
        }

        return $this->_data_instances['gacha'][$gacha_id];
    }
    // }}}

    public function __readCloset()
    {
        return Gree_Service_Shop_Data_Factory::instantiate('User_Closet', $this->toArray());
    }
    public function __readContest()
    {
        return Gree_Service_Shop_Data_Factory::instantiate('User_Closet', $this->toArray());
    }
    // {{{ __readSelectedItems
    /**
     * @access  protected
     * @return  array   the selected items
     */
    protected function __readSelectedItems()
    {
        $selected_items = $this->_life_service->getUserSelectedItems(
            $this->user_id,
            $this->user_sex
        );
        if (PEAR::isError($selected_items)) {
            throw new Gree_Service_Shop_Exception($selected_items->getMessage());
        }

        $instances = Gree_Service_Shop_Data_Factory::instantiateList(
            'Life_Item', $selected_items);

        return $instances;
    }
    // }}}
}
