<?php

class Gree_Service_AvatarFeed_Processor_Entry_Destination_Add
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;
    var $mod_follow;
    var $followed_count;

    protected function invoke()
    {
        $this->mod_appfeed = self::getModule('AppFeed');
        $this->mod_follow  = self::getModule('Follow');

        $has_more_destination = true;
        $offset_user_id       = 0;

        while ($has_more_destination) {
            try {
                list($has_more, $destination_user_list) = $this->mod_follow->getFollowedListByFollowedUser(
                    $offset_user_id,
                    $this->input_values['sender_id'],
                    GREE_SERVICE_AVATARFEED_DESTINATION_API_LIMIT
                );

                if (empty($destination_user_list)) {
                    return false;
                }

                $destinations = $this->_getFeedKeyList($destination_user_list);
                $this->_addDestination($destinations);

                if ($has_more == false) {
                    $has_more_destination = false;
                } else {
                    $offset_user_id = array_pop($destination_user_list);
                }
                // ignore add destination result
            } catch (Exception $e) {
                $msg     = 'failed add destination.';
                $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_DESTINATION_ADD;
                $context = $this->input_values;

                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }
        }

        return true;
    }

    public function _getFeedKeyList($destination_users)
    {
        $destinations = array();
        foreach ($destination_users as $user_id) {
            $destinations[] = array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' .
                    GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $user_id
            );
        }

        return $destinations;
    }

    public function _addDestination($destinations)
    {
        $add_params = array(
            'entry_id'     => $this->input_values['entry_id'],
            'destinations' => $destinations
        );
        $this->mod_appfeed->addDestination($add_params);
    }
}