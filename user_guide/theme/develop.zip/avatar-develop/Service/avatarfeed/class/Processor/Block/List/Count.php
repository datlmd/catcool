<?php

class Gree_Service_AvatarFeed_Processor_Block_List_Count
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return int
     *
     * return the block users total of a user
     */
    protected function invoke()
    {
        $mod_block = self::getModule('Block');

        $block_count = 0;
        try {
            $block_count = $mod_block->getCount($this->input_values['user_id']);
        } catch (Exception $e) {
            $msg     = 'failed get the block users total';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_BLOCK_LIST_SHOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return $block_count;
    }
}
