<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	ScheduleDao.php
 *
 *	GREESHOP �������塼��ģ��ϡ�
 *
 *	@author		Namnandorj Sansarkhuu <namnandorj.sansar@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: ScheduleDao.php
 */
class Gree_GenericDao_ScheduleDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'life_schedule';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/shop';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/shop';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
            'id',
            'execute_time',
            'schedule_type', // 1:purchase setting; 2:attr setting
            'status',        // 0:wait; 1:done; 2:cancel
            'comment',
            'mtime',
            'ctime',
        );
	var $_queries = array(
			'find_all' => array(
			    'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id'
			),
			'find_status_wait' => array(
				'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = 0 ORDER BY execute_time ASC',
			),
            'find_status_done' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = 1 ORDER BY execute_time DESC',
            ),
            'find_by_type' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE schedule_type = :type ORDER BY execute_time ASC',
            ),
            'find_by_id' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
            ),
			'update_status_by_id' => array(
				'sql' => 'UPDATE __TABLE_NAME__ SET status = :status, mtime = NOW() WHERE id = :id',
			),
            'update_schedule_by_id' => array(
                'sql' => 'UPDATE __TABLE_NAME__ SET execute_time = :execute_time, schedule_type = :schedule_type, comment = :comment, mtime = NOW() WHERE id = :id',
            ),
            'find_by_execute_time' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE execute_time = :execute_time AND status = 0',
            ),
	);

	/**
	 *	�������塼��򤵤ޤ��ޤʾ��Ǹ������롣
	 */
	function _query_find_by_filter($name, $params) {

		$sql = 'SELECT * FROM __TABLE_NAME__';
        $where = array();
        if (isset($params['schedule_ids'])) {
            $where[] = 'id in (:schedule_ids)';
        }
        if (isset($params['execute_time_from'])) {
            $where[] = 'execute_time >= :execute_time_from';
        }
        if (isset($params['execute_time_to'])) {
            $where[] = 'execute_time <= :execute_time_to';
        }
        if (count($params['schedule_type']) == 1) {
            $where[] = 'schedule_type in (:schedule_type)';
        }
        if (count($params['schedule_status']) == 1) {
            $where[] = 'status in (:schedule_status)';
        }
        if (isset($params['comment'])) {
            $where[] = 'comment like :comment';
        }
        if (count($where) > 0) {
            $where = implode(' AND ', $where);
            $sql .= " WHERE $where";
        }
        switch ($params['schedule_sort']) {
        case 1:
            $sql .= " ORDER BY execute_time DESC";
            break;
        case 2:
            $sql .= " ORDER BY mtime ASC";
            break;
        case 3:
            $sql .= " ORDER BY mtime DESC";
            break;
        case 0:
        default:
            $sql .= " ORDER BY execute_time ASC";
            break;
        }
		$query = array('sql' => $sql);

		return $query;
	}
}
?>
