<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/SpurtDao.php
 *
 *  @author   Shintaro Okada <z.shintaro.okada@gree.net>
 *  @package  GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Gacha_SpurtDao extends Gree_GenericDao_Apc {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'gacha_spurt';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
            'id',
            'gacha_ids',
            'type',
            'open_datetime',
            'close_datetime',
            'status',
            'mtime',
            'ctime',
    );

    /** @var ������ */
    var $_queries = array(
            // ������
            'all' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
            ),
            'find_by_id'  => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id'
            ),
            'find_by_status'  => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :status order by id desc',
            ),
            'get_latest_id' => array(
                'sql' => 'SELECT id FROM __TABLE_NAME__ ORDER BY id DESC'
            ),
            'insert' => array(
                'sql' => 'INSERT INTO __TABLE_NAME__ (gacha_ids, type, open_datetime, close_datetime, ctime) VALUES (:gacha_ids, :type, :open_datetime, :close_datetime, now())',
            ),
            'create_table' => array(
                'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                INT(11)         UNSIGNED NOT NULL AUTO_INCREMENT,
                    `gacha_ids`         VARCHAR(127)    NOT NULL,
                    `type`              INT(4)          NOT NULL DEFAULT 0,
                    `open_datetime`     DATETIME        NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `close_datetime`    DATETIME        NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `status`            tinyint(2)      NOT NULL DEFAULT 0,
                    `mtime`             TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                    `ctime`             DATETIME        NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY   KEY  (`id`),
                    INDEX (`status`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis"
            ),
        );

}
