<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/LifeItemStatusDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-18
 */

/**
 * LifeItemStatus form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_LifeItemStatusDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'life_item_status';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'life_item_id',
        'gacha_id',
        'status_1',
        'status_2',
        'status_3',
        'status_4',
        'status_5',
        'grade',
        'group_code',
        'skill_id',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'find_by_life_item_ids'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE life_item_id IN (:life_item_id)',
        ),
        'find_by_life_item_ids_and_group_code'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE life_item_id IN (:life_item_id) AND  group_code IN (:group_code)',
        ),
        'find_by_group_code'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE group_code = :group_code',
        ),
        'find_by_grade'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE grade = :grade',
        ),
        'find_by_gacha_id_list'             => array(
            'sql' => 'SELECT gacha_id FROM __TABLE_NAME__ WHERE grade = :grade GROUP BY gacha_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (life_item_id, gacha_id, status_1, status_2, status_3, status_4, status_5, grade, skill_id, group_code, ctime) VALUES (:life_item_id, :gacha_id, :status_1, :status_2, :status_3, :status_4, :status_5, :grade, :skill_id, :group_code, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET life_item_id = :life_item_id, gacha_id = :gacha_id, status_1 = :status_1, status_2 = :status_2, status_3 = :status_3, status_4 = :status_4, status_5 = :status_5, grade = :grade, skill_id = :skill_id , group_code = :group_code WHERE id = :id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `life_item_id` INT(11) UNSIGNED NOT NULL,
                    `gacha_id` INT(11) UNSIGNED NOT NULL,
                    `status_1` TINYINT(3) UNSIGNED NOT NULL,
                    `status_2` TINYINT(3) UNSIGNED NOT NULL,
                    `status_3` TINYINT(3) UNSIGNED NOT NULL,
                    `status_4` TINYINT(3) UNSIGNED NOT NULL,
                    `status_5` TINYINT(3) UNSIGNED NOT NULL,
                    `grade`    INT(10) UNSIGNED NOT NULL,       
                    `skill_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',  
                    `group_code` int(8) unsigned NOT NULL DEFAULT '0',     
                    `mtime`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`         DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                KEY `item_id_idx` (`life_item_id`),
                KEY `group_code_idx` (`group_code`),
                KEY `grade_idx` (`grade`),
                KEY `gacha_id_idx` (`gacha_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
