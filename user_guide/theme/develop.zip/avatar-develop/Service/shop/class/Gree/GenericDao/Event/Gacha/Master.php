<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Event/Gacha/Master.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Event_Gacha_MasterDao extends Gree_GenericDao_Apc {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'event_gacha_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'event_gacha_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_event_count';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'event_gacha_id',
        'name',
        'status',
        'start_date',
        'end_date',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(                 // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY event_gacha_id DESC',
        ),
        'find_by_event_gacha_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_gacha_id=:event_gacha_id',
        ),
        'find_by_event_gacha_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_gacha_id IN (:event_gacha_id)',
        ),
        // }}}

        // {{{ ��������������
        'insert' => array(              // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (name, start_date, end_date, ctime) VALUES(:name, :start_date, :end_date, NOW())',
        ),
        'update_by_event_gacha_id' => array(  // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET name=:name, status=:status, start_date=:start_date, end_date=:end_date WHERE event_gacha_id=:event_gacha_id',
        ),
        // }}}

        // {{{ �ơ��֥����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `event_gacha_id`    int(11) unsigned NOT NULL auto_increment,
                    `name`              varchar(255) NOT NULL DEFAULT '',
                    `status`            tinyint(2) unsigned NOT NULL default '0',
                    `start_date`        datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `end_date`          datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`event_gacha_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
