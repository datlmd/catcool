<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/KeyValue.php
 *
 * @package     GREE Avatar
 * @since       2020-02-20
 */

require_once PATH_SRC_CLASS . 'Gree/GenericDao/UserIdFarmSelector.php';

/**
 * PetDisplay form constructor
 * @access      public
 */
class Gree_GenericDao_KeyValueDao extends Gree_GenericDao
{
    /** table devide num */
    const TABLE_DIVIDE_NUM = 10;

    /** @var table name */
    var $_table_name = 'key_value';

    /** @var primary key */
    var $_primary_key = array('user_id', 'key');

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',
        'key',
        'value',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_value_by_user_id_and_name'             => array(
            'sql' => 'SELECT value FROM __TABLE_NAME__ WHERE user_id = :user_id AND key = :key',
        ),
        // }}}
        // {{{ update queries
        'create_or_update' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__ (`user_id`, `key`, `value`, `ctime`)
                VALUES (:user_id, :key, :value, NOW())
                ON DUPLICATE KEY UPDATE value = :value
            ',
        ),
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` INT(11) UNSIGNED NOT NULL,
                `key`     VARCHAR(255) NOT NULL,
                `value`   VARCHAR(255) NOT NULL,
                `mtime`   timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime`   datetime NOT NULL default '0000-00-00 00\:00\:00',
                PRIMARY KEY (`user_id`, `key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_UserIdFarmSelector(self::TABLE_DIVIDE_NUM);
    }
    // }}}
}
