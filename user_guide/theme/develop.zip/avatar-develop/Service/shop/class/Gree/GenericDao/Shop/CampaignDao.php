<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	CampaignDao.php
 *
 *	@author		Tomoaki Sawa <sawa@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: CampaignDao.php 33522 2008-06-25 07:22:57Z  $
 */
class Gree_GenericDao_Shop_CampaignDao extends Gree_GenericDao {
	var $_table_name = 'shop_campaign';
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';
	var $_primary_key = 'campaign_id';
	var $_auto_increment = true;
	var $_queries = array(
			'find_by_campaign_id' => array(
					'sql' => 'SELECT * FROM shop_campaign WHERE campaign_id=:campaign_id'
			),
			'find_all' => array(
					'sql' => 'SELECT * FROM shop_campaign order by campaign_id desc'
			),
			'count_all' => array(
					'sql' => 'SELECT count(*) FROM shop_campaign'
			),
            'find_by_type' => array(
                    'sql'   => 'SELECT * FROM shop_campaign where campaign_tpl_type=:campaign_type order by campaign_id desc'
            ),
            'count_by_type' => array(
                'sql'   => 'SELECT count(*) FROM shop_campaign where campaign_tpl_type=:campaign_type'
            ),
            'search_by_campaign_name' => array(
                'sql'   => 'SELECT * FROM shop_campaign where campaign_name like :name order by campaign_id desc'
            ),
            'count_by_campaign_name'  => array(
                'sql'   => 'SELECT count(*) FROM shop_campaign where campaign_name like :name'
            ),
            'find_campaign_ids_by_date'  => array(  // avatar only
                'sql'   => 'SELECT campaign_id FROM shop_campaign where campaign_id >= 2430 and start_datetime <= :start_datetime and end_datetime >= :end_datetime'
            ),
            'find_campaign_by_ids'  => array(
                'sql'   => 'SELECT * FROM shop_campaign where campaign_id in (:campaign_ids) order by campaign_id desc'
            )
	);

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
