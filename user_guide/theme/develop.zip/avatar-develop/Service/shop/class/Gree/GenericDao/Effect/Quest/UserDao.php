<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Effect/Quest/UserDao.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */

class Gree_GenericDao_Effect_Quest_UserDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'user_effect_quest';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_effect';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_effect';

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'quest_id',
        'result',
        'ctime',
        'mtime',
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_user_id_and_quest_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND quest_id = :quest_id',
        ),
        // }}}
        // {{{ ������
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (
                        user_id,
                        quest_id,
                        result,
                        ctime
                    ) VALUES (
                        :user_id, 
                        :quest_id,
                        :result,
                        NOW()
                    )',
            'return_last_insert_id' => true
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET result = :result WHERE user_id = :user_id AND quest_id = :quest_id',
        ),
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`            INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id`       INT(10) UNSIGNED NOT NULL,
                `quest_id`      INT(10) UNSIGNED NOT NULL,
                `result`        INT(10) UNSIGNED NOT NULL,
                `ctime`         DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime`         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `quest_id` (`user_id`, `quest_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Effect_Quest_UserFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Effect_Quest_UserFarmSelector extends Gree_GenericDao_FarmSelector
{

    /** @var string table suffix format */
    var $_table_suffix_format = '_%02d';

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        /** var �ơ��֥�ʬ��� */
        $table_nums = 10;

        // check $hint[user_id]
        if (empty($hint['user_id']) || is_numeric($hint['user_id']) == false || $hint['user_id'] <= 0) {
            $error_msg  = sprintf('hint is empty. dao = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
        $user_id = $hint['user_id'];
        $postfix = (int)($user_id % $table_nums);

        // create table name
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
    // }}}
}
