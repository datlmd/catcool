<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Notification_Remove
 */
class Gree_Service_AvatarFeed_Processor_Notification_Remove
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * don't check entry owner
     */
    protected function invoke()
    {
        $is_remove_success = false;
        $entry_id          = null;

        $mod_appfeed = self::getModule('AppFeed');

        try {
            list($is_remove_success, $entry_id) = $mod_appfeed->deleteEntry($this->input_values);
        } catch (Exception $e) {
            $msg     = 'failed remove notification.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_NOTIFICATION_REMOVE;
            $context = $this->input_values;
            $is_remove_success = false;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $is_remove_success,
            $entry_id
        );
    }
}
