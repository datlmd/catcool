<?php

class Gree_Service_AvatarFeed_Processor_Score_Increment
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_score;
    var $score_key;
    var $top_score_list_key;
    var $incremented_value;

    protected function invoke()
    {
        $this->mod_score = self::getModule('Score');
        $this->score_key = $this->mod_score->_getScoreKey($this->input_values['category'], $this->input_values['user_id'], $this->input_values['date']);
        $this->top_score_list_key = $this->mod_score->_getTopScoreListKey($this->input_values['category'], $this->input_values['date']);

        try {
            // unit_test_story_2_1
            if (isset($this->input_values['is_retry']) && $this->input_values['is_retry'] == true) {
                $this->incremented_value = $this->input_values['incremented_value'];
                $is_incremented_success = true;
            } else {
                $is_incremented_success = $this->_increment();
            }

            if ($is_incremented_success == false) {
                return false;
            }

            $is_updated_list = $this->_update_list();

            if ($is_updated_list == false){
                return false;
            }
        } catch (Exception $e) {
            $msg = 'failed incremented.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_SCORE_INCREMENT;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return false;
        }

        return true;
    }

    protected function _increment()
    {
        $incremented_value = $this->mod_score->increment($this->input_values['cycle'], $this->score_key);

        // success incremented
        // unit_test_story_2
        if ($incremented_value > 0) {
            $this->incremented_value = $incremented_value;

            return true;
        }

        // failed incremented
        $is_add_success = $this->mod_score->add($this->input_values['cycle'], $this->score_key);

        // success added
        // unit_test_story_1
        if ($is_add_success == true) {
            $this->incremented_value = 1;

            return true;
        }

        // If you want to retry processing, please comment out the code below
        /*
        // failed added
        $retry_incremented_value = $this->mod_score->increment($this->input_values['cycle'], $this->score_key);

        // success retry incremented
        if ($retry_incremented_value > 0) {
            $this->incremented_value = $retry_incremented_value;

            return true;
        }

        // failed retry incremented
        $msg = 'failed retry incremented.';
        */

        // failed increment
        $msg = 'failed increment.';
        $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_SCORE_INCREMENT;
        $context = $this->input_values;

        new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

        return false;
    }

    protected function _update_list()
    {
        $is_exist_target = false;
        $is_within_limit = false;
        $is_over_threshold = false;

        list($top_score_list, $token) = $this->mod_score->get($this->input_values['cycle'], $this->top_score_list_key);
        // not exist top score list
        // unit_test_story_1
        if (is_array($top_score_list) == false) {
            $new_top_score_list = array(
                'min'                          => $this->incremented_value,
                $this->input_values['user_id'] => $this->incremented_value
            );
            $expire_time = 7200;

            $is_added_success = $this->mod_score->add($this->input_values['cycle'], $this->top_score_list_key, $new_top_score_list, $expire_time);

            // unit_test_story_1_1
            if ($is_added_success == false){
                // failed add top score list
                $msg = 'failed top score list.';
                $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_SCORE_INCREMENT;
                $context = $this->input_values;

                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }

            return true;
        }


        if (array_key_exists($this->input_values['user_id'], $top_score_list)) {
            $is_exist_target = true;
        }

        if (count($top_score_list) < GREE_SERVICE_AVATARFEED_SCORE_LIST_NUMBER) {
            $is_within_limit = true;
        }

        if ($this->incremented_value > $top_score_list['min']) {
            $is_over_threshold = true;
        }

        // unit_test_story_2
        if ($is_exist_target) {
            if ($this->incremented_value > $top_score_list[$this->input_values['user_id']]) {
                $new_top_score_list = $top_score_list;
                $new_top_score_list[$this->input_values['user_id']] = $this->incremented_value;
            } else {
                // unit_test_story_2_1
                return false;
            }
        // unit_test_story_2_2
        } elseif ($is_within_limit) {
            // && $is_exist_target == false
            $new_top_score_list = $top_score_list;
            $new_top_score_list[$this->input_values['user_id']] = $this->incremented_value;
        // unit_test_story_2_3
        } elseif ($is_over_threshold) {
            // && $is_exist_target == false
            // && $is_within_limit == false
            $new_top_score_list = $this->_get_sorted_list($top_score_list);
        // unit_test_story_2_4
        } else {
            return false;
        }

        $is_cased_success = $this->mod_score->cas($this->input_values['cycle'], $token, $this->top_score_list_key, $new_top_score_list);
        if ($is_cased_success == false) {
            if (isset($this->input_values['is_retry']) && $this->input_values['is_retry'] == true) {
                // failed retry update
                $msg = 'failed retry updated.';
                $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_SCORE_INCREMENT;
                $context = $this->input_values;

                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

                return false;
            }

            // retry enqueue
            $async_params = array(
                'is_retry'          => true,
                'user_id'           => $this->input_values['user_id'],
                'category'          => $this->input_values['category'],
                'date'              => $this->input_values['date'],
                'cycle'             => $this->input_values['cycle'],
                'incremented_value' => $this->incremented_value,
            );
            Gree_Async::add('shop::avatarfeed', 'incrementScore', null, $async_params);
        }

        return true;
    }

    protected function _get_sorted_list($top_score_list)
    {
        $top_score_list[$this->input_values['user_id']] = $this->incremented_value;

        arsort($top_score_list);

        $new_top_score_list = array();
        foreach($top_score_list as $user_id => $score){
            $new_top_score_list[$user_id] = $score;

            if(count($new_top_score_list) >= GREE_SERVICE_AVATARFEED_SCORE_LIST_NUMBER){
                $new_top_score_list['min'] = $score;
                break;
            }
        }

        return $new_top_score_list;
    }
}