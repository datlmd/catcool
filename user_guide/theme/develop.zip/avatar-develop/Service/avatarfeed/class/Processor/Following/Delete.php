<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Following_Delete
 */
class Gree_Service_AvatarFeed_Processor_Following_Delete
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return bool|void
     *
     * flow is
     *   remove following user
     *   decrement following count
     *   remove followed user
     *   decrement followed count
     */
    protected function invoke()
    {
        $delete_result = true;

        $code    =  Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOWING_DELETE;
        $context = $this->input_values;

        $mod_follow = self::getModule('Follow');
        $mod_block  = self::getModule('Block');

        try {
            $delete_following_result = $mod_follow->removeFollowingUser(
                $this->input_values['user_id']
            );

            if ($delete_following_result == false){
                $msg = 'failed delete following user.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
                return false;
            }

            $decrement_following_result = $mod_follow->decrementFollowCount(
                'following'
            );

            if ($decrement_following_result == false){
                $msg = 'failed decrement following count.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
                return false;
            }

            // if user is block user then not followed
            $is_block = $mod_block->getBlockUser(
                $this->_certified_user->my['user_id'],
                $this->input_values['user_id']
            );

            if ($is_block) {
                return $delete_result;
            }

            $delete_followed_result = $mod_follow->removeFollowedUser(
                $this->_certified_user->my['user_id'],
                $this->input_values['user_id']
            );
            if ($delete_followed_result == false){
                $msg = 'failed delete followed user.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
                return false;
            }

            $decrement_followed_result = $mod_follow->decrementFollowCount(
                'followed',
                $this->input_values['user_id']
            );

            if ($decrement_followed_result == false){
                $msg = 'failed decrement followed count.';
                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
                return false;
            }

            $shop_service = getService('shop');
            $silencer = $shop_service->getFlareFollowNotificationSilencer();
            $silencer->setSilencer($this->_certified_user->my['user_id'], $this->input_values['user_id']);

        } catch (Exception $e){
            $msg = 'failed delete following user.';
            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            $delete_result = false;
        }

        return $delete_result;
    }
}
