<?php

final class Gree_Service_Avatarfeed_Test_Cascade_FollowedTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $accessor;

    public function setUp()
    {
        $this->accessor = Cascade::getAccessor('avatar_feed#test_followed');
        $params = array(
            'user_id' => UNIT_TEST_USER_ID_1
        );
        $this->accessor->execute('drop_table', $params);
        $this->accessor->execute('create_table', $params);
    }

    /*
     * 'SELECT followed_user_id FROM __TABLE_NAME__
     *      WHERE user_id = :user_id
     *      AND   followed_user_id > :followed_user_id
     *      ORDER BY followed_user_id',
     */
    public function test_find_list_by_user_id_and_followed_user_id()
    {
        $this->_insert_dummy_data();

        $find_values = array(
            'followed_user_id' => 0, // offset
            'user_id' => UNIT_TEST_USER_ID_1,
        );

        $limit = 3;
        // use master.
        $find_result = $this->accessor->find('find_list_by_user_id_and_followed_user_id', $find_values, 0, $limit, null, true);

        // The value does not exist is specified in an offset
        $this->assertNotEquals(0, $find_result[0]['followed_user_id']);
        $this->assertEquals(1, $find_result[0]['followed_user_id']);
        $this->assertEquals(2, $find_result[1]['followed_user_id']);
        $this->assertEquals(3, $find_result[2]['followed_user_id']);
    }

    public function _insert_dummy_data($user_id = UNIT_TEST_USER_ID_1)
    {
        for ($i=0; $i < 100; $i++){
            $params = array(
                'user_id' => $user_id,
                'followed_user_id' => $i
            );
            $this->accessor->execute('add_followed', $params);
        }
    }
}