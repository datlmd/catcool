<?php

class Gree_Service_AvatarFeed_Processor_Follow_List_Recommend
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $seed   = $this->input_values['seed'];
        $offset = $this->input_values['offset'];
        $num    = $this->input_values['num'];

        $mod_appfeed   = self::getModule('AppFeed');
        $mod_recommend = self::getModule('RecommendUser');
        $srv_user = getService('user');
        $mod_user = $srv_user->profile;
        $mod_avatar = self::getModule('Avatar');
        $mod_follow = self::getModule('Follow');

        // check exist table
        $is_exist_table = $mod_recommend->isExistTable();
        if ($is_exist_table == false) {
            $msg  = 'not exist recommend table';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_RECOMMEND;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $this->input_values);

            return false;
        }


        $rand_array = range(1, GREE_SERVICE_AVATARFEED_TOTAL_RECOMMEND_NUMBER);
        $rand_array = $this->_shuffle($rand_array, $seed);

        $user_list = array();
        for ($i = $offset; $i < ($offset+$num); $i++) {
            if (!isset($rand_array[$i])) {
                continue;
            }

            $user_id = $mod_recommend->getUserIdFromId($rand_array[$i]);
            if (is_null($user_id)) {
                continue;
            }

            $user_info = $mod_user->selectByID($user_id);
            if (empty($user_info)) {
                continue;
            }

            $second_image = Gree_Service_Shop_SecondUtil::getPreviewUrlIncludeSecond($user_id);
            if (!empty($second_image)) {
                $img_url = $second_image;
            } else {
                $img_url = $mod_avatar->getAvatarImgUrl($user_id, GREE_SERVICE_AVATARFEED_CHANGE_IMG_SIZE);
            }

            list($following_count, $followed_count) = $mod_follow->getFollowCount($user_id);

            $user_list[] = array(
                'user_id' => $user_id,
                'nickname' => $user_info['nick_name'],
                'following_count' => $following_count,
                'followed_count' => $followed_count,
                'preview_url' => $img_url,
            );
        }

        return $user_list;
    }

    private function _shuffle($arr, $seed)
    {
        mt_srand($seed);
        $order = array_map(create_function('$val', 'return mt_rand();'), range(1, count($arr)));
        array_multisort($order, $arr);

        return $arr;
    }
}
