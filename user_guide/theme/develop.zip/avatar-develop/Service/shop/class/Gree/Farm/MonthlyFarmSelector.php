<?php
/**
 * Gree_GenericDao_Shop_MonthlyFarmSelector
 *
 * @author  Norie Matsuda <norie.matsuda@gree.co.jp>
 * @package GREE
 */
class Gree_GenericDao_Shop_MonthlyFarmSelector extends Gree_GenericDao_FarmSelector
{
    /** @var string table suffix format */
    var $_table_suffix_format = "_%s";

    // {{{ getTableName
    /**
     * get the table name
     *
     * @param   object  $dao    the dao object
     * @param   int     $type   the type
     * @param   array   $hint   the hint
     * @return  string          the table name
     */
    function getTableName($dao, $type, $hint)
    {
        // check $hint[ctime]
        if (isset($hint['ctime'])) {
            $date = strtotime($hint['ctime']);

        // check $hint[date]
        } else if (isset($hint['date'])) {
            $date = strtotime($hint['date']);

        } else {
            $error_msg  = sprintf('hint is empty. dao = %s ', get_class($dao));
            return PEAR::raiseError($error_msg);
        }
        
        $postfix = date('Ym', $date);

        // create table name
        $table_suffix   = sprintf($this->_table_suffix_format, $postfix);
        $table_name     = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
    // }}}
}
