<?php

class Gree_GenericDao_ExecuteLimiterDao extends Gree_GenericDao
{
    public $_table_name = 'execute_limiter';

    public $_primary_key = 'user_id';

    public $_created_at_column = 'ctime';

    public $_master_dsn = 'gree://master/avatar_user';

    public $_slave_dsn  = 'gree://slave/avatar_user';

    public $_auto_increment = false;

    public $_field_names = [
        'user_id',
        'execute_type',
        'ctime',
    ];

    public $_queries = [

        //Refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY user_id DESC'
        ],
        'find_user_id_by_user_ids' => [
            'sql' => 'SELECT user_id FROM __TABLE_NAME__ WHERE user_id in (:user_ids) AND execute_type = :execute_type'
        ],
        'find_by_execute_type' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE execute_type = :execute_type ORDER BY ctime'
        ],

        //Insert query
        'insert' => [
            'sql' => "
            INSERT IGNORE INTO __TABLE_NAME__ (
                    user_id,
                    execute_type,
                    ctime,
                )
                VALUES(
                    :user_id,
                    :execute_type,
                    NOW()
                )
            ",
        ],

        //Create table query
        'create_table' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` int(10) NOT NULL,
                `execute_type` tinyint(4) UNSIGNED NOT NULL,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`user_id`),
                UNIQUE (`user_id`, `execute_type`),
                KEY `user_idx` (`user_id`),
                KEY `execute_type` (`execute_type`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],

        // Delete query
        'delete_by_user_ids' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id in (:user_ids) AND execute_type = :execute_type'
        ],
        // Delete query
        'delete_by_execute_type_and_ctime' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE execute_type = :execute_type AND ctime <= :ctime'
        ],
    ];

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
