<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Item/SearchJobDao.php
 *
 * @package     GREE Avatar
 * @since       2017-01-16
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * SearchJob form constructor
 * @access      public
 */
class Gree_GenericDao_Item_SearchJobDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'search_job';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_item_tags';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_item_tags';

    /** @var field names */
    var $_field_names = array(
        'id',
        'item_id',
        'target',
        'from_datetime',
        'to_datetime',
        'status',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'find_first_by_status'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :status ORDER BY id ASC',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (item_id, target, from_datetime, to_datetime, status, ctime) VALUES (:item_id, :target, :from_datetime, :to_datetime, :status, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET item_id = :item_id, target = :target, from_datetime = :from_datetime, to_datetime = :to_datetime, status = :status WHERE id = :id',
        ),
        'update_status'               => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE id = :id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'create_table'           => array(
            'sql' => 'CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `item_id` INT(10) UNSIGNED DEFAULT NULL,
                `target` TINYINT(3) UNSIGNED NOT NULL,
                `from_datetime` DATETIME DEFAULT NULL,
                `to_datetime` DATETIME DEFAULT NULL,
                `status` TINYINT(3) UNSIGNED NOT NULL,
                `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;',
        ),
        // }}}
    );

}
