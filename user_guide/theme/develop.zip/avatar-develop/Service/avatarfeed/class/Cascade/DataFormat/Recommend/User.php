<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Recommend_user
    extends Cascade_DB_SQL_DataFormat
{
    // dsn setting
    protected $master_dsn = 'gree://master/avatar_recommend_user';
    protected $slave_dsn  = 'gree://slave/avatar_recommend_user';
    protected $extra_dsn  = array();

    // cascade setting
    protected $primary_key = 'id';
    protected $fetch_mode  = self::FETCH_MODE_ASSOC;
    // use primary_key
    protected $fetch_key      = NULL;
    protected $auto_increment = true;

    // table and column setting
    protected $table_name  = 'recommend_user_';
    protected $field_names = array(
        'id',
        'user_id'
    );

    protected $queries = array(
        'create_table'   => array(
            'sql' => '
              CREATE TABLE IF NOT EXISTS __TABLE_NAME__  (
              `id`       bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
              `user_id`  bigint(20) UNSIGNED NOT NULL,
              PRIMARY KEY (`id`)
              ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
            ',
        ),
        'drop_table'   => array(
            'sql' => '
              DROP TABLE IF EXISTS __TABLE_NAME__
            ',
        ),
        'find_by_id'     => array(
            'sql' => 'SELECT user_id FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'insert_user_id' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__  (user_id) VALUES(:user_id)
            ',
        ),
        'check_table'    => array(
            'sql' => "
                SHOW TABLES LIKE '__TABLE_NAME__'
            ",
        ),
    );

    public function getTableName($criteria)
    {
        $input = $criteria->params;
        if (isset($input['date'])) {
            $date = $input['date'];
        } else {
            $date = date("Ymd");
        }

        $tb_name = $this->table_name . $date;

        return $tb_name;
    }
}
