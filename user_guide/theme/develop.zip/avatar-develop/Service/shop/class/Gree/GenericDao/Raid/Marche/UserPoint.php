<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserPoint.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Raid_Marche_UserPointDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'raid_marche_user_point';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_raid';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_raid';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'point',
        'group_id',
        'summary_id',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
        'count_by_summary_id' => array(
            'sql' => 'SELECT COUNT(user_id) AS cnt FROM __TABLE_NAME__ WHERE summary_id=:summary_id',
        ),
        'count_by_group_id' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM __TABLE_NAME__ WHERE group_id=:group_id',
        ),
        'count_user_point' => array(
            'sql' => 'SELECT COUNT(*) AS user_num FROM __TABLE_NAME__',
        ),
        'count_user_ranking_for_summary_id' => array(
            'sql' => 'SELECT COUNT(*) + 1 AS rank FROM __TABLE_NAME__ WHERE point > :point AND summary_id = :summary_id',
        ),
        'find_by_ingroup_ranking' => array(
            'sql' => 'SELECT user_id, point, group_id FROM __TABLE_NAME__ WHERE group_id=:group_id ORDER BY point DESC',
        ),
        'find_by_user_ranking_for_support' => array(
            'sql' => 'SELECT user_id, point, 0 as group_id FROM __TABLE_NAME__ ORDER BY point DESC',
        ),
        'find_by_user_ranking' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE summary_id > 0 ORDER BY point DESC',
        ),

        // {{{ ��������������
        'insert_or_update' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, point, group_id, summary_id, ctime) VALUES(:user_id, :point, :group_id, :summary_id, NOW()) ON DUPLICATE KEY UPDATE point=:point, summary_id=:summary_id',
        ),
        'insert_for_support' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, point, group_id, summary_id, ctime) VALUES(:user_id, :point, :group_id, :summary_id, NOW())',
        ),
        // }}}

        // {{{ support only
        // where �� old_summary_id ���ɲä������߹�����Υ桼�������錄��硢update ��������ʤ��褦Ĵ��
        'update_for_ranking_modify' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET summary_id=:summary_id WHERE user_id=:user_id AND summary_id=:old_summary_id',
        ),
        'count_by_min_point_and_max_point' => array(        // for support tool
            'sql' => 'SELECT count(user_id) as cnt FROM __TABLE_NAME__ WHERE point >= :min_point AND point <= :max_point',
        ),
        'find_by_min_point_and_max_point_not_summary' => array(        // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE point >= :min_point AND point <= :max_point AND summary_id <> :summary_id',
        ),
        'find_by_over_max_point' => array(        // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE point > :over_point ORDER BY point ASC',
        ),
        // }}}

        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `user_id`           int(11) unsigned NOT NULL default '0',
                    `point`             int(11) unsigned NOT NULL default '0',
                    `group_id`          int(11) unsigned NOT NULL default '0',
                    `summary_id`        int(11) unsigned NOT NULL default '0',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`user_id`),
                    KEY `group_id` (`point`, `group_id`),
                    KEY `summary_id` (`point`, `summary_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'truncate_table' => array(      // for batch
            'sql' => "TRUNCATE TABLE __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Raid_Marche_UserPointSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserPoint.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Raid_Marche_UserPointSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d";   // event_id
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['event_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, $hint['event_id']);

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
