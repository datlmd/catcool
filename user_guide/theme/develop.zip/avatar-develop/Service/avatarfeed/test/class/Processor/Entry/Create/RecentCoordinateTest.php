<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Entry_Create_RecentCoordinateTest
 *
 * this test is create entry process on recent coordinate
 */
final class Gree_Service_Avatarfeed_Test_Processor_Entry_Crate_RecentCoordinateTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    var $module_follow;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        sleep(2);

        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
    }

    /**
     * test1:
     * Success Create Entry
     * is_success == true
     * entry_id   == string
     *
     * test2
     * Failed Crate Entry
     * is success == false
     * entry_id   == null
     */
    public function test_create_entry()
    {
        $this->module_follow->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        $is_following = $this->module_follow->getFollowingUser(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);

        if ($is_following == false) {
            $add_following = $this->module_follow->addFollowingUser(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);
            $this->assertEquals(1, $add_following);
            sleep(2);
        }

        // test1
        list($is_success_create, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_success_create);

        sleep(2);

        $add_params = array(
            'entry_id' => $entry_id
        );

        $add_destination = $this->avatar_feed->process('entry_create_recentCoordinate', $add_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($add_destination);

        sleep(6);

        $this->module->setUserIDtoCtfy(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);
        list($has_more, $dest_stream_data) = $this->module->getEntriesByFeedKey();
        $dest_entry = array_shift($dest_stream_data);

        $this->assertEquals($entry_id, $dest_entry['entry_id']);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $dest_entry['content']['sender_id']);
        $this->assertEquals('activity', $dest_entry['content']['entry_type']);
        $this->assertEquals(GREE_SERVICE_AVATARFEED_DEFAULT_CHANGE_TEXT, $dest_entry['content']['text']);
        $this->assertEquals('change', $dest_entry['content']['attr']['entry_category']);
        $this->assertEquals('41T00fjlukgtkgJ', $dest_entry['content']['attr']['avatar_key']);
    }

    public function test_not_following() {
        $this->module_follow->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        $is_following = $this->module_follow->getFollowingUser(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);

        if ($is_following == true) {
            $remove_following = $this->module_follow->removeFollowingUser(GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID);
            $this->assertEquals(1, $remove_following);
            sleep(2);
        }

        list($is_success_create, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        $this->assertTrue($is_success_create);

        sleep(2);

        $add_params = array(
            'entry_id' => $entry_id
        );

        $add_destination = $this->avatar_feed->process('entry_create_recentCoordinate', $add_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($add_destination);
    }


    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'activity',
                'text'       => GREE_SERVICE_AVATARFEED_DEFAULT_CHANGE_TEXT,
                'attr'       => array(
                    'entry_category' => 'change',
                    'avatar_key'     => '41T00fjlukgtkgJ'
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}
