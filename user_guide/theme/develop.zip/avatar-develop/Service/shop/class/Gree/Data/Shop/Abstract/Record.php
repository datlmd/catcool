<?php
/**
 * Service/shop/class/Gree/Data/Abstract/Record.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
require_once sprintf('%s/Abstract.php', dirname(dirname(__FILE__)));

/**
 * Gree_Service_Shop_Data_Abstract_Record
 *
 * @package GREE
 * @access  public
 */
abstract class Gree_Service_Shop_Data_Abstract_Record
    extends Gree_Service_Shop_Data_Abstract
{
    /** ---- [ Class Constants ] -------------------------------- */

    const DAO_NAME = null; // override me

    /** ---- [ Properties ] -------------------------------- */

    static private $_format_list = array();

    /** ---- [ static methods ] -------------------------------- */

    // {{{ _generateAccessor
    /**
     * @param   mixed   $key    the value of instance key(s)
     * @param   array   $hint
     * @param   string  $class_name
     * @return  array   the accessor
     */
    protected static /* array */
        function _generateAccessor($key, $hint, $class_name)
    {
        // override me
        $dao_name   = constant("$class_name::DAO_NAME");
        if (is_null($dao_name)) {
            $ex_msg = 'the constant DAO_NAME is not declared (%s)';
            $ex_msg = sprintf($ex_msg, $class_name);
            throw new Gree_Service_Shop_Exception($ex_msg);
        }

        $session    = getService('shop')->getSessionWrapper();
        $accessor   = $session->get($dao_name, $key, $hint);
        if (is_null($accessor)) {
            $ex_msg = 'the accessor does not exist';
            throw new Gree_Service_Shop_Exception($ex_msg);
        }

        return $accessor;
    }
    // }}}
    // {{{ _getAccessorFormat
    /**
     * @access  protected
     * @return  array   the format
     */
    protected function _getAccessorFormat()
    {
        $class_name = get_class($this);
        if (!isset(self::$_format_list[$class_name])) {
            $dao_name   = constant("$class_name::DAO_NAME");
            $dao        = $this->_session->getDao($dao_name);
            $format     = $dao->_getFieldNames();

            self::$_format_list[$class_name] = $format;
        }

        return self::$_format_list[$class_name];
    }
    // }}}
}
