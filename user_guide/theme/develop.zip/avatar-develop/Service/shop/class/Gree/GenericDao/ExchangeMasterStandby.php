<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
require_once PATH_SRC_CLASS . '/Gree/GenericDao/LifeBodyTypeFarmSelector.php';
class Gree_GenericDao_ExchangeMasterStandbyDao extends Gree_GenericDao_ExchangeMasterDao {
	
	var $_slave_dsn = 'gree://standby/shop';
	
	/** @var ������ */
	var $_queries_standby = array(
		'find_by_item_and_user_and_completion'  => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ AS m LEFT JOIN exchange_second AS s ON m.id = s.id WHERE ((m.from_items LIKE :item_id AND m.from_user_id = :user_id) OR (s.to_items LIKE :item_id AND m.to_user_id = :user_id)) AND m.completion IN (:completion)'
		),
	);

	function __construct()
	{
		parent::__construct();
		$this->_setQuery($this->_queries_standby);
	}

	function _setQuery($queries)
	{
		$this->_queries = array_merge($this->_queries, $queries);
	}

}
?>
