<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Stamp_Shop_MasterDao extends Gree_GenericDao_Apc
{
    var $_table_name = 'stamp_shop_master';

    var $_primary_key = 'id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_stamp';

    var $_slave_dsn = 'gree://slave/avatar_stamp';

    var $_auto_increment = true;

    var $_field_names = array(
        'id',
        'stamp_id',
        'stamp_set_id',
        'status',
        'start_time',
        'end_time',
        'price',
        'mtime',
        'ctime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id`           INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `stamp_id`     INT(11) UNSIGNED DEFAULT NULL,
                `stamp_set_id` INT(11) UNSIGNED NOT NULL,
                `status`       TINYINT(2) UNSIGNED NOT NULL DEFAULT 0,
                `start_time`   DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_time`     DATETIME DEFAULT NULL,
                `price`        INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `mtime`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime`        DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`id`),
                KEY `stamp_id` (`stamp_id`),
                KEY `stamp_set_id` (`stamp_set_id`),
                KEY `stamp_id_and_status` (`stamp_id`, `status`),
                KEY `stamp_set_id_and_status` (`stamp_set_id`, `status`),
                KEY `status` (`status`)
            ) ENGINE=INNODB DEFAULT CHARSET=ujis",
        ),

        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (
                    stamp_id,
                    stamp_set_id,
                    start_time,
                    end_time,
                    price,
                    status,
                    ctime
                ) VALUES(
                    :stamp_id,
                    :stamp_set_id,
                    :start_time,
                    :end_time,
                    :price,
                    :status,
                    NOW()
                )',
            'return_last_insert_id' => true,
        ),

        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET stamp_id = :stamp_id, stamp_set_id = :stamp_set_id, start_time = :start_time, end_time = :end_time, price = :price, status = :status WHERE id = :id',
        ),

        'update_status' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE id in (:ids)',
        ),

        /*
         * find all
         */

        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),

        'find_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id=:id',
        ),

        'find_by_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status=:status ORDER BY id DESC',
        ),

        /*
         * find select stamp
         */

        'all_select_stamp' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE stamp_set_id = 1 ORDER BY id DESC',
        ),

        'find_select_stamp_by_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE stamp_set_id = 1 and status=:status ORDER BY id DESC',
        ),

        // find set

        'all_set_stamp' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE stamp_id is NULL ORDER BY id DESC',
        ),

        'find_set_stamp_by_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE stamp_id is NULL and status=:status ORDER BY id DESC',
        ),

        'find_set_stamp_by_stamp_set_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE stamp_id is NULL and stamp_set_id=:stamp_set_id'
        ),
    );
}
