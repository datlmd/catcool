<?php
/**
 * Flare.php
 * Rapper for Flare
 * @package GREE
 */
require_once PATH_SRC_CLASS . 'Gree/Flare.php';
abstract class Gree_Service_Shop_Flare
{
    abstract protected function getExpireTime();
    abstract protected function getNameSpace();
    
    const FLARE_EMERGENCY_ERROR = 2001;
    
    private function getPrefix() {
        return 'avatar_';
    }

    // {{{ getGreeFlare
    protected function getGreeFlare()
    {
        static $gree_flare = null;
        $namespace = $this->getNameSpace();
        if (empty($gree_flare[$namespace])) {
            $gree_flare[$namespace] = Gree_Flare::getInstance($this->getPrefix() . $this->getNameSpace());
            // compress trigger from product
            // make sure add compress to /home/gree/src/class/Gree/Flare.php
            //$gree_flare[$namespace]->compress = true;
        }
        return $gree_flare[$namespace];
    }
    // }}}
    // {{{ set
    public function set($key, $val) {
        $ret = $this->getGreeFlare()->set($key, $val, $this->getExpireTime());
        if (PEAR::isError($ret) || !$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            error_log("flare set error. error code:" . $err_code);
            throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = '1000');
        }
        return $ret;
    }
    // }}}
    // {{{ get
    public function get($key) {
        $ret = $this->getGreeFlare()->get($key, true);
        if (PEAR::isError($ret)) {
            $err_code = $this->getGreeFlare()->getResultCode();
            error_log("flare get error. error code:" . $err_code);
            throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = '2000');
        }

        if (!$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            if ($err_code == MEMCACHED_DATA_DOES_NOT_EXIST || $err_code == MEMCACHED_NOTFOUND) {
                return false;
            }
            error_log("flare get error. error code:" . $err_code);
            throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = self::FLARE_EMERGENCY_ERROR);
        }

        return $ret;
    }
    // }}}
    // {{{ cas
    public function cas($key, $val, $version) {
        $key = $this->getGreeFlare()->_getKey($this->getGreeFlare()->namespace, $key);
        $ret = $this->getGreeFlare()->memcache->cas($key, $val, $this->getExpireTime(), $this->getGreeFlare()->compress ? MEMCACHED_COMPRESSED : 0, $version);
        if (PEAR::isError($ret) || !$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            if ($err_code == MEMCACHED_DATA_EXISTS) {
                return false;
            }
            if ($err_code !== MEMCACHED_NOTFOUND) {
                $err_msg = $this->getGreeFlare()->getResultMessage();
                error_log("flare cas error. error code:" . $err_code . " error msg:" . $err_msg);
                throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = self::FLARE_EMERGENCY_ERROR);
            }
            throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = '3000');
        }
        return $ret;
    }
    // }}}
    // {{{ add
    public function add($key, $value, $expire_time = 0) {
        $key = $this->getGreeFlare()->_getKey($this->getGreeFlare()->namespace, $key);
        $ret = $this->getGreeFlare()->memcache->add($key, $value, $expire_time, $this->getGreeFlare()->compress ? MEMCACHED_COMPRESSED : 0);
        if (PEAR::isError($ret) || !$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            if ($err_code == MEMCACHED_DATA_EXISTS || $err_code == MEMCACHED_NOTFOUND || $err_code == MEMCACHED_NOTSTORED) {
                return false;
            }
            if ($err_code !== MEMCACHED_NOTFOUND) {
                $err_msg = $this->getGreeFlare()->getResultMessage();
                error_log("flare add error. error code:" . $err_code . " error msg:" . $err_msg);
                throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = self::FLARE_EMERGENCY_ERROR);
            }
            throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = '4000');
        }
        return $ret;
    }
    // }}} add
    // {{{ replace
    public function replace($key, $value) {
        $key = $this->getGreeFlare()->_getKey($this->getGreeFlare()->namespace, $key);
        $ret = $this->getGreeFlare()->memcache->replace($key, $value, 0, $this->getGreeFlare()->compress ? MEMCACHED_COMPRESSED : 0);
        if (PEAR::isError($ret) || !$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            if ($err_code == MEMCACHED_DATA_DOES_NOT_EXIST || $err_code == MEMCACHED_NOTFOUND || $err_code == MEMCACHED_NOTSTORED) {
                return false;
            }
            if ($err_code !== MEMCACHED_NOTFOUND) {
                $err_msg = $this->getGreeFlare()->getResultMessage();
                error_log("flare replace error. error code:" . $err_code . " error msg:" . $err_msg);
                throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = self::FLARE_EMERGENCY_ERROR);
            }
            throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = '5000');
        }
        return $ret;
    }
    // }}} replace
    // {{{ delete
    public function delete($key) {
        $key = $this->getGreeFlare()->_getKey($this->getGreeFlare()->namespace, $key);
        $ret = $this->getGreeFlare()->memcache->delete($key);
        if (PEAR::isError($ret) || !$ret) {
            $err_code = $this->getGreeFlare()->getResultCode();
            if ($err_code == MEMCACHED_DATA_DOES_NOT_EXIST || $err_code == MEMCACHED_NOTFOUND) {
                return false;
            }
            if ($err_code !== MEMCACHED_NOTFOUND) {
                $err_msg = $this->getGreeFlare()->getResultMessage();
                error_log("flare delete error. error code:" . $err_code . " error msg:" . $err_msg);
                throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = self::FLARE_EMERGENCY_ERROR);
            }
            throw new Gree_Service_Shop_Exception("System Error(AVAFL)", $code = '6000');
        }
        return $ret;
    }
    // }}} delete
}

