<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

class Gree_GenericDao_Serial_CodeDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'serial_code';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'id',
        'code',
        'pid',
        'status',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all' => array(
            'sql' => 'SELECT *, COUNT(id) as cnt FROM __TABLE_NAME__ GROUP BY pid ORDER BY pid DESC',
        ),
        'find_all_pid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE pid = :pid',
        ),
        'find_code' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE code = :code',
        ),
        'find_valid_code' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE code = :code AND status = 0',
        ),
        'find_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE pid IN (:pid) AND status = :uid',
        ),
        'find_pid_count' => array(
            'sql' => 'SELECT COUNT(*) as cnt FROM __TABLE_NAME__ WHERE pid = :pid',
        ),
        'find_by_uid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = :user_id',
        ),
        // }}}

        // {{{ update queries
        'entry'=> array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, type, item_ids, sex, ctime) VALUES (:user_id, :type, :item_ids, :sex, NOW())',
            'return_last_insert_id' => true
        ),
        'update_code'=> array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :user_id WHERE code = :code AND status = 0',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `code` VARCHAR(255) NOT NULL DEFAULT '',  
                    `pid` INT(11) UNSIGNED NOT NULL DEFAULT 0,
                    `status` INT(11) UNSIGNED NOT NULL DEFAULT 0,
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE KEY `code` (`code`),
                KEY `pid` (`pid`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
