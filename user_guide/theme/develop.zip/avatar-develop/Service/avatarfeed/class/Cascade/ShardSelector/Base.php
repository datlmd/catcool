<?php

class Gree_Service_AvatarFeed_Cascade_ShardSelector_Base
    extends Cascade_DB_SQL_ShardSelector
{

}