<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Notification_RemoveTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Notification_RemoveTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        } catch (Exception $e) {
        }

        sleep(2);

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        } catch (Exception $e) {
        }

        sleep(2);

        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        } catch (Exception $e) {
        }

        sleep(2);

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION);
        } catch (Exception $e) {
        }

        sleep(2);

    }

    public function test_notification_remove()
    {
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_success_create_entry);

        sleep(2);

        $notification_params = array(
            'user_id'               => UNIT_TEST_USER_ID_2,
            'entry_category'        => 'notification_like',
            'notification_entry_id' => $entry_id,
            'destination_user'      => UNIT_TEST_USER_ID_1,
        );
        $is_success_add_notification = $this->avatar_feed->process('notification_add', $notification_params, UNIT_TEST_USER_ID_2);
        $this->assertTrue($is_success_add_notification);

        sleep(2);

        list($has_more, $entries) = $this->module->getEntriesByFeedKey(
            UNIT_TEST_USER_ID_1,
            GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION,
            GREE_SERVICE_AVATARFEED_NOTIFICATION_LIMIT_COUNT,
            null,
            'batch'
        );

        $this->assertEquals(1, count($entries));

        $delete_entry = array_shift($entries);
        $delete_notification_params = array(
            'entry_id' => $delete_entry['entry_id'],
        );
        list($is_delete_success, $deleted_entry_id) = $this->avatar_feed->process('notification_remove', $delete_notification_params);

        $this->assertTrue($is_delete_success);
        $this->assertEquals($delete_entry['entry_id'], $deleted_entry_id);

        sleep(2);
        
        list($has_more, $entries) = $this->module->getEntriesByFeedKey(
            UNIT_TEST_USER_ID_1,
            GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION,
            GREE_SERVICE_AVATARFEED_NOTIFICATION_LIMIT_COUNT,
            null,
            'batch'
        );

        $this->assertEquals(0, count($entries));



    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_notification_add',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}