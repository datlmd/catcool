<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Gree_GenericDao_Shop_SkinDao
 */
class Gree_GenericDao_SkinDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'avatar_skin_setting';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',          // UserID
        'skin',             // ItemID
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_userid' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}

        // {{{ update queries
        'entry' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, skin, ctime) VALUES (:user_id, :skin, NOW()) ON DUPLICATE KEY UPDATE skin=:skin',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `skin`                VARCHAR(255),
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
