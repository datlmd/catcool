<?php
/**
 * Gree_GenericDao_Coordell_VoteDao
 * 
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */

class Gree_GenericDao_Coordell_VoteDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'vote';
    /** @var primary key */
    var $_primary_key = 'id';
    /** @var auto increment */
    var $_auto_increment = true;
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_coordell';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_coordell';

    /** @var field names */
    var $_field_names = array(
        'id',
        'feed_id',
        'voted_user_id',
        'value',
        'votetime',
    );

    var $_queries = array(
    // --select
        'select_ranking' => array(
            'sql' => 'SELECT feed_id,SUM(value) AS sum_val FROM __TABLE_NAME__ WHERE votetime BETWEEN :start AND :end GROUP BY feed_id ORDER BY sum_val DESC, feed_id',
        ),
    // --insert & update
        'insert' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (feed_id, voted_user_id, value, votetime) VALUES (:feed_id, :voted_user_id, :value, :votetime)',
        ),
    // --create table 
    // ctime is unixtime
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `feed_id` INT(10) UNSIGNED NOT NULL,
                `voted_user_id` INT(10) UNSIGNED NOT NULL,
                `value` INT(10) UNSIGNED DEFAULT 0 NOT NULL,
                `votetime` INT(10) UNSIGNED NOT NULL,
                PRIMARY KEY (`id`),
                KEY (`feed_id`),
                KEY (`votetime`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Coordell_VoteFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Coordell_VoteFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    // var string �ơ��֥�ե������ֹ�ե����ޥå�
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        if (empty($hint)) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾�˥ե�������ɲ�
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['event_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
