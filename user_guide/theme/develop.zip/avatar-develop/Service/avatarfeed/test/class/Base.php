<?php

abstract class Gree_Service_AvatarFeed_Test_Base
    extends PHPUnit_Framework_TestCase
{
    var $enable_user_list = array(
        519883,
        544540,
        519887,
        2018709,
        518598,
        518659,
        519011,
        519980,
        //544421,
        526448,
        542186,
        522657,
        522912,
        526262,
        513692,
        544251,
        542989,
        527781,
        526317, // moritani
        542184, // kasuga
        522467, // kuramata
        546492,
        548805,
    );

    var $test_user_list = array(
        UNIT_TEST_USER_ID_1,
        UNIT_TEST_USER_ID_2,
        UNIT_TEST_USER_ID_3,
        UNIT_TEST_USER_ID_4,
        UNIT_TEST_USER_ID_5,
    );


    public function initialize_following_status($user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = UNIT_TEST_USER_ID_1;
        }
        try {
            $this->module_follow->updateFollowCount($user_id);
            list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
                $user_id,
                100,
                0
            );

            foreach ($following_user_ids as $following_user_id) {
                $this->module_follow->removeFollowingUser($following_user_id['content']['sender_id'], $user_id);
                $this->module_follow->removeFollowingUser($user_id, $following_user_id['content']['sender_id']);
                $this->module_follow->removeFollowedUser($user_id, $following_user_id['content']['sender_id']);
                $this->module_follow->removeFollowedUser($following_user_id['content']['sender_id'], $user_id);
            }
        } catch (Exception $e) {
        }
    }

    public function initialize_followed_status($user_id = null)
    {
        if (is_null($user_id)) {
            $user_id = UNIT_TEST_USER_ID_1;
        }
        try {
            $this->module_follow->updateFollowCount($user_id);
            list($has_more, $followed_user_ids) = $this->module_follow->getFollowedListOrderInTime(
                $user_id,
                100,
                0
            );

            foreach ($followed_user_ids as $following_user_id) {
                $this->module_follow->removeFollowingUser($following_user_id['content']['sender_id'], $user_id);
                $this->module_follow->removeFollowingUser($user_id, $following_user_id['content']['sender_id']);
                $this->module_follow->removeFollowedUser($user_id, $following_user_id['content']['sender_id']);
                $this->module_follow->removeFollowedUser($following_user_id['content']['sender_id'], $user_id);
            }
        } catch (Exception $e) {
        }
    }

    public function initialize_all_test_user_follow_status()
    {
        foreach($this->test_user_list as $test_user_id){
            $this->initialize_following_status($test_user_id);
            $this->initialize_followed_status($test_user_id);
        }
    }

    public function initialize_block_status()
    {
        try {
            list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
                UNIT_TEST_USER_ID_1,
                100,
                0
            );

            foreach ($block_user_ids as $block_user_id) {
                $this->module_block->removeBlockUser($block_user_id['content']['sender_id'], UNIT_TEST_USER_ID_1);
                $this->module_block->removeBlockUser(UNIT_TEST_USER_ID_1, $block_user_id['content']['sender_id']);
            }

        } catch (Exception $e) {
        }
    }

    public function initialize_like_status($user_id = UNIT_TEST_USER_ID_1)
    {
        try {
            $get_params = array(
                'user_id'  => $user_id,
                'limit'    => 100,
                'start_id' => null
            );
            list($has_more, $like_data) = $this->module->getLikeTimeLine($get_params);

            foreach ($like_data as $entry) {
                $delete_params = array(
                    'entry_id' => $entry['parent']['body']['entry_id']
                );
                $this->module->removeLike($delete_params);
            }
        } catch (Exception $e) {
        }

        list($has_more_false, $like_data_empty) = $this->module->getLikeTimeLine($get_params);

        $this->assertFalse($has_more_false);
        $this->assertEmpty($like_data_empty);
    }

    public function initialize_setting_info_of_like()
    {
        $start_date_time = date("Y-m-d H:i:s", mktime(date('H') - 1));
        $end_date_time   = date("Y-m-d H:i:s", mktime(date('H') + 1));

        $like_save_params = array(
            'action_type'                 => 'like',
            'start_date_time'             => $start_date_time,
            'end_date_time'               => $end_date_time,
            'point_per_action'            => 10,
            'daily_limit_of_point'        => 50,
            'limit_of_point_to_same_user' => 3,
        );
        $this->module_setting->saveSettingInfoOfIncentive($like_save_params);

    }

    public function initialize_point_and_history($user_id)
    {
        $srv_shop            = getService('shop');
        $this->point_manager = $srv_shop->getPointManager();

        try {
            $this->point_manager->resetPointAndHistory($user_id, date('Ymd'));
        } catch (Exception $e) {
        }

    }

    public function initialize_feed($category = GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY, $user_id = UNIT_TEST_USER_ID_1)
    {
        $this->module_appfeed->setUserIDtoCtfy($user_id);
        try {
            $this->module_appfeed->deleteFeed($category);
        } catch (Exception $e) {
        }

        try {
            $this->module_appfeed->createFeed($category);
        } catch (Exception $e) {
        }

        $this->module_appfeed->setUserIDtoCtfy(null);
    }

    public function initialize_feed_all_test_user()
    {
        foreach($this->test_user_list as $test_user_id){
            $this->initialize_feed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY, $test_user_id);
            $this->initialize_feed('user', $test_user_id);
        }
    }

    public function _createEntry($sender_id, $destination_user_id, $category = GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_incentive_add',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . $category . ':' . $destination_user_id
            )),
        );
        $this->module->setUserIDtoCtfy($sender_id);
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);
        $this->module->setUserIDtoCtfy(null);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }

    public function debug($value)
    {
        error_log(print_r($value, true));
    }
}