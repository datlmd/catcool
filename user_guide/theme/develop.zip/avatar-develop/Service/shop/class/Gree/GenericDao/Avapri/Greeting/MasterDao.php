<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Avapri/Greeting/MasterDao.php
 *
 * @package     GREE Avatar
 * @since       2018-06-04
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_Avapri_Greeting_MasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'greeting_master';

    /** @var primary key */
    var $_primary_key = 'book_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';

    /** @var field names */
    var $_field_names = [
        'book_id',
        'name',
        'start_datetime',
        'end_datetime',
        'end_sending',
        'start_reciving',
        'start_present',
        'end_present',
        'avapri_view_end',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all_and_sort_desc' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY book_id DESC',
        ],
        'find_by_book_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE book_id = :book_id',
        ],
        // }}}

        // {{{ update queries
        'entry' => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (name, start_datetime, end_datetime, end_sending, start_reciving, start_present, end_present, avapri_view_end, ctime) VALUES (:name, :start_datetime, :end_datetime, :end_sending, :start_reciving, :start_present, :end_present, :avapri_view_end, NOW())',
            'return_last_insert_id' => true
        ],
        'update' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET name = :name, start_datetime = :start_datetime, end_datetime = :end_datetime, end_sending = :end_sending, start_reciving = :start_reciving, start_present = :start_present, end_present = :end_present, avapri_view_end = :avapri_view_end  WHERE book_id = :book_id',
        ],
        // }}}

        // {{{
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `book_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `name` VARCHAR(255) NOT NULL DEFAULT '',
                    `start_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `end_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `end_sending` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `start_reciving` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `start_present` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                    `end_present` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                    `avapri_view_end` DATETIME NOT NULL default '0000-00-00 00\:00\:00',
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`book_id`)
            ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=ujis;"
        ],
        // }}}
    ];
}
