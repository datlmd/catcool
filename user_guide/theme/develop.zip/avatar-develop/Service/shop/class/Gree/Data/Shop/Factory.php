<?php
/**
 * Service/shop/class/Gree/Data/Factory.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
require_once sprintf('%s/Abstract.php', dirname(__FILE__));
require_once sprintf('%s/Abstract/Record.php', dirname(__FILE__));
require_once sprintf('%s/Abstract/Record/Singleton.php', dirname(__FILE__));

/**
 * Gree_Service_Shop_Data_Factory
 *
 * @package GREE
 * @access  public
 */
abstract class Gree_Service_Shop_Data_Factory
{
    // {{{ $_instances
    private static $_instances = array();
    // }}}

    // {{{ getData
    /**
     * get instance of data object by key
     * - data name ex) Gacha_Master_Attr
     *
     * @access  public
     * @static
     * @param   string  $data_name      php < 5.3で遅延静的束縛ができないのでしかたなく
     * @param   mixed   $key            the key
     * @param   array   $hint           the farm hint
     * @return  mixed   the instance
     */
    public static function getData($data_name, $key, $hint = null)
    {
        self::_requireClassFileByDataName($data_name);

        $class_name = self::_getClassNameByDataName($data_name);
        $callback   = array($class_name, 'getInstance');
        $params     = array($class_name, $key, $hint);
        $instance   = call_user_func_array($callback, $params);

        return $instance;
    }
    // }}}
    // {{{ getDataList
    /**
     * get instances of data object by keys
     * - data name ex) Gacha_Master_Attr
     *
     * @param   string  $data_name
     * @param   array   $key_list
     * @param   hint    $hint
     * @return  array   the instance list
     */
    public static function getDataList($data_name, $key_list, $hint = null)
    {
        self::_requireClassFileByDataName($data_name);

        $class_name = self::_getClassNameByDataName($data_name);
        $callback   = array($class_name, 'getInstances');
        $params     = array($class_name, $key_list, $hint);
        $instances  = call_user_func_array($callback, $params);

        return $instances;
    }
    // }}}
    // {{{ instantiate
    /**
     * instantiate data object by record
     * - data name ex) Gacha_Master_Attr
     *
     * @access  public
     * @static
     * @param   string  $data_name
     * @param   array   $record
     */
    public static function instantiate($data_name, $record)
    {
        self::_requireClassFileByDataName($data_name);

        $class_name = self::_getClassNameByDataName($data_name);
        $callback   = array($class_name, 'instantiate');
        $params     = array($class_name, $record);
        $instance   = call_user_func_array($callback, $params);

        return $instance;
    }
    // }}}
    // {{{ instantiateList
    /**
     * instantiate data object by records
     * - data name ex) Gacha_Master_Attr
     *
     * @access  public
     * @param   string  $data_name
     * @param   array   $records
     * @return  array   the object list
     */
    public static function instantiateList($data_name, $records)
    {
        self::_requireClassFileByDataName($data_name);

        $class_name = self::_getClassNameByDataName($data_name);
        $callback   = array($class_name, 'instantiateList');
        $params     = array($class_name, $records);
        $instances  = call_user_func_array($callback, $params);

        return $instances;
    }
    // }}}
    // {{{ _getOrRegisterInstance
    /**
     * get instance after registeration
     *
     * @access  protected
     * @param   object  $instance
     * @return  bool    if register instance
     */
    protected static function _getOrRegisterInstance($instance)
    {
        $class_name     = get_class($instance);
        $key            = $instance->getKey();
        $instance_key   = self::_generateInstanceKey($key);
        if (!isset(self::$_instances[$class_name][$instance_key])) {
            self::$_instances[$class_name][$instance_key] = $instance;
        }

        return self::$_instances[$class_name][$instance_key] = $instance;
    }
    // }}}

    // {{{ _generateInstanceKey
    /**
     * generate instance key
     *
     * @access  protected
     * @static
     * @param   mixed   $key
     * @return  string  the instance key
     */
    protected static function _generateInstanceKey($key)
    {
        if (!is_array($key)) {
            return $key;
        }

        ksort($key);

        return implode('__', $key);
    }
    // }}}
    // {{{ _getClassNameByDataName
    /**
     * get class name by data name
     *
     * @access  protected
     * @param   string  $data_name
     * @return  string  the class name
     */
    protected static function _getClassNameByDataName($data_name)
    {
        return sprintf('Gree_Service_Shop_Data_%s', $data_name);
    }
    // }}}
    // {{{ _requireClassFileByDataName
    /**
     * require once class file by data name
     *
     * @access  protected
     * @param   string  $data_name
     */
    protected static function _requireClassFileByDataName($data_name)
    {
        $relative_path  = str_replace('_', '/', $data_name);
        $absolutee_path = sprintf('%s/%s.php', dirname(__FILE__), $relative_path);

        require_once($absolutee_path);
    }
    // }}}
}
