<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/EventMission/EventMasterAttrDao.php
 * @package     GREE Avatar
 * @since       2018-10-16
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * EventMasterAttr form constructor
 * @access      public
 */
class Gree_GenericDao_EventMission_EventMasterAttrDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'mission_event_master_attr';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'master_id',
        'name',
        'value',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_id'                   => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'find_by_master_id'            => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_id = :master_id',
        ],
        // }}}

        // {{{ update queries
        'entry'                        => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (master_id, name, value, ctime) VALUES (:master_id, :name, :value, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'                       => [
            'sql' => 'UPDATE __TABLE_NAME__ SET master_id = :master_id, name = :name, value = :value WHERE id = :id',
        ],
        'delete_by_master_id_and_name' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE master_id = :master_id AND name = :name',
        ],
        // }}}

        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `master_id` INT UNSIGNED NOT NULL,
                    `name` VARCHAR(255) NOT NULL,
                    `value` VARCHAR(255) NOT NULL,
                    `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `name` (`master_id`,`name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
    ];
}
