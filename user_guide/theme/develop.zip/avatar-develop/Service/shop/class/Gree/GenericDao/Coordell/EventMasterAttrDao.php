<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Coordell/EventMasterAttrDao.php
 *
 * @author      Thien Nguyen <z.thanhthien.nguyen@gree.net>
 * @package     GREE Avatar
 * @since       2016-05-17
 */


/**
 * EventMasterAttr form constructor
 * @access      public
 */
class Gree_GenericDao_Coordell_EventMasterAttrDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'coordell_event_master_attr';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_coordell';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_coordell';

    /** @var field names */
    var $_field_names = array(
        'id',
        'event_id',
        'name',
        'value',
        'mtime',
        'ctime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ),
        'find_by_id_and_name'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id = :event_id AND  name = :name',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (event_id, name, value, ctime) VALUES (:event_id, :name, :value, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET  value = :value WHERE event_id = :event_id AND name = :name',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ),
        'delete_by_id_and_name'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE event_id = :event_id AND  name = :name',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                  `event_id` INT(10) UNSIGNED NOT NULL,
                  `name` VARCHAR(255) NOT NULL,
                  `value` VARCHAR(5000) NOT NULL,
                  `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `event_id` (`event_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
