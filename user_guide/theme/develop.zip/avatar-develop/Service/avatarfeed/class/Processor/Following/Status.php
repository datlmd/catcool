<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Following
 */
class Gree_Service_AvatarFeed_Processor_Following_Status
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return
     *   is_following
     */
    protected function invoke()
    {

        $mod_follow = self::getModule('Follow');

        $following_date = null;
        try {
            $following_date =  $mod_follow->getFollowingDate($this->input_values['target_user_id'], $this->input_values['user_id']);
        } catch (Exception $e) {
            $msg     = 'failed get follow status.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return $following_date;
    }
}
