<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/NpcBattleResultDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-18
 */

/**
 * BattleResult form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_NpcBattleResultDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'npc_battle_result';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'enemy_id',
        'user_item_ids',
        'enemy_item_ids',
        'stage',
        'is_win',
        'status',
        'values',
        'next_url',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id_and_user_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id AND user_id = :user_id',
        ),
        'count_win_by_user_and_stage'                 => array(
            'sql' => 'SELECT count(is_win) as total FROM __TABLE_NAME__ WHERE user_id = :user_id AND stage = :stage AND is_win = 1',
        ),
        'count_win_by_user'                 => array(
            'sql' => 'SELECT count(is_win) as total FROM __TABLE_NAME__ WHERE user_id = :user_id AND is_win = 1',
        ),
        'get_enemy_id_by_user_id' => array(
            'sql' => 'SELECT enemy_id  FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, enemy_id, user_item_ids, enemy_item_ids, stage, is_win, `status`, `values`, next_url, ctime) VALUES (:user_id, :enemy_id, :user_item_ids, :enemy_item_ids, :stage, :is_win, :status, :values, :next_url, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET user_id = :user_id, enemy_id = :enemy_id, user_item_ids = :user_item_ids, enemy_item_ids = :enemy_item_ids, is_win = :is_win WHERE id = :id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ), 
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`           INT(11) UNSIGNED NOT NULL,
                    `enemy_id`          INT(11) UNSIGNED DEFAULT NULL,
                    `user_item_ids`     VARCHAR(255) NOT NULL DEFAULT '',
                    `enemy_item_ids`    VARCHAR(255) NOT NULL DEFAULT '',
                    `stage`             TINYINT(4) UNSIGNED NOT NULL,
                    `is_win`            TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
                    `status`            TEXT NOT NULL,
                    `values`            TEXT NOT NULL,
                    `next_url`          VARCHAR(255) NOT NULL,
                    `mtime`             TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             DATETIME  NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        'edit_column' => array(
            'sql' => '
                ALTER TABLE __TABLE_NAME__ 
                ADD COLUMN `status` text NOT NULL,
                ADD COLUMN `values` text NOT NULL,
                ADD COLUMN `next_url` varchar(255) NOT NULL'
        ),
        // }}}
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Osacolo_NpcBattleResultFarmSelector();
    }
}

class Gree_GenericDao_Osacolo_NpcBattleResultFarmSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%02d_%02d"; //[osacolo_id]_[user_id]

    function getTableName($dao, $type, $hint)
    {
        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = 2;
        } else {
            $table_nums = 100;
        }

        if (empty($hint) || !isset($hint['osacolo_id']) || !isset($hint['user_id'])) {
            return PEAR::raiseError("hint is empty osacolo_id or user_id. dao=" . get_class($dao) . "];");
        }

        $farm_no      = (int)($hint['user_id'] % $table_nums);
        $table_suffix = sprintf($this->_table_suffix_format, $hint['osacolo_id'], $farm_no);
        $table_name   = $dao->_getTableName() . $table_suffix;

        return $table_name;
    }
}