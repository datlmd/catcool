<?php

/**
 * AvaMee�����θĿ��������֤�
 * �桼���������������ʤ�����stream_show�Ǥμ�������®
 */
class Gree_Service_AvatarFeed_Processor_Stream_Notification_Count
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $service_shop = getService('shop');
        $mod_appfeed  = self::getModule('AppFeed');

        $user_id  = $this->input_values['user_id'];
        $category = GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION;
        $limit    = 101;
        $start_id = null;

        try {
            list($has_more, $entries) = $mod_appfeed->getEntriesByFeedKey(
                    $user_id,
                    $category,
                    $limit,
                    $start_id
            );
        } catch (Exception $e) {
            if ($e->getCode() == Gree_Service_AvatarFeed_Exception::E_APINET_DATA_NOT_FOUND
                && $user_id == $this->_certified_user->my['user_id']
            ) {
                try {
                    $mod_appfeed->createFeed($category);
                } catch (Exception $e) {
                    $msg     = 'failed get feed and create feed.';
                    $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_STREAM;
                    $context = $this->input_values;

                    new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
                }
            }

            $msg     = 'failed get feed.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_STREAM;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return 0;
        }

        if (count($entries) == 0) {
            return 0;
        }

        $today = $service_shop->getDate('Y-m-d');
        foreach ($entries as $index => $entry) {
            if (!isset($entry['content']['attr'])) {
                unset($entries[$index]);
                continue;
            }
            if ($entry['content']['attr']['entry_category'] == 'notification_incentive'
            && $entry['content']['attr']['notification_entry_id'] >= $today
            ) {
                unset($entries[$index]);
            }
        }

        return count($entries);
    }
}
