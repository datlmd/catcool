<?php

class Gree_Service_AvatarFeed_Processor_Follow_Import_Link
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $mod_user = self::getModule('User');

        try {
            $limit    = GREE_SERVICE_AVATARFEED_IMPORT_LINK_GET_LIMIT_PER_ONCE;
            $offset   = 0;
            $has_more = true;
            while ($has_more) {
                list($has_more, $link_list) = $mod_user->getLinkList($this->input_values['user_id'], $offset, $limit);

                if (empty($link_list)) {
                    return false;
                }

                if ($has_more) {
                    $offset = $offset + $limit;
                }
                foreach ($link_list as $user_id) {
                    $add_params = array(
                        'user_id'        => $user_id,
                        'certified_user' => $this->input_values['user_id'],
                        'is_async'       => true
                    );
                    Gree_Service_AvatarFeed_Processor::execute(
                        'following_add',
                        $add_params
                    );
                }
            }
        } catch (Exception $e) {
            $msg  = 'failed Import link user.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_LINK;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $this->input_values);

            return false;
        }

        return true;
    }
}