<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Crosspromo/IncentiveDao.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_Crosspromo_IncentiveDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'crosspromo_incentive';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'master_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_event_count';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var ��Ͽ�������̾ */
    var $_auto_increment = 'true';

    /** @var �ե������̾ */
    var $_field_names = array(
        'master_id',
        'campaign_ids',
        'incentive_id',
        'incentive_type',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'get_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY master_id DESC'
        ),
        'find_by_master_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_id = :master_id'
        ),
        // }}}
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `master_id` int(11) unsigned NOT NULL,
                `campaign_ids` VARCHAR(255)  NOT NULL DEFAULT '',
                `incentive_id` int(11) unsigned NOT NULL,
                `incentive_type` tinyint(2) unsigned NOT NULL,
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                 PRIMARY KEY (`master_id`)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis"
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__
                        (master_id, campaign_ids, incentive_id, incentive_type, ctime) 
                      VALUES
                        (:master_id, :campaign_ids, :incentive_id, :incentive_type, NOW())'
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ 
                      SET campaign_ids = :campaign_ids,
                          incentive_id = :incentive_id,
                          incentive_type = :incentive_type
                      WHERE 
                          master_id = :master_id'
        ),
        // {{{ �����
        'delete' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE master_id = :master_id'
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
