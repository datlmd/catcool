<?php

abstract class Gree_Service_AvatarFeed_Module
    extends Gree_Service_AvatarFeed_Object
{
    protected final function __construct()
    {
        parent::__construct();
    }

    public final static function singleton($name)
    {
        static $instances = array();

        return isset($instances[$name])
            ?       ($instances[$name])
            :       ($instances[$name] = self::factory($name));
    }

    protected final static function factory($name)
    {
        // detect module class name by given name
        static $base = __CLASS__;

        $class = $base . '_'
            . implode('_', array_map('ucfirst', explode('_', $name)));
        if (!class_exists($class)) {
            $message = 'Could not found class definition';
            $context = array('name' => $name, 'class' => $class);
            $code    = Gree_Service_AvatarFeed_Exception::E_NOT_FOUND_CLASS_DEF;
            throw new  Gree_Service_AvatarFeed_Exception($message, $code, $context);
        }
        // factory and verify instance
        $module = new $class;
        if (($module instanceof $base) === false) {
            $message = 'Does not match type of mould instance';
            $context = array('name' => $name, 'class' => $class);
            $code    = Gree_Service_AvatarFeed_Exception::E_INVALID_INSTANCE;
            throw new  Gree_Service_AvatarFeed_Exception($message, $code, $context);
        }

        return $module;
    }
}
