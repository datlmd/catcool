<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Crosspromo/MasterAttrDao.php
 *
 *  @author   Shingo Harada <shingo.harada@gree.co.jp>
 *  @package  GREE
 */
class Gree_GenericDao_Crosspromo_MasterAttrDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'crosspromo_master_attr';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_event_count';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'master_id',
        'name',
        'value',
        'mtime', 
        'ctime'
    );

	/** @var ������ */
	var $_queries = array(
        // {{{ ���ȷ�
        'find_master_attr_by_master_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_id = :master_id',
        ),
        'find_master_attr_by_master_id_and_name' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_id = :master_id AND name = :name',
        ),
        'delete_by_master_id_and_name' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE master_id = :master_id AND name = :name'
        ),
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` int(10) unsigned NOT NULL auto_increment,
                    `master_id` int(10) unsigned NOT NULL,
                    `name` varchar(255) NOT NULL,
                    `value` varchar(255) NOT NULL,
                    `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY  (`id`),
                    KEY `master_id` (`master_id`)
                ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=ujis
            ",
        ),
	);

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
