<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Gacha/Prize/MasterDao.php
 *
 * @package     GREE Avatar
 * @since       2018-06-04
 */


/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_Gacha_Prize_MasterDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'gacha_prize_master';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var field names */
    var $_field_names = [
        'id',
        'name',
        'start_date',
        'end_date',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all_and_sort_desc'           => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ],
        'find_by_id'                       => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        'find_by_ids'                     => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id IN (:ids)',
        ],
        // }}}

        // {{{ update queries
        'entry'                            => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (name, start_date, end_date, ctime) VALUES (:name, :start_date, :end_date, NOW())',
            'return_last_insert_id' => true
        ],
        'update'                           => [
            'sql' => 'UPDATE __TABLE_NAME__ SET name = :name, start_date = :start_date, end_date = :end_date WHERE id = :id',
        ],
        // }}}

        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `name` VARCHAR(255) NOT NULL DEFAULT '',
                  `start_date` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `end_date` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ],
        // }}}
    ];
}