<?php

class Gree_GenericDao_PushNotification_PermissionDao extends Gree_GenericDao
{
    var $_table_name        = 'push_notification_permission';

    var $_primary_key       = array(
        'user_id',
        'notification_type',
    );

    var $_auto_increment    = false;

    var $_created_at_column = 'ctime';

    var $_updated_at_column = 'mtime';

    var $_master_dsn        = 'gree://master/avatar_user';

    var $_slave_dsn         = 'gree://slave/avatar_user';

    var $_field_names       = array(
        'user_id',
        'notification_type',
        'permission_type',
        'ctime',
        'mtime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    user_id           INT(11)      UNSIGNED NOT NULL,
                    notification_type INT(3)       UNSIGNED NOT NULL,
                    permission_type   INT(3)       UNSIGNED NOT NULL,
                    ctime             DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    mtime             TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, notification_type)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),

        'update_permission' => array(
            'sql' => "
                INSERT INTO __TABLE_NAME__ (
                    user_id,
                    notification_type,
                    permission_type,
                    ctime
                )
                VALUES (
                    :user_id,
                    :notification_type,
                    :permission_type,
                    NOW()
                )
                ON DUPLICATE KEY UPDATE permission_type=:permission_type
            ",
        ),

        'find_by_user_id_and_notification_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND notification_type = :notification_type',
        ),

        'find_by_user_ids_and_notification_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id in (:user_ids) AND notification_type = :notification_type',
        ),
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_PushNotification_PermissionSelector();
    }
}

class Gree_GenericDao_PushNotification_PermissionSelector extends Gree_GenericDao_FarmSelector
{
    function getTableName($dao, $type, $hint)
    {
        if (empty($hint['notification_type'])) {
            $type = !isset($hint['notification_type']) ? 'missing' : 'empty';
            return PEAR::raiseError("farm hint notification_type is $type. hint=[" . var_export($hint, true) . "];");
        }

        $id = $hint['notification_type'];

        // テーブル名の取得
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }
        $table_name = sprintf("%s_%d", $original_table_name, $id);

        return $table_name;
    }
}
