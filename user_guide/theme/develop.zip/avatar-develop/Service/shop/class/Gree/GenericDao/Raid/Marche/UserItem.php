<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserItem.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Raid_Marche_UserItemDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'raid_marche_user_item';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_raid';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_raid';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array( 'id', 'user_id', 'item_id', 'life_item_id', 'num', 'mtime', 'ctime');

    /** @var ������ */
    var $_queries = array(
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id ORDER BY item_id ASC',
        ),
        'find_by_user_id_and_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id and item_id=:item_id',
        ),
        'find_by_user_id_and_multi_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND item_id IN (:item_id)',
        ),
        // {{{ �������������������
        'insert' => array(                // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, item_id, life_item_id, num, ctime) VALUES(:user_id, :item_id, :life_item_id, :num, NOW())',
        ),
        'update_by_user_id_and_item_id' => array(               // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET num=:num WHERE user_id=:user_id And item_id=:item_id',
        ),
        // }}}
        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                int(11) unsigned NOT NULL auto_increment,
                    `user_id`           int(11) unsigned NOT NULL default '0',
                    `item_id`           int(11) unsigned NOT NULL default '0',
                    `life_item_id`      int(11) unsigned NOT NULL default '0',
                    `num`               int(11) unsigned NOT NULL default '1',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    UNIQUE `user_id` (`user_id`, `item_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'truncate_table' => array(      // for batch
            'sql' => "TRUNCATE TABLE __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Raid_Marche_UserItemSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/UserItem.php
 *
 *  @author   katsumi.zeniya
 *  @package  GREE
 */
class Gree_GenericDao_Raid_Marche_UserItemSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ TABLE_DIVIDE_NUM
    /* �ơ��֥�ʬ��� */
    const TABLE_DIVIDE_NUM = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%d";   // event_id, user_id
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['event_id']) || !isset($hint['user_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, $hint['event_id'], ($hint['user_id'] % self::TABLE_DIVIDE_NUM));

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
