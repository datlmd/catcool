<?php
/**
 * Gree_GenericDao_Shop_Mypage_WatchScoreDao
 *
 * ������֤Υ����å����ʥ����å����ˤ򥹥�����󥰤��뵡ǽ
 *   ���ݾ��ߡ����٥�Ȥʤɤ˻���
 *   ���������������avatar_mypage_info.php�˵���
 *   ��2015/04/07 avatar_mypage_info.php ���
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Mypage_WatchScoreDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'watch_score';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',          // �桼����ID
        'score',            // ���̿�
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}

        // {{{ update queries
        'increment' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, score, ctime)
                VALUES
                    (:user_id, 1, NOW())
                ON DUPLICATE KEY UPDATE score = score + 1
            ',
        ),
        'update' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, score, ctime)
                VALUES
                    (:user_id, :score, NOW())
                ON DUPLICATE KEY UPDATE score = :score
            ',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `score`               INT(10)     UNSIGNED NOT NULL,
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`user_id`),
                  KEY `score` (`score`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;
            ',
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Shop_Mypage_WatchScoreSelector();
    }
    // }}}
}

/**
 * Gree_GenericDao_Shop_Mypage_WatchScoreSelector
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Mypage_WatchScoreSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // hint�μ���
        if (empty($hint['term_id'])) {
            throw new Gree_Service_Shop_Exception_ServiceException('farm hint term_id is empty. hint=[' . var_export($hint, true) . '];');
        }
        $term_id = $hint['term_id'];

        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            throw new Gree_Service_Shop_Exception_ServiceException('original table name is empty. dao=' . get_class($dao) . '];');
        }

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = sprintf("%s_%d", $original_table_name, $term_id);
        return $table_name;
    }
    // }}}
}
