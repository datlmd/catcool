<?php

require_once "/home/gree/xgree/avatar/Service/avatarfeed/service.php";
require_once "/home/gree/xgree/avatar/Service/avatarfeed/class/Logger.php";

class Gree_Service_Shop_Async_Avatarfeed
{
    var $avatar_feed;

    public function __construct()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();
    }

    function handleAddDestination($parameter)
    {
        try {
            $this->avatar_feed->process('entry_destination_add', $parameter);
        } catch(Exception $e){
            $msg     = 'failed add destination.';
            $code    =  Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_DESTINATION_ADD;
            $context = $parameter;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }
    }

    function handleImportLinkUser($parameter)
    {
        $this->avatar_feed->process('follow_import_link', $parameter);
    }

    function handleImportCheckUser($parameter)
    {
        $this->avatar_feed->process('follow_import_check', $parameter);
    }

    function handleaddCommentRelationCreate($parameter)
    {
        $this->avatar_feed->process('comment_relation_create', $parameter);
    }

    function handleImportRecommendUser($parameter)
    {
        $this->avatar_feed->process('follow_import_recommend', $parameter);
    }

    function handleIncrementScore($parameter)
    {
        $this->avatar_feed->process('score_increment', $parameter);
    }
}
