<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Gree_GenericDao_Shop_Mypage_WatchDao
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Mypage_WatchDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'avatar_mypage_watch';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'watch_user_id',        // �����å��оݥ桼����ID
        'status',               // ͭ���ե饰
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_watch' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND watch_user_id = :watch_user_id',
        ),
        'find_by_user' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND status = :status ORDER BY ctime DESC',
        ),
        'find_by_user_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND watch_user_id IN (:watch_user_id) AND status = :status',
        ),
        'get_watch_count' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM __TABLE_NAME__ WHERE user_id = :user_id AND status = :status',
        ),
        'get_watch_count_by_ctime' => array(
            'sql' => 'SELECT COUNT(*) AS cnt FROM __TABLE_NAME__ WHERE user_id = :user_id AND ctime < :ctime',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, watch_user_id, status, ctime)
                VALUES
                    (:user_id, :watch_user_id, :status, NOW())
                ON DUPLICATE KEY UPDATE status = :status
            ',
        ),
        'update_status' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = :status WHERE user_id = :user_id AND watch_user_id = :watch_user_id',
        ),
        // {{{ debug
        'reset_user_info' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id`                  INT(10)     UNSIGNED NOT NULL AUTO_INCREMENT,
                  `user_id`             INT(10)     UNSIGNED NOT NULL,
                  `watch_user_id`       INT(10)     UNSIGNED NOT NULL,
                  `status`              TINYINT(3)  UNSIGNED NOT NULL,
                  `ctime`               DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `user_id` (`user_id`, `watch_user_id`),
                  KEY `watch` (`user_id`, `status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserFarmSelector();
    }
}
