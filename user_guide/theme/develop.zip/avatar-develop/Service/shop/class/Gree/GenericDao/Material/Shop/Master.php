<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Material_Shop_MasterDao extends Gree_GenericDao_Apc
{
    var $_table_name = 'material_shop_master';

    var $_primary_key = 'stock_id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_studio';

    var $_slave_dsn = 'gree://slave/avatar_studio';

    var $_auto_increment = true;

    var $_field_names = array(
        'stock_id',
        'bundle_id',
        'type',
        'status',
        'priority',
        'price',
        'point',
        'c_count',
        'p_count',
        'start_time',
        'end_time',
        'mtime',
        'ctime',
    );

    var $_queries = array(

        //Refer query
        'all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY stock_id',
        ),

        'find_by_stock_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE stock_id=:stock_id',
        ),

        'find_by_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status=:status ORDER BY stock_id DESC',
        ),

        'find_by_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE type=:type ORDER BY type DESC',
        ),

        'find_by_status_and_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status=:status AND type=:type ORDER BY stock_id DESC',
        ),

        'find_by_stock_ids_and_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE stock_id IN (:stock_ids) AND status=:status ORDER BY stock_id DESC',
        ),

        //Update
        'update_all' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET
            bundle_id  = :bundle_id,
            type       = :type,
            status     = :status,
            priority   = :priority,
            price      = :price,
            point      = :point,
            start_time = :start_time,
            end_time   = :end_time,
            c_count    = :c_count,
            p_count    = :p_count,
            end_time   = :end_time,
            status     = :status
            WHERE stock_id = :stock_id',
        ),

        //Insert
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (
                    bundle_id,
                    type,
                    priority,
                    price,
                    point,
                    c_count,
                    p_count,
                    ctime
                ) VALUES(
                    :bundle_id,
                    :type,
                    :priority,
                    :price,
                    :point,
                    :c_count,
                    :p_count,
                    NOW()
                )',
            'return_last_insert_stock_id' => true,
        ),


        //Create table
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `stock_id`     INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                `bundle_id`    INT(11) UNSIGNED NOT NULL,
                `type`         TINYINT(2) UNSIGNED NOT NULL DEFAULT 0,
                `status`       TINYINT(2) UNSIGNED NOT NULL DEFAULT 0,
                `priority`     TINYINT(2) UNSIGNED NOT NULL DEFAULT 0,
                `price`        INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `point`        INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `c_count`      INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `p_count`      INT(10) UNSIGNED NOT NULL DEFAULT 0,
                `start_time`   DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_time`     DATETIME DEFAULT NULL,
                `mtime`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime`        DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`stock_id`),
                KEY `bundle_id` (`bundle_id`),
                KEY `type` (`type`),
                KEY `status` (`status`),
                KEY `priority` (`priority`),
                KEY `status_and_type` (`status`, `type`)
            ) ENGINE=INNODB DEFAULT CHARSET=ujis",
        ),
    );

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
