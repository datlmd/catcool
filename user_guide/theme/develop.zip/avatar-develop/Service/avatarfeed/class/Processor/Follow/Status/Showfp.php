<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Follow_Status_Show
 */
class Gree_Service_AvatarFeed_Processor_Follow_Status_Showfp
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return
     *   is_following
     *   is_followed
     *   following_count
     *   followed_count
     */
    protected function invoke()
    {
        $is_following    = false;
        $is_followed     = false;
        $following_count = 0;
        $followed_count  = 0;

        $mod_follow = self::getModule('Follow');

        try {
            list($following_count, $followed_count) = $mod_follow->getFollowCount($this->input_values['send_user_id']);
            $is_following = $mod_follow->getFollowingUser($this->input_values['send_user_id'], $this->input_values['user_id']);
            $is_followed  = $mod_follow->getFollowedUser($this->input_values['send_user_id'], $this->input_values['user_id']);
        } catch (Exception $e) {
            $msg     = 'failed get follow status.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $is_following,
            $is_followed,
            $following_count,
            $followed_count
        );
    }
}
