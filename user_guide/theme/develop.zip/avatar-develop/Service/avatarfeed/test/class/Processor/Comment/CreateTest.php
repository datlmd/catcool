<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Comment_CreateTest
 *
 * this test is comment create
 */
final class Gree_Service_Avatarfeed_Test_Processor_Comment_CreateTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
    }

    /**
     * test1: success create comment
     * expect: is_create == true, comment_id == string
     *
     * text2: failed create, entry_id is not specified
     * expect: is_create == false, comment_id == null
     */
    public function test_create_comment()
    {
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_success_create_entry);

        // test1
        $text_1                = 'test1 create comment';
        $success_create_params = array(
            'text'              => $text_1,
            'entry_id'          => $entry_id,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $success_create_params);
        $this->assertTrue($is_create_comment);
        $this->assertFalse(is_null($comment_id));

        // test2
        $text_2               = 'test2 create comment';
        $failed_create_params = array(
            'text' => $text_2,
            'user_id'           => UNIT_TEST_OFFICIAL_THEME_USER_ID_1, //for td
            'commented_user_id' => UNIT_TEST_OFFICIAL_THEME_USER_ID_1 //for td
        );
        list($is_create_comment, $comment_id) = $this->avatar_feed->process('comment_create', $failed_create_params);
        $this->assertFalse($is_create_comment);
        $this->assertTrue(is_null($comment_id));
    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content'      => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_stream_show',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}