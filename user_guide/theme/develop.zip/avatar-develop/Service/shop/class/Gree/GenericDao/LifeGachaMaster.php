<?php
/**
 *  /home/gree/service/shop/class/GenericDao/LifeGachaMaster.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: LifeGachaMaster.php 143605 2012-02-01 02:56:22Z takashi-taniguchi $
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_LifeGachaMasterDao extends Gree_GenericDao_Apc
{
    /** @var �ơ��֥�̾ */
    var $_table_name = 'life_gacha_master';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'gacha_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/shop';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/shop';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

    /** @var �ե������̾ */
    var $_field_names = array(
        'gacha_id',
        'type_id',
        'name',
        'tpl_type',
        'gold',
        'first_free_flag',
        'rare_ratio',
        'image_url',
        'shoulder_text',
        'user_sex',
        'gacha_method',
        'start_time',
        'end_time',
        'mtime',
        'ctime',
    );

    /** @var ������ */
    var $_queries = array(
        'find_by_gacha_id' => array(
            'sql' => 'SELECT * FROM life_gacha_master WHERE gacha_id = :gacha_id'
        ),
        'find_by_gacha_ids' => array(
            'sql' => 'SELECT * FROM life_gacha_master WHERE gacha_id IN (:gacha_ids)',
            'disable_apc' => true,
        ),
        'find_by_type_id'  => array(
            'sql' => 'SELECT * FROM life_gacha_master WHERE type_id = :type_id'
        ),
        'find_by_end_time'  => array(
            'sql' => 'SELECT * FROM life_gacha_master WHERE end_time >= :end_time ORDER BY gacha_id DESC'
        ),
        'find_by_end_time_for_term'  => array(
            'sql' => 'SELECT * FROM life_gacha_master WHERE end_time <= :end_time AND end_time >= :start_time ORDER BY gacha_id DESC'
        ),
        'find_by_start_time_for_term'  => array(
            'sql' => 'SELECT * FROM life_gacha_master WHERE start_time <= :end_time AND start_time >= :start_time ORDER BY gacha_id DESC'
        ),
        'find_by_date'  => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE :start_time <= end_time AND start_time <= :end_time'
        ),
        'find_all' => array(
            'sql' => 'SELECT * FROM life_gacha_master order by gacha_id desc limit 20'
        ),
        'all' => array(
            'sql' => 'SELECT * FROM life_gacha_master order by gacha_id desc'
        ),
        'find_by_date_and_sort_gacha_id_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE  :start_time <= start_time AND start_time <= :end_time ORDER BY gacha_id desc'
        ),
        'max_gacha_id' => array(
            'sql' => 'SELECT MAX(gacha_id) FROM life_gacha_master'
        ),
        'find_type_id_by_gacha_id' => array(
            'sql' => 'SELECT type_id FROM life_gacha_master WHERE gacha_id = :gacha_id'
        ),
        'update_method_by_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET gacha_method = :gacha_method WHERE gacha_id = :gacha_id',
        ),
        /* for support tool */
        'search_gacha_name' => array(
            'sql' => 'SELECT * FROM life_gacha_master where name like :name',
            'disable_apc' => true,
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
// vim: sts=4 sw=4 ts=4 fdm=marker
