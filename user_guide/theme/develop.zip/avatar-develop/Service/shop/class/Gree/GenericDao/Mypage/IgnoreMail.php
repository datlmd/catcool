<?php
/**
 * Gree_GenericDao_Shop_Mypage_IgnoreMailDao
 *
 * @author  Takashi Taniguchi <takashi.taniguchi@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Mypage_IgnoreMailDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'avatar_ignore_mail';

    /** @var primary key */
    var $_primary_key       = 'user_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = array(
        'user_id',
        'status',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'get_status' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_ignore_list' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = 1',
        ),
        'find_ignore_list_userid' => array(
            'sql' => 'SELECT user_id FROM __TABLE_NAME__ WHERE status = 1',
        ),
        // }}}

        // {{{ update queries
        'on_status' => array(
            'sql' => '
                INSERT IGNORE INTO __TABLE_NAME__
                    (user_id, status, ctime)
                VALUES
                    (:user_id, 1, NOW())
                ON DUPLICATE KEY UPDATE status = 1
            ',
        ),
        'off_status' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET status = 0 WHERE user_id = :user_id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`     INT(10)     UNSIGNED NOT NULL,
                  `status`      TINYINT(3)  UNSIGNED NOT NULL,
                  `ctime`       DATETIME    NOT NULL DEFAULT "00-00-00 00\:00\:00",
                  `mtime`       TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`user_id`),
                  KEY `status` (`status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        // }}}
    );
}
