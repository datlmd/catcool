<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Follow_Mutual_List_Show
 *
 * #####
 * How to use:
 * $get_params = array(
 *     'user_id' => 550834,
 *     'limit'   => 10,
 *     'offset'  => 0
 * );
 * $avatar_feed = Gree_Service_AvatarFeed::getInstance()
 * $avatar_feed->process('follow_mutual_list_show', $get_params);
 * ######
 *
 * @author     Thien Nguyen <z.thanhthien.nguyen@gree.co.jp>
 * @package    GREE
 */
class Gree_Service_AvatarFeed_Processor_Follow_Mutual_List_Show extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * Gree_Service_AvatarFeed::getInstance()
     *
     * @param
     *
     * @return array
     * Example: Array(
     *      [0] => true,
     *      [1] => array(
     *          [0] => array(
     *              'content' => array(
     *                  'sender_id' => 123,
     *              ),
     *          )
     *          [1] => array()
     *      )
     * );
     */
    protected function invoke()
    {
        $has_more        = false;
        $total           = false;
        $mutual_user_ids = null;

        $mod_follow = self::getModule('Follow');

        try {
            list($has_more, $total, $mutual_user_ids) = $mod_follow->getFollowMutualListByUserId($this->input_values['user_id'], $this->input_values['limit'], $this->input_values['offset']);
        } catch (Exception $e) {
            $msg     = 'failed get follow mutual.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        return array(
            $has_more,
            $total,
            $mutual_user_ids
        );
    }
}