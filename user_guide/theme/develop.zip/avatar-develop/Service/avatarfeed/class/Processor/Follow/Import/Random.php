<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Follow_Import_Random
 */
class Gree_Service_AvatarFeed_Processor_Follow_Import_Random
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array|void
     *
     * return $import_result = array(
     *            'success_import' => array(
     *                array(
     *                   'user_id'   => int
     *                   'entry_id'  => string
     *                ),
     *            ),
     *            'miss_hit'       => int
     *         );
     *
     * folow is
     *   get Entries from official user limit 100 offset 0
     *   get random value from 0 to 99
     *   get import user
     *     - count($check_users) < GREE_SERVICE_AVATARFEED_RANDOM_CHECK_USER_NUMBER
     *     - random_user_id = $stream_data[$index]['content']['sender_id']
     *     - if ($miss_hit >= 50) then throw Exception
     *   following add import user
     *   add Destination import user entry
     */
    protected function invoke()
    {
        $import_result = array(
            'success_import' => array(),
            'miss_hit'       => 0
        );

        $mod_user    = self::getModule('User');
        $mod_appfeed = self::getModule('Appfeed');
        $mod_follow  = self::getModule('Follow');

        try {
            list($has_more, $stream_data) = $mod_appfeed->getEntriesByFeedKey(
                GREE_SERVICE_AVATARFEED_RECENT_COORDINATE_FEED_USER_ID,
                GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
                300,
                null,
                'batch'
            );

            $check_users = array();
            $miss_hit    = 0;
            while (count($check_users) < GREE_SERVICE_AVATARFEED_RANDOM_CHECK_USER_NUMBER) {
                $index = mt_rand(0, 299);

                if (isset($stream_data[$index])) {
                    $random_user_id = $stream_data[$index]['content']['sender_id'];
                } else {
                    $msg  = 'failed find index on stream data. index is ' . $index;
                    $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_RANDOM;
                    throw new Gree_Service_AvatarFeed_Exception($msg, $code, $this->input_values);
                }

                list($following_count, $followed_count) = $mod_follow->getFollowCount($random_user_id);

                if (in_array($random_user_id, $check_users)
                    || $random_user_id == $this->_certified_user->my['user_id']
                    || $followed_count >= 400
                ) {
                    $miss_hit++;
                } else {
                    $check_users[$index] = $random_user_id;
                }

                if ($miss_hit >= 50) {
                    $import_result['miss_hit'] = $miss_hit;
                    $msg                       = 'failed find random user. miss hit is over limit';
                    $code                      = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_RANDOM;
                    throw new Gree_Service_AvatarFeed_Exception($msg, $code, $this->input_values);
                }
            }

            foreach ($check_users as $index => $user_id) {
                $add_params        = array(
                    'user_id' => $user_id,
                );
                $follow_add_result = Gree_Service_AvatarFeed_Processor::execute(
                    'following_add',
                    $add_params
                );

                if ($follow_add_result) {
                    $destinations   = array();
                    $destinations[] = array(
                        'type'  => 'feed_key',
                        'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' .
                            GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $this->_certified_user->my['user_id']
                    );

                    $add_params = array(
                        'entry_id'     => $stream_data[$index]['entry_id'],
                        'destinations' => $destinations
                    );
                    // ignore add destination result
                    $mod_appfeed->addDestination($add_params);

                    $import_result['success_import'][] = array(
                        'user_id'  => $user_id,
                        'entry_id' => $stream_data[$index]['entry_id'],
                    );
                }
            }

            $import_result['miss_hit'] = $miss_hit;
        } catch (Exception $e) {
            $msg  = 'failed Import random user.';
            $code = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW_IMPORT_RANDOM;
            new Gree_Service_AvatarFeed_Logger($msg, $code, $this->input_values);
        }

        return $import_result;
    }
}