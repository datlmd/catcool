<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/Gree/CacheGateway/Shop/Collabo/PurchaseNum.php
 *
 *  @author   Masatoshi Ibuki <ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: skel.manager.php 60810 2010-06-22 04:08:38Z ibuki $
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/CacheGateway.php';

/**
 *  �������Υ���å������
 *
 *  @author   Masatoshi Ibuki <ibuki@gree.co.jp>
 *  @access   public
 *  @package  GREE
 */
class Gree_Service_Shop_CacheGateway_Shop_Collabo_PurchaseNum extends Gree_Service_Shop_CacheGateway
{
	/**#@+
	 *  @access private
	 */
	/** @var string ����å���μ��� */
	var $_cache_type = 'flare';
	/** @var string ����å����̾������ */
	var $_namespace = 'shop_collabo_default';
	/** @var string ���������ֻ� */
	var $_key_prefix = 'purchase_num_';
	/**#@-*/

	function get($key)
	{
		return $this->_get($key);
	}

	function set($key, $purchase_num)
	{
		return $this->_set($key, $purchase_num);
	}

	function lock($key)
    {
        return $this->_lock($key);
    }

	function unlock($key)
    {
        return $this->_unlock($key);
    }

	function clear($key)
    {
        return $this->_clear($key);
    }	
}
?>
