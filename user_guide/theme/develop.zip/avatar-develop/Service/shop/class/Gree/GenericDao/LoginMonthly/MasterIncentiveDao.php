<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/LoginMonthly/MasterIncentiveDao.php
 * @package     GREE Avatar
 * @since       2018-06-04
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Master form constructor
 * @access      public
 */
class Gree_GenericDao_LoginMonthly_MasterIncentiveDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name = 'loginmonthly_master_incentive';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var field names */
    var $_field_names = [
        'id',
        'master_id',
        'type',
        'day_num',
        'incentive',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_master_id_and_type'               => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_id = :master_id and type = :type ORDER BY day_num ASC',
        ],
        'find_by_master_id_and_type_and_day_num'   => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE master_id = :master_id and type = :type and day_num = :day_num',
        ],
        // }}}

        // {{{ update queries
        'entry'                                    => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (master_id, type, day_num, incentive, ctime) VALUES (:master_id, :type, :day_num, :incentive, NOW())',
            'return_last_insert_id' => true,
        ],
        'update'                                   => [
            'sql' => 'UPDATE __TABLE_NAME__ SET master_id = :master_id, type = :type, day_num = :day_num, incentive = :incentive WHERE id = :id',
        ],
        'delete_by_master_id_and_day_num_and_type' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE master_id =:master_id AND day_num = :day_num and type = :type',
        ],
        // }}}

        // {{{ create table
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `master_id` INT UNSIGNED NOT NULL,
                  `type` INT UNSIGNED NOT NULL,
                  `day_num`   INT unsigned NOT NULL default '0',
                  `incentive` VARCHAR(255) NOT NULL,
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  INDEX (`type`),
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `incentive_type`(`master_id`, `type`, `day_num`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
    ];
}
