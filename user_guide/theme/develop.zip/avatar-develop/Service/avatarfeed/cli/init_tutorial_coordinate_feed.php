<?php
$start_time = microtime(true);
require "/home/gree/src/Gree_Bootstrap.php";
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once "/home/gree/xgree/avatar/Service/avatarfeed/service.php";
echo '-------------------------------------------' . PHP_EOL;
echo ' init feed... ' . PHP_EOL;
echo '-------------------------------------------' . PHP_EOL;

try {
    if (Config::get('state') != 'dev'){
        exit();
    }
    $shop_service = getService('shop');
    $tutorial_coordinate_manger = $shop_service->getTutorialCoordinateManager();
    $feed_list = $tutorial_coordinate_manger->getAllFeedInfo();

    $module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');

    foreach($feed_list as $feed_info) {
        $user_id       = $feed_info['user_id'];
        $feed_category = $feed_info['feed_category'];

        $module->setUserIDtoCtfy($user_id);
        // try {
            // $module->deleteFeed($feed_category);
            // sleep(5);
        // } catch (Exception $e) {}
        try {
            $module->createFeed($feed_category);
        } catch (Exception $e) {}
        sleep(1);
    }

} catch (Exception $e) {
    echo $e->getMessage(),PHP_EOL;
    exit();
}

echo "[DONE]\t" . sprintf('%.3f', (microtime(TRUE) - $start_time)) . PHP_EOL;
