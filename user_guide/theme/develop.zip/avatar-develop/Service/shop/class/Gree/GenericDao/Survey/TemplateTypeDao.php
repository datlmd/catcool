<?php

class Gree_GenericDao_Survey_TemplateTypeDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'customer_survey_template_types';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_user';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_user';

    /** @var field names */
    var $_field_names = [
        'id',
        'name',
        'status',
        'mtime',
        'ctime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ],
        'find_by_status' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE status = 1 ORDER BY id DESC',
        ],
        'find_by_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ],
        // }}}

        // {{{ update queries
        'entry' => [
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (name, status, ctime) VALUES (:name, :status, NOW())',
            'return_last_insert_id' => true,
        ],
        'update' => [
            'sql' => 'UPDATE __TABLE_NAME__ SET name = :name, status = :status WHERE id = :id',
        ],
        // }}}

        // {{{ create table
        'create' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `name` VARCHAR(255) NOT NULL,
                  `status` INT UNSIGNED NOT NULL DEFAULT 1,
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
    ];
}
