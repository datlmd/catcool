#!/bin/sh
TESTDIR=`dirname $0`
PHPUNIT="/home/gree/common/php/bin/phpunit"
$PHPUNIT --bootstrap $TESTDIR/bootstrap.php $* --colors $TESTDIR/class