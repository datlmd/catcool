<?php

class Gree_GenericDao_Analytics_GachaReport_PayGachaDailyDao extends Gree_GenericDao
{
    var $_table_name = 'pay_gacha_daily';

    var $_primary_key = 'id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_analytics';

    var $_slave_dsn = 'gree://slave/avatar_analytics';

    var $_auto_increment = true;

    var $_field_names = array(
        'id',
        'date',
        'gacha_id',
        'type_id',
        'sex',
        'pay',
        'pay_uu',
        'login_uu',
        'gacha_page_uu',
        'mtime',
        'ctime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `date` DATE NOT NULL,
                    `gacha_id` INT NOT NULL,
                    `type_id` INT NOT NULL,
                    `sex` TINYINT UNSIGNED NOT NULL,
                    `pay` INT UNSIGNED NOT NULL DEFAULT 0,
                    `pay_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `login_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `gacha_page_uu` INT UNSIGNED NOT NULL DEFAULT 0,
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    UNIQUE (date, gacha_id, type_id, sex),
                    INDEX gacha_id (gacha_id),
                    INDEX type_id (type_id)
                 ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'insert_or_update_pay' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ (date, gacha_id, type_id, sex, pay, pay_uu, ctime)
                      VALUES (:date, :gacha_id, :type_id, :sex, :pay, :pay_uu, NOW())
                      ON DUPLICATE KEY UPDATE pay = VALUES(pay), pay_uu = VALUES(pay_uu)",
        ),
        'insert_or_update_login_uu' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ (date, gacha_id, type_id, sex, login_uu, gacha_page_uu, ctime)
                      VALUES (:date, :gacha_id, :type_id, :sex, :login_uu, :gacha_page_uu, NOW())
                      ON DUPLICATE KEY UPDATE login_uu = VALUES(login_uu), gacha_page_uu = VALUES(gacha_page_uu)",
        ),
        'find_by_gacha_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE gacha_id=:gacha_id ORDER BY date, sex",
        ),
        'find_by_date_range' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE :begin_date <= date and date < :end_date ORDER BY date, sex",
        ),
        'find_total_all' => array(
            'sql' => "SELECT DATE_FORMAT(date, '%Y-%m') as month, DATE_FORMAT(date, '%d') as day, sum(pay) as pay FROM __TABLE_NAME__  group by DATE_FORMAT(date, '%Y-%m'), DATE_FORMAT(date, '%d') order by month, day",
        ),
        'total_pay_by_date_range' => array(
            'sql' => "SELECT gacha_id, type_id, sex, sum(pay) as pay FROM __TABLE_NAME__ WHERE gacha_id <> -1 and :begin_date <= date and date < :end_date GROUP BY gacha_id, sex",
        ),
        'pay_by_gacha_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE gacha_id <> -1 and gacha_id = :gacha_id and `sex` = :sex order by `date`",
        ),
        'find_release_day_by_gacha_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE gacha_id=:gacha_id and date=(SELECT min(date) from __TABLE_NAME__ WHERE gacha_id=:gacha_id) ORDER BY sex",
        ),
        'total_by_date' => [
            'sql' => 'SELECT sum(`pay`) FROM __TABLE_NAME__ WHERE `date` = :date',
        ],
    );
}
