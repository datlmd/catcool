<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	AttrDao.php
 *
 *	@author		Yoshihiro Takemura <takemura@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: AttrDao.php 67210 2010-03-08 03:25:18Z takemura $
 */
class Gree_GenericDao_Shop_Campaign_AttrDao extends Gree_GenericDao {
	var $_table_name  = 'shop_campaign_attr';
	var $_master_dsn  = 'gree://master/shop';
	var $_slave_dsn   = 'gree://slave/shop';
	var $_primary_key = 'id';
	var $_auto_increment = true;
	
	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';
	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';
	
	/** @var �ե������̾ */
	var $_field_names = array(
		'id',
		'campaign_id',
		'name',
		'value',
		'mtime',
		'ctime',
	);

	var $_queries = array(
			'find_by_campaign_id' => array(
				'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE campaign_id = :campaign_id'
			),
			'find_by_id' => array(
				'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id'
			),
			'find_by_campaign_id_and_name' => array(
				'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE campaign_id = :campaign_id AND name = :name'
			),
			'delete_by_campaign_id_and_name' => array(
				'sql' => 'DELETE FROM __TABLE_NAME__ WHERE campaign_id = :campaign_id AND name = :name'
			),
	);

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
