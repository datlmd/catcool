<?php
/**
 * Gree_GenericDao_Coordell_FeedInfoDao
 * 
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */

class Gree_GenericDao_Coordell_FeedInfoDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'feed_info';
    /** @var primary key */
    var $_primary_key = 'feed_id';
    /** @var auto increment */
    var $_auto_increment = true;
    /** @var updated at column */
    var $_updated_at_column = 'mtime';
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_coordell';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_coordell';

    /** @var field names */
    var $_field_names = array(
        'feed_id',
        'user_id',
        'theme_id',
        'item_ids',
        'effect',
        'state',
        'title',
        'value',
        'unixctime',
        'ctime',
        'mtime'
    );

    var $_queries = array(
    // --select
        'find_feed_by_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE feed_id = :feed_id',
        ),
        'find_feed_by_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE feed_id in (:feed_ids)',
        ),
        'find_recent_feed' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = 1 ORDER BY feed_id DESC',
        ),
        'find_user_feed' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY feed_id DESC',
        ),
        'find_feed_by_theme_ids_and_other_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE theme_id in (:theme_ids) AND user_id <> :user_id ORDER BY feed_id DESC',
        ),
        'find_feed_by_unixctime' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE unixctime BETWEEN :starttime AND :endtime',
        ),
        'count_user_feed' => array(
            'sql' => 'SELECT count(feed_id) as count FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'count_user_total_value' => array(
            'sql' => 'SELECT sum(value) as total FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'count_theme_posted_by_other_user' => array(
            'sql' => 'SELECT count(feed_id) as count FROM __TABLE_NAME__ WHERE theme_id in (:theme_ids) AND user_id <> :user_id',
        ),
    // --insert & update
        'insert_user_feed' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, theme_id, item_ids, effect, title, unixctime, ctime) VALUES (:user_id, :theme_id, :item_ids, :effect, :title, :unixctime, :ctime)',
            'return_last_insert_id' => true,
        ),
        'update_state_by_feed_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state, title = :title WHERE feed_id = :feed_id',
        ),
        'increment_value_by_feed_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET value = value + :value WHERE feed_id = :feed_id',
        ),
    // --support tool
        'find_all_recent_feed' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY feed_id DESC',
        ),
    // --create table
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `feed_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT(10) UNSIGNED NOT NULL,
                `theme_id` INT(10) UNSIGNED,
                `item_ids` VARCHAR(255) NOT NULL,
                `effect` TINYINT(3) UNSIGNED NOT NULL,
                `state`  TINYINT(3) UNSIGNED DEFAULT 1,
                `title`  VARCHAR(255) NOT NULL,
                `value`  INT(10) UNSIGNED DEFAULT 0,
                `unixctime` INT(10) UNSIGNED DEFAULT 0,
                `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`feed_id`),
                KEY `user_id` (`user_id`),
                KEY `state` (`state`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Coordell_FeedInfoFarmSelector();
    }
    // }}}
}

class Gree_GenericDao_Coordell_FeedInfoFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    // var string �ơ��֥�ե������ֹ�ե����ޥå�
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        if (empty($hint)) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }
        // �ơ��֥�̾�˥ե�������ɲ�
        $table_suffix   = sprintf($this->_table_suffix_format, $hint['event_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
    // }}}
}
