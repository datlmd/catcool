<?php
/**
 * Gree_GenericDao_EventMovieMasterDao
 */
class Gree_GenericDao_EventMovie_MasterDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'event_movie_master';
    /** @var primary key */
    var $_primary_key = 'event_id';
    /** @var auto increment */
    var $_auto_increment = true;
    /** @var updated at column */
    var $_updated_at_column = 'mtime';
    /** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_event_count';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var field names */
    var $_field_names = array(
        'event_id',
        'stime',
        'etime',
        'state',
        'template',
        'ctime',
        'mtime',
        );

    var $_queries = array(
    // --select
        'find_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY event_id DESC',
        ),
        'find_by_event_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ),
    // --insert & update
        'insert_event' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (stime, etime, state, template, ctime) VALUES(:stime, :etime, :state, :template, NOW())',
        ),
        'update_event_by_event_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET stime = :stime, etime = :etime, state = :state, template = :template WHERE event_id = :event_id',
        ),
    // --create table
        'create_table' => array(
            'sql' => "    
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `event_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `stime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `etime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `state` TINYINT(3) UNSIGNED NOT NULL DEFAULT '0',
                    `template` INT(10) UNSIGNED NOT NULL DEFAULT '0',
                    `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`event_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
    );
}
