<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
/**
 *  /home/gree/service/shop/class/GenericDao/Raid/Marche/Master.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_Raid_Marche_MasterDao extends Gree_GenericDao_Apc {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'master_raid_marche';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'event_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_raid';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_raid';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'event_id',
        'name',
        'status',
        'max_buy_item_num',
        'max_have_item_num',
        'festival_time',
        'game_end_date',
        'start_date',
        'end_date',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'all' => array(                 // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY event_id DESC',
        ),
        'find_by_event_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id=:event_id',
        ),
        // }}}

        // {{{ ��������������
        'insert' => array(              // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (name, max_buy_item_num, max_have_item_num, festival_time, game_end_date, start_date, end_date, ctime) VALUES(:name, :max_buy_item_num, :max_have_item_num, :festival_time, :game_end_date, :start_date, :end_date, NOW())',
        ),
        'update_by_event_id' => array(  // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET name=:name, status=:status, max_buy_item_num=:max_buy_item_num, max_have_item_num=:max_have_item_num, festival_time=:festival_time, game_end_date=:game_end_date, start_date=:start_date, end_date=:end_date WHERE event_id=:event_id',
        ),
        // }}}

        // {{{ �ơ��֥����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `event_id`          int(11) unsigned NOT NULL auto_increment,
                    `name`              varchar(255) NOT NULL DEFAULT '',
                    `status`            tinyint(2) unsigned NOT NULL default '0',
                    `max_buy_item_num`  int(11) unsigned NOT NULL default '0',
                    `max_have_item_num` int(11) unsigned NOT NULL default '0',
                    `festival_time`     int(11) unsigned NOT NULL default '0',
                    `game_end_date`     datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `start_date`        datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `end_date`          datetime NOT NULL default '0000-00-00 00\:00\:00',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`event_id`)
                ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(      // for batch
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
