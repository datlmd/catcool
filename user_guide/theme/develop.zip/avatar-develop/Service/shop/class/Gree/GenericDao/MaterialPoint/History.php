<?php
/**
 * Gree_GenericDao_Point_History
 *
 * @package GREE
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/DateFarmSelector.php';

class Gree_GenericDao_Shop_MaterialPoint_HistoryDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'material_point_history';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_point';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_point';

    /** @var field names */
    var $_field_names       = array(
        'id',
        'user_id',
        'point',
        'type',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),       
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (user_id, point, type, ctime) VALUES (:user_id, :point, :type, :ctime)',
        ),
        'create_table'      => array(
            'sql'   => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`          INT(11)     UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`     INT(11)     UNSIGNED NOT NULL,
                    `point`       INT(11)     NOT NULL,
                    `type`        TINYINT(4)  UNSIGNED NOT NULL,
                    `ctime`       DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `mtime`       TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    KEY `user_id` (`user_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'delete' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}
    );

    // {{{ _initFarmSelector
    /**
     * initialize farm selector
     *
     * @access  private
     */
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Shop_DateFarmSelector();
    }
    // }}}
}
