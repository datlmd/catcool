<?php
/**
 *	AnniversaryDao.php
 *
 *	@author		Keisuke Kagiya
 *	@package	GREE
 *	@version	$Id: AnniversaryDao.php
 */
class Gree_GenericDao_Shop_Campaign_AnniversaryDao extends Gree_GenericDao {
    var $_table_name = 'campaign_anniversary_13th';
    var $_master_dsn = 'gree://master/avatar_gacha';
    var $_slave_dsn = 'gree://slave/avatar_gacha';
    var $_primary_key = 'id';
    var $_auto_increment = true;
    var $_created_at_column = 'ctime';
    var $_updated_at_column = null;
    var $_field_names = array(
        'id',
        'user_id',
        'sex',
        'type',
        'data1',
        'data2',
        'data3',
        'ctime',
    );

    var $_queries = array(
        'find_by_user_id_and_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND type=:type'
        ),
        'find_by_sex_and_type' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND sex=:sex AND type=:type'
        ),
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`      int       unsigned NOT NULL AUTO_INCREMENT,
                    `user_id` int       unsigned NOT NULL,
                    `sex`     tinyint   unsigned NOT NULL DEFAULT '1',
                    `type`    tinyint   unsigned NOT NULL DEFAULT '1',
                    `data1`   smallint  unsigned NOT NULL DEFAULT '0',
                    `data2`   smallint  unsigned NOT NULL DEFAULT '0',
                    `data3`   smallint  unsigned NOT NULL DEFAULT '0',
                    `ctime`   datetime             NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    KEY `user_id_idx` (`user_id`)
                ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis
            "
        ),
        /* For summary the result and show ranking */
        'find_by_type' => array(
            'sql' => 'SELECT sex, data1, data2, data3 FROM __TABLE_NAME__ WHERE type=:type'
        ),
        'find_all' => array(
            'sql' => 'SELECT sex, data1, data2, data3 FROM __TABLE_NAME__'
        ),
    );

    function _initFarmSelector() {
        $this->_farm_selector = new Gree_GenericDao_Shop_Campaign_AnniversarySelector();
    }
}

class Gree_GenericDao_Shop_Campaign_AnniversarySelector extends Gree_GenericDao_FarmSelector {
    function getTableName($dao, $type, $hint) {
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }
        $table_name = sprintf("%s", $original_table_name);
        return $table_name;
    }
}
?>
