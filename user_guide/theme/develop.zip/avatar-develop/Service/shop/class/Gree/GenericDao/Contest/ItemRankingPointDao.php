<?php

/**
 * Class Gree_GenericDao_Contest_ItemRankingPointDao
 * @author z.shintaro.okada
 * @package  GREE
 */

class Gree_GenericDao_Contest_ItemRankingPointDao extends Gree_GenericDao
{
    /** @var テーブル名 */
    var $_table_name = 'contest_item_ranking_point';

    /** @var 主キー。複合キーはarrayハッシュで指定する。*/
    var $_primary_key = array('contest_id', 'item_id');

    /** @var オートインクリメント*/
    var $_auto_increment = false;

    /** @var 更新日カラム名 */
    var $_created_at_column = 'ctime';

    /** @var 登録日カラム名 */
    var $_updated_at_column = 'mtime';

    /** @var マスターデータベースの接続文字列 */
    var $_master_dsn = 'gree://master/avatar_contest';

    /** @var スレーブデータベースの接続文字列 */
    var $_slave_dsn = 'gree://slave/avatar_contest';

    /** @var フィールド名 */
    var $_field_names = array(
        'contest_id',
        'item_id',
        'point',
        'ctime',
        'mtime',
    );

    /** @var クエリ */
    var $_queries = array(
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                      `contest_id`  INT(11)     UNSIGNED  NOT NULL,
                      `item_id`     INT(11)     UNSIGNED  NOT NULL,
                      `point`       BIGINT(20)  UNSIGNED  NOT NULL DEFAULT '0',
                      `ctime`       DATETIME              NOT NULL DEFAULT '00-00-00 00\:00\:00',
                      `mtime`       TIMESTAMP             NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                      PRIMARY KEY (`contest_id`, `item_id`),
                      KEY (`point`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        /** @var 参照系 */
        'find_by_contest_id_and_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND item_id = :item_id',
        ),
        'find_all_by_contest_id_order_point_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id ORDER BY point DESC, mtime ASC',
        ),

        'find_by_contest_id_and_item_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND item_id IN (:item_ids) ORDER BY point DESC, mtime ASC',
        ),

        /** @var 更新系 */
        'insert_or_update' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__
                        (contest_id, item_id, point, ctime)
                      VALUES
                        (:contest_id, :item_id, :point, NOW())
                      ON DUPLICATE KEY UPDATE
                        point = point + :point
                      ',
        ),
    );
}
