<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Gree_GenericDao_Market_Master
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_MasterDao extends Gree_GenericDao_Apc
{
    /** @var table name */
    var $_table_name        = 'market_master';

    /** @var primary key */
    var $_primary_key       = 'market_id';

    /** @var auto increment */
    var $_auto_increment    = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'market_id',
        'state',
        'sell_start_time',
        'bid_start_time',
        'receive_start_time',
        'close_time',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        'find_by_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state ORDER BY market_id desc',
        ),
        'get_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY market_id',
        ),
        'last_insert' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY market_id desc',
        ),
        // }}}

        // {{{ update queries
        'create' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__
                    (state, sell_start_time, bid_start_time, receive_start_time, close_time, ctime)
                VALUES
                    (:state, :sell_start_time, :bid_start_time, :receive_start_time, :close_time, NOW())
            ',
            'return_last_insert_id' => true,
        ),
        'update_state' => array(
            'sql' => '
                UPDATE
                    __TABLE_NAME__
                SET
                    state       = :state
                WHERE
                    market_id   = :market_id
            ',
        ),
        'update_time' => array(
            'sql' => '
                UPDATE
                    __TABLE_NAME__
                SET
                    sell_start_time     = :sell_start_time,
                    bid_start_time      = :bid_start_time,
                    receive_start_time  = :receive_start_time,
                    close_time          = :close_time
                WHERE
                    market_id           = :market_id
            ',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    market_id               INT(11)     UNSIGNED NOT NULL AUTO_INCREMENT,
                    state                   TINYINT(4)  UNSIGNED NOT NULL,
                    sell_start_time         DATETIME    NOT NULL,
                    bid_start_time          DATETIME    NOT NULL,
                    receive_start_time      DATETIME    NOT NULL,
                    close_time              DATETIME    NOT NULL,
                    ctime                   DATETIME    NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime                   TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (market_id),
                    KEY (state)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );
}
