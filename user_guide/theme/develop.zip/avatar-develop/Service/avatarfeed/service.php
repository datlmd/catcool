<?php

require_once dirname(__FILE__) . '/bootstrap.php';

final class Gree_Service_AvatarFeed
{
    public function singleton()
    {
        static  $instance = null;

        return ($instance !== null)
            ?  ($instance)
            :  ($instance   = new self);
    }

    public function getInstance()
    {
        return self::singleton();
    }

    public function process($name,
                            $input_values = array(),
                            $set_user = null) // for unit test
    {
        try {
            $result = Gree_Service_AvatarFeed_Processor::execute(
                $name,
                $input_values,
                $set_user
            );
        } catch(Exception $e){
            throw new Gree_Service_Shop_Exception_FrontendException('現在、この機能はお使いいただけません。');
        }

        return $result;
    }
}