<?php

class Gree_Service_AvatarFeed_Processor_Following_List_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $following_list = array();
        $has_more       = false;
        $show_all       = false;


        $mod_follow = self::getModule('Follow');

        if (!empty($this->input_values['show_all'])) {
            $show_all = $this->input_values['show_all'];
        }

        $following_user_ids = null;
        try {
            list($has_more, $following_user_ids) = $mod_follow->getFollowingListOrderInTime(
                $this->input_values['user_id'],
                $this->input_values['limit'],
                $this->input_values['offset']
            );
        } catch (Exception $e) {
            $msg     = 'failed get follow status.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        if (is_null($following_user_ids)) {
            return array(
                $has_more,
                $following_list
            );
        }

        $mod_user       = self::getModule('User');
        $following_list = $mod_user->appendUserInfo($following_user_ids, $show_all);

        return array(
            $has_more,
            $following_list
        );
    }
}
