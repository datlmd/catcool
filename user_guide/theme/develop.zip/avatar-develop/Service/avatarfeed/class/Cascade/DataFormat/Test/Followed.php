<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Test_Followed
    extends Gree_Service_AvatarFeed_Cascade_DataFormat_Followed
{
    protected $table_name        = 'followed_test';
}