<?php

class Gree_Service_AvatarFeed_Processor_Tutorial_Coordinate_Destination_Add
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;

    protected function invoke()
    {
        $this->mod_appfeed = self::getModule('AppFeed');

        $entry_id            = $this->input_values['entry_id'];
        $destination_user_id = $this->input_values['user_id'];
        $feed_category       = $this->input_values['feed_category'];

        try {
            $destinations = $this->_getFeedKey($destination_user_id, $feed_category);
            $this->_addDestination($entry_id, $destinations);
        } catch (Exception $e) {
            $msg     = 'failed add destination.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_DESTINATION_ADD;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return false;
        }

        return true;
    }

    private function _getFeedKey($destination_user_id, $feed_category)
    {
        $destinations = array();
        $destinations[] = array(
            'type'  => 'feed_key',
            'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' .
            $feed_category . ':' . $destination_user_id
        );

        return $destinations;
    }

    public function _addDestination($entry_id, $destinations)
    {
        $add_params = array(
            'entry_id'     => $entry_id,
            'destinations' => $destinations
        );
        $this->mod_appfeed->addDestination($add_params);
    }
}
