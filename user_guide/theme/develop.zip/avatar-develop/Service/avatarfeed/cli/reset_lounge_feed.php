<?php
$start_time = microtime(true);
require "/home/gree/src/Gree_Bootstrap.php";
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once PATH_SRC_CLASS.'/Gree/CLI.php';
require_once "/home/gree/xgree/avatar/Service/avatarfeed/service.php";
echo '-------------------------------------------' . PHP_EOL;
echo ' delete lounge feed... ' . PHP_EOL;
echo '-------------------------------------------' . PHP_EOL;

try {
    if (Config::get('state') != 'dev'){
        exit();
    }
    $delete_user_list = array(549825);

    $shop_service      = getService('shop');
    $registry          = $shop_service->getRegistry();
    $avatar_feed_lounge_info = $registry->getArray('avatar_feed_lounge_info');
    $lounge_user_list = array();

    foreach ($avatar_feed_lounge_info['official_user_list'] as $lounge_info) {
        $lounge_user_list[] = $lounge_info['dev_user_id'];
    }

    $module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
    foreach($delete_user_list as $user_id){
        if (in_array($user_id, $lounge_user_list)) {
            $module->setUserIDtoCtfy($user_id);
            $module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
            sleep(2);
            $module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        }
    }
} catch (Exception $e) {
    echo $e->getMessage(),PHP_EOL;
    exit();
}

echo "[DONE]\t" . sprintf('%.3f', (microtime(TRUE) - $start_time)) . PHP_EOL;
