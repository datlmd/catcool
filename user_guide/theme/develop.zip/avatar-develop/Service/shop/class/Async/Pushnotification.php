<?php
/**
 * async handler for push notifiation.
 */

/**
 * Gree_Service_Shop_Async_Pushnotification
 */
class Gree_Service_Shop_Async_Pushnotification
{
    private $_notification_manager = null;

    public function __construct()
    {
        $this->_notification_manager = getService('shop')->getPushNotificationNotificationManager();
    }

    /**
     * pushNotificationTest
     */
    public function handlePushNotificationTest($params)
    {
        $user_id = $params['user_id'];

        $this->_notification_manager->pushNotificationTest($user_id);
    }

    /**
     * pushNotificationAvapri
     */
    public function handlePushNotificationAvapri($params)
    {
        $user_id = $params['user_id'];
        $members = $params['members'];
        $seal_id = $params['seal_id'];

        $this->_notification_manager->pushNotificationAvapri($user_id, $members, $seal_id);
    }

    /**
     * pushNotificationAvapriEntry
     */
    public function handlePushNotificationAvapriEntry($params)
    {
        $from_user_id    = $params['from_user_id'];
        $to_user_id      = $params['to_user_id'];
        $entry_id        = $params['entry_id'];
        $notification_id = $params['notification_id'];
        $badge_count     = $params['badge_count'];

        $this->_notification_manager->pushNotificationAvapriEntry($from_user_id, $to_user_id, $entry_id, $notification_id, $badge_count);
    }

    /**
     * pushNotificationGift
     */
    public function handlePushNotificationGift($params)
    {
        $user_id    = $params['user_id'];
        $to_user_id = $params['to_user_id'];

        $this->_notification_manager->pushNotificationGift($user_id, $to_user_id);
    }

    /**
     * pushNotificationBadgeUpdate
     */
    public function handlePushNotificationBadgeUpdate($params)
    {
        $to_user_id  = $params['to_user_id'];
        $badge_count = $params['badge_count'];

        $this->_notification_manager->pushNotificationBadgeUpdate($to_user_id, $badge_count);
    }

    /**
     * pushNotificationFollow
     */
    public function handlePushNotificationFollow($params)
    {
        $from_user_id    = $params['from_user_id'];
        $to_user_id      = $params['to_user_id'];
        $notification_id = $params['notification_id'];
        $badge_count     = $params['badge_count'];

        $this->_notification_manager->pushNotificationFollow($from_user_id, $to_user_id, $notification_id, $badge_count);
    }

    /**
     * pushNotificationLike
     */
    public function handlePushNotificationLike($params)
    {
        $from_user_id    = $params['from_user_id'];
        $to_user_id      = $params['to_user_id'];
        $entry_id        = $params['entry_id'];
        $notification_id = $params['notification_id'];
        $badge_count     = $params['badge_count'];

        $this->_notification_manager->pushNotificationLike($from_user_id, $to_user_id, $entry_id, $notification_id, $badge_count);
    }

    /**
     * pushNotificationPbox
     */
    public function handlePushNotificationPbox($params)
    {
        $to_user_id   = $params['to_user_id'];
        $present_type = $params['present_type'];

        $this->_notification_manager->pushNotificationPbox($to_user_id, $present_type);
    }
}
