<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Ranking/Vote/ToUserStandbyDao.php
 *
 *  Standby����³����Τǡ���������
 *
 *  @author   Takashi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package  GREE
 *  @version  $Id$
 */
require_once 'ToUserDao.php';

class Gree_GenericDao_Ranking_Vote_ToUserStandbyDao extends Gree_GenericDao_Ranking_Vote_ToUserDao
{
    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://standby/avatar_ranking_vote';

    /** @var ������ */
    var $_queries_standby = array(
        // {{{ Ĵ���ѥ����꡼
        'get_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__'
        ),
        'get_all_vote_by_date_and_farm_id' => array(
            'sql' => "SELECT user_id, MID(ctime, 1, 10) AS date, COUNT(*) AS cnt FROM __TABLE_NAME__ GROUP BY user_id, date",
        ),
        'get_all_vote_by_farm_id_and_user_id' => array(
            'sql' => "SELECT user_id, user_sex, ctime FROM __TABLE_NAME__ WHERE target_id = :target_id",
        ),
        'find_user_id_and_target_id' => array(
            'sql' => 'SELECT user_id, target_id FROM __TABLE_NAME__'
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
    );

    function __construct()
    {
        parent::__construct();

        $this->_setQuery($this->_queries_standby);
    }

    function _setQuery($queries)
    {
        $this->_queries = array_merge($this->_queries, $queries);
    }
}
