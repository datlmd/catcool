<?php
/**
 *  SimulationSettingDao.php
 *
 *  @author     Kanro Kikuchi
 *  @package    GREE
 *  @version    $Id: 
 */
class Gree_GenericDao_Shop_Simulation_SettingDao extends Gree_GenericDao {
    var $_table_name = 'gacha_simulation_setting';
    var $_master_dsn = 'gree://master/avatar_gacha';
    var $_slave_dsn = 'gree://slave/avatar_gacha';
    var $_primary_key = 'id';
    var $_auto_increment = true;
    var $_created_at_column = 'ctime';
    var $_updated_at_column = 'mtime';
    var $_field_names = [
        'id',
        'gacha_id',
        'sex',
        'name',
        'total',
        'limit',
        'multi',
        'rateup',
        'time',
        'run_time',
    ];

    var $_queries = [
        'find_by_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id=:id'
        ],
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC;'
        ],
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `gacha_id`      INT UNSIGNED NOT NULL,
                    `sex`           TINYINT UNSIGNED NOT NULL DEFAULT '1',
                    `name`          VARCHAR(255) NOT NULL,
                    `item_total`    INT UNSIGNED NOT NULL DEFAULT '0',
                    `set_limit`     INT UNSIGNED NOT NULL DEFAULT '0',
                    `multi`         INT UNSIGNED NOT NULL DEFAULT '1',
                    `rateup`        INT UNSIGNED NOT NULL DEFAULT '1',
                    `time`          FLOAT UNSIGNED NOT NULL DEFAULT '0.00',
                    `run_time`      DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    `mtime`         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`         DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    KEY `gacha_id_1` (`gacha_id`, `sex`)
                ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis
            "
        ],
        'insert' => [
            'sql' => "
                INSERT INTO __TABLE_NAME__ (
                    gacha_id, sex, name, item_total, set_limit, multi, rateup, time, run_time, ctime
                ) values (
                    :gacha_id, :sex, :name, :item_total, :set_limit, :multi, :rateup, :time, :run_time, NOW()
                )
            "
        ],
        'last_insert_id'  => [
            'sql' => 'SELECT LAST_INSERT_ID()'
        ],
        'find_by_run_times' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE gacha_id=:gacha_id AND sex=:sex AND name=:name AND set_limit=:set_limit AND multi=:multi AND rateup=:rateup AND run_time>=:run_time'
        ],
    ];
}
?>
