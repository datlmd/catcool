<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Battle/RankingDao.php
 *
 *  @author   Adib Gholaminezhad <adib.gholaminezhad@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_Battle_RankingDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'battle_ranking';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'user_id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_coorde_battle';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_coorde_battle';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'user_id',
        'user_sex',
        'win',
        'rank',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__'
        ),
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        'get_top_rank' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ where user_sex = :user_sex ORDER BY rank, user_id'
        ),
        'get_top_rank_by_sex_and_rank' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ where user_sex = :user_sex and rank <= :rank ORDER BY rank'
        ),
        'get_total_ranking_count' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__',
        ),
        'get_ranking_count_by_user_sex' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ where user_sex = :user_sex',
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}

        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id`       INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                `user_sex`      TINYINT(1)  NOT NULL DEFAULT '1',
                `win`           INT(11)     UNSIGNED NOT NULL DEFAULT '0',
                `rank`          INT(11)     UNSIGNED NOT NULL,
                `mtime`         TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime`         DATETIME    NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY  (`user_id`),
                KEY `rank` (`rank`, `user_sex`),
                KEY `user_sex` (`user_sex`)
            ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
        ),
        'insert' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ SET user_id = :user_id, user_sex = :user_sex, win = :win, rank = :rank, ctime = NOW()'
        ),
        'replace' => array(
            'sql' => "REPLACE INTO __TABLE_NAME__ (user_id, user_sex, win, rank, mtime, ctime) values (:user_id, :user_sex, :win, :rank, :modify_time, :ctime)"
        ),
        'truncate_table' => array(
            'sql' => "TRUNCATE __TABLE_NAME__"
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__"
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Battle_RankingFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Battle/RankingFarmSelector.php
 *
 *  @package  GREE
 */
class Gree_GenericDao_Battle_RankingFarmSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['battle_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $battle_id = $hint['battle_id'];
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is empty. dao=" . get_class($dao) . "];");
        }

        // �ơ��֥�̾�˥ե�������ɲ�
        $farm = sprintf($this->_table_suffix_format, $battle_id);
        if (empty($farm)) {
            return PEAR::raiseError("farm is blank. battle_id=" . $battle_id . "");
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
