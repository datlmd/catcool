<?php
/**
 * Service/shop/class/Gree/Apc.php
 */

/**
 * Gree_Service_Shop_Apc
 * アバター用にGree_Cacheをラップしたものです。
 *
 * Gree_Cacheとの違いは
 *
 * * ネームスペースに自動的にアバター用の接頭辞が付加される
 * * 引数のパラメータ配列から自動的にキャッシュするためのキーを生成する
 *
 * などです。
 */
class Gree_Service_Shop_Apc
{
    const NAMESPACE_PREFIX = 'avatar_apc#';

    /** @var Gree_Cache 本体 */
    private $_gree_cache = null;
    /** @var string ネームスペース このネームスペース毎にキャッシュを持ちます */
    private $_namespace  = null;
    /** @var string キャッシュの種類 */
    private $_cache_type = 'local';

    /**
     * コンストラクタ
     * privateコンストラクタなため外部からnewすることはできません。
     * Gree_Service_Shop_Apc::getInstance()を呼び出してください。
     *
     * @param string $namespace ネームスペース
     */
    private function __construct($namespace)
    {
        $this->_namespace = self::NAMESPACE_PREFIX . $namespace;
        $this->_gree_cache = Gree_Cache::getInstance($this->_cache_type, $this->_namespace);
    }

    /**
     * Gree_Service_Shop_Apcのインスタンスを返します。
     * インスタンスは$namespaceごとに別れた共有のインスタンスを持ちます。
     *
     * @param string $namespace
     *
     * @return Gree_Service_Shop_Apc このクラスのインスタンス
     */
    public static function getInstance($namespace)
    {
        static $instance = array();

        if (isset($instance[$namespace])) {
            return $instance[$namespace];
        }

        $apc = new Gree_Service_Shop_Apc($namespace);
        $instance[$namespace] = $apc;

        return $apc;
    }

    /**
     * ネームスペースを取得します。
     * ネームスペースは先頭にself::NAMESPACE_PREFIXが加えられます。
     *
     * @return string ネームスペース
     */
    public function getNamespace() {
        return $this->_gree_cache->getNameSpace();
    }

    /**
     * パラメータに一致するキャッシュを取得します。
     *
     * キャッシュがない場合や$lifetimeの時間を過ぎている場合、
     * またはエラーが発生した場合はPEAR_Errorオブジェクトを返します。
     *
     * @param array $params   キャッシュを取得するためのパラメータ。中身が一つでも違う場合は別のキャッシュと認識されます。
     * @param int   $lifetime キャッシュの生存時間(秒)。キャッシュをsetした時間から$lifetime秒以上過ぎてgetした場合はPEAR_Errorが返されます。
     *
     * @return object キャッシュされたデータ
     */
    public function get($params, $lifetime)
    {
        $cache_key = $this->_generateCacheKey($params);
        $cached_data = $this->_gree_cache->get($cache_key, $lifetime, $this->_namespace);

        return $cached_data;
    }

    /**
     * $paramsパラメータをキーとして$valueをキャッシュとしてセットします。
     *
     * @param array  $params キャッシュを設定するためのパラメータ。このパラメータをキーとしてキャッシュをセットします。
     * @param object $value キャッシュさせる値
     */
    public function set($params, $value)
    {
        if (PEAR::isError($value)) {
            return $value;
        }

        $cache_key = $this->_generateCacheKey($params);

        $this->_gree_cache->set($cache_key, $value, time(), $this->_namespace);
    }

    /**
     * $paramsパラメータをキーとして、それに対応するキャッシュがある場合には削除します。
     *
     * @param array $params キャッシュを削除するためのパラメータ。このパラメータをキーとしてキャッシュを削除します。
     */
    public function clear($params)
    {
        $cache_key = $this->_generateCacheKey($params);

        $this->_gree_cache->clear($cache_key);
    }

    /**
     * パラメータから一意なハッシュを生成します。
     *
     * @param array $params パラメータ
     *
     * @return string 一意なハッシュ文字列
     */
    private function _generateCacheKey($params)
    {
        return md5(serialize($params));
    }
}
