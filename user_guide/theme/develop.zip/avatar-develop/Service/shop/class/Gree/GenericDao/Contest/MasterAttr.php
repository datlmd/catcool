<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
// vim: sts=4 sw=4 ts=4 fdm=marker
class Gree_GenericDao_Contest_MasterAttrDao extends Gree_GenericDao_Apc {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'contest_master_attr';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = 'id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_contest';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_contest';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
    var $_field_names = array('id','contest_id','name','value','mtime', 'ctime');

	/** @var ������ */
	var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` int(10) unsigned NOT NULL auto_increment,
                    `contest_id` int(10) unsigned NOT NULL default '0',
                    `name` varchar(255) NOT NULL,
                    `value` text NOT NULL,
                    `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY  (`id`),
                    UNIQUE KEY `name` (`contest_id`,`name`)
                ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=ujis
            ",
        ),
        'find_by_contest_id' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id'
		),
        'find_cautioin_text_by_contest_id' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND name LIKE \'caution_%\''
		),
		'find_by_id' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id'
		),
		'find_by_contest_id_and_name' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND name = :name'
		),
        'delete_by_contest_id_and_name' => array(
			'sql' => 'DELETE FROM __TABLE_NAME__ WHERE contest_id = :contest_id AND name = :name'
		),
	);

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

}
