<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Contest/Entry/HistoryDao.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: HistoryDao.php 142382 2011-12-15 03:08:35Z ibuki $
 */

class Gree_GenericDao_Contest_Entry_HistoryDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'contest_entry_history';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key ='id';

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/avatar_contest';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/avatar_contest';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

	/** @var �ե������̾ */
	var $_field_names = array(
	                          'id',
							  'user_id',
							  'sex',
							  'is_bonus',
							  'title',
							  'item_ids',
							  'entry_datetime',
							  'mtime',
							  'ctime'
							 );

	/** @var ������ */
	var $_queries = array(
	    // {{{ ���ȷ�
        'find_by_user' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE user_id =:user_id ORDER BY id DESC",
        ),
		// }}}

		// {{{ ������
		'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                 `user_id` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                 `sex` TINYINT(2) NOT NULL DEFAULT '1',
                 `is_bonus` TINYINT(2) NOT NULL DEFAULT '0',
                 `title` VARCHAR(60) NOT NULL DEFAULT '',
                 `item_ids` VARCHAR(255) NOT NULL DEFAULT '',
                 `entry_datetime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                 `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                 `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                 PRIMARY KEY  (`id`),
                 KEY `user_id` (`user_id`)
             ) ENGINE=INNODB AUTO_INCREMENT=0 DEFAULT CHARSET=ujis"
		),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__"
        ),
        'show_tables' => array(
            'sql' => 'show tables like "__TABLE_NAME__"'
        ),
        // }}}
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Contest_Entry_HistoryFarmSelector();
    }
    // }}}
}

/**
 *  /home/gree/service/shop/class/GenericDao/Contest/Entry/HistoryFarmSelector.php
 *
 *  @author   Masatoshi Ibuki <masatoshi.ibuki@gree.co.jp>
 *  @package  GREE
 *  @version  $Id: HistoryDao.php 142382 2011-12-15 03:08:35Z ibuki $
 */
class Gree_GenericDao_Contest_Entry_HistoryFarmSelector extends Gree_GenericDao_FarmSelector
{

    // {{{ _table_nums
    /** var int �ơ��֥�ʬ��� */
    var $_table_nums = 100;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%d_%02d";
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint) {
        if (empty($hint['user_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        if (empty($hint['contest_id'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        if (empty($hint['user_sex'])) {
            return PEAR::raiseError("hint is emptry. dao=" . get_class($dao) . "];");
        }
        $user_id = $hint['user_id'];
        $contest_id = $hint['contest_id'];
        $user_sex = $hint['user_sex'];

        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name)) {
            return PEAR::raiseError("original table name is emptry. dao=" . get_class($dao) . "];");
        }

        // �ơ��֥�̾�˥ե�������ɲ�
        $farm_no = (int)(((int)$user_id) % $this->_table_nums);
        if ($farm_no < 0) {
            return PEAR::raiseError("system error.");
        }
        $farm = sprintf($this->_table_suffix_format, $contest_id, $user_sex, $farm_no);
        if (empty($farm)) {
            return PEAR::raiseError("farm is blank. user_id=" . $user_id . " contest_id=" . $contest_id . " user_sex=" . $user_sex);
        }

        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}

}
