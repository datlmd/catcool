<?php
/**
 *
 */
class Gree_Service_Shop_Exception_ServiceException
    extends Gree_Service_Shop_Exception
{
}
