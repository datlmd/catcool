<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Effect/User.php
 * 
 * @author      masayoshi.yoshino <masayoshi.yoshino@gree.co.jp>
 * @package     GREE
 */

class Gree_GenericDao_Effect_UserselectDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'effect_user_select';
    
    /** @var auto increment */
    var $_auto_increment = false;

    /** @var updated at column */
    var $_updated_at_column = 'mtime';
    
    /** @var create at column */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_effect';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_effect';

    /** @var field names */
    var $_field_names = array(
        'user_id',
        'item_id',
        'ctime',
        'mtime'
    );

    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        // }}}
        // {{{ ������
        'insert' => array(
            'sql' => 'INSERT INTO __TABLE_NAME__ (
                        user_id, 
                        item_id,
                        ctime
                    ) VALUES (
                        :user_id, 
                        :item_id,
                        :ctime
                    ) ON DUPLICATE KEY UPDATE item_id = :item_id'
        ),
        // {{{ create table
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `user_id` INT(10) UNSIGNED NOT NULL,
                `item_id` INT(10) UNSIGNED,
                `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY `user_id` (`user_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        // }}}
    );
}
