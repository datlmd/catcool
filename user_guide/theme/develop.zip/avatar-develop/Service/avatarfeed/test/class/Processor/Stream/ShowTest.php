<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Stream_Show
 *
 * this test is show process
 *
 * block test => Test_Processor_Block
 * change entry test => Test_Processor_Entry
 */
final class Gree_Service_Avatarfeed_Test_Processor_Stream_Show
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }

        try {
            $this->module->createFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
        }
    }

    /**
     * $stream_params = array(
     *      'user_id'  => UNIT_TEST_USER_ID_1,
     *      'category' => GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
     *      'limit'    => GREE_SERVICE_AVATARFEED_DEFAULT_GET_ENTRIES_LIMIT,
     *      'start_id' => null,
     * );
     *
     * test: 1
     * feed is empty
     * has_more == false, stream_data == empty array
     *
     * test: 2
     * feed has one entry
     * has_more == false, stream_data == array
     *
     * test 3
     * feed has many entries
     * specifed: limit ==2
     * specifed: start_id
     * has_more == true, stream_data == array
     *
     * test 4
     * if feed is not exist then create feed
     * has_more == false, stream_data == empty array
     */
    public function test_get_stream_data_mood()
    {
        // test 1
        $stream_params = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
            'limit'    => GREE_SERVICE_AVATARFEED_DEFAULT_GET_ENTRIES_LIMIT,
            'start_id' => null,
        );
        list($has_more, $stream_data) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more);
        $this->assertEquals(array(), $stream_data);

        // test 2
        list($is_success_create_entry, $entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);

        list($has_more_2, $stream_data_2) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more_2);
        $this->assertEquals(1, count($stream_data_2));
        $get_entry = array_shift($stream_data_2);
        $this->assertEquals($entry_id, $get_entry['entry_id']);
        $this->assertTrue(isset($get_entry['content']['user_info']['nick_name']));
        $this->assertTrue(isset($get_entry['content']['user_info']['thumbnail_url']));

        // test 3
        $create_mood_count = 5;
        for ($i = 0; $i < $create_mood_count; $i++) {
            list($is_success_create_entry, $last_entry_id) = $this->_createEntry(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_1);
        }

        $stream_params_2 = array(
            'user_id'  => UNIT_TEST_USER_ID_1,
            'category' => GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
            'limit'    => 2,
            'start_id' => $last_entry_id,
        );
        list($has_more_3, $stream_data_3) = $this->avatar_feed->process('stream_show', $stream_params_2, UNIT_TEST_USER_ID_1);

        $this->assertTrue($has_more_3);
        $this->assertEquals(2, count($stream_data_3));
        $get_entry_2 = array_shift($stream_data_3);
        $is_same_entry_id = true;
        if ($entry_id != $get_entry_2['entry_id']){
            $is_same_entry_id = false;
        }
        $this->assertFalse($is_same_entry_id);

        // test 4
        try {
            $this->module->deleteFeed(GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY);
        } catch (Exception $e) {
            $this->assertTrue(false);
        }

        list($has_more_4, $stream_data_4) = $this->avatar_feed->process('stream_show', $stream_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($has_more_4);
        $this->assertEquals(array(), $stream_data_4);

        try {
            list($has_more, $entries) = $this->module->getEntriesByFeedKey(
                UNIT_TEST_USER_ID_1,
                GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY,
                GREE_SERVICE_AVATARFEED_DEFAULT_GET_ENTRIES_LIMIT,
                null
            );
        } catch (Exception $e) {
            $this->assertTrue(false);
        }


    }

    public function _createEntry($sender_id, $destination_user_id)
    {
        $create_params = array(
            'content' => array(
                'sender_id'  => $sender_id,
                'entry_type' => 'mood',
                'text'       => 'test_processor_stream_show',
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $destination_user_id
            )),
        );
        list($is_success_create_entry, $entry_id) = $this->module->createEntry($create_params);

        return array(
            $is_success_create_entry,
            $entry_id
        );
    }
}