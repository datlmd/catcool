<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Stream_Show
 */
class Gree_Service_AvatarFeed_Processor_Stream_Show
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * @return array()
     *
     * get Stream data
     *
     * if failed to find feed then create feed.
     *
     * return has_more and stream data
     */
    protected function invoke()
    {
        $stream_data = array();
        $has_more    = false;
        $mod_appfeed = self::getModule('AppFeed');
        $mod_user    = self::getModule('User');
        $avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $is_block = $this->_checkVisibilty();
        if ($is_block) {
            return array(
                $has_more,
                $stream_data
            );
        }

        $this->input_values['category'] = $this->_transformCategory($this->input_values['category']);

        try {
            $start_id = $this->input_values['start_id'];
            $service_shop = getService('shop');
            $unsupported_items = $service_shop->getUnsupportedItems();
            if (!empty($unsupported_items)) {
                list($has_more, $entries) = $this->_getUnsupportedEntry();
            } else {
                list($has_more, $entries) = $mod_appfeed->getEntriesByFeedKey(
                        $this->input_values['user_id'],
                        $this->input_values['category'],
                        $this->input_values['limit'],
                        $start_id
                );
            }
        } catch (Exception $e) {
            if ($e->getCode() == Gree_Service_AvatarFeed_Exception::E_APINET_DATA_NOT_FOUND
                && $this->input_values['user_id'] == $this->_certified_user->my['user_id']
            ) {
                try {
                    $mod_appfeed->createFeed($this->input_values['category']);
                } catch (Exception $e) {
                    $msg     = 'failed get feed and create feed.';
                    $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_STREAM;
                    $context = $this->input_values;
                    $context['request_error_code']      = $e->getCode();
                    $context['request_error_message']   = $e->getMessage();

                    new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
                }
            }

            $msg     = 'failed get feed.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_STREAM;
            $context = $this->input_values;
            $context['request_error_code']      = $e->getCode();
            $context['request_error_message']   = $e->getMessage();

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array(
                $has_more,
                $stream_data
            );
        }

        if (count($entries) == 0) {
            return array(
                $has_more,
                $stream_data
            );
        }

        if ($this->input_values['category'] == GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION) {
            $point_manager = $service_shop->getPointManager();
            $sort_index = array();
            foreach ($entries as $index => $entry) {
                if (!isset($entry['content']['attr'])) {
                    unset($entries[$index]);
                    continue;
                }
                $entries[$index]['content']['attr']['notification_user'] = unserialize($entry['content']['attr']['notification_user']);

                $service_shop = getService('shop');
                $entry_category = $entry['content']['attr']['entry_category'];
                $today = $service_shop->getDate('Y-m-d');
                $expire_day = date('Y-m-d', strtotime('-' . GREE_SERVICE_SHOP_POINT_HISTORY_TERM_LIMIT . 'day', strtotime($today)));
                if ($entry_category == 'notification_incentive') {
                    if ($entry['content']['attr']['notification_entry_id'] >= $today) {
                        unset($entries[$index]);
                        continue;
                    } elseif ($entry['content']['attr']['notification_entry_id'] < $expire_day) {
                        //���¤��ڤ�Ƥ������Τ�������
                        if (isset($entry['entry_id'])) {
                            $notification_params = array(
                                'entry_id' => $entry['entry_id'],
                            );
                            $avatar_feed->process('notification_remove', $notification_params);
                        }
                        unset($entries[$index]);
                        continue;
                    } else {
                        $user_id = $this->input_values['user_id'];
                        $date    = $entry['content']['attr']['notification_entry_id'];
                        $points  = $point_manager->getLikePointHistory($user_id, $date);
                        $entries[$index]['content']['attr']['incentive'] = $points['like'] + $points['liked'];
                        $entries[$index]['created_time'] = date("Y-m-d 00:00:00", strtotime($date . ' +1day'));
                    }
                }

                if ($entry_category == 'notification_comment_relation' && isset($entry['content']['attr']['parent_entry_user_id'])) {
                    $parent_user_id = $entry['content']['attr' ]['parent_entry_user_id'];

                    $parent_entry_user_info = $mod_user->_getUserInfo(array($parent_user_id));
                    if ($mod_user->_isExistUser($parent_user_id, $parent_entry_user_info)) {
                        $entries[$index]['content']['attr']['parent_entry_nick_name'] = $parent_entry_user_info[(int)$parent_user_id]['nick_name'];
                        $entries[$index]['content']['attr']['parent_thumbnail'] = $parent_entry_user_info[(int)$parent_user_id]['thumbnail_url'];
                    } else {
                        // �桼�������󤬼����Ǥ��ʤ��������Τ�������
                        $notification_params = array(
                                'entry_id' => $entry['entry_id'],
                                );
                        $avatar_feed->process('notification_remove', $notification_params);

                        // ���顼������ɽ���ˤʤ뤿��
                        unset($entries[$index]);
                        continue;
                    }
                }
                $sort_index[] = $entries[$index]['created_time'];
            }
            array_multisort($sort_index, SORT_DESC, $entries);
        }

        $entries     = $mod_appfeed->appendCommentInfo($entries);
        $entries     = $mod_appfeed->appendEntryInfo($entries);
        $stream_data = $mod_user->appendUserInfo($entries);

        return array(
            $has_more,
            $stream_data
        );
    }

    /**
     * @return boolean
     *
     * when View Other User Feed, Check block status
     */
    public function _checkVisibilty()
    {
        $is_block = false;

        if ($this->_certified_user->my['user_id'] == $this->input_values['user_id']) {
            return $is_block;
        }
        $mod_block = self::getModule('Block');
        $is_block  = $mod_block->getBlockUser($this->_certified_user->my['user_id'], $this->input_values['user_id']);

        return $is_block;
    }

    /**
     * @param $category
     * @return string transform custom category
     *
     * ex. 'notification' => 'cutum00'
     */
    public function _transformCategory($category)
    {
        switch ($category) {
            case 'notification':
                return GREE_SERVICE_AVATARFEED_CATEGORY_NOTIFICATION;
                break;
            default:
                return $category;
        }
    }
    // {{{ _getUnsupportedEntry()
    private function _getUnsupportedEntry() {
        $start_id = $this->input_values['start_id'];
        $roop_limit = 2;//�������ˤ������
        $roop_count = 0;
        $entries_tmp = array();
        $mod_appfeed = self::getModule('AppFeed');

        while (true) {
            $roop_count++;
            list($has_more, $entries) = $mod_appfeed->getEntriesByFeedKey(
                    $this->input_values['user_id'],
                    $this->input_values['category'],
                    $this->input_values['limit'],
                    $start_id
            );
            $entries_tmp = array_merge($entries_tmp, $entries);

            foreach ($entries_tmp as $key => $val) {
                if (!isset($val['content']['attr'])) {
                    continue;
                }
                switch($val['content']['attr']['entry_category']) {
                    // unsupported avatar key
                    case 'unsupported_change':
                    case 'unsupported_avapri':
                    case 'unsupported_change_mood':
                        unset($entries_tmp[$key]);
                        break;
                    default:
                        break;
                }
            }
            if (!$has_more || count($entries_tmp) >= $this->input_values['limit'] || $roop_count >= $roop_limit ) {
                $entries = array_slice($entries_tmp, 0, $this->input_values['limit']);
                break;
            } else {
                $start_id = $val['entry_id'];
            }
        }
        return array($has_more, $entries);
    }
    // }}}
}
