<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Gacha/Promo/UserDao.php
 * @package     GREE Avatar
 */
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserLightFarmSelector.php';

/**
 * Promo_User form constructor
 * @access      public
 */
class Gree_GenericDao_Gacha_Promo_UserDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'gacha_promo_user';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var field names */
    var $_field_names = [
        'id',
        'event_id',
        'user_id',
        'gacha_id',
        'date',
        'ctime',
        'mtime',
    ];

    /** @var query definitions */
    var $_queries = [
        // {{{ refer queries
        'find_by_user_id'                   => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id DESC',
        ],
        'find_by_event_id_user_id_and_date' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id =:event_id and user_id = :user_id and date = :date',
        ],
        // }}}
        // {{{ update queries
        'entry'                             => [
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (event_id, user_id, gacha_id, date, ctime) VALUES (:event_id, :user_id, :gacha_id, :date, NOW())',
            'return_last_insert_id' => true,
        ],
        // }}}
        // {{{
        'create_table'                      => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                  `event_id` INT UNSIGNED NOT NULL,
                  `user_id`  INT UNSIGNED NOT NULL,
                  `gacha_id` INT UNSIGNED NOT NULL,
                  `date` INT UNSIGNED NOT NULL,
                  `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`),
                  UNIQUE KEY `event_id_user_id_date` (`event_id`,`user_id`,`date`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
        ],
        // }}}
        // {{{ only debug
        'drop_table' => [
            'sql' => 'DROP TABLE IF EXISTS __TABLE_NAME__',
        ],
        'delete'     => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        // }}}
    ];

    public function _init()
    {
        parent::_init();
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
}
