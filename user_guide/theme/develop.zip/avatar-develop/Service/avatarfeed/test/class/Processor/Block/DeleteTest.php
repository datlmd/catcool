<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Block_DeleteTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Block_DeleteTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module_block;
    var $module_follow;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module_block  = Gree_Service_AvatarFeed_Module::singleton('Block');
        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_block->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        $this->initialize_following_status();
        $this->initialize_followed_status();
        $this->initialize_block_status();

        list($has_more, $empty_following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_following_user_ids));

        list($has_more, $empty_followed_user_ids) = $this->module_follow->getFollowedListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_followed_user_ids));

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($block_user_ids));
    }

    public function test_add_not_following_user()
    {
        $add_block_result = $this->module_block->addBlockUser(UNIT_TEST_USER_ID_2);

        $this->assertEquals(1, $add_block_result);

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertFalse($has_more);
        $this->assertEquals(1, count($block_user_ids));
        $block_user = array_shift($block_user_ids);
        $this->assertEquals(UNIT_TEST_USER_ID_2, $block_user['content']['sender_id']);

        $block_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
        );

        $delete_result = $this->avatar_feed->process('block_delete', $block_params);

        $this->assertTrue($delete_result);

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertFalse($has_more);
        $this->assertEquals(0, count($block_user_ids));

        list($has_more, $empty_followed_user_ids) = $this->module_follow->getFollowedListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_followed_user_ids));

        $delete_result_2 = $this->avatar_feed->process('block_delete', $block_params);

        $this->assertFalse($delete_result_2);
    }

    public function test_add_following_user()
    {
        $this->module_follow->addFollowingUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
        $this->module_block->addBlockUser(UNIT_TEST_USER_ID_2);

        $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1, 0, 0);
        $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_2, 1, 0);

        $block_params = array(
            'user_id'  => UNIT_TEST_USER_ID_2,
        );
        $delete_result = $this->avatar_feed->process('block_delete', $block_params);

        $this->assertTrue($delete_result);

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertFalse($has_more);
        $this->assertEquals(0, count($block_user_ids));

        list($has_more_followed, $followed_users) = $this->module_follow->getFollowedListOrderInTime(
            UNIT_TEST_USER_ID_1,
            10,
            0
        );

        $this->assertFalse($has_more_followed);
        $this->assertEquals(1, count($followed_users));
        $followed_user = array_shift($followed_users);
        $this->assertEquals($block_params['user_id'], $followed_user['content']['sender_id']);

        list($following_count, $followed_count) = $this->module_follow->getFollowCount();
        $this->assertEquals(1, $followed_count);
    }
}