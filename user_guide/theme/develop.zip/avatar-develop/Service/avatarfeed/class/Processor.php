<?php

abstract class Gree_Service_AvatarFeed_Processor
    extends Gree_Service_AvatarFeed_Object
{
    protected $input_values = array();

    public final static function execute($name,
                                         $values = array(),
                                         $set_user = null)// for unit test
    {
        static $instances = array();

        // we need to initialize internal properties in processor instance,
        // so we use clone function.
        if (!isset($instances[$name])) {
            $instances[$name] = self::factory($name);
        }
        $proc = clone $instances[$name];
        if (Config::get('state') == 'dev' && isset($set_user)){
            $proc->setUserIDtoCtfy($set_user);
        }
        $proc->init($values);
        try {
            $result = $proc->invoke();
        } catch (Exception $ex) {
            throw $ex;
        }

        return $result;
    }

    protected final static function factory($name)
    {
        // detect module class name by given name
        static $base = __CLASS__;
        $class = $base . '_'
            . implode('_', array_map('ucfirst', explode('_', $name)));
        if (!class_exists($class)) {
            $message = 'Could not found class definition';
            $context = array('name' => $name, 'class' => $class);
            $code    = Gree_Service_AvatarFeed_Exception::E_NOT_FOUND_CLASS_DEF;
            throw new  Gree_Service_AvatarFeed_Exception($message, $code, $context);
        }
        // factory and verify instance
        $module = new $class($name);
        if (($module instanceof $base) === false) {
            $message = 'Does not match type of mould instance';
            $context = array('name' => $name, 'class' => $class);
            $code    = Gree_Service_AvatarFeed_Exception::E_INVALID_INSTANCE;
            throw new  Gree_Service_AvatarFeed_Exception($message, $code, $context);
        }

        return $module;
    }

    abstract protected function invoke();

    private final function init($values)
    {
        $this->input_values = $values;
    }
}
