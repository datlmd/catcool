<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	SplitRankingDao.php
 *
 *	����åץ�󥭥󥰥ơ��֥�
 *
 *	@author		Yusuke Hisaoka <hisaoka@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: SplitRankingDao.php 29804 2008-03-11 06:42:42Z  $
 */
class Gree_GenericDao_Shop_SplitRankingDao extends Gree_GenericDao {

	var $_table_name = 'shop_split_ranking';
	var $_primary_key = 'id';
	var $_auto_increment = true;
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';
	var $_queries = array(
		// �桼��������ͭ���뾦�ʤǺ������Ƥ��ʤ���Τΰ�����
		'find_by_date' => array(
			'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE date = :date'
		),
		'get_max_date' => array(
			'sql' => 'select max(date) as max  from __TABLE_NAME__ WHERE group_code IN (:group_code_list)'
		),
		'get_max_date_all' => array(
			'sql' => 'select max(date) as max  from __TABLE_NAME__'
		),
		'find_for_ranking' =>  array(
			'sql' => 'select * from __TABLE_NAME__ where date = :date AND group_code IN (:group_code_list) AND sex <> :exclude_sex order by count desc'
		),
		'find_for_ranking_all' =>  array(
			'sql' => 'select * from __TABLE_NAME__ where date = :date AND sex <> :exclude_sex order by count desc'
		),
        'count_for_ranking' =>  array(
            'sql' => 'select count(*) from __TABLE_NAME__ where date = :date AND group_code IN (:group_code_list) AND sex <> :exclude_sex'
        ),
        'count_for_ranking_all' =>  array(
            'sql' => 'select count(*) from __TABLE_NAME__ where date = :date AND sex <> :exclude_sex'
        ),
        'get_max_date_by_id' => [
            'sql' => 'SELECT MAX(date) as max  FROM __TABLE_NAME__ WHERE group_code IN (:group_code_list) AND id > :start_id'
        ],
        'get_max_date_all_by_id' => [
            'sql' => 'select max(date) as max  from __TABLE_NAME__ WHERE id > :start_id'
        ],
	);

}
?>
