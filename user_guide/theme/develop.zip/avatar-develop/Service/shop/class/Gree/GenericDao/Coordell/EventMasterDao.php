<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Coordell/EventMasterDao.php
 *
 * @author      Thien Nguyen <z.thanhthien.nguyen@gree.net>
 * @package     GREE Avatar
 * @since       2016-05-17
 */

/**
 * EventMaster form constructor
 * @access      public
 */
class Gree_GenericDao_Coordell_EventMasterDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'coordell_event_master';

    /** @var primary key */
    var $_primary_key = 'event_id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_coordell';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_coordell';

    /** @var field names */
    var $_field_names = array(
        'event_id',
        'start_datetime',
        'new_post_datetime',
        'post_end_datetime',
        'post_end_datetime_plus',
        'end_datetime',
        'mtime',
        'ctime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__  ORDER BY event_id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (start_datetime, new_post_datetime, post_end_datetime,post_end_datetime_plus, end_datetime, ctime) VALUES (:start_datetime, :new_post_datetime, :post_end_datetime, :post_end_datetime_plus, :end_datetime, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET start_datetime = :start_datetime, new_post_datetime = :new_post_datetime, post_end_datetime = :post_end_datetime, post_end_datetime_plus = :post_end_datetime_plus, end_datetime = :end_datetime WHERE event_id = :event_id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE event_id = :event_id',
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `event_id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                  `start_datetime` DATETIME NOT NULL,
                  `new_post_datetime` DATETIME NOT NULL,
                  `post_end_datetime` DATETIME NOT NULL,
                  `post_end_datetime_plus` DATETIME NOT NULL,
                  `end_datetime` DATETIME NOT NULL,
                  `ctime` DATETIME NOT NULL DEFAULT '00-00-00 00\:00\:00',
                  `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`event_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"

        ),
        // }}}
    );
}
