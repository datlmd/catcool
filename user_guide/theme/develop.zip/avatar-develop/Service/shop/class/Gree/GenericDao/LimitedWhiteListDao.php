<?php

class Gree_GenericDao_LimitedWhiteListDao extends Gree_GenericDao
{
    public $_table_name = 'limited_white_list';

    public $_primary_key = 'id';

    public $_created_at_column = 'ctime';

    public $_updated_at_column = 'mtime';

    public $_master_dsn = 'gree://master/avatar_user';

    public $_slave_dsn  = 'gree://slave/avatar_user';

    public $_auto_increment = true;

    public $_field_names = [
        'id',
        'user_id',
        'limited_type',
        'mtime',
        'ctime',
    ];

    public $_queries = [

        //Refer queries
        'find_all' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY user_id DESC'
        ],
        'find_user_id_by_user_ids' => [
            'sql' => 'SELECT user_id FROM __TABLE_NAME__ WHERE user_id in (:user_ids) AND limited_type = :limited_type'
        ],
        'find_by_limited_type' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE limited_type = :limited_type ORDER BY user_id DESC'
        ],

        //Insert query
        'insert' => [
            'sql' => "
            INSERT IGNORE INTO __TABLE_NAME__ (
                    id,
                    user_id,
                    limited_type,
                    mtime,
                    ctime,
                )
                VALUES(
                    DEFAULT,
                    :user_id,
                    :limited_type,
                    NOW(),
                    NOW()
                )
            ",
        ],

        //Create table query
        'create_table' => [
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` int(10) NOT NULL,
                `limited_type` tinyint(4) UNSIGNED NOT NULL,
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE (`user_id`, `limited_type`),
                KEY `user_idx` (`user_id`),
                KEY `limited_type` (`limited_type`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ],

        // Delete query
        'delete_by_user_ids' => [
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id in (:user_ids) AND limited_type = :limited_type'
        ],
    ];

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
