<?php

    require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

    class Gree_GenericDao_Studio_CatalogDao extends Gree_GenericDao_Apc
    {
        /** @var table name */
        var $_table_name = 'studio_catalog';
        /** @var primary key */
        var $_primary_key = 'id';
        /** @var auto increment */
        var $_auto_increment = true;
        /** @var created at column */
        var $_created_at_column = 'ctime';
        /** @var updated at column */
        var $_updated_at_column = 'mtime';
        /** @var master dsn */
        var $_master_dsn = 'gree://master/avatar_studio';
        /** @var slave dsn */
        var $_slave_dsn = 'gree://slave/avatar_studio';
        /** @var field names */
        var $_field_names = [
            'id',
            'item_id',
            'status',
            'after_item_id',
            'gacha_type',
            'gacha_id',
            'gacha_sex',
            'item_category',
            'item_sex',
            'rarity',
            'start_dt',
            'end_dt',
            'mtime',
            'ctime',
        ];
        /** @var query definitions */
        var $_queries = [
            // {{{ refer queries
            'find_all_and_sort_desc' => [
                'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY `item_id` DESC',
            ],
            'find_by_item_id'        => [
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `item_id` = :item_id',
            ],
            'count_all'              => [
                'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__',
            ],

            'find_by_gacha_id'                                              => [
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `gacha_id` = :gacha_id AND `status` = :status AND `start_dt` <= :now ORDER BY `id` DESC',
            ],

            //for fp only
            'find_all_by_item_sex_and_status_and_gacha_sex'                 => [
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `item_sex` IN (:item_sex) AND `gacha_sex` IN (:gacha_sex) AND `status` = :status AND `start_dt` <= :now ORDER BY `id` DESC',
            ],
            //for fp only
            'count_all_by_item_sex_and_status_and_gacha_sex'                => [
                'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE `item_sex` IN (:item_sex) AND `gacha_sex` IN (:gacha_sex) AND `status` = :status AND `start_dt` <= :now ',
            ],

            //for fp only
            //since item_category does not use in but uses '='
            'find_all_by_item_sex_and_status_and_group_code_and_gacha_sex'  => [
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE `item_category` = :item_category AND `item_sex` IN (:item_sex) AND `gacha_sex` IN (:gacha_sex) AND `status` = :status AND `start_dt` <= :now ORDER BY `id` DESC',
            ],
            //for fp only
            //since item_category does not use in but uses '='
            'count_all_by_item_sex_and_status_and_group_code_and_gacha_sex' => [
                'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE `item_category` = :item_category AND `item_sex` IN (:item_sex) AND `gacha_sex` IN (:gacha_sex) AND `status` = :status AND `start_dt` <= :now',
            ],
            // }}}

            // {{{ update queries
            'entry'                                                         => [
                'sql'                   => "INSERT IGNORE INTO __TABLE_NAME__ (
                `item_id`, 
                `status`, 
                `after_item_id`, 
                `gacha_type`, 
                `gacha_id`, 
                `gacha_sex`,
                `item_category`, 
                `item_sex`, 
                `rarity`, 
                `start_dt`, 
                `end_dt`, 
                `ctime`
            ) VALUES (
                :item_id, 
                :status, 
                :after_item_id, 
                :gacha_type, 
                :gacha_id, 
                :gacha_sex,
                :item_category, 
                :item_sex, 
                :rarity, 
                :start_dt, 
                :end_dt, 
                NOW()
            )",
                'return_last_insert_id' => true,
            ],
            'update_status_after_item_id_and_start_dt_and_end_dt'           => [
                'sql' => 'UPDATE __TABLE_NAME__ SET 
                `status`        = :status, 
                `after_item_id` = :after_item_id, 
                `start_dt`      = :start_dt, 
                `end_dt`        = :end_dt
                WHERE `item_id` = :item_id',
            ],
            'update_status_by_item_ids'                                     => [
                'sql' => 'UPDATE __TABLE_NAME__ SET `status` = :status WHERE `item_id` IN (:item_ids)',
            ],
            'update_start_dt_by_item_ids'                                   => [
                'sql' => 'UPDATE __TABLE_NAME__  SET `start_dt` = :start_dt WHERE `item_id` IN (:item_ids)',
            ],
            'update_end_dt_by_item_ids'                                     => [
                'sql' => 'UPDATE __TABLE_NAME__ SET `end_dt` = :end_dt WHERE `item_id` IN (:item_ids)',
            ],
            // }}}

            'create_table' => [
                'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `item_id` INT UNSIGNED NOT NULL,
                `status` TINYINT UNSIGNED NOT NULL,
                `after_item_id` text NOT NULL,
                `gacha_type` INT UNSIGNED NOT NULL,
                `gacha_id` INT UNSIGNED NOT NULL,
                `gacha_sex` TINYINT UNSIGNED NOT NULL,
                `item_category` INT UNSIGNED NOT NULL,
                `item_sex` TINYINT UNSIGNED NOT NULL,
                `rarity` TINYINT UNSIGNED NOT NULL,
                `start_dt` timestamp NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `end_dt` timestamp NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`),
                UNIQUE (`item_id`,`gacha_id`),
                KEY `gacha_type_idx` (`gacha_type`),
                KEY `item_category_idx` (`item_category`),
                KEY `item_sex_idx` (`item_sex`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;",
            ],
            // }}}
        ];
    }
