<?php

class Gree_Service_AvatarFeed_Processor_Follow_User_Status
    extends Gree_Service_AvatarFeed_Processor_Base
{
    /**
     * get status for delete/delete_reserve user and update it into current user data
     * @param $following user data
     * @return $following user data
     */
    protected function invoke()
    {
        $user_data = $this->input_values;

        foreach ($user_data as $l => $user) {
            if ($user['content']['user_info']['nick_name'] === null) {
                list($status, $status_text) = $this->_getUserStatus($user['content']['sender_id']);
                $user_data[$l]['content']['sender_status'] = $status;
                $user_data[$l]['content']['sender_status_text'] = $status_text;
            }
        }

        return $user_data;
    }

    private function _getUserStatus($user_id)
    {
        $status = null;
        $mod_user = self::getModule('User');

        try {
            $status = $mod_user->getUserStatus($user_id);
        } catch (Exception $e) {
            $msg     = 'failed get the follow user status';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_FOLLOW;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
        }

        switch ($status) {
            case USER_STATUS_DELETE_RESERVE:
                $status_text = GREE_SERVICE_AVATAR_USER_STATUS_TEXT_DELETE_RESERVE;
                break;
            case USER_STATUS_DELETE:
                $status_text = GREE_SERVICE_AVATAR_USER_STATUS_TEXT_DELETE;
                break;
            case USER_STATUS_STOP:
                $status_text = GREE_SERVICE_AVATAR_USER_STATUS_TEXT_STOP;
                break;
            case USER_STATUS_ALIVE:
                $status_text = GREE_SERVICE_AVATAR_USER_STATUS_TEXT_ALIVE;
                break;
            default:
                 $status_text = null;
        }

        return array(
            $status,
            $status_text,
        );
    }
}
