<?php

$start_time = microtime(true);
require "/home/gree/src/Gree_Bootstrap.php";
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once PATH_SRC_CLASS . '/Gree/CLI.php';
echo '-------------------------------------------' . PHP_EOL;
echo ' Create Table... ' . PHP_EOL;
echo '-------------------------------------------' . PHP_EOL;

$accessor_oauth        = Cascade::getAccessor('avatar_feed#oauth');
$accessor_follow_count = Cascade::getAccessor('avatar_feed#follow_count');
$accessor_block        = Cascade::getAccessor('avatar_feed#block');

$hint = array(
    'user_id' => 1,
);
/*


d("oauth");
$accessor_oauth->execute('create_table', $hint);

d("follow_count");
$accessor_follow_count->execute('create_table', $hint);

d("block");
$accessor_block->execute('create_table', $hint);

$accessor_following = Cascade::getAccessor('avatar_feed#following');
for ($user_id = 1; $user_id <= 8; $user_id++) {
    d("following", $user_id);
    $hint = array(
        'user_id' => $user_id,
    );
    $accessor_following->execute('create_table', $hint);
}
$accessor_followed = Cascade::getAccessor('avatar_feed#followed');
for ($user_id = 1; $user_id <= 8; $user_id++) {
    d("followed", $user_id);
    $hint = array(
        'user_id' => $user_id,
    );
    $accessor_followed->execute('create_table', $hint);
}
*/
d("setting_incentive_point");
$accessor_setting_incentive_point = Cascade::getAccessor('avatar_feed#setting_incentive_point');
$accessor_setting_incentive_point->execute('create_table', $hint);

echo "[DONE]\t" . sprintf('%.3f', (microtime(TRUE) - $start_time)) . PHP_EOL;