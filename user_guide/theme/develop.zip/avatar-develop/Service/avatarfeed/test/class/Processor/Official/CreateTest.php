<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Official_Create
 *
 * this test is create entry process
 */
final class Gree_Service_Avatarfeed_Test_Processor_Official_Crate
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;

    var $module_follow;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('AppFeed');

        try {
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
        } catch (Exception $e) {
        }

        try {
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
            $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_2);
        } catch (Exception $e) {
        }
    }

    /**
     * test1:
     * Success Create Entry
     * is_success == true
     * entry_id   == string
     *
     * test2
     * Failed Crate Entry
     * is success == false
     * entry_id   == null
     */
    public function test_official_create_entry()
    {
        // test1
        $create_params = array(
            'entry_category' => 'change_mood',
            'text'           => 'test_official_create_entry',
            'avatar_key'     => 'test',
            'destination_user_id' => 527781,
        );
        list($is_create_entry, $entry_id) = $this->avatar_feed->process('official_entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertTrue($is_create_entry);

        list($is_exist, $entry) = $this->module->getEntry($entry_id);
        $entry_data = array_shift($entry);
        $this->assertTrue($is_exist);
        $this->assertEquals($entry_id, $entry_data['entry_id']);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $entry_data['content']['sender_id']);
        $this->assertEquals('mood', $entry_data['content']['entry_type']);
        $this->assertEquals($create_params['text'], $entry_data['content']['text']);
        $this->assertEquals('change_mood', $entry_data['content']['attr']['entry_category']);

        $expect_destinations = array(
            array(
                'type'  => 'feed_key',
                'value' => '2164:default:' . $create_params['destination_user_id'] 
            )
        );
        $this->assertEquals($expect_destinations, $entry_data['destinations']);

        // test2
        $create_params = array(
            'entry_category' => 'change',
            'text'           => 'test_official_create_entry',
            'destination_user_id' => 527781,
        );
        list($is_create_entry, $entry_id_2) = $this->avatar_feed->process('official_entry_create', $create_params, UNIT_TEST_USER_ID_1);
        $this->assertFalse($is_create_entry);
        $this->assertTrue(is_null($entry_id_2));


    }

}
