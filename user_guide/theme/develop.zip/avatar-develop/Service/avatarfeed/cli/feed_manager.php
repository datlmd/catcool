<?php

require_once("/home/gree/xgree/avatar/Service/avatarfeed/cli/Base.php");

class Gree_Service_AvatarFeed_Cli_FeedManager
    extends Gree_Service_AvatarFeed_Cli_Base
{
    public function main()
    {
        $this->_initialize();

        $this->_print_header('feed_manager');

        $this->short_opt = "m:u:d:";
        $this->opt_names = array(
            'destination_user_id='
        );
        $this->input_opt_list = $this->_get_parse_arg_list();

        try {
            $set_options = $this->_set_option_value();
            $this->_invoke($set_options);
        } catch (Exception $e) {
            printf("finish with error. \n");
            printf($e->getMessage() . " \n");
        }

        $this->_print_footer();
    }

    public function _find_input_option($option)
    {
        $option_name = null;
        $option_value = null;

        switch ($option[0]) {
            case 'm':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'mode';
                $option_value = $option[1];
                break;
            case 'u':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'user_id';
                $option_value = $option[1];
                break;
            case 'd':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'date';
                $option_value = $option[1];
                break;
            case '--destination_user_id';
                $option_name = 'destination_user_id';
                $option_value = $option[1];
                break;
            default:
                printf("please input mode \n");
                throw new Exception();
        }

        return array(
            $option_name,
            $option_value,
        );
    }

    public function _invoke($option)
    {
        switch ($option['mode']) {
            case 'createEntry':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }

                if (!isset($option['text'])) {
                    $date = date("Y-m-d H:i:s");      ;
                    $option['text'] = 'from feed manager' . $date;
                }

                if (!isset($option['destination_user_id'])) {
                    printf("need destination_user_id.\n");
                    throw new Exception();
                }

                $this->_createEntry($option);
                break;
            default:
                printf("please input exist mode\n");
                throw new Exception();
        }
    }

    public function _createEntry($option)
    {
        printf("Create Entry \n");
        printf("user_id: " . $option['user_id'] . "\n");

        $create_params = array(
            'content'      => array(
                'sender_id'  => $option['user_id'],
                'entry_type' => 'mood',
                'text'       => $option['text'],
                'attr'       => array(
                    'entry_category' => 'mood',
                ),
            ),
            'destinations' => array(array(
                                        'type'  => 'feed_key',
                                        'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $option['destination_user_id']
                                    )),
        );
        $this->module->setUserIDtoCtfy($option['user_id']);
        $entry_id = $this->module->createEntry($create_params);

        printf("entry_id: " . $entry_id . "\n");
    }
}

$class = new Gree_Service_AvatarFeed_Cli_FeedManager();
$class->main();