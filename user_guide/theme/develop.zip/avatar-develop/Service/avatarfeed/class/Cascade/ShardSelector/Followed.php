<?php

class Gree_Service_AvatarFeed_Cascade_ShardSelector_Followed
    extends Gree_Service_AvatarFeed_Cascade_ShardSelector_Base
{
    protected $index_criteria_params = 'user_id';
    protected $division_count_dsn    = 1;
    protected $division_count_table  = 8;
    protected $format_suffix_table   = '_%03d';
}