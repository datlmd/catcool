<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/MixerDao.php
 *
 *  @author   Jun Tomioka <jun.tomioka@gree.net>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_MixerDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var �ơ��֥�̾ */
    var $_table_name = 'mixer';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_analytics';

    /** @var ��Ͽ�������̾ */
    var $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = [
        'id',
        'datetime',
        'service',
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'action1',
        'action2',
        'item_id',
        'price',
        'having_point',
        'mixer_type',
        'mixer_id',
        'is_tld_net',
        'is_app',
        'id_a',
        'id_b',
        'rare',
        'ctime',
    ];

    /**
     * @var �����������
     */
    var $_queries = [
        // {{{ ������
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    id              INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                    datetime        DATETIME NOT NULL,
                    service         VARCHAR(16) NOT NULL,
                    user_id         BIGINT(20) UNSIGNED NOT NULL,
                    user_sex        TINYINT(4) NOT NULL,
                    user_age        TINYINT(4) NOT NULL,
                    phone_carrier   TINYINT(4) NOT NULL,
                    action1         VARCHAR(255) NOT NULL,
                    action2         VARCHAR(255) NOT NULL,
                    item_id         INT(10) UNSIGNED NOT NULL,
                    price           INT(10) UNSIGNED NOT NULL,
                    having_point    INT(10) UNSIGNED NOT NULL,
                    mixer_type      TINYINT(4) NOT NULL,
                    mixer_id        INT(10) UNSIGNED NOT NULL,
                    is_tld_net      TINYINT(4),
                    is_app          TINYINT(4),
                    id_a            INT(10) UNSIGNED NOT NULL,
                    id_b            INT(10) UNSIGNED NOT NULL,
                    rare            TINYINT(4) NOT NULL,
                    ctime           DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                    PRIMARY KEY  (id),
                    KEY datetime (datetime),
                    KEY service (service),
                    KEY user_id (user_id),
                    KEY user_sex (user_sex),
                    KEY user_age (user_age),
                    KEY phone_carrier (phone_carrier),
                    KEY action1 (action1),
                    KEY action2 (action2),
                    KEY item_id (item_id),
                    KEY price (price),
                    KEY having_point (having_point),
                    KEY mixer_type (mixer_type),
                    KEY mixer_id (mixer_id),
                    KEY id_a (id_a),
                    KEY id_b (id_b),
                    KEY rare (rare)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ],
        'drop_table' => [
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ],
        // }}}
        // {{{ ���ȷ�
        'find_by_user_id' => [
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ],
        'get_summary' => [
            'sql' => '
                SELECT
                    user_id,
                    user_sex,
                    user_age,
                    phone_carrier,
                    sum(price) as mixer_spent_coin,
                    COUNT(*) AS use_mixer_count
                FROM __TABLE_NAME__
                WHERE price > 0
                GROUP BY user_id
            '
        ],
        'count_by_user_id' => [
            'sql' => 'SELECT COUNT(item_id) AS cnt, SUM(price) AS sum FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ],
        'count_by_user_id_and_type' => [
            'sql' => 'SELECT COUNT(item_id) AS cnt, SUM(price) AS sum FROM __TABLE_NAME__ WHERE user_id = :user_id AND purchase_type = :purchase_type',
        ],
        'show_tables' => [
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ],
        // }}}

        // {{{
        'get_summary_by_mixer_id_and_service' => [
            'sql' => '
                SELECT SUM(price) AS sum
                FROM __TABLE_NAME__
                WHERE mixer_id = :mixer_id AND service = :service',
        ],
        // }}}
    ];
    /** #@- */
}

