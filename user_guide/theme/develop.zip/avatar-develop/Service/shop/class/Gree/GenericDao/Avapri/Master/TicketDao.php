<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 * Gree_GenericDao_AvapriMasterTicketDao
 * 
 * @author      norie.matsuda <norie.matsuda@gree.net> 
 * @package     GREE
 */
class Gree_GenericDao_Avapri_Master_TicketDao extends Gree_GenericDao_Apc
{
	/** @var table name */
    var $_table_name = 'master_seal_ticket';
	/** @var primary key */
    var $_primary_key = 'ticket_id';
    /** @var auto increment */
    var $_auto_increment = true;
	/** @var updated at column */
    var $_updated_at_column = 'mtime';
	/** @var create at column */
    var $_created_at_column = 'ctime';
    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_print';
    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_print';
    
    /** @var field names */
    var $_field_names = array(
        'ticket_id',
        'name',
        'state',
        'level',
        'open_datetime',
        'close_datetime',
        'ctime',
        'mtime'
    );

    var $_queries = array(
        'find_by_ticket_id_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE ticket_id = :ticket_id AND state=:state',
        ),
        'get_all_master' => array( // for support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY ticket_id DESC',
        ),
        // update----------------------
        'update_setting' => array( // for support tool
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state, name = :name, num = :num, open_datetime=:open_datetime, close_datetime = :close_datetime WHERE ticket_id =:ticket_id',
        ),
        // insert----------------------
        'insert_ticket' => array( // for support tool
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (name, state, num, open_datetime, close_datetime, ctime) VALUES (:name, :state, :num, :open_datetime, :close_datetime, NOW())',
        ),
        // create table ----------------
        'create_table' => array(
            'sql' => "
            CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `ticket_id` int(11) unsigned NOT NULL auto_increment,
                `name` varchar(255) NOT NULL default '',
                `state` tinyint(4) unsigned NOT NULL default '1',
                `level` tinyint(4) unsigned NOT NULL default '0',
                `num` tinyint(4) unsigned NOT NULL default '0',
                `open_datetime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `close_datetime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                PRIMARY KEY  (`ticket_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=ujis",
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        'delete_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
    );
}
?>
