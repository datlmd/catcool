<?php
/**
 * GachaMapper.php
 */
class Gree_Service_Shop_Data_User_ContestMapper extends Gree_Service_Shop_Data_Mapper
{
    // ----[ Constants ]--------------------------------------------------------
    const MASTER_DAO = 'Contest_InfoMaster';
    protected $primary_key = 'user_id';



    private $_contest_master_keys = array("contest_id", "status", "name",
        "open_datetime", "close_datetime",
        "vote_open_datetime", "vote_close_datetime",
        "vote_limit_change_count", "vote_limit_change_open_datetime",
        "vote_limit_change_close_datetime", "invite_limit_count",
        "invite_vote_increase_amount", "invite_open_datetime",
        "invite_close_datetime", "secret_open_datetime"
    );

    // ----[ Override Methods ]-------------------------------------------------
    /**
     * load accessor from gacha id
     *
     * @override
     * @param   int
     * @return  array
     */
    protected function load($primary_key, $hint = null)
    {
        $list = $this->session->toArray(self::MASTER_DAO, 'all', null);
        if (PEAR::isError($list)) {
            return $list;
        } elseif (empty($list)) {
            throw new Gree_Service_Shop_Exception_DataException('Invalid Data (Contest)', $code = "001");
        }
        $active_list = array();
        foreach ($list as $v) {
            if ($v['status'] == GREE_SERVICE_SHOP_AVATAR_CONTEST_MASTER_STATUS_RELEASED) {
                $active_list[] = $v;
            }
        }

        if ((Config::get('state') == "staging" || Config::get('state') == 'dev')) {
            if (count($list) === 0) {
                throw new Gree_Service_Shop_Exception_DataException('Invalid Data (Contest)', $code = "003");
            }
            $contest_master = $list[0];
            if (!$this->_validateContestMaster($contest_master)) {
                throw new Gree_Service_Shop_Exception_DataException("Invalid contest master format.");
            }
            $this->_status = GREE_SERVICE_SHOP_AVATAR_CONTEST_MASTER_STATUS_RELEASED;
        } else if (!isset($active_list[0])) {
            throw new Gree_Service_Shop_Exception_DataException('Invalid Data (Contest)', $code = "002");
        } else if (isset($active_list[0])) {
            if (count($active_list) > 1) {
                throw new Gree_Service_Shop_Exception_DataException('Multiple active contest.');
            }
            $contest_master         = $list[0];
            $this->_status = $list[0]['status'];
            if (!$this->_validateContestMaster($contest_master)) {
                throw new Gree_Service_Shop_Exception_DataException("Invalid contest master format.");
            }
        }
        if (!is_null($hint)){
            $contest_master = array_merge($contest_master,$hint);
        }
        return $contest_master;
    }
    /**
     * _validateContestMaster
     * Checks to see all the required fields are filled.
     *
     * @param $master contest master array
     *
     * @return bool
     */
    protected function _validateContestMaster($master) {
        foreach ($this->_contest_master_keys as $key) {
            if (array_key_exists($key, $master)) {
                if (strpos($key, "datetime") > -1) {
                    if (!strtotime($master[$key])) {
                        return false;
                    }
                    ;
                }
            } else {
                if (is_null($master[$key])) {
                    return false;
                }
            }
        }

        return true;
    }
    /**
     * mload accessors from gacha ids
     *
     * @override
     * @param   int
     * @return  array
     */
    protected function mload(array $gacha_ids)
    {
        return $this->session->toArray(
            self::DAO_NAME,
            'find_by_ids',
            array('ids' => $gacha_ids)
        );
    }
}
