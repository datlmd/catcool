<?php


/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Block_List_ShowTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Block_List_ShowTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module_block;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module_block = Gree_Service_AvatarFeed_Module::singleton('Block');
        $this->module_block->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        $this->initialize_block_status();

        list($has_more, $block_user_ids) = $this->module_block->getBlockListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($block_user_ids));
    }

    public function test_get_no_block_list()
    {

        $get_params = array(
            'user_id' => UNIT_TEST_USER_ID_1,
            'limit'   => 10,
            'offset'  => 0
        );
        list($has_more, $block_list) = $this->avatar_feed->process('block_list_show', $get_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more);
        $this->assertEmpty($block_list);
    }

    /**
     * test1:
     *   case  : offset == 0, limit == 2
     *   expect: has_more == true, count(list) == 2
     * test2:
     *   case  : offset == 2, limit == 2
     *   expect: has_more == false, count(list) == 2
     */
    public function test_get_block_list()
    {
        $this->module_block->addBlockUser(UNIT_TEST_USER_ID_2);
        $this->module_block->addBlockUser(UNIT_TEST_USER_ID_3);
        $this->module_block->addBlockUser(UNIT_TEST_USER_ID_4);
        $this->module_block->addBlockUser(UNIT_TEST_USER_ID_5);

        // test1
        $get_params = array(
            'user_id' => UNIT_TEST_USER_ID_1,
            'limit'   => 2,
            'offset'  => 0
        );
        list($has_more, $block_list) = $this->avatar_feed->process('block_list_show', $get_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($has_more);
        $this->assertEquals($get_params['limit'], count($block_list));
        $block_list_1 = array_shift($block_list);
        $this->assertEquals(UNIT_TEST_USER_ID_5, $block_list_1['content']['sender_id']);
        $block_list_2 = array_shift($block_list);
        $this->assertEquals(UNIT_TEST_USER_ID_4, $block_list_2['content']['sender_id']);

        // test2
        $get_params_2 = array(
            'user_id' => UNIT_TEST_USER_ID_1,
            'limit'   => 2,
            'offset'  => 2
        );
        list($has_more_2, $block_list_2) = $this->avatar_feed->process('block_list_show', $get_params_2, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more_2);
        $this->assertEquals($get_params['limit'], count($block_list_2));
        $block_list_2_1 = array_shift($block_list_2);
        $this->assertEquals(UNIT_TEST_USER_ID_3, $block_list_2_1['content']['sender_id']);
        $block_list_2_2 = array_shift($block_list_2);
        $this->assertEquals(UNIT_TEST_USER_ID_2, $block_list_2_2['content']['sender_id']);
    }
}