<?php

define('CASCADE_CONFIG_DIR_PATH', dirname(__FILE__).'/conf');
require_once 'PHPUnit/Autoload.php';
require_once '/home/gree/src/Gree_Bootstrap.php';
require_once dirname(dirname(__FILE__)) . '/bootstrap.php';
require_once dirname(__FILE__) . '/class/Base.php';
require_once "/home/gree/xgree/avatar/Service/avatarfeed/service.php";

define('UNIT_TEST_USER_ID_1', 548662);
define('UNIT_TEST_USER_ID_2', 548670);
define('UNIT_TEST_USER_ID_3', 548672);
define('UNIT_TEST_USER_ID_4', 548673);
define('UNIT_TEST_USER_ID_5', 549160);
define('UNIT_TEST_OFFICIAL_USER_ID_1', 549162);
define('UNIT_TEST_OFFICIAL_THEME_USER_ID_1', 549548);
define('UNIT_TEST_OFFICIAL_THEME_USER_ID_2', 549549);
define('UNIT_TEST_OFFICIAL_THEME_USER_ID_3', 549550);
define('UNIT_TEST_OFFICIAL_THEME_USER_ID_4', 549825);
