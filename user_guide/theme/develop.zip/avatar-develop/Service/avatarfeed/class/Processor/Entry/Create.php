<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Entry_Create
 */
class Gree_Service_AvatarFeed_Processor_Entry_Create
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;
    var $mod_follow;
    var $followed_count;

    /**
     * @return array|void
     *
     * return array has is_success and etnry_id
     *
     * flow is
     *     - check parameter and followed user number => _getCreateParams()
     *     - create Entry
     *     - (add Destination)
     *       if $is_create_success && $is_require_additional_destination
     */
    protected function invoke()
    {
        $is_create_success = false;
        $entry_id          = null;

        list($is_require_additional_destination, $create_params) = $this->_getCreateParams($this->input_values['entry_category']);

        if ($create_params == false) {
            return array(
                $is_create_success,
                $entry_id
            );
        }

        try {
            $this->mod_appfeed = self::getModule('AppFeed');
            list($is_create_success, $entry_id) = $this->mod_appfeed->createEntry($create_params);
        } catch (Exception $e) {
            $msg     = 'failed create feed entry.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_CREATE;
            $context = $this->input_values;
            $context['request_error_code']      = $e->getCode();
            $context['request_error_message']   = $e->getMessage();

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array(
                $is_create_success,
                $entry_id
            );
        }

        if ($is_create_success && $is_require_additional_destination) {
            try {
                $this->_addDestination($entry_id);
            } catch (Exception $e) {
                $msg     = 'failed add destination.';
                $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_CREATE;
                $context = $this->input_values;

                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            }
        }

        return array(
            $is_create_success,
            $entry_id
        );
    }

    /**
     * @param $category
     * @return array
     *
     * return array has is_require_additional_destination, create params
     *
     * $create_params = array(
     *     'content'      => array(
     *          'sender_id'  => $this->_certified_user->my['user_id'],
     *          'entry_type' => 'mood',
     *          'text'       => $text,
     *          'attr'       => array(
     *              'entry_category' => $category,
     *          ),
     *     ),
     *     'destinations' => $destinations,
     * );
     *
     * flow is
     *     - check input value
     *     - check destination
     *     - create input params
     *     - add params of category-specific
     *
     * category-specific(type) is
     *     - change(activity): avatar key
     *     - avapri(activity): avatar key
     */
    public function _getCreateParams($category)
    {
        $text = '';
        if (isset($this->input_values['text'])) {
            $text = $this->input_values['text'];
        }

        list($is_require_additional_destination,
            $destination_users
            ) = $this->_getDestinations();

        $destinations = array();
        foreach ($destination_users as $user_id) {
            $destinations[] = array(
                'type'  => 'feed_key',
                'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $user_id
            );
        }
        // post user history
        $destinations[] = array(
            'type'  => 'feed_key',
            'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . 'user' . ':' . $this->_certified_user->my['user_id']
        );

        $create_params = array(
            'content'      => array(
                'sender_id'  => $this->_certified_user->my['user_id'],
                'entry_type' => 'mood',
                'text'       => $text,
                'attr'       => array(
                    'entry_category' => $category,
                ),
            ),
            'destinations' => $destinations,
        );
        if (!empty($this->input_values['effect_id'])) {
            $create_params['content']['attr']['effect_id'] = $this->input_values['effect_id'];
        }
        if (!empty($this->input_values['effect_css_type'])) {
            $create_params['content']['attr']['effect_css_type'] = $this->input_values['effect_css_type'];
        }

        switch ($category) {
            case 'change':
            case 'unsupported_change':
                $create_params['content']['text']       = GREE_SERVICE_AVATARFEED_DEFAULT_CHANGE_TEXT;
                $create_params['content']['entry_type'] = 'activity';
                if (isset($this->input_values['item_ids'])) {
                    $create_params['content']['attr']['item_ids'] = join(',', $this->input_values['item_ids']);
                }
                if (isset($this->input_values['avatar_key'])) {
                    $create_params['content']['attr']['avatar_key'] = $this->input_values['avatar_key'];
                } else {
                    $create_params = false;
                }
                break;
            case 'mood':
                $create_params['content']['text']       = $text;
                $create_params['content']['entry_type'] = 'mood';
                break;
            case 'avapri':
            case 'unsupported_avapri':
                $create_params['content']['text']       = GREE_SERVICE_AVATARFEED_AVAPRI_CREATE_TEXT;
                $create_params['content']['entry_type'] = 'activity';
                if (isset($this->input_values['members'])) {
                    $create_params['content']['attr']['members'] = join(',', $this->input_values['members']);
                }
                if (isset($this->input_values['avatar_key'])) {
                    $create_params['content']['attr']['avatar_key'] = $this->input_values['avatar_key'];
                } else {
                    $create_params = false;
                }
                break;
            default:
        }

        return array(
            $is_require_additional_destination,
            $create_params
        );
    }

    /**
     * @return array
     *
     * return array has is_require_additional_destination, destination_users
     *
     * check followed user number
     * if followed count > GREE_SERVICE_AVATARFEED_FIRST_DESTINATION_LIMIT
     *     is_require_additional_destination == true
     *     destination_users                 == certified_user
     * then
     *     is_require_additional_destination == false
     *     destination_users                 == followed users
     */
    public function _getDestinations()
    {
        $destination_users                 = array();
        $is_require_additional_destination = false;

        $this->mod_follow = self::getModule('Follow');

        list($following_count, $this->followed_count) = $this->mod_follow->getFollowCount();

        if ($this->followed_count > GREE_SERVICE_AVATARFEED_FIRST_DESTINATION_LIMIT) {
            $is_require_additional_destination = true;
            $destination_users[]               = $this->_certified_user->my['user_id'];
        } else {
            $destination_users   = $this->mod_follow->getFollowedListOrderInFollowedUser();
            $destination_users[] = $this->_certified_user->my['user_id'];
        }

        return array(
            $is_require_additional_destination,
            $destination_users
        );
    }

    /**
     * @param $entry_id
     */
    public function _addDestination($entry_id)
    {
        if ($this->followed_count > GREE_SERVICE_AVATARFEED_SECOND_DESTINATION_LIMIT) {
            $async_params = array(
                'entry_id'  => $entry_id,
                'sender_id' => $this->_certified_user->my['user_id'],
            );
            Gree_Async::add('shop::avatarfeed', 'addDestination', null, $async_params);
        } else {
            $destinations      = array();
            $destination_users = $this->mod_follow->getFollowedListOrderInFollowedUser(
                $this->_certified_user->my['user_id'],
                200, // limit
                0 // offset
            );
            foreach ($destination_users as $user_id) {
                $destinations[] = array(
                    'type'  => 'feed_key',
                    'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' .
                        GREE_SERVICE_AVATARFEED_DEFAULT_CATEGORY . ':' . $user_id
                );
            }

            $add_params = array(
                'entry_id'     => $entry_id,
                'destinations' => $destinations
            );
            $this->mod_appfeed->addDestination($add_params);
        }
    }
}
