<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Following_List_ShowTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Following_List_ShowTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module_follow;
    var $module_block;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');

        $this->initialize_following_status();

        list($has_more, $empty_following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_following_user_ids));
    }

    public function test_get_no_following_list()
    {

        $get_params = array(
            'user_id' => UNIT_TEST_USER_ID_1,
            'limit'   => 10,
            'offset'  => 0
        );
        list($has_more, $following_list) = $this->avatar_feed->process('following_list_show', $get_params, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more);
        $this->assertEmpty($following_list);
    }

    /**
     * test1:
     *   case  : offset == 0, limit == 2
     *   expect: has_more == true, count(list) == 2
     * test2:
     *   case  : offset == 2, limit == 2
     *   expect: has_more == false, count(list) == 2
     */
    public function test_get_following_list()
    {
        $this->module_follow->addFollowingUser(UNIT_TEST_USER_ID_1);
        $this->module_follow->addFollowingUser(UNIT_TEST_USER_ID_2);
        $this->module_follow->addFollowingUser(UNIT_TEST_USER_ID_3);
        $this->module_follow->addFollowingUser(UNIT_TEST_USER_ID_4);

        // test1
        $get_params = array(
            'user_id' => UNIT_TEST_USER_ID_1,
            'limit'   => 2,
            'offset'  => 0
        );
        list($has_more, $following_list) = $this->avatar_feed->process('following_list_show', $get_params, UNIT_TEST_USER_ID_1);

        $this->assertTrue($has_more);
        $this->assertEquals($get_params['limit'], count($following_list));
        $following_list_1 = array_shift($following_list);
        $this->assertEquals(UNIT_TEST_USER_ID_4, $following_list_1['content']['sender_id']);
        $following_list_2 = array_shift($following_list);
        $this->assertEquals(UNIT_TEST_USER_ID_3, $following_list_2['content']['sender_id']);

        // test2
        $get_params_2 = array(
            'user_id' => UNIT_TEST_USER_ID_1,
            'limit'   => 2,
            'offset'  => 2
        );
        list($has_more_2, $following_list_2) = $this->avatar_feed->process('following_list_show', $get_params_2, UNIT_TEST_USER_ID_1);

        $this->assertFalse($has_more_2);
        $this->assertEquals($get_params['limit'], count($following_list_2));
        $following_list_2_1 = array_shift($following_list_2);
        $this->assertEquals(UNIT_TEST_USER_ID_2, $following_list_2_1['content']['sender_id']);
        $following_list_2_2 = array_shift($following_list_2);
        $this->assertEquals(UNIT_TEST_USER_ID_1, $following_list_2_2['content']['sender_id']);
    }
}