<?php

class Gree_GenericDao_Analytics_GachaReport_BudgetDao extends Gree_GenericDao
{
    var $_table_name = 'gachareport_budget';

    var $_primary_key = 'id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_analytics';

    var $_slave_dsn = 'gree://slave/avatar_analytics';

    var $_auto_increment = true;

    var $_field_names = array(
        'id',
        'date',
        'budget',
        'target',
        'mtime',
        'ctime',
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `date` DATE NOT NULL,
                    `budget` INT UNSIGNED NOT NULL DEFAULT 0,
                    `target` INT UNSIGNED NOT NULL DEFAULT 0,
                    `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime` DATETIME NOT NULL,
                    PRIMARY KEY (id),
                    UNIQUE (date)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'insert_or_update' => array(
            'sql' => "INSERT INTO __TABLE_NAME__ (date, budget, target, ctime)
                      VALUES (:date, :budget, :target, NOW())
                      ON DUPLICATE KEY UPDATE budget = VALUES(budget), target = VALUES(target)",
        ),
        'find_by_date' => array(
            'sql' => "SELECT date, budget, target FROM  __TABLE_NAME__ WHERE date = :date",
        ),
        'find_by_date_range' => array(
            'sql' => "SELECT date, budget, target FROM  __TABLE_NAME__ WHERE date >= :begin and date < :end",
        ),
    );
}
