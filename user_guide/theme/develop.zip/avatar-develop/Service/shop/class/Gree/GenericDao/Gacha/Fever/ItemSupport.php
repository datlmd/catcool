<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Class Gree_GenericDao_Gacha_Fever_ItemSupportDao
 */
class Gree_GenericDao_Gacha_Fever_ItemSupportDao extends Gree_GenericDao_Apc
{

    /** @var �ơ��֥�̾ */
    public $_table_name = 'gacha_fever_item_support';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣 */
    public $_primary_key = 'item_id';

    /** @var �����������̾ */
    public $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    public $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    public $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    public $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �����ȥ��󥯥���� */
    public $_auto_increment = false;

    /** @var �ե������̾ */
    public $_field_names = [
        'item_id',
        'gacha_type',
        'input_gacha_id',
        'month',
        'gacha_reusable',
        'ctime',
        'mtime',
    ];

    /**
     * @var �����������
     */
    public $_queries = [
        // {{{ ������
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `item_id` INT NOT NULL,
                `gacha_type` INT NOT NULL,
                `input_gacha_id` INT NOT NULL,
                `month` INT NOT NULL,
                `gacha_reusable` INT NOT NULL DEFAULT 1,
                `mtime` DATETIME NOT NULL default CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL default CURRENT_TIMESTAMP,
                PRIMARY KEY  (`item_id`),
                UNIQUE KEY `gacha_id_and_item_id` (`gacha_type`,`input_gacha_id`,`item_id`),
                KEY `idx_month` (`month`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ],
        'drop_table'   => [
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ],
        'insert'       => [
            'sql' => "INSERT IGNORE INTO __TABLE_NAME__ (item_id, gacha_type, input_gacha_id, month, gacha_reusable) values (:item_id, :gacha_type, :input_gacha_id, :month, :gacha_reusable)",
        ],

        'select_gacha_ids_by_months'=>[
            'sql' => 'SELECT distinct gacha_type, input_gacha_id from __TABLE_NAME__ WHERE `month` IN (:months)',
        ],
        'select_by_months'=>[
            'sql' => 'SELECT * FROM `__TABLE_NAME__` WHERE `month` IN (:months)',
        ],
        'select_by_gacha_type_and_id'=>[
            'sql' => 'SELECT * FROM `__TABLE_NAME__` WHERE `gacha_type` = :gacha_type AND `input_gacha_id` = :input_gacha_id',
        ],
    ];
}
