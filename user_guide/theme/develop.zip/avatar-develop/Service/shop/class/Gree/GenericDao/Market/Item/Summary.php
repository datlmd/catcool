<?php

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/MarketFarmSelector.php';

/**
 * Gree_GenericDao_Market_Item
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_Item_SummaryDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'market_item_summary';

    /** @var primary key */
    var $_primary_key       = 'item_id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'item_id',
        'state',
        'group_code',
        'sex',
        'counter',              // sell count
        'min_point',            // min sell point
        'max_point',            // max sell point
        'total_point',          // total sell point
        'sell_border_id',       // border id that succeeded to sell
        'sell_border_user_id',  // border user id that succeeded to sell
        'bid_border_user_id',   // border user id that succeeded to buy
        'current_bid_border_point', // current bid border point
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        'find_all' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_except_time' => array(
            'sql' => 'SELECT item_id, counter, min_point, max_point, total_point FROM __TABLE_NAME__',
        ),
        'find_all_item_id' => array(
            'sql' => 'SELECT item_id FROM __TABLE_NAME__',
        ),
        'find_by_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state',
        ),
        'find_by_state_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state order by item_id desc',
        ),
        'find_by_state_bofore' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state order by item_id',
        ),
        'find_by_state_and_sex_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND sex = :sex order by item_id desc',
        ),
        'find_by_state_and_sex_before' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND sex = :sex order by item_id',
        ),
        'find_by_item_ids' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id in (:item_ids)',
        ),
        'find_by_item_ids_and_state' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id in (:item_ids) AND state = :state',
        ),
        'find_by_item_ids_and_state_order_by_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id in (:item_ids) AND state = :state order by item_id',
        ),
        'find_by_state_and_group' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND group_code = :group_code',
        ),
        'find_by_state_and_group_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND group_code = :group_code order by item_id desc',
        ),
        'find_by_state_and_group_before' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND group_code = :group_code order by item_id',
        ),
        'find_by_state_and_group_and_sex_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND group_code = :group_code AND sex = :sex order by item_id desc',
        ),
        'find_by_state_and_group_and_sex_before' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE state = :state AND group_code = :group_code AND sex = :sex order by item_id',
        ),
        'get_count_by_state' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE state = :state',
        ),
        'get_count_by_state_and_sex' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE state = :state AND sex = :sex',
        ),
        'get_count_by_item_ids_and_state' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE item_id in (:item_ids) AND state = :state',
        ),
        'get_count_by_state_group' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE state = :state AND group_code = :group_code',
        ),
        'get_count_by_state_group_and_sex' => array(
            'sql' => 'SELECT COUNT(*) FROM __TABLE_NAME__ WHERE state = :state AND group_code = :group_code AND sex = :sex',
        ),
        'get_sell_border_id_by_item_id' => array(
            'sql' => 'SELECT sell_border_id FROM __TABLE_NAME__ WHERE item_id = :item_id',
        ),
        'get_bid_border_user_id_by_item_id' => array(
            'sql' => 'SELECT bid_border_user_id FROM __TABLE_NAME__ WHERE item_id = :item_id',
        ),
        'get_current_bid_border_point_by_item_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = :item_id',
        ),
        'get_current_bid_border_point_by_item_ids' => array(
            'sql' => 'SELECT item_id, current_bid_border_point FROM __TABLE_NAME__ WHERE item_id in (:item_ids)',
        ),
        'show_table' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}

        // {{{ update queries
        'increment' => array(
            'sql' => '
                UPDATE
                    __TABLE_NAME__
                SET
                    counter     = counter + 1,
                    total_point = total_point + :point,
                    state       = IF (:border <= counter, :state_enable, :state_disable),
                    min_point   = IF (:point < min_point, :point, min_point),
                    max_point   = IF (max_point < :point, :point, max_point)
                WHERE
                    item_id     = :item_id
            ',
        ),
        'create_or_increment' => array(
            'sql' => '
                INSERT INTO __TABLE_NAME__
                    (item_id, state, group_code, sex, counter, min_point, max_point, total_point, ctime)
                VALUES
                    (:item_id, :state, :group_code, :sex, 1, :point, :point, :point, NOW())
                ON DUPLICATE KEY UPDATE
                    counter     = counter + 1,
                    total_point = total_point + :point,
                    state       = IF (:border <= counter, :state_enable, :state_disable),
                    min_point   = IF (:point < min_point, :point, min_point),
                    max_point   = IF (max_point < :point, :point, max_point)
            ',
        ),
        'update_state' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state WHERE item_id = :item_id',
        ),
        'update_item_sex' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET sex = :sex WHERE item_id = :item_id',
        ),
        'update_border_by_item' => array(
            'sql' => '
                UPDATE __TABLE_NAME__
                SET
                    sell_border_id      = :sell_border_id,
                    sell_border_user_id = :sell_border_user_id,
                    bid_border_user_id  = :bid_border_user_id
                WHERE
                    item_id             = :item_id
            ',
        ),
        'update_current_bid_border_point_by_item_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET current_bid_border_point = :current_bid_border_point, mtime = NOW() WHERE item_id = :item_id',
        ),
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    item_id             INT(11)     UNSIGNED NOT NULL,
                    state               TINYINT(4)  UNSIGNED NOT NULL,
                    group_code          INT(8)      UNSIGNED NOT NULL,
                    sex                 TINYINT(4)  UNSIGNED default NULL,
                    counter             INT(11)     UNSIGNED NOT NULL,
                    min_point           INT(11)     UNSIGNED NOT NULL,
                    max_point           INT(11)     UNSIGNED NOT NULL,
                    total_point         BIGINT(20)  UNSIGNED NOT NULL,
                    sell_border_id      INT(11)     UNSIGNED,
                    sell_border_user_id INT(11)     UNSIGNED,
                    bid_border_user_id  INT(11)     UNSIGNED,
                    current_bid_border_point  INT(11)  UNSIGNED,
                    ctime               DATETIME    NOT NULL DEFAULT \'0000-00-00 00\:00\:00\',
                    mtime               TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    PRIMARY KEY (item_id),
                    KEY (state, group_code),
                    KEY (sex, state)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        'truncate' => array(
            'sql' => 'TRUNCATE __TABLE_NAME__',
        ),
        // }}}
    );

    function _init()
    {
        parent::_init();

        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_MarketFarmSelector();
    }
}
