<?php

class Gree_Service_AvatarFeed_Module_Avatar
    extends Gree_Service_AvatarFeed_Module_Base
{
    public function getAvatarImgUrl($user_id, $size)
    {
        $srv_life   = getService('life');
        $avatar_key = $srv_life->getForceProfileImageUrl($user_id, 'key', null, false);
        if (PEAR::isError($avatar_key)){
            $context = array(
                'user_id' => $user_id,
                'size'    => $size
            );
            throw new Gree_Service_AvatarFeed_Exception('Failed to get avatar_key',
                      Gree_Service_AvatarFeed_Exception::E_AVATAR_KEY_NOT_FOUND,
                      $context
            );
        }
        $url = $srv_life->getImageUrlWithToken($avatar_key . $size);

        return $url;
    }

    public function getAvatarImgUrlByKey($avatar_key, $size)
    {
        $srv_life   = getService('life');
        $url        = $srv_life->getImageUrlWithToken($avatar_key . $size);

        return $url;
    }

    public function getEffectImgUrlById($id)
    {
        $srv_life   = getService('life');

        if (defined('IS_MSHOP') !== false) {
            $url = HTTP_MSHOP_ITEM_IMG . $srv_life->getDisplayImagePathPng($id, 'effect');
        } elseif(defined('HTTP_GAVATAR_ITEM_IMG') !== false) {
            $url = HTTP_GAVATAR_ITEM_IMG . $srv_life->getDisplayImagePathPng($id, 'effect');
        } else {
            return false;
        }
        return $url;
    }

    public function getStampImgUrlByStampId($stamp_id)
    {
        $srv_shop = getService('shop');
        $stamp_manager = $srv_shop->getStampManager();
        $is_mshop = defined('IS_MSHOP');

        return $stamp_manager->getStampImageUrl($stamp_id, $is_mshop);
    }
}
