<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *  /home/gree/service/shop/class/GenericDao/Campaign/Athena/IncentiveDao.php
 *
 *  @author   Kiriko Yano <kiriko.yano@gree.net>
 *  @package  GREE
 */

class Gree_GenericDao_Campaign_Athena_IncentiveDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'athena_serial_code_201504';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'serial_code';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_event_count';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_event_count';

    /** @var ��Ͽ�������̾ */
    var $_auto_increment = 'true';

    /** @var �ե������̾ */
    var $_field_names = array(
        'serial_code',
        'item_id',
        'state',
        'user_id',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ ���ȷ�
        'find_by_serial_code' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE serial_code = :serial_code'
        ),
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id'
        ),
        // }}}
        // {{{ ������
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `serial_code` char(10) NOT NULL,
                `item_id` int(10) UNSIGNED NOT NULL,
                `state` tinyint(2) UNSIGNED NOT NULL default 0,
                `user_id` int(10) UNSIGNED NOT NULL default 0,
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL default '0000-00-00 00\:00\:00',
                PRIMARY KEY(`serial_code`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis"
        ),
        'update_state_and_user_id' => array(
            'sql' => 'UPDATE __TABLE_NAME__ 
                      SET state = :state,
                          user_id = :user_id
                      WHERE
                          serial_code = :serial_code'
        ),
        'insert_record' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (serial_code, item_id, ctime) VALUES (:serial_code, :item_id, NOW())'
        ),
    );

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
