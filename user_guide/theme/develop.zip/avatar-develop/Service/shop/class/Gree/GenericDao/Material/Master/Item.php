<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

class Gree_GenericDao_Material_Master_ItemDao extends Gree_GenericDao_Apc
{
    var $_table_name = 'material_item_master';

    var $_primary_key = 'item_id';

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_studio';

    var $_slave_dsn = 'gree://slave/avatar_studio';

    var $_auto_increment = true;

    var $_field_names = array(
        'item_id',
        'type',
        'name',
        'info',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        //Refer query
        'find_item' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE item_id in (:item_ids)",
        ),

        //Refer query for Support tool
        'find_item_all' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__",
        ),

        'find_item_by_type' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE type = :type",
        ),

        //Update queries
        'update_all_attr' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET
                name = :name,
                type = :type,
                info = :info
            WHERE item_id = :item_id",
        ),

        //Insert query
        'insert' => array(
            'sql' => "
            INSERT IGNORE INTO __TABLE_NAME__ (
                type,
                name,
                info,
                ctime
            )
            VALUES (
                :type,
                :name,
                :info,
                NOW()
            )
            ",
        ),

        //Create table
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `item_id`   int(11)    unsigned auto_increment,
                    `type`      tinyint(4) unsigned NOT NULL,
                    `name`      varchar(255) NOT NULL,
                    `info`      varchar(255) NOT NULL,
                    `mtime`     timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`     datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`item_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
    );

    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
}
