<?php

class Gree_Service_AvatarFeed_Exception
    extends Exception
{
    const E_UNKNOWN              = 1;
    const E_USER_INFO_NOT_FOUND  = 2;
    const E_AVATAR_KEY_NOT_FOUND = 3;
    const E_NOT_FOUND_CLASS_DEF  = 5;
    const E_INVALID_INSTANCE     = 6;
    const E_OAuth_UNKNOWN        = 7;
    const E_DATA_NOT_FOUND       = 8;
    const E_PEAR_ERROR           = 9;

    const E_APINET_UNKNOWN        = 1001;
    const E_APINET_DATA_NOT_FOUND = 1008;

    public function __construct($message,
                                $code,
                                $context  = array(),
                                $previous = null)
    {
        // use either constructor by PHP version
        version_compare(PHP_VERSION, '5.3.0', '<')
            ? parent::__construct($message, $code)
            : parent::__construct($message, $code, $previous);

        $log_name = GREE_SERVICE_AVATARFEED_LOG_PATH . 'exception';
        $log_data = array(
            'msg'  => $message,
            'code' => $code
        );


        if (is_array($context)){
            foreach($context as $key => $value){
                $log_data[$key] = $value;
            };
        }else{
            $log_data = array($context);
        }

        $srv_life = getService('shop');
        $logger   = $srv_life->getServiceLogger();
        $logger->avatarFeedLog($log_name, $log_data);
    }
}
