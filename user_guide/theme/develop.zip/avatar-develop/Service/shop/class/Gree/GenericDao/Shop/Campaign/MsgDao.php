<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
/**
 *	CampaignMsgDao.php
 *
 *	@author		Tomoaki Sawa <sawa@gree.co.jp>
 *	@package	GREE
 *	@version	$Id: MsgDao.php 30044 2008-03-17 10:25:16Z  $
 */
class Gree_GenericDao_Shop_Campaign_MsgDao extends Gree_GenericDao {
	var $_table_name = 'shop_campaign_msg';
	var $_master_dsn = 'gree://master/shop';
	var $_slave_dsn = 'gree://slave/shop';
	var $_primary_key = 'id';
	var $_auto_increment = true;
	var $_queries = array(
			'find_by_campaign_id' => array(
					'sql' => 'SELECT * FROM shop_campaign_msg WHERE campaign_id=:campaign_id'
			),
			'find_by_campaign_id_and_message_type' => array(
					'sql' => 'SELECT * FROM shop_campaign_msg WHERE campaign_id=:campaign_id AND message_type=:message_type'
			),
			'find_all' => array(
					'sql' => 'SELECT * FROM shop_campaign_msg'
			),
			'update_by_campaign_id_and_message_type' => array(
					'sql' => 'UPDATE __TABLE_NAME__ SET campaign_id = :campaign_id, message_type =
					 :message_type, message = :message WHERE campaign_id = :campaign_id AND
					 message_type = :message_type'
			),
	);

    // {{{ prepareI18n()
    function prepareI18n($row, $rw = 'r') {
        $row = parent::prepareI18n($row, $rw);
        return Gree_Service_Shop_Util::dataAccessFilter($row);
    }
    // }}}
}
