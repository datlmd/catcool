<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Osacolo/MasterAttrDao.php
 *
 * @package     GREE Avatar
 * @since       2017-04-17
 */

/**
 * MasterAttr form constructor
 * @access      public
 */
class Gree_GenericDao_Osacolo_MasterAttrDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'master_attr';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_osacolo';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_osacolo';

    /** @var field names */
    var $_field_names = array(
        'id',
        'osacolo_id',
        'name',
        'value',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'find_all'               => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__',
        ),
        'find_all_and_sort_desc' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ ORDER BY id DESC',
        ),
        'find_by_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'find_by_osacolo_id'             => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE osacolo_id = :osacolo_id',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (osacolo_id, name, value, ctime) VALUES (:osacolo_id, :name, :value, NOW())',
            'return_last_insert_id' => true
        ),
        'update'                 => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET osacolo_id = :osacolo_id, name = :name, value = :value WHERE id = :id',
        ),
        'delete'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE id = :id',
        ),
        'delete_by_id_and_name'                 => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE osacolo_id = :osacolo_id AND name= :name',
        ),
        'create_table'           => array(
            'sql' => "
                    CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                        `id`            INT(10)      UNSIGNED NOT NULL AUTO_INCREMENT,
                        `osacolo_id`    INT(10)      UNSIGNED NOT NULL,
                        `name`          VARCHAR(255) NOT NULL,
                        `value`         VARCHAR(255) NOT NULL,
                        `mtime`         TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                        `ctime`         DATETIME     NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                        PRIMARY KEY (`id`),
                      UNIQUE KEY `name` (`osacolo_id`,`name`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
    );
}
