<?php
/**
 *  /home/gree/service/shop/class/Gree/GenericDao/Analytics/PurchaseDao.php
 *
 *  @author   Takahsi Taniguchi <takashi.taniguchi@gree.co.jp>
 *  @package     GREE
 *  @version     $id$
 */
require_once('AnalyticsDao.php');
class Gree_GenericDao_Analytics_PurchaseDao extends Gree_GenericDao_Analytics
{
    /** #@+
     *  @access private
     */

    /** @var �ơ��֥�̾ */
    var $_table_name = 'purchase';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_analytics';

    /** @var ��Ͽ�������̾ */
    var $_slave_dsn = 'gree://slave/avatar_analytics';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'datetime',
        'service',
        'user_id',
        'user_sex',
        'user_age',
        'phone_carrier',
        'action1',
        'action2',
        'shop',
        'purchase_type',
        'price',
        'is_tld_net',
        'is_app',
        'item_id',
        'ctime',
    );

    /** @var namespace */
    var $_namespace = null;

    /**
     * @var �����������
     */
    var $_queries = array(
        // {{{ ������
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `id`                  INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                  `datetime`            DATETIME NOT NULL,
                  `service`             VARCHAR(16) NOT NULL,
                  `user_id`             BIGINT(20) UNSIGNED NOT NULL,
                  `user_sex`            TINYINT(4),
                  `user_age`            TINYINT(4),
                  `phone_carrier`       TINYINT(4),
                  `action1`             VARCHAR(255),
                  `action2`             VARCHAR(255),
                  `shop`                VARCHAR(16),
                  `purchase_type`       TINYINT(4) UNSIGNED,
                  `price`               INT(10) UNSIGNED,
                  `item_id`             INT(10) UNSIGNED,
                  `is_tld_net`          TINYINT(4),
                  `is_app`              TINYINT(4),
                  `ctime`               DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                  PRIMARY KEY  (`id`),
                  KEY `datetime` (`datetime`),
                  KEY `service` (`service`),
                  KEY `user_id` (`user_id`),
                  KEY `user_sex` (`user_sex`),
                  KEY `user_age` (`user_age`),
                  KEY `phone_carrier` (`phone_carrier`),
                  KEY `action1` (`action1`),
                  KEY `action2` (`action2`),
                  KEY `shop` (`shop`),
                  KEY `purchase_type` (`purchase_type`),
                  KEY `price` (`price`),
                  KEY `is_tld_net` (`is_tld_net`),
                  KEY `is_app` (`is_app`),
                  KEY `item_id` (`item_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis AUTO_INCREMENT=1
            ",
        ),
        'drop_table' => array(
            'sql' => 'DROP TABLE __TABLE_NAME__',
        ),
        // }}}
        // {{{ ���ȷ�
        'find_by_user_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY id',
        ),
        'get_summary' => array(
            'sql' => '
                SELECT
                    user_id,
                    if((A.user_sex in (1) \&\& A.user_sex in (2)),
                        3, -- unisex
                        if(A.user_sex in (1),
                            1,
                            if(A.user_sex in (2), 2, -1)
                          )
                      ) as user_sex,
                    user_age,
                    phone_carrier,
                    sum(price) as purchase_spent_coin,
                    sum(item_count) as purchase_count,
                    sum(item_count_boy) as purchase_count_boy,
                    sum(item_count_girl) as purchase_count_girl,
                    count(*) as purchase_item_kind_count,
                    max(item_count) as item_count_max
                    FROM
                        (SELECT
                             user_id,
                             user_sex,
                             user_age,
                             phone_carrier,
                             item_id,
                             sum(price) as price,
                             count(*) as item_count,
                             sum(user_sex = 1) as item_count_boy,
                             sum(user_sex = 2) as item_count_girl
                             FROM __TABLE_NAME__
                             GROUP BY user_id, item_id)
                        as A
                    WHERE price > 0
                    GROUP BY user_id
            '
        ),
        'count_by_user_id' => array(
            'sql' => 'SELECT COUNT(item_id) AS cnt, SUM(price) AS sum FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'count_by_user_id_and_type' => array(
            'sql' => 'SELECT COUNT(item_id) AS cnt, SUM(price) AS sum FROM __TABLE_NAME__ WHERE user_id = :user_id AND purchase_type = :purchase_type',
        ),
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"'
        ),
        // }}}
        // {{{
        'get_summary_by_item_ids' => array(
            'sql' => '
                SELECT SUM(price) AS sum
                FROM __TABLE_NAME__
                WHERE item_id IN (:item_id) AND service = :service',
        ),
        // }}}
    );
    /** #@- */
}
