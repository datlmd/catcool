<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/GeneralCampaign/VolunteerDao.php
 *
 * @author      Thien Nguyen <z.thanhthien.nguyen@gree.net>
 * @package     GREE Avatar
 * @since       2016-07-21
 */


/**
 * Volunteer form constructor
 * @access      public
 */
class Gree_GenericDao_GeneralCampaign_VolunteerDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'general_campaign_volunteer';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/shop';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/shop';

    /** @var field names */
    var $_field_names = array(
        'id',
        'campaign_id',
        'user_id',
        'item_id',
        'item_price',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'statistic_volunteer_by_campaign_id'             => array(
            'sql' => 'SELECT COUNT(item_id) as total_item, SUM(item_price) as total_price FROM __TABLE_NAME__',
        ),
        'get_last_time_volunteer_by_campaign_id'             => array(
            'sql' => 'SELECT mtime FROM __TABLE_NAME__ ORDER BY mtime DESC',
        ),
        // }}}

        // {{{ update queries
        'entry'                  => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, item_id, item_price, ctime) VALUES (:user_id, :item_id, :item_price, NOW())',
            'return_last_insert_id' => true
        ),
        'create_table'           => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT(10) UNSIGNED NOT NULL,
                `item_id` INT(11) UNSIGNED NOT NULL,
                `item_price` INT(10) UNSIGNED NOT NULL,
                `mtime` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        'show_table' => array(
                'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
        // }}}
    );
    // {{{ _initFarmSelector()
    function _initFarmSelector() {
        $this->_farm_selector = new Gree_GenericDao_GeneralCampaign_VolunteerSelector();
    }
    // }}}
}

class Gree_GenericDao_GeneralCampaign_VolunteerSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%d";   // campaign_id

    // {{{ getTableName
    function getTableName($dao, $type, $hint)
    {
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['campaign_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, $hint['campaign_id']);
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
