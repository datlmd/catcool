<?php

require_once("/home/gree/xgree/avatar/Service/avatarfeed/cli/Base.php");

/**
 * Class Gree_Service_AvatarFeed_Cli_ModifyListUser
 */
class Gree_Service_AvatarFeed_Cli_ModifyListUser
    extends Gree_Service_AvatarFeed_Cli_Base
{
    public $log_dir = '/home/gree/log/statistics/shop/avatar_feed/cli';

    public function main()
    {
        $this->_initialize();

        $this->_print_header('modiry_follow');

        $this->short_opt = "m:u:t:";
        $this->opt_names = array(
            'start_date=',
            'end_date=',
            'file=',
        );
        $this->input_opt_list = $this->_get_parse_arg_list();

        try {
            $set_options = $this->_set_option_value();
            $this->_invoke($set_options);
        } catch (Exception $e) {
            printf("finish with error. \n");
        }

        $this->_print_footer();
    }

    public function _find_input_option($option)
    {
        $option_name = null;
        $option_value = null;

        switch ($option[0]) {
            case 'm':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'mode';
                $option_value = $option[1];
                break;
            case 'u':
                if (!isset($option[1])) {
                    printf("invalid option value\n");

                    throw new Exception();
                }

                $option_name = 'user_id';
                $option_value = $option[1];
                break;
            case '--file':
                if (!isset($option[1])) {
                    printf("invalid option value\n");
                    throw new Exception();
                }

                $option_name = 'file';
                $option_value = $option[1];
                break;

            default:
                printf("please input mode \n");
                throw new Exception();
        }

        return array(
            $option_name,
            $option_value,
        );
    }

    public function _invoke($option)
    {
        switch ($option['mode']) {
            case 'modify_follow':
                if (!isset($option['user_id'])) {
                    printf("need user_id.\n");
                    throw new Exception();
                }
                if (!isset($option['file'])) {
                    printf("need file.\n");
                    throw new Exception();
                }
                $this->_modify_follow($option);
                break;
            default:
                printf("please input exist mode\n");
                throw new Exception();
        }
    }

    public function _modify_relation_follow($user_id, $target_user_id)
    {
        $this->_print_line();
        printf("_modify_follow\n");
        printf("user_id: " . $user_id . "\n");

        $result = ($this->module_follow->removeFollowingUser($target_user_id, $user_id)) ? 'true' : 'false';
        printf('target_user_id:' . $target_user_id. ": " . $result . "\n");

        $result = ($this->module_follow->removeFollowedUser($user_id, $target_user_id)) ? 'true' : 'false';
        printf('target_user_id:' . $target_user_id . ": " . $result . " --followed \n");

        $is_decremented = ($this->module_follow->decrementFollowCount('followed', $target_user_id)) ? 'true' : 'false';
        printf($target_user_id . ": " . $is_decremented . " --decrement followed count \n");
        $this->_print_line();
    }

    public function _modify_follow($option)
    {
        printf("user_id: " . $option['user_id'] . "\n");
        $user_id = $option['user_id'];
        $file_name = $option['file'];
        if (file_exists($file_name) == false) {
            printf("not exist delete user list.\n");
            throw new Exception();
        }

        $delete_followeds = @file($file_name, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (empty($delete_followeds) || empty($user_id)) {
            printf("empty delete user list.\n");
            throw new Exception();
        }
        $exclude_id = array(47001825,);     // exclude official user
        $delete_user = array();

        $this->_print_line();

        foreach ($delete_followeds as $followed_user) {
            printf($followed_user);
            if (empty($followed_user)) {
                printf(">>>> EMPTY USER ESCAPE\n");
                continue;
            }
            if (in_array($followed_user, $exclude_id)) {
                printf(">>>> EXCLUDE USER ESCAPE\n");
                continue;
            }
            printf("\n");
            $delete_user[] = $followed_user;
        }

        // delete
        if (empty($delete_user) || !is_array($delete_user)) {
            printf("empty delete user.\n");
            throw new Exception();
        }

        $this->_print_line();
        printf("delete count:" . count($delete_user) . "\n");
        printf("is delete user from followed(yes/no)?");
        $is_delete_user = fgets(STDIN);
        if (trim($is_delete_user) != 'yes') {
            printf("not select 'yes'.\n");
            throw new Exception();
        }

        printf("start...\n");
        printf("\n");
        $delete_count = 0;
        foreach ($delete_user as $followed_user) {
            $this->_modify_relation_follow($user_id, $followed_user);

            $delete_count++;
            if (($delete_count%50) == 0) {
                sleep(1);
            }
        }
        printf("........delete finish.\n");
        printf("complete: " . date('Y-m-d H:i:s') . ".\n");
        $this->_print_line();
    }
}

$class = new Gree_Service_AvatarFeed_Cli_ModifyListUser();
$class->main();
