<?php
/**
 * /home/gree/xgree/avatar/Service/shop/class/Gree/GenericDao/Contest/TicketDao.php
 *
 * @author      Thien Nguyen <z.thanhthien.nguyen@gree.net>
 * @package     GREE Avatar
 * @since       2015-09-18
 */

require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserFarmSelector.php';

/**
 * Ticket form constructor
 * @access      public
 */
class Gree_GenericDao_Contest_TicketDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name = 'contest_ticket';

    /** @var primary key */
    var $_primary_key = 'id';

    /** @var auto increment */
    var $_auto_increment = true;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn = 'gree://master/avatar_contest';

    /** @var slave dsn */
    var $_slave_dsn = 'gree://slave/avatar_contest';

    /** @var field names */
    var $_field_names = array(
        'id',
        'user_id',
        'plus_vote_ticket',
        'ctime',
        'mtime',
        'from_date_time',
        'to_date_time',
    );

    /** @var query definitions */
    var $_queries = array(
        // {{{ refer queries
        'count_purchased_today_by_user_id'   => array(
            'sql' => 'SELECT COUNT(id) as total_purchase, SUM(plus_vote_ticket) as total_vote_ticket FROM __TABLE_NAME__ WHERE user_id = :user_id AND ctime BETWEEN :from_date_time AND :to_date_time'
        ),
        'count_ticket_today_by_user_id'   => array(
            'sql' => 'SELECT SUM(plus_vote_ticket) as total_vote_ticket FROM __TABLE_NAME__ WHERE user_id = :user_id AND ctime BETWEEN :from_date_time AND :to_date_time'
        ),
        // }}}
        // {{{ update queries
        'entry'        => array(
            'sql'                   => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, plus_vote_ticket, ctime) VALUES (:user_id, :plus_vote_ticket, :ctime)',
            'return_last_insert_id' => true
        ),
        'create_table' => array(
            'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                      `id`              INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                      `user_id`         INT(11) UNSIGNED NOT NULL,
                      `plus_vote_ticket` SMALLINT(3) UNSIGNED NOT NULL DEFAULT 0,
                      `ctime`           DATETIME    NOT NULL DEFAULT '00-00-00 00\:00\:00',
                      `mtime`           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                      PRIMARY KEY (`id`),
                      KEY `user_id` (`user_id`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=ujis;"
        ),
        // }}}
        'show_tables' => array(
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Contest_TicketFarmSelector();
    }
}


class Gree_GenericDao_Contest_TicketFarmSelector extends Gree_GenericDao_FarmSelector
{
    var $_table_suffix_format = "_%d";

    function getTableName($dao, $type, $hint)
    {
        if (empty($hint) || !isset($hint['contest_id'])) {
            return PEAR::raiseError("hint is empty. dao=" . get_class($dao) . "];");
        }

        $table_suffix   = sprintf($this->_table_suffix_format, $hint['contest_id']);
        $table_name     = $dao->_getTableName() . $table_suffix;
        return $table_name;
    }
}
