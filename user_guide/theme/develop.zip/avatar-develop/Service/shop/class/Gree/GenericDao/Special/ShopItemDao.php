<?php
// vim: sts=4 sw=4 ts=4 fdm=marker
class Gree_GenericDao_Special_ShopItemDao extends Gree_GenericDao {

	/** @var �ơ��֥�̾ */
	var $_table_name = 'special_shop_item';

	/** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
	var $_primary_key = array('shop_id', 'item_id');

	/** @var �����������̾ */
	var $_updated_at_column = 'mtime';

	/** @var ��Ͽ�������̾ */
	var $_created_at_column = 'ctime';

	/** @var �ޥ������ǡ����١�������³ʸ���� */
	var $_master_dsn = 'gree://master/shop';

	/** @var ���졼�֥ǡ����١�������³ʸ���� */
	var $_slave_dsn = 'gree://slave/shop';
    
    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = false;

	/** @var �ե������̾ */
	var $_field_names = array('shop_id' ,'item_id' ,'count' ,'mtime' ,'ctime');
      
	/** @var ������ */
	var $_queries = array(
            'create_table' => array(
                'sql' => "CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `shop_id`     INT(10) unsigned NOT NULL default '0',
                `item_id`     INT(10) unsigned NOT NULL default '0',
                `count`       INT(10) unsigned NOT NULL default '0',
                `ctime`       DATETIME      NOT NULL DEFAULT '0000-00-00 00\:00\:00',
                `mtime`       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`shop_id`,`item_id`),
                KEY `item_id` (`item_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis"
            ),
        'find_by_shop_id'   => array('sql' => 'SELECT * FROM __TABLE_NAME__ WHERE shop_id = :shop_id'),
        'find_by_shop_ids'  => array('sql' => 'SELECT shop_id,item_id FROM __TABLE_NAME__ WHERE shop_id IN (:shop_ids)'),
        'find_by_item_id'   => array('sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id = :item_id'),
        'find_by_item_idl'  => array('sql' => 'SELECT * FROM __TABLE_NAME__ WHERE item_id IN (:item_idl)'),
        'all'               => array('sql' => 'SELECT * FROM __TABLE_NAME__'),
        'count_sum_by_shop_id' => array('sql' => 'SELECT SUM(count) FROM __TABLE_NAME__ WHERE shop_id = :shop_id'),
        'increase_count'    => array('sql' => 'UPDATE __TABLE_NAME__ SET count = count + 1 WHERE shop_id = :shop_id AND item_id = :item_id'),
    );
}