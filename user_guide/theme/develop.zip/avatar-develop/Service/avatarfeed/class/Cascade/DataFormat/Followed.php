<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Followed
    extends Cascade_DB_SQL_DataFormat
{
    // dsn setting
    protected $master_dsn        = 'gree://master/avatar_followed';
    protected $slave_dsn         = 'gree://slave/avatar_followed';
    protected $extra_dsn         = array(
        'standby' => 'gree://standby/avatar_followed',
    );

    // cascade setting
    protected $primary_key       = array(
        'user_id',
        'followed_user_id',
    );
    protected $fetch_mode        = self::FETCH_MODE_ASSOC;
    // use primary_key
    protected $fetch_key         = NULL;
    protected $auto_increment    = false;

    // table and column setting
    protected $created_at_column = 'ctime';
    protected $table_name        = 'followed';
    protected $field_names       = array(
        'user_id',
        'followed_user_id',
        'ctime',
    );

    protected $queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                  `user_id`           bigint(20) UNSIGNED  NOT NULL,
                  `followed_user_id`  bigint(20) UNSIGNED  NOT NULL,
                  `ctime`             datetime             NOT NULL,
                  PRIMARY KEY (`user_id`, `followed_user_id`),
                          KEY `sort_ctime` (`user_id`, `ctime`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ",
        ),
        'drop_table' => array(
            'sql' => "
                DROP TABLE IF EXISTS __TABLE_NAME__
            ",
        ),
        'find_user_by_user_id_and_followed_user_id' => array(
            'sql' => 'SELECT followed_user_id FROM __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   followed_user_id = :followed_user_id
            ',
        ),
        'find_date_by_user_id_and_followed_user_id' => array(
            'sql' => 'SELECT ctime FROM __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   followed_user_id = :followed_user_id
            ',
        ),
        // offset = int
        'find_list_by_user_id_sort_ctime' => array(
            'sql' => 'SELECT followed_user_id FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY ctime DESC',
        ),
        // offset = int
        'find_list_by_user_id_sort_followed_user_id' => array(
            'sql' => 'SELECT followed_user_id FROM __TABLE_NAME__ WHERE user_id = :user_id ORDER BY followed_user_id',
        ),
        // offset = followed_user_id
        'find_list_by_user_id_and_followed_user_id' => array(
            'sql' => 'SELECT followed_user_id FROM __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   followed_user_id > :followed_user_id
                        ORDER BY followed_user_id',
        ),
        'add_followed' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, followed_user_id, ctime) VALUES(:user_id, :followed_user_id, NOW())'
        ),
        'remove_followed' => array(
            'sql' => 'DELETE FROM  __TABLE_NAME__
                        WHERE user_id = :user_id
                        AND   followed_user_id = :followed_user_id
            '
        ),
        'find_list_by_user_id_and_date' => array(
            'sql' => 'SELECT followed_user_id FROM __TABLE_NAME__
                        WHERE user_id = :user_id
                          AND :end_date > ctime
                          AND ctime >= :start_date
                          ORDER BY ctime DESC'
        ),
        // get the total number of followed users
        'count_list_by_user_id' => array(
            'sql' => 'SELECT count(followed_user_id) as followed_count FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
    );

    public function getShardSelector() {
        return new Gree_Service_AvatarFeed_Cascade_ShardSelector_Followed();
    }
}
