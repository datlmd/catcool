<?php
/**
 * UserMapper.php
 */
class Gree_Service_Shop_Data_UserMapper extends Gree_Service_Shop_Data_Mapper
{
    // ----[ Properties ]-------------------------------------------------------
    /**
     * @var primary key
     */
    protected $primary_key = 'user_id';

    // ----[ Methods ]----------------------------------------------------------
    /**
     * load accessor from primary key
     *
     * @param   int
     * @return  array
     */
    protected function load($user_id)
    {
        $shop_service    = getService('shop');
        $profile_manager = $shop_service->getManager('profile');
        $user_data       = $profile_manager->getUserInfoFromUserId(
            $user_id,
            USER_STATUS_ALIVE
        );
        if (PEAR::isError($user_data)) {
            throw new Gree_Service_Shop_Exception($user_data->getMessage());
        }

        return $user_data;
    }
}
