<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Class Gree_GenericDao_Gacha_Fever_ItemDao
 */
class Gree_GenericDao_Gacha_Fever_ItemDao extends Gree_GenericDao_Apc
{

    /** @var �ơ��֥�̾ */
    public $_table_name = 'gacha_fever_item';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣 */
    public $_primary_key = 'id';

    /** @var �����������̾ */
    public $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    public $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    public $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    public $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �����ȥ��󥯥���� */
    public $_auto_increment = true;

    /** @var �ե������̾ */
    public $_field_names = [
        'id',
        'gacha_id',
        'item_id',
        'gacha_rarity',
        'mtime',
        'ctime',
    ];

    /**
     * @var �����������
     */
    public $_queries = [
        // {{{ ������
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT NOT NULL AUTO_INCREMENT,
                `gacha_id` INT NOT NULL,
                `item_id` INT NOT NULL,
                `gacha_rarity` INT NOT NULL default 0,
                `mtime` DATETIME NOT NULL default CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL default CURRENT_TIMESTAMP,
                PRIMARY KEY  (`id`),
                KEY `idx_gacha_id` (`gacha_id`),
                UNIQUE KEY `gacha_id_and_item_id` (`gacha_id`,`item_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ],
        'drop_table'   => [
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ],
        'insert'       => [
            'sql' => "INSERT INTO __TABLE_NAME__ (gacha_id, item_id, gacha_rarity) values (:gacha_id, :item_id, :gacha_rarity)",
        ],

        'find_by_gacha_id' => [
            'sql' => "SELECT * FROM `__TABLE_NAME__` WHERE `gacha_id` = :gacha_id",
        ],
        'delete_by_gacha_id_and_item_id' => [
            'sql' => "DELETE FROM `__TABLE_NAME__` WHERE `gacha_id` = :gacha_id AND `item_id` = :item_id",
        ],

        'find_items_by_gacha_id_and_rarity' => [
            'sql' => "SELECT * FROM `__TABLE_NAME__` WHERE `gacha_id` = :gacha_id AND `gacha_rarity` = :gacha_rarity",
        ],

        'is_exists_item_id' => [
            'sql' => "SELECT * FROM `__TABLE_NAME__` WHERE `item_id` = :item_id LIMIT 1",
        ],
    ];
}
