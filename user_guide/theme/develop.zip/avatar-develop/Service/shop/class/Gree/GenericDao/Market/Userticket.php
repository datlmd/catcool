<?php

require_once('/home/gree/xgree/avatar/Service/shop/class/Gree/Farm/UserLightFarmSelector.php');

/**
 * Gree_GenericDao_Market_Userticket
 *
 * @author  Norie Matsuda <norie.matsuda@gree.net>
 * @package GREE
 */
class Gree_GenericDao_Shop_Market_UserticketDao extends Gree_GenericDao
{
    /** @var table name */
    var $_table_name        = 'market_ticket_user';

    /** @var primary key */
    var $_primary_key       = 'id';

    /** @var auto increment */
    var $_auto_increment    = false;

    /** @var created at column */
    var $_created_at_column = 'ctime';

    /** @var updated at column */
    var $_updated_at_column = 'mtime';

    /** @var master dsn */
    var $_master_dsn        = 'gree://master/avatar_market';

    /** @var slave dsn */
    var $_slave_dsn         = 'gree://slave/avatar_market';

    /** @var field names */
    var $_field_names       = array(
        'id',
        'user_id',
        'ticket_master_id',
        'ctime',
        'mtime',
    );

    /** @var query definitions */
    var $_queries           = array(
        // {{{ refer queries
        'find_by_user' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id',
        ),
        'find_by_user_and_id' => array(
                'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id = :user_id AND ticket_master_id=:ticket_master_id',
        ),
        // }}}

        // {{{ create ticket
        'create' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, ticket_master_id,  ctime) VALUES (:user_id, :ticket_master_id, NOW())',
        ),
        'update_state' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET state = :state WHERE id = :id AND user_id = :user_id AND item_id = :item_id',
        ),
        // {{{ create table ( 'status' not use yet.)
        'create_table' => array(
            'sql' => '
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` int(11) unsigned NOT NULL auto_increment,
                `user_id` int(11) unsigned NOT NULL,
                `status` tinyint(2) NOT NULL default 0,
                `ticket_master_id` int(11) unsigned NOT NULL,
                `mtime` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                `ctime` datetime NOT NULL default \'0000-00-00 00\:00\:00\',
                PRIMARY KEY  (`id`),
                KEY `user_id_1` (`user_id`, `ticket_master_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ',
        ),
        'delete' => array(
            'sql' => 'DELETE FROM __TABLE_NAME__ WHERE user_id = :user_id AND ticket_master_id=:ticket_master_id limit 1',
        ),
        'drop_table' => array(
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ),
        // }}}
    );

    function _init(){
        parent::_init();
        /** @var farm selector */
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
}
