<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Following_AddTest
 *
 * this test is follow status
 */
final class Gree_Service_Avatarfeed_Test_Processor_Following_AddTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module;
    var $module_block;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        $this->module = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);

        // initialize follow status
        try {
            $this->module->updateFollowCount(UNIT_TEST_USER_ID_1);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_1);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_1);

            $this->module->updateFollowCount(UNIT_TEST_USER_ID_2);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowingUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_3, UNIT_TEST_USER_ID_2);
            $this->module->removeFollowedUser(UNIT_TEST_USER_ID_4, UNIT_TEST_USER_ID_2);


        } catch (Exception $e) {
        }

        $this->module_block = Gree_Service_AvatarFeed_Module::singleton('Block');
        $this->module_block->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        try {
            $this->module_block->removeBlockUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->module_block->removeBlockUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
        } catch (Exception $e) {

        }
    }

    /**
     * test1: UNIT_TEST_USER_ID_1 try to following UNIT_TEST_USER_ID_2
     * expect: add_result == true
     *
     * test2: UNIT_TEST_USER_ID_1 already following UNIT_TEST_USER_ID_2
     * expect: add_result == false
     *
     */
    public function test_add_following()
    {

        // test1
        $follow_params = array(
            'user_id' => UNIT_TEST_USER_ID_2,
        );
        $add_result    = $this->avatar_feed->process('following_add', $follow_params);

        $this->assertTrue($add_result);

        list($owner_following_count_test_1, $owner_followed_count_test_1) = $this->module->getFollowCount(UNIT_TEST_USER_ID_1);
        list($target_following_count_test_1, $target_followed_count_test_1) = $this->module->getFollowCount(UNIT_TEST_USER_ID_2);
        $is_following_test_1 = $this->module->getFollowingUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
        $is_followed_test_1  = $this->module->getFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);

        $this->assertEquals(1, $owner_following_count_test_1);
        $this->assertEquals(0, $owner_followed_count_test_1);
        $this->assertEquals(0, $target_following_count_test_1);
        $this->assertEquals(1, $target_followed_count_test_1);
        $this->assertTrue($is_following_test_1);
        $this->assertTrue($is_followed_test_1);

        // test2
        $add_result_2 = $this->avatar_feed->process('following_add', $follow_params);

        $this->assertFalse($add_result_2);

        list($owner_following_count_test_2, $owner_followed_count_test_2) = $this->module->getFollowCount(UNIT_TEST_USER_ID_1);
        list($target_following_count_test_2, $target_followed_count_test_2) = $this->module->getFollowCount(UNIT_TEST_USER_ID_2);
        $is_following_test_2 = $this->module->getFollowingUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
        $is_followed_test_2  = $this->module->getFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);

        $this->assertEquals(1, $owner_following_count_test_2);
        $this->assertEquals(0, $owner_followed_count_test_2);
        $this->assertEquals(0, $target_following_count_test_2);
        $this->assertEquals(1, $target_followed_count_test_2);
        $this->assertTrue($is_following_test_2);
        $this->assertTrue($is_followed_test_2);
    }

    /**
     * test1: UNIT_TEST_USER_ID_1 is blocked from UNIT_TEST_USER_ID_2
     * expect: add_result == true
     */
    public function test_add_following_when_blocked()
    {
        // test1

        $is_success_block = $this->module_block->addBlockUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);

        $follow_params = array(
            'user_id' => UNIT_TEST_USER_ID_2,
        );
        $add_result    = $this->avatar_feed->process('following_add', $follow_params);

        $this->assertTrue($add_result);

        list($owner_following_count_test_1, $owner_followed_count_test_1) = $this->module->getFollowCount(UNIT_TEST_USER_ID_1);
        list($target_following_count_test_1, $target_followed_count_test_1) = $this->module->getFollowCount(UNIT_TEST_USER_ID_2);
        $is_following_test_1 = $this->module->getFollowingUser(UNIT_TEST_USER_ID_2, UNIT_TEST_USER_ID_1);
        $is_followed_test_1  = $this->module->getFollowedUser(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);

        $this->assertEquals(1, $owner_following_count_test_1);
        $this->assertEquals(0, $owner_followed_count_test_1);
        $this->assertEquals(0, $target_following_count_test_1);
        $this->assertEquals(0, $target_followed_count_test_1);
        $this->assertTrue($is_following_test_1);
        $this->assertFalse($is_followed_test_1);
    }
}