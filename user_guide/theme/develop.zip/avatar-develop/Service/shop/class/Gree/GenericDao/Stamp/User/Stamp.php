<?php
require_once PATH_SRC_CLASS . 'Gree/GenericDao/UserIdFarmSelector.php';

class Gree_GenericDao_Stamp_User_StampDao extends Gree_GenericDao
{
    var $_table_name = 'stamp_user';

    var $_primary_key = array('user_id', 'stamp_id');

    var $_updated_at_column = 'mtime';

    var $_created_at_column = 'ctime';

    var $_master_dsn = 'gree://master/avatar_stamp';

    var $_slave_dsn = 'gree://slave/avatar_stamp';

    var $_auto_increment = false;

    var $_field_names = array(
        'user_id',
        'stamp_id',
        'stamp_set_id',
        'hidden',
        'state',
        'last_use',
        'mtime',
        'ctime'
    );

    var $_queries = array(
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `user_id`      int(11) unsigned NOT NULL,
                    `stamp_id`     int(11) unsigned NOT NULL,
                    `stamp_set_id` int(11) unsigned NOT NULL,
                    `hidden`       boolean NOT NULL DEFAULT '0',
                    `state`        int(2) unsigned NOT NULL DEFAULT '1',
                    `last_use`     int(11) unsigned NOT NULL DEFAULT '0',
                    `mtime`        timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`        datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`user_id`, `stamp_id`),
                    UNIQUE KEY `user_stamp_set_stamp` (`user_id`, `stamp_set_id`, `stamp_id`),
                    KEY `user_stamp_set_ctime` (`user_id`, `stamp_set_id`, `ctime`),
                    KEY `user_last_use` (`user_id`, `last_use`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),

        'insert' => array(
            'sql' => "
                INSERT IGNORE INTO __TABLE_NAME__ (
                    user_id,
                    stamp_id,
                    stamp_set_id,
                    ctime
                )
                VALUES (
                    :user_id,
                    :stamp_id,
                    :stamp_set_id,
                    NOW()
                )
            ",
        ),

        'mark_as_used' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET last_use = :last_use where user_id = :user_id and stamp_id = :stamp_id",
        ),

        'update_hidden_by_user_id_and_stamp_set_id' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET hidden = :hidden WHERE user_id = :user_id and stamp_set_id = :stamp_set_id",
        ),

        'update_hidden_by_user_id_and_stamp_id' => array(
            'sql' => "UPDATE __TABLE_NAME__ SET hidden = :hidden WHERE user_id = :user_id and stamp_id = :stamp_id",
        ),

        'find_by_user_id_and_stamp_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE state = 1 and user_id = :user_id and stamp_id = :stamp_id",
        ),

        'find_by_user_id_and_stamp_set_id' => array(
            'sql' => "SELECT * FROM __TABLE_NAME__ WHERE state = 1 and user_id = :user_id and stamp_set_id = :stamp_set_id ORDER BY stamp_id",
        ),

        'find_latest_by_user_id' => array(
            'sql' => "SELECT stamp_id, stamp_set_id, last_use FROM __TABLE_NAME__ WHERE hidden = 0 and state = 1 and last_use > 0 and user_id = :user_id order by last_use desc",
        ),

        'find_active_select_stamp_by_user_id' => array(
            'sql' => "SELECT stamp_id FROM __TABLE_NAME__ WHERE hidden = 0 and state = 1 and user_id = :user_id and stamp_set_id = 1 ORDER BY ctime desc",
        ),
        
        'find_all_select_stamp_by_user_id' => array(
            'sql' => "SELECT stamp_id, hidden FROM __TABLE_NAME__ WHERE state = 1 and user_id = :user_id and stamp_set_id = 1 ORDER BY ctime desc",
        ),
    );

    public function _initFarmSelector()
    {
        $table_nums = 100;

        if (Config::get('state') === GREE_STATE_DEVELOPMENT) {
            $table_nums = 2;
        }

        $this->_farm_selector = new Gree_GenericDao_UserIdFarmSelector($table_nums);
    }
}
