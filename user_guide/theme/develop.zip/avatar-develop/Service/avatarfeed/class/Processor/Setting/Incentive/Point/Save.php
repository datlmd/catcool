<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Setting_Incentive_Point_Save
 */
class Gree_Service_AvatarFeed_Processor_Setting_Incentive_Point_Save
    extends Gree_Service_AvatarFeed_Processor_Base
{
    protected function invoke()
    {
        $mod_setting = self::getModule('Setting');
        $is_success  = false;

        try {
            $is_success = $mod_setting->saveSettingInfoOfIncentive($this->input_values);
        } catch (Exception $e) {

        }

        return $is_success;
    }
}