<?php
/**
 *  /home/gree/service/shop/class/GenericDao/Gacha/DailyDiscountUser.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
require_once(GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/Farm/UserLightFarmSelector.php');

class Gree_GenericDao_Gacha_DailyDiscountUserDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'gacha_daily_discount_user';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_gacha';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_gacha';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'gacha_id',
        'last_use_day',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        'find_by_user_id_and_gacha_id' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND gacha_id=:gacha_id',
        ),
        // {{{ �������������������
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, gacha_id, last_use_day, ctime) VALUES(:user_id, :gacha_id, :last_use_day, NOW())',
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET last_use_day=:last_use_day WHERE user_id=:user_id AND gacha_id=:gacha_id AND last_use_day=:old_last_use_day',
        ),

        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`                INT(11) unsigned NOT NULL AUTO_INCREMENT,
                    `user_id`           int(11) unsigned NOT NULL default '0',
                    `gacha_id`          int(11) unsigned NOT NULL default '0',
                    `last_use_day`      int(11) unsigned NOT NULL default '0',
                    `mtime`             timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`             datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `user_id` (`user_id`, `gacha_id`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'truncate_table' => array(      // for batch
            'sql' => "TRUNCATE TABLE __TABLE_NAME__",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelectoi
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_Shop_UserLightFarmSelector();
    }
    // }}}
}

