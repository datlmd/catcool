<?php
/**
 * Service/shop/class/Gree/Data/Abstract/Record/Singleton.php
 *
 * @author  Jun Tomioka <jun.tomioka@gree.net>
 * @package GREE
 */
require_once sprintf('%s/Record.php', dirname(dirname(__FILE__)));

/**
 * Gree_Service_Shop_Data_Abstract_Singleton
 *
 * @package GREE
 * @access  public
 */
abstract class Gree_Service_Shop_Data_Abstract_Record_Singleton
    extends Gree_Service_Shop_Data_Abstract_Record
{
    /** ---- [ Properties ] -------------------------------- */

    // {{{ $_instances
    private static $_instances  = array();
    // }}}

    /** ---- [ static methods ] -------------------------------- */

    // {{{ getInstance
    /**
     * get instance of data object
     *
     * @override
     * @param   string  $class_name     php < 5.3で遅延静的束縛ができないので仕方なく
     * @param   mixed   $key            the primary key of the data class
     * @param   array   $hint           the farm hint
     * @return  mixed   the instance or null
     */
    public static /* Gree_Service_Shop_Data_Abstract */
        function getInstance($class_name, $key, $hint = null)
    {
        $instance_key = self::_generateInstanceKey($key);
        if (!isset(self::$_instances[$class_name][$key])) {
            $instance = parent::getInstance($class_name, $key, $hint);
            self::_registerInstance($class_name, $instance);
        }

        return self::$_instances[$class_name][$instance_key];
    }
    // }}}
    // {{{ getInstances
    /**
     * get instances of data object
     *
     * @override
     * @param   string  $class_name
     * @param   string  $keys
     * @param   array   $hint
     * @return  array   the instances
     */
    public static /* array */
        function getInstances($class_name, $keys, $hint = null)
    {
        $callback       = array($class_name, '_generateInstanceKey');
        $instance_keys  = array_map($callback, $keys);

        $unread_keys = array_diff($instance_keys, self::$_instances);
        if (!empty($unread_keys)) {
            $unread_instances = parent::getInstances($class_name, $keys, $hint);
            foreach ($unread_instances as $unread_instance) {
                self::_registerInstance($class_name, $unread_instance);
            }
        }

        $instances = array();
        foreach ($instance_keys as $instance_key) {
            if (!isset(self::$_instances[$class_name][$instance_key])) {
                throw new Gree_Service_Shop_Exception();
            }
            $instance = self::$_instances[$class_name][$instance_key];
            $instances[$instance_key] = $instance;
        }

        return $instances;
    }
    // }}}
    // {{{ instantiate
    /**
     * instantiate data object
     *
     * @override
     * @param   string  $class_name
     * @param   array   $record
     * @return  object  the instance
     */
    public static /* Gree_Service_Shop_Data_Abstract */
        function instantiate($class_name, $record)
    {
        $instance = parent::instantiate($class_name, $record);
        self::_registerInstance($class_name, $instance);

        $instance_key   = $instance->_getKey();

        return self::$_instances[$class_name][$instance_key];
    }
    // }}}
    // {{{ instantiateList
    /**
     * instnaciate data object list
     *
     * @override
     * @param   string  $class_name
     * @param   array   $records
     * @return  array   data objects
     */
    public static /* array */
        function instantiateList($class_name, $records)
    {
        $instances = parent::instantiateList($class_name, $records);
        foreach ($instances as $instance) {
            self::_registerInstance($class_name, $instance);
        }

        $ret = array();
        foreach ($instances as $instance) {
            $instance_key = $instance->_getKey();
            $ret[$instance_key] = self::$_instances[$class_name][$instance_key];
        }

        return $ret;
    }
    // }}}
    // {{{ _registerInstance
    /**
     * register instance if not exist
     *
     * @param   $class_name
     * @param   $instance
     */
    private static function _registerInstance($class_name, $instance)
    {
        $instance_key = $instance->_getKey();
        if (!isset(self::$_instances[$class_name][$instance_key])) {
            self::$_instances[$class_name][$instance_key] = $instance;
        }
    }
    // }}}
    // {{{ _generateInstanceKey
    /**
     * generate instance key
     *
     * @access  private
     * @static
     * @param   mixed   $key
     * @return  string  the instance key
     */
    private static function _generateInstanceKey($key)
    {
        if (!is_array($key)) {
            return $key;
        }

        ksort($key);

        return implode('__', $key);
    }
    // }}}
    // {{{ _getKey
    /**
     * get dao primary key
     *
     * @access  private
     * @return  mixed   the instance key
     */
    private function _getKey()
    {
        $dao_name       = sprintf('%s::DAO_NAME', get_class($this));
        $dao_name       = constant($dao_name);
        $dao            = $this->_session->getDao($dao_name);
        $primary_key    = $dao->_primary_key;

        if (!is_array($primary_key)) {
            if (array_key_exists($primary_key, $this->__accessor)) {
                $key            = $this->__accessor[$primary_key];
                $instance_key   = self::_generateInstanceKey($key);
                return $instance_key;
            } else {
                throw new Gree_Service_Shop_Exception();
            }
        }

        $keys = array();
        foreach ($primary_key as $instance_key_name) {
            if (array_key_exists($instance_key_name, $this->__accessor)) {
                $keys[$instance_key_name] = $this[$instance_key_name];
            } else {
                throw new Gree_Service_Shop_Exception();
            }
        }

        return self::_generateInstanceKey($keys);
    }
    // }}}
}
