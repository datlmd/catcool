<?php
require_once GREE_SERVICE_SHOP_CLASS_ROOT . '/Gree/GenericDao/Apc.php';

/**
 * Class Gree_GenericDao_Gacha_Fever_RareRateDao
 */
class Gree_GenericDao_Gacha_Fever_RareRateDao extends Gree_GenericDao_Apc
{

    /** @var �ơ��֥�̾ */
    public $_table_name = 'gacha_fever_rare_rate';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣 */
    public $_primary_key = 'id';

    /** @var �����������̾ */
    public $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    public $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    public $_master_dsn = 'gree://master/avatar_gacha_daily';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    public $_slave_dsn = 'gree://slave/avatar_gacha_daily';

    /** @var �����ȥ��󥯥���� */
    public $_auto_increment = true;

    /** @var �ե������̾ */
    public $_field_names = [
        'id',
        'start_date',
        'gacha_rank',
        'normal_weight',
        'rare_fire_weight',
        'rare_storm_weight',
        'face_weight',
        'mtime',
        'ctime',
    ];

    /**
     * @var �����������
     */
    public $_queries = [
        // {{{ ������
        'create_table' => [
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                `id` INT NOT NULL AUTO_INCREMENT,
                `start_date` DATETIME NOT NULL,
                `gacha_rank` INT NOT NULL,
                `normal_weight` INT NOT NULL,
                `rare_fire_weight` INT NOT NULL,
                `rare_storm_weight` INT NOT NULL,
                `face_weight` INT NOT NULL,
                `mtime` DATETIME NOT NULL default CURRENT_TIMESTAMP on UPDATE CURRENT_TIMESTAMP,
                `ctime` DATETIME NOT NULL default CURRENT_TIMESTAMP,
                PRIMARY KEY  (`id`),
                UNIQUE KEY `rank_and_start_date` (`gacha_rank`,`start_date`)
                ) ENGINE=InnoDB DEFAULT CHARSET=ujis
            ",
        ],

        'drop_table' => [
            'sql' => "DROP TABLE IF EXISTS __TABLE_NAME__",
        ],
        'insert'     => [
            'sql' => "INSERT INTO __TABLE_NAME__ (start_date, gacha_rank, normal_weight, rare_fire_weight, rare_storm_weight, face_weight) values (:start_date, :gacha_rank, :normal_weight, :rare_fire_weight, :rare_storm_weight, :face_weight)",
        ],
        'update_rare_rate_by_id' => [
            'sql' => 'UPDATE __TABLE_NAME__
                SET
                  start_date = :start_date,
                  gacha_rank = :gacha_rank,
                  normal_weight = :normal_weight,
                  rare_fire_weight = :rare_fire_weight,
                  rare_storm_weight = :rare_storm_weight,
                  face_weight = :face_weight
                WHERE id = :id
            ',
        ],


        'select_all_rare_rate_now' => [
            'sql' => '
                SELECT * from `__TABLE_NAME__` as t1
                WHERE id = (
                    SELECT id
                    FROM `__TABLE_NAME__` AS t2
                    WHERE t1.gacha_rank = t2.gacha_rank
                    AND start_date < :now_date
                    ORDER BY t2.start_date DESC
                    LIMIT 1)
                ',
        ],

        'find_rare_rate_by_gacha_rank_and_now_date' => [
            'sql' => '
                    SELECT
                        *
                    FROM
                        `__TABLE_NAME__`
                    WHERE
                        gacha_rank = :gacha_rank
                    AND start_date = (
                            SELECT
                                MAX(start_date)
                            FROM
                                `__TABLE_NAME__`
                            WHERE
                                start_date < :now_date
                            AND gacha_rank = :gacha_rank
                        )',
        ],

        'get_all_rate_rate' => [
            'sql' => 'select * from __TABLE_NAME__'
        ],

    ];
}
