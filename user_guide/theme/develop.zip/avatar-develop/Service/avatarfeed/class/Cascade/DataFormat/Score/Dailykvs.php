<?php

class Gree_Service_AvatarFeed_Cascade_DataFormat_Score_Dailykvs
    extends Cascade_DB_KVS_DataFormat
{
    protected $dsn           = 'gree(flare)://node/avatar_score_daily';
    protected $driver_type   = self::DRIVER_FLARE;
    protected $namespace     = 'avatar_score_daily';
    protected $compressed    = false; // use increment
    protected $expiration    = 3600; // 1day
}