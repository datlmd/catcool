<?php

/**
 * Class Gree_Service_AvatarFeed_Processor_Support_Entry_Create
 */
class Gree_Service_AvatarFeed_Processor_Support_Entry_Create
    extends Gree_Service_AvatarFeed_Processor_Base
{
    var $mod_appfeed;

    /**
     * @return array|void
     *
     * return array has is_success and etnry_id
     *
     * flow is
     *     - check parameter and followed user number => _getCreateParams()
     *     - create Entry
     *     - (add Destination)
     *       if $is_create_success && $is_require_additional_destination
     */
    protected function invoke()
    {
        // ���ݡ��ȥġ��뤫���authǧ�ڤ��̤�ʤ����ᥳ����user_id�򥻥åȤ��Ƶ�������
        // �����쥮��顼���Τ���ž��/�����Ѥ��ʤ�����
        $this->setUserIDtoCtfy(GREE_SERVICE_SHOP_AVATAR_OFFICIAL_USER_ID);

        $is_create_success = false;
        $entry_id          = null;

        list($is_require_additional_destination, $create_params) = $this->_getCreateParams($this->input_values['entry_category']);

        if ($create_params == false) {
            return array(
                $is_create_success,
                $entry_id
            );
        }
        try {
            $this->mod_appfeed = self::getModule('AppFeed');
            list($is_create_success, $entry_id) = $this->mod_appfeed->createEntry($create_params);
        } catch (Exception $e) {
            $msg     = 'failed supoort create feed entry.';
            $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_SUPPORT_ENTRY_CREATE;
            $context = $this->input_values;

            new Gree_Service_AvatarFeed_Logger($msg, $code, $context);

            return array(
                $is_create_success,
                $entry_id
            );
        }
        if ($is_create_success && $is_require_additional_destination) {
            try {
                $async_params = array(
                    'entry_id'  => $entry_id,
                    'sender_id' => GREE_SERVICE_SHOP_AVATAR_OFFICIAL_USER_ID,
                );
                Gree_Async::add('shop::avatarfeed', 'addDestination', null, $async_params);
                
            } catch (Exception $e) {
                $msg     = 'failed add destination.';
                $code    = Gree_Service_AvatarFeed_Logger::ERROR_PROCESSOR_ENTRY_CREATE;
                $context = $this->input_values;

                new Gree_Service_AvatarFeed_Logger($msg, $code, $context);
            }
        }
        return array(
            $is_create_success,
            $entry_id
        );
    }

    /**
     * @param $category
     * @return array
     *
     * return array has is_require_additional_destination, create params
     *
     * $create_params = array(
     *     'content'      => array(
     *          'sender_id'  => $this->_certified_user->my['user_id'],
     *          'entry_type' => 'mood',
     *          'text'       => $text,
     *          'attr'       => array(
     *              'entry_category' => $category,
     *          ),
     *     ),
     *     'destinations' => $destinations,
     * );
     *
     * flow is
     *     - check input value
     *     - check destination
     *     - create input params
     *     - add params of category-specific
     *
     * category-specific(type) is
     *     - change(activity): avatar key
     *     - avapri(activity): avatar key
     */
    public function _getCreateParams($category)
    {
        $text = '';
        if (isset($this->input_values['text'])) {
            $text = $this->input_values['text'];
        }

        $create_params = array(
            'content'      => array(
                'sender_id'  => GREE_SERVICE_SHOP_AVATAR_OFFICIAL_USER_ID,
                'entry_type' => 'mood',
                'text'       => $text,
                'attr'       => array(
                    'entry_category' => $category,
                ),
            ),
            'destinations' => array(
                array(
                    'type'  => 'feed_key',
                    'value' => GREE_SERVICE_AVATARFEED_APP_ID . ':' . 'user' . ':' . GREE_SERVICE_SHOP_AVATAR_OFFICIAL_USER_ID
                ),
            ),
        );

        switch ($category) {
            case 'change_mood':
                $interenc = mb_internal_encoding();
                $text = mb_convert_encoding($text, 'UTF-8', $interenc );
                $create_params['content']['text']       = $text;
                if (isset($this->input_values['entry_item_ids'])) {
                    $create_params['content']['attr']['item_ids'] = join(',', $this->input_values['entry_item_ids']);
                }
                $create_params['content']['entry_type'] = 'activity';
                if (isset($this->input_values['avatar_key'])) {
                    $create_params['content']['attr']['avatar_key'] = $this->input_values['avatar_key'];
                } else {
                    $create_params = false;
                }
                break;
            default:
        }

        $is_require_additional_destination = true;
        return array(
            $is_require_additional_destination,
            $create_params
        );
    }
}
