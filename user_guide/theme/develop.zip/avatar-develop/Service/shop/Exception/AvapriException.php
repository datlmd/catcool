<?php
/**
 *
 */
class Gree_Service_Shop_Exception_AvapriException
    extends Gree_Service_Shop_Exception_ServiceException
{
    public function getTpl(){
        return "avapri/error";
    }
}
