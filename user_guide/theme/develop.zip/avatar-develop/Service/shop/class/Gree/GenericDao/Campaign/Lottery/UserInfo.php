<?php
/**
 *  /home/gree/service/shop/class/GenericDao/CampaignLottery/UserInfo.php
 *
 *  @author     katsumi.zeniya
 *  @package    GREE
 */
class Gree_GenericDao_CampaignLottery_UserInfoDao extends Gree_GenericDao {

    /** @var �ơ��֥�̾ */
    var $_table_name = 'campaign_lottery_user_info';

    /** @var �祭����ʣ�祭����array�ϥå���ǻ��ꤹ�롣*/
    var $_primary_key = 'id';

    /** @var �����������̾ */
    var $_updated_at_column = 'mtime';

    /** @var ��Ͽ�������̾ */
    var $_created_at_column = 'ctime';

    /** @var �ޥ������ǡ����١�������³ʸ���� */
    var $_master_dsn = 'gree://master/avatar_login_campaign';

    /** @var ���졼�֥ǡ����١�������³ʸ���� */
    var $_slave_dsn = 'gree://slave/avatar_login_campaign';

    /** @var �����ȥ��󥯥����*/
    var $_auto_increment = true;

    /** @var �ե������̾ */
    var $_field_names = array(
        'id',
        'user_id',
        'week_num',
        'day_num',
        'result',
        'mtime',
        'ctime'
    );

    /** @var ������ */
    var $_queries = array(
        // {{{ �������������������
        'find_by_weeknum' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND week_num=:week_num',
        ),
        'find_by_day_info' => array(
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id AND week_num=:week_num AND day_num=:day_num',
        ),
        'find_by_user_id' => array(     // support tool
            'sql' => 'SELECT * FROM __TABLE_NAME__ WHERE user_id=:user_id',
        ),
        'insert' => array(
            'sql' => 'INSERT IGNORE INTO __TABLE_NAME__ (user_id, week_num, day_num, ctime) VALUES(:user_id, :week_num, :day_num, NOW())',
        ),
        'update' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET day_num=:day_num WHERE user_id=:user_id AND week_num=:week_num',
        ),
        'update_by_batch' => array(
            'sql' => 'UPDATE __TABLE_NAME__ SET result=:result WHERE user_id=:user_id AND week_num=:week_num',
        ),
        // }}}

        // {{{ �ơ��֥�����
        'create_table' => array(
            'sql' => "
                CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
                    `id`            int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`       int(11) unsigned NOT NULL default '1',
                    `week_num`      int(11) unsigned NOT NULL default '1',
                    `day_num`       int(11) unsigned NOT NULL default '0',
                    `result`        int(11) unsigned NOT NULL default '0',
                    `mtime`         timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
                    `ctime`         datetime NOT NULL default '0000-00-00 00\:00\:00',
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `user_id` (`user_id`,`week_num`)
                ) ENGINE=INNODB DEFAULT CHARSET=ujis
            ",
        ),
        'show_table' => array(      // for batch
            'sql' => 'SHOW TABLES LIKE "__TABLE_NAME__"',
        ),
    );

    // {{{ _initFarmSelector
    // �ե����ॻ�쥯���ν����
    //  @access private
    function _initFarmSelector()
    {
        $this->_farm_selector = new Gree_GenericDao_CampaignLottery_UserSelector();
    }
    // }}}
}

/**
 * Gree_GenericDao_CampaignLottery_UserSelector
 *
 * @author   katsumi.zeniya
 * @package  GREE
 */
class Gree_GenericDao_CampaignLottery_UserSelector extends Gree_GenericDao_FarmSelector
{
    // {{{ TABLE_DIVIDE_NUM
    /* �ơ��֥�ʬ��� */
    const TABLE_DIVIDE_NUM = 10;
    // }}}

    // {{{ _table_suffix_format
    /** var string �ơ��֥�ե������ֹ�ե����ޥå� */
    var $_table_suffix_format = "_%d_%d";   // campaign_id, shading no (user_id % TABLE_DIVIDE_NUM)
    // }}}

    // {{{ getTableName
    /**
     *  �ơ��֥�̾��������롣
     *
     *  @param      $dao        DAO���饹
     *  @param      $type       ���������ס�
     *  @param      $hint       �ơ��֥�����ҥ��
     *  @return     string      �ơ��֥�̾
     */
    function getTableName($dao, $type, $hint)
    {
        // �ơ��֥�̾�μ���
        $original_table_name = $dao->_getTableName();
        if (PEAR::isError($original_table_name)) {
            return $original_table_name;
        }
        if (empty($original_table_name) || empty($hint['campaign_id']) || empty($hint['user_id'])) {
            return PEAR::raiseError("original table name is empty. dao=[" . get_class($dao) . "];");
        }
        $farm = sprintf($this->_table_suffix_format, $hint['campaign_id'], ($hint['user_id'] % self::TABLE_DIVIDE_NUM));

        // �ơ��֥�̾�˥ե�������ɲ�
        $table_name = $original_table_name . $farm;
        return $table_name;
    }
    // }}}
}
