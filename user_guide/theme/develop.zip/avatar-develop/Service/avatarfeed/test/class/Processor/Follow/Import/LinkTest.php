<?php

/**
 * Class Gree_Service_Avatarfeed_Test_Processor_Follow_Import_LinkTest
 */
final class Gree_Service_Avatarfeed_Test_Processor_Follow_Import_LinkTest
    extends Gree_Service_AvatarFeed_Test_Base
{
    var $avatar_feed;
    var $module_follow;
    var $friend_manager;

    /**
     * initialize default feed(Unit test user 1)
     */
    public function setUp()
    {
        $this->avatar_feed = Gree_Service_AvatarFeed::getInstance();

        // initialize follow status
        $this->module_follow = Gree_Service_AvatarFeed_Module::singleton('Follow');
        $this->module_follow->setUserIDtoCtfy(UNIT_TEST_USER_ID_1);
        try {
            $this->module_follow->updateFollowCount(UNIT_TEST_USER_ID_1);
            list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
                UNIT_TEST_USER_ID_1,
                100,
                0
            );

            foreach ($following_user_ids as $following_user_id) {
                $this->module_follow->removeFollowingUser($following_user_id['content']['sender_id'], UNIT_TEST_USER_ID_1);
                $this->module_follow->removeFollowedUser(UNIT_TEST_USER_ID_1, $following_user_id['content']['sender_id']);
            }
        } catch (Exception $e) {
        }

        sleep(2);

        list($has_more, $empty_following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($empty_following_user_ids));

        // initialize Link list
        $service_sns          = getService('sns');
        $this->friend_manager = $service_sns->getServiceManager('friend');

        try {
            $this->friend_manager->deleteLinkOnly(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_2);
            $this->friend_manager->deleteLinkOnly(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_3);
            $this->friend_manager->deleteLinkOnly(UNIT_TEST_USER_ID_1, UNIT_TEST_USER_ID_4);
            $this->friend_manager->deleteLinkOnly(UNIT_TEST_USER_ID_1, UNIT_TEST_OFFICIAL_USER_ID_1);
        } catch (Exception $e) {
        }

        sleep(2);

        $friend_list = $this->friend_manager->getLinkHash(UNIT_TEST_USER_ID_1, 0, 10);

        $this->assertEquals(0, count($friend_list));
        sleep(2);
    }

    public function test_success_import_link()
    {
        $link_users = array(
            UNIT_TEST_USER_ID_2,
            UNIT_TEST_USER_ID_3,
            UNIT_TEST_USER_ID_4,
            UNIT_TEST_OFFICIAL_USER_ID_1
        );

        foreach ($link_users as $user_id) {
            $this->friend_manager->saveLinkOnly(UNIT_TEST_USER_ID_1, $user_id);
        }

        sleep(2);

        $friend_list = $this->friend_manager->getLinkHash(UNIT_TEST_USER_ID_1, 0, 10);

        $this->assertEquals(4, count($friend_list));

        $import_params = array(
            'user_id' => UNIT_TEST_USER_ID_1
        );
        $import_result = $this->avatar_feed->process('follow_import_link', $import_params);

        $this->assertTrue($import_result);

        sleep(2);

        list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(count($link_users) - 1, count($following_user_ids));
    }

    public function test_failed_import_link()
    {
        $import_params = array(
            'user_id' => UNIT_TEST_USER_ID_1
        );
        $import_result = $this->avatar_feed->process('follow_import_link', $import_params);

        $this->assertFalse($import_result);

        sleep(2);

        list($has_more, $following_user_ids) = $this->module_follow->getFollowingListOrderInTime(
            UNIT_TEST_USER_ID_1,
            100,
            0
        );

        $this->assertEquals(0, count($following_user_ids));
    }
}